# Yocto環境構築マニュアル

## 前提条件

- [動作マニュアル](README.md)を読み終わっていること
- [動作マニュアル](README.md)の前提条件を満たしていること
- ホームディレクトリに`1_Linux_SW-PKG.zip`が配置できていること
    - MD5ハッシュ値が`12d1574567d44802d99d2a2101a15962`であること
- ホームディレクトリに`2_Graphics.zip`が配置できていること
    - MD5ハッシュ値が`75ac5e73324b1930432ce83f0250aa87`であること
- ホームディレクトリに`3_Codec.zip`が配置できていること
    - MD5ハッシュ値が`170ef4e09e23b0e945956abd78a3459b`であること
- ホームディレクトリに`4_DRP-AI_Tools.zip`が配置できていること
    - MD5ハッシュ値が`2ceb62e05d429cbd9bb62ee4ed1ca1ef`であること

## 環境変数の設定

以降ではYocto環境を構築するディレクトリを`/yocto_rzv2x_ver1_workdir`とする。  
以下のコマンドを実行し、Yocto環境を構築するディレクトリを指定する。

```shell
export YOCTO_DIR=/yocto_rzv2x_ver1_workdir
```

## 圧縮ファイルの展開

圧縮ファイルを展開を行う。  
ここではWindowsではなくYocto環境を構築する対象のコンピュータ上で以下のコマンドを実行する。

```shell
sudo mkdir -p ${YOCTO_DIR:?}

cd ${YOCTO_DIR:?}

cp \
  ${HOME}/1_Linux_SW-PKG.zip \
  ${HOME}/2_Graphics.zip \
  ${HOME}/3_Codec.zip \
  ${HOME}/4_DRP-AI_Tools.zip \
  .
unzip -Ocp932 1_Linux_SW-PKG.zip
unzip -Ocp932 2_Graphics.zip
unzip -Ocp932 3_Codec.zip
unzip -Ocp932 4_DRP-AI_Tools.zip
```

次に、`ECSD-IMB-23-0113-01_RZV2H_GettingStarted_ForVersion1.0-rc1.pdf`の`1-2. BUILD INSTRUCTIONS`を行う。

```shell
tar xzvf 1_Linux_SW-PKG/1_Linux/meta-renesas-v2h_a16a818c.tar.gz

unzip -Ocp932 2_Graphics/RTK0EF0045Z13001ZJ-v1.1.0a_JP.zip
tar xzvf RTK0EF0045Z13001ZJ-v1.1.0a_JP/meta-rz-features_graphics_v1.1.0.tar.gz

unzip -Ocp932 3_Codec/RTK0EF0045Z92001ZJ-v3.0.0_JP.zip
tar xzvf  RTK0EF0045Z92001ZJ-v3.0.0_JP/meta-rz-features_v3.0.0.tar.gz

tar xzvf 1_Linux_SW-PKG/2_DRP-AI/rzv2h_drpai-driver_ver1.00.tar.gz
mv rzv2h_drpai-driver_ver1.00/meta-rz-features/meta-rz-drpai/ ./meta-rz-features/

unzip -Ocp932 1_Linux_SW-PKG/5_OpenCVA/r11an0836ej0100-rzv2h-opencv-accelerator-sp.zip
unzip -Ocp932 r11an0836ej0100-rzv2h-opencv-accelerator-sp/OpenCV_sample.zip

tar xzvf r11an0836ej0100-rzv2h-opencv-accelerator-sp/rzv2h_OpenCVA_ver1.00.tar.gz
mv rzv2h_OpenCVA_ver1.00/meta-rz-features/meta-rz-opencva/ ./meta-rz-features/
```

## Yocto環境構築

### リポジトリの準備

`ECSD-IMB-23-0113-01_RZV2H_GettingStarted_ForVersion1.0-rc1.pdf`の`(5) Download all Yocto related public source to your workspace to prepare the build environment as below`を行う。  
Yocto環境を構築する対象のコンピュータ上で以下のコマンドを実行する。

```shell
cd ${YOCTO_DIR:?}

git clone https://git.yoctoproject.org/git/poky -b dunfell
cd poky
git checkout dunfell-23.0.21
cd ..
git clone https://github.com/openembedded/meta-openembedded -b dunfell
cd meta-openembedded
git checkout 7952135f650b4a754e2255f5aa03973a32344123
cd ..
git clone https://git.yoctoproject.org/git/meta-gplv2 -b dunfell
cd meta-gplv2 
git checkout 60b251c25ba87e946a0ca4cdc8d17b1cb09292ac
cd ..
git clone https://git.yoctoproject.org/git/meta-virtualization -b dunfell
cd meta-virtualization
git checkout a63a54df3170fed387f810f23cdc2f483ad587df
cd ..
```

### レイヤーの追加

`ECSD-IMB-23-0113-01_RZV2H_GettingStarted_ForVersion1.0-rc1.pdf`の`(6) Initialize`以降の手順を行う。  
Yocto環境を構築する対象のコンピュータ上で以下のコマンドを実行する。

```shell
cd ${YOCTO_DIR:?}
TEMPLATECONF=${PWD}/meta-renesas/meta-rzv2/docs/template/conf/ \
  source poky/oe-init-build-env build

bitbake-layers add-layer ../meta-rz-features/meta-rz-graphics
bitbake-layers add-layer ../meta-rz-features/meta-rz-opencva
bitbake-layers add-layer ../meta-openembedded/meta-filesystems
bitbake-layers add-layer ../meta-openembedded/meta-networking
bitbake-layers add-layer ../meta-virtualization
bitbake-layers add-layer ../meta-rz-features/meta-rz-drpai
```

`ECSD-IMB-23-0113-01_RZV2H_GettingStarted_ForVersion1.0-rc1.pdf`の`(10) Build the target file system image using bitbake`を行う。  
Yocto環境を構築する対象のコンピュータ上で以下のコマンドを実行する。

```shell
cd ${YOCTO_DIR:?}
TEMPLATECONF=${PWD}/meta-renesas/meta-rzv2/docs/template/conf/ \
  source poky/oe-init-build-env build

MACHINE=rzv2h-evk-alpha bitbake core-image-weston
```

### SDKの準備

`ECSD-IMB-23-0113-01_RZV2H_GettingStarted_ForVersion1.0-rc1.pdf`の`4-2. BUILD AND INSTALL SDK ENVIRONMENT`を行う。  
Yocto環境を構築する対象のコンピュータ上で以下のコマンドを実行する。

```shell
cd ${YOCTO_DIR:?}

TEMPLATECONF=${PWD}/meta-renesas/meta-rzv2/docs/template/conf/ \
  source poky/oe-init-build-env build

MACHINE=rzv2h-evk-alpha bitbake core-image-weston -c populate_sdk
```

Yocto環境を構築する対象のコンピュータ上で以下のコマンドを実行し、SDKをインストールする。

```shell
cd ${YOCTO_DIR:?}

mkdir -p weston_sdk
sh ./build/tmp/deploy/sdk/poky-glibc-x86_64-core-image-weston-aarch64-rzv2h-evk-alpha-toolchain-3.1.21.sh -y -d ${YOCTO_DIR:?}/weston_sdk
```

### ビルド生成物の退避

ビルド生成物一式を含む`images`ディレクトリを`${YOCTO_DIR:?}`以下に退避する。

```shell
cd ${YOCTO_DIR:?}

cp -r build/tmp/deploy/images .
```
