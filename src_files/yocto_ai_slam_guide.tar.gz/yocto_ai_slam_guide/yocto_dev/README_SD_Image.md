# SDカード作成マニュアル

## 前提条件

- [BitBakeマニュアル](README_BitBake.md)を読み終わっていること
- [BitBakeマニュアル](README_BitBake.md)の前提条件を満たしていること
- [BitBakeマニュアル](README_BitBake.md)の作業が完了していること
    - Linuxイメージのビルドが完了していること
- 16GB以上の容量を持つSDカードが準備できていること
    - 中身が空であること、または中のデータをすべて削除しても問題ないこと
- Yocto環境を構築したコンピュータからSDカードへファイル書き込みが可能であること
- YOLO-Planar-SLAMのリポジトリがYocto環境を構築したコンピュータ上に展開されていること
    - gitを使用して本案件のGitLabサーバーからクローンする場合は[リポジトリのクローンマニュアル](../README_Clone.md)の手順を参照すること
- stella_vslamのリポジトリがYocto環境を構築したコンピュータ上に展開されていること
    - gitを使用して本案件のGitLabサーバーからクローンする場合は[リポジトリのクローンマニュアル](../README_Clone.md)の手順を参照すること
- stella_vslam_examplesのリポジトリがYocto環境を構築したコンピュータ上に展開されていること
    - gitを使用して本案件のGitLabサーバーからクローンする場合は[リポジトリのクローンマニュアル](../README_Clone.md)の手順を参照すること
- DRP-AI TranslatorのYOLOX-SのDRP-AIのオブジェクトファイル一式（`YOLOX_S_dense_640x640_RGB_10271351`）がYocto環境を構築したコンピュータ上に展開されていること
- DRP-AI TVMのファイル一式（`v210_yolox_tmp_240119`）がYocto環境を構築したコンピュータ上に展開されていること
- DRP-AI TVMのYOLOX-Sのファイル一式（`app_yolox-S_bgr640x640/yolox_cam`）がYocto環境を構築したコンピュータ上に展開されていること
- V1_01_easyデータセットを使用する場合には`/opt/dataset/`に`V1_01_easy.zip`が配置されていること
- TUMデータセットを使用する場合には`/opt/dataset/`に以下のファイルが[動作マニュアル](README.md)の`1 データのダウンロード`の手順に従って配置されていること
    - `rgbd_dataset_freiburg3_walking_xyz.tgz`
    - `rgbd_dataset_freiburg3_walking_halfsphere.tgz`
    - `rgbd_dataset_freiburg1_desk.tgz`
    - `GRAY_rgbd_dataset_freiburg3_walking_xyz.tar.gz`

## 注意事項

本マニュアルではSDカードのフォーマットを行う。  
**使用したSDカードの中のデータはすべて削除されるため、注意すること。**  
必要があれば事前にデータのバックアップを取ること。

## SDカードのフォーマット

SDカードをYocto環境を構築したコンピュータへ接続する。

[RZ/V2MA Linux Package Start-Up Guide (Rev1.1.0)](https://www.renesas.com/jp/ja/document/qsg/rzv2ma-linux-start-guide-rev110?r=1764081)の`3.1.2 SD card setting for booting Linux`を参考に、SDカードをフォーマットする。

## イメージと関連ファイルの書き込み

以降ではSDカードのデバイスパスを`/dev/sdx`と仮定する。  
Yocto環境を構築したコンピュータから認識されるSDカードのデバイスパスに合わせて変更すること。

以下のコマンドを実行し、SDカードの第一パーティションと第二パーティションをマウントする。

```shell
DST_PATH=/dev/sdx
sudo mkdir -p /media/sd/BOOT
sudo mkdir -p /media/sd/rootfs
sudo mount --read-write --types vfat ${DST_PATH}1 /media/sd/BOOT
sudo mount --read-write --types ext4 ${DST_PATH}2 /media/sd/rootfs
```

### 環境変数の設定

以降ではYocto環境を構築したディレクトリを`/yocto_rzv2x_ver1_workdir`とする。  
以下のコマンドを実行し、Yocto環境を構築するディレクトリを指定する。

```shell
export YOCTO_DIR=/yocto_rzv2x_ver1_workdir
```

### Linuxイメージ

以下のコマンドを実行し、第一パーティションへファイルを書き込む。

```shell
sudo cp ${YOCTO_DIR:?}/images/rzv2h-evk-alpha/Image-rzv2h-evk-alpha.bin       /media/sd/BOOT/
sudo cp ${YOCTO_DIR:?}/images/rzv2h-evk-alpha/Image-r9a09g057h4-evk-alpha.dtb /media/sd/BOOT/
```

以下のコマンドを実行し、第二パーティションへrootfsを書き込む。

```shell
cd /media/sd/rootfs
sudo tar jxvf ${YOCTO_DIR:?}/images/rzv2h-evk-alpha/core-image-weston-rzv2h-evk-alpha.tar.bz2
```

### OpenCVA

以下のコマンドを実行し、第一パーティションへOpenCVAのバイナリファイルを書き込む。

```shell
sudo cp ${YOCTO_DIR:?}/r11an0836ej0100-rzv2h-opencv-accelerator-sp/OpenCV_Bin.bin /media/sd/BOOT/
```

### TVM Runtime

以下のコマンドを実行し、`libtvm_runtime.so`を書き込む。

`app_yolox-S_bgr640x640_20240325.tar.gz`に含まれている`libtvm_runtime`を使用する場合

```shell
sudo cp \
  $HOME/app_yolox-S_bgr640x640/libtvm_runtime.so \
  /media/sd/rootfs/usr/lib64/
```

[DRP-AI TVMマニュアル（GitHub版）](README_DRP-AI_TVM.github.md)に記載の手順でURLからダウンロードし、コンパイルして生成した`libtvm_runtime`を使用する場合

```shell
sudo cp \
  ${YOCTO_DIR:?}/drp-ai_tvm/obj/build_runtime/V2H/libtvm_runtime.so \
  /media/sd/rootfs/usr/lib64/
```

### データセット

V1_01_easyデータセットを使用する場合には、以下のコマンドを実行し、V1_01_easyデータセットを書き込む。

```shell
sudo mkdir -p /media/sd/rootfs/opt/dataset/V1_01_easy
sudo unzip /opt/dataset/V1_01_easy.zip -d /media/sd/rootfs/opt/dataset/V1_01_easy/
sudo rm -r /media/sd/rootfs/opt/dataset/V1_01_easy/mav0/pointcloud0
```

TUMデータセットを使用する場合には、以下のコマンドを実行し、TUMのデータセットを書き込む。

```shell
sudo mkdir -p /media/sd/rootfs/opt/dataset/tum
cd /opt/dataset/tum/
sudo tar xzvf rgbd_dataset_freiburg3_walking_xyz.tgz         --directory=/media/sd/rootfs/opt/dataset/tum/
sudo tar xzvf rgbd_dataset_freiburg3_walking_halfsphere.tgz  --directory=/media/sd/rootfs/opt/dataset/tum/
sudo tar xzvf rgbd_dataset_freiburg1_desk.tgz                --directory=/media/sd/rootfs/opt/dataset/tum/
sudo tar xzvf GRAY_rgbd_dataset_freiburg3_walking_xyz.tar.gz --directory=/media/sd/rootfs/opt/dataset/tum/

sudo cp /opt/dataset/tum/rgbd_dataset_freiburg3_walking_xyz/associate.txt \
  /media/sd/rootfs/opt/dataset/tum/rgbd_dataset_freiburg3_walking_xyz/
sudo cp /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/associate.txt \
  /media/sd/rootfs/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/
sudo cp /opt/dataset/tum/rgbd_dataset_freiburg1_desk/associate.txt \
  /media/sd/rootfs/opt/dataset/tum/rgbd_dataset_freiburg1_desk/
sudo cp /media/sd/rootfs/opt/dataset/tum/GRAY_rgbd_dataset_freiburg3_walking_xyz/gray.txt \
  /media/sd/rootfs/opt/dataset/tum/GRAY_rgbd_dataset_freiburg3_walking_xyz/rgb.txt
```

### Yolo-Planar-SLAM

以下のコマンドを実行し、OpenCVA組み込み版のYolo-Planar-SLAMで使用するVocabularyファイルを書き込む。

```shell
sudo mkdir -p /media/sd/rootfs/home/root/yolo-planar-slam/Vocabulary/
sudo tar xzvf $HOME/yolo-planar-slam/Vocabulary/ORBvoc.txt.tar.gz -C /media/sd/rootfs/home/root/yolo-planar-slam/Vocabulary/
```

以下のコマンドを実行し、OpenCVA組み込み版のYolo-Planar-SLAMの単眼モードで使用する設定ファイルを書き込む。

```shell
sudo mkdir -p /media/sd/rootfs/home/root/yolo-planar-slam/Examples/Monocular/
sudo cp $HOME/yolo-planar-slam/Examples/Monocular/*.yaml \
  /media/sd/rootfs/home/root/yolo-planar-slam/Examples/Monocular/
sudo cp -r $HOME/yolo-planar-slam/Examples/Monocular/EuRoC_TimeStamps \
  /media/sd/rootfs/home/root/yolo-planar-slam/Examples/Monocular/
```

以下のコマンドを実行し、OpenCVA組み込み版のYolo-Planar-SLAMのRGB-Dモードで使用する設定ファイルを書き込む。

```shell
sudo mkdir -p /media/sd/rootfs/home/root/yolo-planar-slam/Examples/RGB-D/
sudo cp $HOME/yolo-planar-slam/Examples/RGB-D/*.yaml \
  /media/sd/rootfs/home/root/yolo-planar-slam/Examples/RGB-D/
```

以下のコマンドを実行し、OpenCVA組み込み版のYolo-Planar-SLAMで使用するコンフィギュレーションコードを書き込む。

```shell
sudo cp -r $HOME/yolo-planar-slam/configuration_code \
  /media/sd/rootfs/home/root/yolo-planar-slam/
```

以下のコマンドを実行し、OpenCVA組み込み版のYolo-Planar-SLAMで使用するSocket Viewerの実行ファイルを書き込む。

```shell
sudo mkdir -p /media/sd/rootfs/home/root/yolo-planar-slam/viewer
sudo cp -r \
  $HOME/yolo-planar-slam/viewer/app.js \
  $HOME/yolo-planar-slam/viewer/package.json \
  $HOME/yolo-planar-slam/viewer/public \
  $HOME/yolo-planar-slam/viewer/views \
  /media/sd/rootfs/home/root/yolo-planar-slam/viewer/
```

以下のコマンドを実行し、OpenCVA組み込み版のYolo-Planar-SLAMで使用するDRP-AI TranslatorのYOLOX-SのDRP-AIオブジェクトファイルを書き込む。

```shell
sudo cp -r \
  $HOME/YOLOX_S_dense_640x640_RGB_10271351 \
  /media/sd/rootfs/home/root/yolo-planar-slam/
```

以下のコマンドを実行し、OpenCVA組み込み版のYolo-Planar-SLAMで使用するDRP-AI TVMのYOLOX-Sのファイル一式を書き込む。

`app_yolox-S_bgr640x640_20240325.tar.gz`に含まれている`yolox_com`と`libtvm_runtime`を使用する場合

```shell
sudo cp -r \
  $HOME/app_yolox-S_bgr640x640/yolox_cam \
  /media/sd/rootfs/home/root/yolo-planar-slam/
```

[DRP-AI TVMマニュアル（GitHub版）](README_DRP-AI_TVM.github.md)に記載の手順でURLからダウンロードし、コンパイルして生成した`yolox_com`と`libtvm_runtime`を使用する場合

```shell
sudo cp -r \
  $${YOCTO_DIR:?}/drp-ai_tvm/tutorials/yolox_cam \
  /media/sd/rootfs/home/root/yolo-planar-slam/
```

### stella_vslam

以下のコマンドを実行し、stella_vslamで使用するVocabularyファイルを書き込む。

```shell
sudo mkdir -p /media/sd/rootfs/home/root/stella_vslam_examples
sudo cp -r \
  $HOME/stella_vslam_examples/orb_vocab.fbow \
  /media/sd/rootfs/home/root/stella_vslam_examples/
```

以下のコマンドを実行し、stella_vslamで使用する設定ファイルを書き込む。

```shell
sudo mkdir -p /media/sd/rootfs/home/root/stella_vslam/example
sudo cp -r \
  $HOME/stella_vslam/example/* \
  /media/sd/rootfs/home/root/stella_vslam/example/
```

以下のコマンドを実行し、stella_vslamで使用するコンフィギュレーションコードを書き込む。

```shell
sudo cp -r $HOME/stella_vslam_examples/configuration_code \
  /media/sd/rootfs/home/root/stella_vslam_examples/
```

以下のコマンドを実行し、stella_vslamで使用するDRP-AI TVMのYOLOX-Sのファイル一式を書き込む。

`app_yolox-S_bgr640x640_20240325.tar.gz`に含まれている`yolox_com`と`libtvm_runtime`を使用する場合

```shell
sudo cp -r \
  $HOME/app_yolox-S_bgr640x640/yolox_cam \
  /media/sd/rootfs/home/root/stella_vslam_examples/
```

[DRP-AI TVMマニュアル（GitHub版）](README_DRP-AI_TVM.github.md)に記載の手順でURLからダウンロードし、コンパイルして生成した`yolox_com`と`libtvm_runtime`を使用する場合

```shell
sudo cp -r \
  $${YOCTO_DIR:?}/drp-ai_tvm/tutorials/yolox_cam \
  /media/sd/rootfs/home/root/stella_vslam_examples/
```

以下のコマンドを実行し、stella_vslamの実行結果ファイルを格納するディレクトリを作成する。

```shell
sudo mkdir -p /media/sd/rootfs/home/root/stella_vslam_examples/eval
```

Socket Viewerを使用する場合には、以下のコマンドを実行し、`socket_viewer`を書き込む。

```shell
cd ~
git clone https://github.com/stella-cv/socket_viewer
cd socket_viewer
git checkout e1e14ee

sudo mkdir -p /media/sd/rootfs/home/root/socket_viewer
sudo cp -r \
  $HOME/socket_viewer/* \
  /media/sd/rootfs/home/root/socket_viewer/
```

### 書き込みの完了

以下のコマンドを実行し、SDカードへの書き込みを完了する。

```shell
sync
```

以下のコマンドを実行し、SDカードをアンマウントする。

```shell
cd $HOME
sudo umount /media/sd/BOOT
sudo umount /media/sd/rootfs
```
