# Boot loader更新マニュアル

## 前提条件

- Windows10マシンを用意できていること
    - Tera Termがインストール済みであること
- [Yocto環境構築マニュアル](README_Yocto_Env.md)を読み終わっていること
- [Yocto環境構築マニュアル](README_Yocto_Env.md)の前提条件を満たしていること
- [Yocto環境構築マニュアル](README_Yocto_Env.md)に記載されている作業が完了していること

## ファイルの確認

[Yocto環境構築マニュアル](README_Yocto_Env.md)で作成したビルド生成物である`/yocto_rzv2x_ver1_workdir/images/rzv2h-evk-alpha`ディレクトリを、Windows10マシンに配置する。

Windows10マシン上の`rzv2h-evk-alpha`の中のファイルのMD5ハッシュ値をPowerShell上で確認する。

```shell
> certutil -hashfile .\rzv2h-evk-alpha\bl2_bp_spi-rzv2h-evk-alpha.srec MD5
MD5 ハッシュ (対象 .\rzv2h-evk-alpha\bl2_bp_spi-rzv2h-evk-alpha.srec):
e18d48600908ea7dd177650f46d13a80
CertUtil: -hashfile コマンドは正常に完了しました。
> certutil -hashfile .\rzv2h-evk-alpha\fip-rzv2h-evk-alpha.srec MD5
MD5 ハッシュ (対象 .\rzv2h-evk-alpha\fip-rzv2h-evk-alpha.srec):
59a1d23775ecbb706d530b0f28fbb874
CertUtil: -hashfile コマンドは正常に完了しました。
> certutil -hashfile .\rzv2h-evk-alpha\Flash_Writer_SCIF_RZV2H_DEV_INTERNAL_MEMORY.mot MD5
MD5 ハッシュ (対象 .\rzv2h-evk-alpha\Flash_Writer_SCIF_RZV2H_DEV_INTERNAL_MEMORY.mot):
40fc8bf6e5379e0d2489a7d43ae321ca
CertUtil: -hashfile コマンドは正常に完了しました。
```

## SCIFダウンロードモードへの変更

`ECSD-IMB-23-0113-01_RZV2H_GettingStarted_ForVersion1.0-rc1.pdf`の記載に従って`SW1`を以下のように変更する。

- 1：ON
- 2：OFF
- 3：ON
- 4：OFF
- 5：ON
- 6：OFF
- 7：ON
- 8：OFF

## USB接続

V2xボードの2つのmicro USBポートと、Windows10マシンのUSBポートをUSBケーブルで接続する。  
Windows10マシンからTera Termを使用して、V2xボードとシリアル接続する。

## V2xボードの起動

USB Type-Cケーブルをコンセントに接続してから、V2xボード上段のSW4の電源スイッチをONにする。

Tera Termのコンソールに以下の内容が出力されることを確認する。

```shell
 SCIF Download mode
 (C) Renesas Electronics Corp.
-- Load Program to System RAM ---------------
please send !
```

## Flash Writerの書き込み

Tera Termの`ファイル`→`ファイル送信`から`Flash_Writer_SCIF_RZV2H_DEV_INTERNAL_MEMORY.mot`を送信する。

## Boot loaderの書き込み

V2xボード上で`XLS2`と入力し、Enterを入力する。

`Please Input Program Top Address`と表示された後に`H'8101E00`と入力する。  
`Please Input Qspi Save Address`と表示された後に`H'0000`と入力する。  
`please send ! `と表示された後に、Tera Termの`ファイル`→`ファイル送信`から`bl2_bp_spi-rzv2h-evk-alpha.srec`を送信する。

V2xボード上で`XLS2`と入力し、Enterを入力する。

`Please Input Program Top Address`と表示された後に`H'0000`と入力する。  
`Please Input Qspi Save Address`と表示された後に`H'60000`と入力する。  
`please send ! `と表示された後に、Tera Termの`ファイル`→`ファイル送信`から`fip-rzv2h-evk-alpha.srec`を送信する。

V2xボード上段のSW4の電源スイッチをOFFにしてから、USB Type-Cケーブルをコンセントから外す。

## DIPスイッチの設定

`ECSD-IMB-23-0113-01_RZV2H_GettingStarted_ForVersion1.0-rc1.pdf`の記載に従って`SW1-5`をONからOFFに変更する。

## u-bootの設定
  
USB Type-Cケーブルをコンセントに接続する。

`S/N number`が`"32110 001" – "32110 010"`に該当**しない**場合は、以下のコマンドを実行する。  
なお、`bootcmd`の`mmc dev 1;`より前の初期設定値はボードに個体差があるため、適宜確認して、設定するべき内容を確認する。  

```shell
setenv bootargs 'console=ttySC0,115200 earlycon root=/dev/mmcblk1p2 rootwait'
setenv bootcmd 'i2c dev 8; i2c mw 0x6a 0x22 0x0f; i2c mw 0x6a 0x24 0x00; i2c md 0x6a 0x00 0x30; i2c mw 0x12 0x8D 0x02; i2c md 0x12 0x2D 0x80; mmc dev 1; fatload mmc 1:1 ${ocaaddr} ${ocabin}; fatload mmc 1:1 0x48080000 Image-rzv2h-evk-alpha.bin; fatload mmc 1:1 0x48000000 ${imgdtb}; booti 0x48080000 - 0x48000000'
setenv ocaaddr '0xC0000000'
setenv ocabin 'OpenCV_Bin.bin'
setenv imgdtb 'Image-r9a09g057h4-evk-alpha.dtb'
saveenv
```

USB Type-Cケーブルをコンセントから外す。  
USB Type-Cケーブルをコンセントに接続してから、V2xボード上段のSW4の電源スイッチをONにする。
