# DRP-AI TVMインストールマニュアル

## 前提条件

- [BitBakeマニュアル](README_BitBake.md)を読み終わっていること
- [BitBakeマニュアル](README_BitBake.md)の前提条件を満たしていること
- [BitBakeマニュアル](README_BitBake.md)の作業が完了していること
- `yocto_ai_slam_guide`リポジトリが対象のコンピュータ上に展開されていること
    - gitを使用して本案件のGitLabサーバーからクローンする場合は[リポジトリのクローンマニュアル](../README_Clone.md)の手順を参照すること

## 環境変数の設定

以下のコマンドを実行し、環境変数の設定を行う。

```shell
export YOCTO_DIR=/yocto_rzv2x_ver1_workdir
```

## DRP-AI TVM向けの環境構築

`drp-tvm_dev-v210_add_yolox_240119/setup/SetupV2H.md`の記載に従って環境構築を行う。

以下のコマンドを実行し、`2.Install DRP-AI Translator`の手順を行う。

```shell
cp ${YOCTO_DIR:?}/4_DRP-AI_Tools/DRP-AI_Translator_i8-v1.00-Linux-x86_64-Install /tmp/
cd /opt
sudo chmod 777 /opt/
yes | /tmp/DRP-AI_Translator_i8-v1.00-Linux-x86_64-Install
rm /tmp/DRP-AI_Translator_i8-v1.00-Linux-x86_64-Install
```

以下のコマンドを実行し、`2. Install the minimal pre-requisites`の手順を行う。

```shell
python3 -m pip install --user --upgrade pip
python3 -m pip install --user pillow==8.2.0 scipy==1.5.4 psutil 
python3 -m pip install --user cython==0.29.32
python3 -m pip install --user decorator attrs
python3 -m pip install --user torchvision tqdm

wget https://github.com/microsoft/onnxruntime/releases/download/v1.16.1/onnxruntime-linux-x64-1.16.1.tgz \
    -O /tmp/onnxruntime.tar.gz
tar xzvf /tmp/onnxruntime.tar.gz -C /tmp/
sudo mv /tmp/onnxruntime-linux-x64-1.16.1/ /opt/
rm /tmp/onnxruntime.tar.gz
```

## V2xボード向けのDRP-AI TVMライブラリのインストール

以下のコマンドを実行し、V2xボード向けのDRP-AI TVMライブラリをSDKにインストールする。

```shell
export YOCTO_DIR=/yocto_rzv2x_ver1_workdir
export TVM_ROOT=${YOCTO_DIR:?}/v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119
export TVM_HOME=${TVM_ROOT:?}/tvm
export PYTHONPATH=${TVM_HOME:?}/python:${PYTHONPATH}
export SDK=${YOCTO_DIR:?}/weston_sdk
export TRANSLATOR=/opt/DRP-AI_Translator_i8/translator/
export QUANTIZER=/opt/DRP-AI_Translator_i8/drpAI_Quantizer/
export PRODUCT=V2H

cd ${TVM_ROOT:?}
bash setup/make_drp_env.sh

cd ~/yocto_ai_slam_guide
./scripts/drp-ai_tvm/install.sh
```
