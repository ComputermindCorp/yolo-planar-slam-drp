# BitBakeマニュアル

## 前提条件

- [Yocto環境構築マニュアル](README_Yocto_Env.md)を読み終わっていること
- [Yocto環境構築マニュアル](README_Yocto_Env.md)の前提条件を満たしていること
- [Yocto環境構築マニュアル](README_Yocto_Env.md)に記載されている作業が完了していること
- `meta-stella-vslam`リポジトリが対象のコンピュータ上に展開されていること
    - gitを使用して本案件のGitLabサーバーからクローンする場合は[リポジトリのクローンマニュアル](../README_Clone.md)の手順を参照すること

## 環境変数の設定

以降ではYocto環境を構築したディレクトリを`/yocto_rzv2x_ver1_workdir`とする。  
以下のコマンドを実行し、Yocto環境を構築するディレクトリを指定する。

```shell
export YOCTO_DIR=/yocto_rzv2x_ver1_workdir
```

## Yocto環境構築

### Yolo-Planar-SLAMとstella_vslamのレシピの追加

`${YOCTO_DIR:?}/`以下に`meta-stella-vslam`を配置する。

ビルド対象のレイヤーに`meta-stella-vslam`を追加する。  
Yocto環境を構築する対象のコンピュータ上で以下のコマンドを実行する。

```shell
cd ${YOCTO_DIR:?}
TEMPLATECONF=${PWD}/meta-renesas/meta-rzv2/docs/template/conf/ \
  source poky/oe-init-build-env build

bitbake-layers add-layer ../meta-stella-vslam
```

実行した後の`${YOCTO_DIR:?}/build/conf/bblayers.conf`は、例えば以下のようになる。

```plaintxt
BBLAYERS ?= " \
  ${TOPDIR}/../meta-gplv2 \
  ${TOPDIR}/../poky/meta \
  ${TOPDIR}/../poky/meta-poky \
  ${TOPDIR}/../poky/meta-yocto-bsp \
  ${TOPDIR}/../meta-renesas/meta-rz-common \
  ${TOPDIR}/../meta-renesas/meta-rzg2l \
  ${TOPDIR}/../meta-renesas/meta-rzv2 \
  ${TOPDIR}/../meta-openembedded/meta-oe \
  ${TOPDIR}/../meta-openembedded/meta-python \
  ${TOPDIR}/../meta-openembedded/meta-multimedia \
  /yocto_rzv2x_ver1_workdir/meta-rz-features/meta-rz-graphics \
  /yocto_rzv2x_ver1_workdir/meta-rz-features/meta-rz-opencva \
  /yocto_rzv2x_ver1_workdir/meta-openembedded/meta-filesystems \
  /yocto_rzv2x_ver1_workdir/meta-openembedded/meta-networking \
  /yocto_rzv2x_ver1_workdir/meta-virtualization \
  /yocto_rzv2x_ver1_workdir/meta-rz-features/meta-rz-drpai \
  /yocto_rzv2x_ver1_workdir/meta-stella-vslam \
  "
```

なお、suitesparse-cxsparseはLGPLである。  
そのため、`build/conf/local.conf`の末尾に以下の内容を追記する必要がある。

```plaintxt
WHITELIST_GPL-3.0 = " suitesparse-cxsparse suitesparse-config "
```

### Linuxイメージの作成

`ECSD-IMB-23-0113-01_RZV2H_GettingStarted_ForVersion1.0-rc1.pdf`の`(10) Build the target file system image using bitbake`を行う。  
Yocto環境を構築する対象のコンピュータ上で以下のコマンドを実行する。

```shell
cd ${YOCTO_DIR:?}
TEMPLATECONF=${PWD}/meta-renesas/meta-rzv2/docs/template/conf/ \
  source poky/oe-init-build-env build

MACHINE=rzv2h-evk-alpha bitbake core-image-weston
```

### SDKの準備

`ECSD-IMB-23-0113-01_RZV2H_GettingStarted_ForVersion1.0-rc1.pdf`の`4-2. BUILD AND INSTALL SDK ENVIRONMENT`を行う。  
Yocto環境を構築する対象のコンピュータ上で以下のコマンドを実行する。

```shell
cd ${YOCTO_DIR:?}

TEMPLATECONF=${PWD}/meta-renesas/meta-rzv2/docs/template/conf/ \
  source poky/oe-init-build-env build

MACHINE=rzv2h-evk-alpha bitbake core-image-weston -c populate_sdk
```

Yocto環境を構築する対象のコンピュータ上で以下のコマンドを実行し、SDKをインストールする。

```shell
cd ${YOCTO_DIR:?}

mkdir -p weston_sdk
sh ./build/tmp/deploy/sdk/poky-glibc-x86_64-core-image-weston-aarch64-rzv2h-evk-alpha-toolchain-3.1.21.sh -y -d ${YOCTO_DIR:?}/weston_sdk
```

### ビルド生成物の退避

ビルド生成物一式を含む`images`ディレクトリを`${YOCTO_DIR:?}`以下に退避する。

```shell
cd ${YOCTO_DIR:?}

cp -r build/tmp/deploy/images .
```

## meta-stella-vslamについて

### レシピ一覧

`meta-stella-vslam`に含まれているレシピは以下の通り。

- libflann_1.9.1.bb
- pcl_1.9.1.bb
- socket.io-client-cpp_1.6.0.bb
- ejs_2.5.7.bb
- express_4.16.2.bb
- socket.io_2.0.4.bb
- yaml-cpp_0.8.0.bb
- suitesparse-cxsparse_5.4.0.bb
- suitesparse-config_5.4.0.bb

### ライセンス設定について

BitBakeのレシピファイルには、対象のプログラムのライセンスが記述されている。  
今回作成したレシピファイルのライセンスの記述は`recipetool create`コマンドで自動で設定されている。  
`recipetool create`が自動で解釈できたケースについては`MIT`などの該当するライセンスが記述されるようになっている。

2024年3月時点の設定は以下の通り。

```shell
$ grep -rn 'LICENSE =' recipes-core/
recipes-core/socket.io-client-cpp/socket.io-client-cpp_1.6.0.bb:26:LICENSE = "Unknown & MIT"
recipes-core/socket.io/socket.io_2.0.4.bb:8:LICENSE = "MIT"
recipes-core/express/express_4.16.2.bb:20:LICENSE = "MIT & ISC & Unknown"
recipes-core/ejs/ejs_2.5.7.bb:20:LICENSE = "Apache-2.0 & MIT & Unknown & ISC"
recipes-core/yaml-cpp/yaml-cpp_0.8.0.bb:19:LICENSE = "MIT & Unknown"
recipes-core/suitesparse/suitesparse-cxsparse_5.4.0.bb:21:LICENSE = "Unknown & GPLv3"
recipes-core/suitesparse/suitesparse-config_5.4.0.bb:20:LICENSE = "Unknown & GPLv3"
recipes-core/libflann/libflann_1.9.1.bb:12:LICENSE = "Unknown"
recipes-core/pcl/pcl_1.9.1.bb:11:LICENSE = "Unknown"
```
