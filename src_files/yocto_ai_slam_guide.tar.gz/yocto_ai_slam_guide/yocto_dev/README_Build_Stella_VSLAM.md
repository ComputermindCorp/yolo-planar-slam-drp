# stella_vslamビルドマニュアル

## 前提条件

- [DRP-AI TVMインストールマニュアル](README_DRP-AI_TVM.md)または[DRP-AI TVMマニュアル（GitHub版）](README_DRP-AI_TVM.github.md)を読み終わっていること
- [DRP-AI TVMインストールマニュアル](README_DRP-AI_TVM.md)または[DRP-AI TVMマニュアル（GitHub版）](README_DRP-AI_TVM.github.md)の前提条件を満たしていること
- [DRP-AI TVMインストールマニュアル](README_DRP-AI_TVM.md)または[DRP-AI TVMマニュアル（GitHub版）](README_DRP-AI_TVM.github.md)の作業が完了していること
- stella_vslamのリポジトリがYocto環境を構築したコンピュータ上に展開されていること
    - gitを使用して本案件のGitLabサーバーからクローンする場合は[リポジトリのクローンマニュアル](../README_Clone.md)の手順を参照すること
- stella_vslam_examplesのリポジトリがYocto環境を構築したコンピュータ上に展開されていること
    - gitを使用して本案件のGitLabサーバーからクローンする場合は[リポジトリのクローンマニュアル](../README_Clone.md)の手順を参照すること

## stella_vslamリポジトリの配置

`/yocto_rzv2x_ver1_workdir`以下に本案件の`stella_vslam`と`stella_vslam_examples`を配置する。

## USBカメラのキャプチャ設定

2024年5月時点で、特定のハードウェア・ソフトウェアの組み合わせでUSBカメラが正常に初期化できない不具合が判明している。  
本不具合を回避するために、stella_vslamは`v4l2src`を使用してUSBカメラを初期化する実装に変更した。  
関連して、USBカメラのキャプチャ設定の一部もソースコードにハードコーディングされている。  
stella_vslamの`src/stella_vslam/image_load/monocular_camera_image_loading.cc`にハードコーディングされている設定値は以下の通り。

- キャプチャ画像のカラーフォーマット

デフォルト設定から変更する場合には、stella_vslamの`src/stella_vslam/image_load/monocular_camera_image_loading.cc`の以下の記述のうち、`format`の設定値を変更する必要がある。

```cpp
    // Workaround #222
    // Cannot be set to cv::VideoCapture::set due to hardware problem, use v4l2src instead
    std::stringstream ss;
    ss << "v4l2src device=/dev/video" << option_.cam_num_
       << " ! "
       << "video/x-raw, "
       << "format=YUY2, "
       << "width=" << option_.camera_width_ << ", "
       << "height=" << option_.camera_height_ << ", "
       << "framerate=(fraction)" << (uint16_t)(option_.fps_) << "/1"
       << " ! "
       << "appsink";
```

## 環境変数の設定

以下のコマンドを実行し、ビルド設定を行う。

```shell
export YOCTO_DIR=/yocto_rzv2x_ver1_workdir
source ${YOCTO_DIR:?}/weston_sdk/environment-setup-aarch64-poky-linux
source ${YOCTO_DIR:?}/stella_vslam/scripts/setup.sh
export CMAKE_INSTALL_PREFIX=${YOCTO_DIR:?}/local
```

## V2xボード向けパッケージのインストールディレクトリの作成

以下のコマンドを実行し、V2xボード向けパッケージのインストールディレクトリを作成する。

```shell
mkdir -p ${CMAKE_INSTALL_PREFIX:?}
```

## g2oのビルド

以下のコマンドを実行し、g2oリポジトリをクローンする。

```shell
cd ${YOCTO_DIR:?}

export G2O_COMMIT=20230223_git
git clone https://github.com/RainerKuemmerle/g2o.git
cd g2o
git checkout ${G2O_COMMIT}
```

以下のコマンドを実行し、g2oをビルドする。

```shell
cd ${YOCTO_DIR:?}/g2o
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX=${CMAKE_INSTALL_PREFIX:?} \
  -DBUILD_SHARED_LIBS=ON \
  -DBUILD_UNITTESTS=OFF \
  -DG2O_USE_CHOLMOD=OFF \
  -DG2O_USE_CSPARSE=ON \
  -DG2O_USE_OPENGL=OFF \
  -DG2O_USE_OPENMP=OFF \
  -DG2O_BUILD_APPS=OFF \
  -DG2O_BUILD_EXAMPLES=OFF \
  -DG2O_BUILD_LINKED_APPS=OFF \
  ..
make -j10
```

以下のコマンドを実行し、g2oのOpenGLへの依存を無効化する。

```shell
cd ${YOCTO_DIR:?}/g2o/build
sed -i 's/find_dependency(OpenGL)/# find_dependency(OpenGL)/g' generated/g2oConfig.cmake
```

以下のコマンドを実行し、g2oをインストールする。

```shell
cd ${YOCTO_DIR:?}/g2o/build
make install
```

## stella_vslamのビルド

以下のコマンドを実行し、stella_vslamのsubmoduleをcloneする。

```shell
cd ${YOCTO_DIR:?}/stella_vslam
git submodule update --init
```

以下のコマンドを実行し、stella_vslamをビルドする。

```shell
mkdir -p ${YOCTO_DIR:?}/stella_vslam/build
cd ${YOCTO_DIR:?}/stella_vslam/build
cmake -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX=${CMAKE_INSTALL_PREFIX:?} \
  -DENABLE_MEASURE_TIME=ON \
  -DENABLE_DEBUG_OUTPUT=OFF \
  -DENABLE_DRP_DRIVER_NATIVE=ON \
  -DENABLE_DRP_AI_TVM=ON \
  -DDISABLE_YOCTO=OFF \
  -DUSE_OPENMP=ON \
  -Dg2o_DIR=${CMAKE_INSTALL_PREFIX:?}/lib/cmake/g2o \
  -DOpenMP_C_FLAGS="-fopenmp" \
  -DOpenMP_CXX_FLAGS="-fopenmp" \
  -DOpenMP_C_LIB_NAMES="gomp;pthread" \
  -DOpenMP_CXX_LIB_NAMES="gomp;pthread" \
  -DOpenMP_gomp_LIBRARY=${SDKTARGETSYSROOT:?}/usr/lib64/libgomp.so \
  -DOpenMP_pthread_LIBRARY=${SDKTARGETSYSROOT:?}/usr/lib64/libpthread.so \
  ..
make -j
make install
```

以下のコマンドを実行し、stella_vslamをインストールする。

```shell
cd ${YOCTO_DIR:?}/stella_vslam/build
make install
```

## socket_publisherのビルド

以下のコマンドを実行し、socket_publisherリポジトリをクローンする。

```shell
cd ${YOCTO_DIR:?}

git clone https://github.com/stella-cv/socket_publisher.git -b 0.0.1
```

`socket_publisher`の`cmake`時に設定される`SIOCLIENT_LIBRARY`は、クロスコンパイルを想定した設定となっていない。  
例えば、`/usr/lib64/cmake/sioclient/sioclientConfig.cmake`では以下のように設定されている。

```cmake
set(SIOCLIENT_LIBRARY "/usr/lib64/libsioclient.so")
```

ここではV2xボードのSysrootを参照してクロスコンパイルできるように変更する必要がある。  
そのため、以下のコマンドを実行して`SIOCLIENT_LIBRARY`にクロスコンパイルを想定した値が設定されるように変更する。

```shell
cd ${YOCTO_DIR:?}/socket_publisher
sed -i 's/find_package(sioclient REQUIRED)/find_package(sioclient REQUIRED)\n# Change SIOCLIENT_LIBRARY for BitBake\nset(SIOCLIENT_LIBRARY "sioclient")\n/g' CMakeLists.txt
```

以下のコマンドを実行し、socket_publisherをビルドする。

```shell
cd ${YOCTO_DIR:?}/socket_publisher
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX=${CMAKE_INSTALL_PREFIX:?} \
  -Dstella_vslam_DIR=${CMAKE_INSTALL_PREFIX:?}/lib/cmake/stella_vslam \
  -Dg2o_DIR=${CMAKE_INSTALL_PREFIX:?}/lib/cmake/g2o \
  -Dfbow_DIR=${CMAKE_INSTALL_PREFIX:?}/share/cmake/fbow \
  -DOpenMP_C_FLAGS="-fopenmp -I${SDKTARGETSYSROOT}/usr/lib64/aarch64-poky-linux/8.3.0/include" \
  -DOpenMP_CXX_FLAGS="-fopenmp -I${SDKTARGETSYSROOT}/usr/lib64/aarch64-poky-linux/8.3.0/include" \
  -DOpenMP_C_LIB_NAMES="gomp;pthread" \
  -DOpenMP_CXX_LIB_NAMES="gomp;pthread" \
  -DOpenMP_gomp_LIBRARY=${SDKTARGETSYSROOT:?}/usr/lib64/libgomp.so \
  -DOpenMP_pthread_LIBRARY=${SDKTARGETSYSROOT:?}/usr/lib64/libpthread.so \
  ..
make -j10
```

以下のコマンドを実行し、socket_publisherをインストールする。

```shell
cd ${YOCTO_DIR:?}/socket_publisher/build
make install
```

## stella_vslam_examplesのビルド

以下のコマンドを実行し、stella_vslam_examplesのsubmoduleをcloneする。

```shell
cd ${YOCTO_DIR:?}/stella_vslam_examples
git submodule update --init
```

以下のコマンドを実行し、stella_vslam_examplesをビルドする。

```shell
mkdir -p ${YOCTO_DIR:?}/stella_vslam_examples/build
cd ${YOCTO_DIR:?}/stella_vslam_examples/build
cmake -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX=${CMAKE_INSTALL_PREFIX:?} \
  -DENABLE_MEASURE_TIME=ON \
  -DENABLE_DEBUG_OUTPUT=OFF \
  -DENABLE_DRP_DRIVER_NATIVE=ON \
  -DENABLE_DRP_AI_TVM=ON \
  -DDISABLE_YOCTO=OFF \
  -Dstella_vslam_DIR=${CMAKE_INSTALL_PREFIX:?}/lib/cmake/stella_vslam \
  -Dg2o_DIR=${CMAKE_INSTALL_PREFIX:?}/lib/cmake/g2o \
  -Dfbow_DIR=${CMAKE_INSTALL_PREFIX:?}/share/cmake/fbow \
  -Dsocket_publisher_DIR=${CMAKE_INSTALL_PREFIX:?}/lib/cmake/socket_publisher \
  -DOpenMP_C_FLAGS="-fopenmp" \
  -DOpenMP_CXX_FLAGS="-fopenmp" \
  -DOpenMP_C_LIB_NAMES="gomp;pthread" \
  -DOpenMP_CXX_LIB_NAMES="gomp;pthread" \
  -DOpenMP_gomp_LIBRARY=${SDKTARGETSYSROOT:?}/usr/lib64/libgomp.so \
  -DOpenMP_pthread_LIBRARY=${SDKTARGETSYSROOT:?}/usr/lib64/libpthread.so \
  ..
make -j
```

## orb_vocab.fbowのダウンロード

以下のコマンドを実行し、`orb_vocab.fbow`をダウンロードする。

```shell
cd ${YOCTO_DIR:?}/stella_vslam_examples
curl -sL "https://github.com/stella-cv/FBoW_orb_vocab/raw/main/orb_vocab.fbow" -o orb_vocab.fbow
```
