# Yocto導入ガイド

## 前提条件

- Yocto環境を構築する対象のコンピュータにUbuntu 20.04がインストールされていること
- ホームディレクトリに`1_Linux_SW-PKG.zip`が配置できていること
    - MD5ハッシュ値が`12d1574567d44802d99d2a2101a15962`であること
- ホームディレクトリに`2_Graphics.zip`が配置できていること
    - MD5ハッシュ値が`75ac5e73324b1930432ce83f0250aa87`であること
- ホームディレクトリに`3_Codec.zip`が配置できていること
    - MD5ハッシュ値が`170ef4e09e23b0e945956abd78a3459b`であること
- ホームディレクトリに`4_DRP-AI_Tools.zip`が配置できていること
    - MD5ハッシュ値が`2ceb62e05d429cbd9bb62ee4ed1ca1ef`であること

## 1 データのダウンロード

ストレージ容量が足りない場合は、別途ストレージ容量が十分に用意されたPCを用意し、下記のうち必要なデータのみをV2xボード上にコピーする。

データセットとして`rgbd_dataset_freiburg3_walking_xyz`を使用する場合には、[rgbd_dataset_freiburg3_walking_xyz.tgz](https://vision.in.tum.de/rgbd/dataset/freiburg3/rgbd_dataset_freiburg3_walking_xyz.tgz)をダウンロードする。  
なお、RGB画像とDepth画像の対応付けは[associate.py](https://svncvpr.in.tum.de/cvpr-ros-pkg/trunk/rgbd_benchmark/rgbd_benchmark_tools/src/rgbd_benchmark_tools/associate.py)を使用して、以下を実行して行った。

```shell
wget https://svncvpr.in.tum.de/cvpr-ros-pkg/trunk/rgbd_benchmark/rgbd_benchmark_tools/src/rgbd_benchmark_tools/associate.py
DATASET=rgbd_dataset_freiburg3_walking_xyz
python2 associate.py \
    /opt/dataset/tum/${DATASET}/rgb.txt \
    /opt/dataset/tum/${DATASET}/depth.txt > associate.txt
sudo mv associate.txt /opt/dataset/tum/${DATASET}/associate.txt
```

## 2 動作マニュアル一覧

### 2.1 Yocto環境構築マニュアル

[Yocto環境構築マニュアル](README_Yocto_Env.md)に記載されている。

### 2.2 BitBakeマニュアル

[BitBakeマニュアル](README_BitBake.md)に記載されている。  
`2.1 Yocto環境構築マニュアル`の作業が完了している必要がある。

### 2.3 DRP-AI TVMインストールマニュアル

[DRP-AI TVMインストールマニュアル](README_DRP-AI_TVM.md)に記載されている。  
`2.2 BitBakeマニュアル`の作業が完了している必要がある。

GitHubで公開されている[rzv_drp-ai_tvmリポジトリ](https://github.com/renesas-rz/rzv_drp-ai_tvm)を使用する手順については[DRP-AI TVMマニュアル（GitHub版）](README_DRP-AI_TVM.github.md)に記載されている。  
`2.2 BitBakeマニュアル`の作業が完了している必要がある。

### 2.4 Yolo-Planar-SLAMビルドマニュアル

[Yolo-Planar-SLAMビルドマニュアル](README_Build_YOLO-Planar-SLAM.md)に記載されている。  
`2.3 DRP-AI TVMインストールマニュアル`の作業が完了している必要がある。

### 2.5 stella_vslamビルドマニュアル

[stella_vslamビルドマニュアル](README_Build_Stella_VSLAM.md)に記載されている。  
`2.3 DRP-AI TVMインストールマニュアル`の作業が完了している必要がある。

### 2.6 SDカード作成マニュアル

[SDカード作成マニュアル](README_SD_Image.md)に記載されている。  
`2.2 BitBakeマニュアル`の作業が完了している必要がある。

### 2.7 Boot loader更新マニュアル

[Boot loader更新マニュアル](README_Boot_Loader.md)に記載されている。

### 2.8 OpenCVA組み込み版のYOLO-Planar-SLAM動作マニュアル

[OpenCVA組み込み版のYOLO-Planar-SLAM動作マニュアル](README_YOLO-Planar-SLAM.md)に記載されている。  
`2.6 SDカード作成マニュアル`の作業が完了している必要がある。

なお、データセットとして`rgbd_dataset_freiburg3_walking_xyz`を使用する場合には`rgbd_dataset_freiburg3_walking_xyz.tgz`を`/opt/dataset/tum/rgbd_dataset_freiburg3_walking_xyz/`以下に展開しておく。

### 2.9 stella_vslam動作マニュアル

[stella_vslam動作マニュアル](README_Stella_VSLAM.md)に記載されている。  
`2.6 SDカード作成マニュアル`の作業が完了している必要がある。

### 2.10 DRP単体環境動作マニュアル

**2024年3月時点で、CIP Linux上では、DRP単体環境の動作確認はされていない。**

[DRP単体環境動作マニュアル](README_DRP_Unit_Env.md)に記載されている。  
`2.6 SDカード作成マニュアル`の作業が完了している必要がある。

## 3 コンフィギュレーションコードについて

`yolo-planar-slam`リポジトリに同梱している、受領した`configuration_code_20230810.zip`に含まれていたコンフィギュレーションコードのMD5ハッシュ値は以下の通り。

- gaussian_blur_drp_out.bin：695be7c77f4522f1a2260a2aa5f8c19c
- orb_descriptors_drp_out.bin：f26481fc5c486f96bb5afbe1d59e78c1
- resize_drp_out.bin：af6838be44807f1033ba267c9e3359a1
- slamfast_drp_out.bin：9402233cc529b5517d5ce008e3a94bab

`stella_vslam_examples`リポジトリに同梱している、受領した`configuration_code_20230810.zip`に含まれていたコンフィギュレーションコードのMD5ハッシュ値は以下の通り。

- resize_drp_out.bin：af6838be44807f1033ba267c9e3359a1

`stella_vslam_examples`リポジトリに同梱している、本案件でビルドしたコンフィギュレーションコードのMD5ハッシュ値は以下の通り。

- gaussian_blur_drp_out.bin：a7f6484990d8c1861558ca2b5303d129
- orb_descriptors_drp_out.bin：61eb17382e9aea44a1fd7c21de335ff3
- slamfast_drp_out.bin：3ee562fe9283071f0abe5be168f063e0
- cvfast_drp_out.bin：51d67ecfcd2ef9a9c8fe3d40e939c752

特に、resize以外についてはYolo-Planar-SLAMとstella_vslamの間で使用するコンフィギュレーションコードが異なるため注意する必要がある。

## 4 受領した資料一覧

受領した資料・ファイルは以下の通り。

| ファイル名                                                           | 説明                                      | MD5ハッシュ値                          | 受領日        |
|-----------------------------------------------------------------|-----------------------------------------|-----------------------------------|------------|
| GRAY_rgbd_dataset_freiburg3_walking_xyz.tar.gz                  | グレースケール版のTUMデータセット（修正版）                 | f855c61afd748a8dff9b8ef3e27f7196  | 2023/10/2 |
| YoloV2_sp90_VGA_RGB_0726                                        |                                         |                                   | 2023/10/2 |
| configuration_code_20230810.zip                                 |                                         | 234c053bd2cb602125672f1db5b932f8  | 2023/10/2 |
| 20230830_RZV2H_linux_drpドライバ_OpenCV一式.zip                       |                                         | 9639ac3176f132b3d7f2e359395ef784  | 2023/10/2 |
| RZV2H_linux_VLP_3.0.3_drpドライバ_OpenCV_Fast対応版_組み込み手順書.txt        |                                         | 79b1a1260d3436b5b48b38ab7f07b6b1  |2023/10/2 |
| Linux.zip                                                       |                                         | daba2d8c2acd2a0fe3364d29f4bd25ab  | 2023/10/10 |
| DRP-AI.zip                                                      |                                         | 9f258cb7d9ab635039333fc12e4dd400  | 2023/10/10 |
| ROS2.zip                                                        |                                         | 95b72dda7507608dae49179ac49bc02d  | 2023/10/10 |
| e-con_Camera.zip                                                |                                         | 055768a03aee7d87e03bf8425aeabefc  | 2023/10/10 |
| EPSD-IMB-23-0095-01_RZV2H_GettingStarted_ForBeta.pdf            |                                         | 468c64a13a79641ee0c916583c811cd0  | 2023/10/10 |
| YoloExecutor.cpp                                                |                                         | 930b7d7ccfc8e5cb8ff720645daa2ca7  | 2023/10/13 |
| recognize_base.cpp                                              |                                         | 1e35deed1363f2e8e2ce06a24267bdcd  | 2023/10/13 |
| app_yolox_cam.zip                                               |                                         | 9bcda4a14c9be33d33aae2bbeedac22f  | 2023/10/18 |
| 20231027_RZV2H_linux_drpドライバ_レシピ_OpenCV一式.zip                   |                                         | 6db4b7645eebf26593df7e957233b818  | 2023/10/31 |
| RZV2H_linux_VLP_beta版_drpドライバ_OpenCV_組み込み手順書.txt                |                                         | 5162bfcc03c0d5f65235e01cd70e19bb  | 2023/10/31 |
| 0001-rz-common-debian-buster-Update-glib2.0-to-2.58.3-2-d.patch |                                         | e6f4dd7bb4460189f1647d13867785c5  | 2023/11/1  |
| OneDrive_1_2023-11-1.zip                                        | YOLOX-SのDRP-AIオブジェクトファイル一式              | f9f93523737786be67c45726b2cf9db8  | 2023/11/1  |
| 20231108_RZV2H_linux_drpドライバ_レシピ_OpenCV一式.zip                   |                                         | fe85ea797164997184ce426de1122f8b  | 2023/11/8  |
| RZV2H_linux_VLP_beta版_drpドライバ_OpenCV_組み込み手順書.txt                |                                         | 6ce483a84af342cad4c1972819a3dfda  | 2023/11/8  |
| OneDrive_1_2023-11-22.zip                                       | YOLOX-SのDenseモデルのDRP-AIオブジェクトファイル一式     | b0b6ff86a3d75a3e0e0e8daba08060c3  | 2023/11/22 |
| drp-tvm_v2x_apps.zip                                            |                                         | 85f29de6c6e2b9c397e0403cc3c40b8c  | 2023/12/4  |
| drp-tvm_v2x_samples.zip                                         |                                         | b912126864d4565fd534123a81e0161b  | 2023/12/4  |
| 20231206_RZV2H_DRP-AI_V1pre.zip                                 |                                         | 6d49412a13e9cd51264d0755474a7e4d  | 2023/12/8  |
| 1_Linux_SW-PKG.zip                                              |                                         | 12d1574567d44802d99d2a2101a15962  | 2024/1/11  |
| 2_Graphics.zip                                                  |                                         | 75ac5e73324b1930432ce83f0250aa87  | 2024/1/11  |
| 3_Codec.zip                                                     |                                         | 170ef4e09e23b0e945956abd78a3459b  | 2024/1/11  |
| 4_DRP-AI_Tools.zip                                              |                                         | 2ceb62e05d429cbd9bb62ee4ed1ca1ef  | 2024/1/11  |
| ECSD-IMB-23-0113-01_RZV2H_GettingStarted_ForVersion1.0-rc1.pdf  |                                         | 96dfba4430b1ef1740dad3877fd86a9c  | 2024/1/11  |
| v210_yolox_tmp_240119.zip                                       |                                         | 27f2bbc1c9d79584bdc9c15c970e621a  | 2024/1/19  |
| app_yolox-S_bgr640x640_20240325.tar.gz                          |                                         | 1e21976a02ea69aab4b0a8ed6ce08980  | 2024/3/25  |
| RZV2x_VSLAM_yolox-S_bgr640x640_20240323.pptx                    |                                         | 626053378953c2b60df483027281b57d  | 2024/3/25  |
| DatasetImageLoading.cc                                          |                                         | ba52afb4960475e58fccc99963469415  | 2024/4/15  |
| MonocularCameraImageLoading.cc                                  |                                         | 34b5a0f0f4663bfad7d42ad697defe06  | 2024/4/15  |
| yocto_dev_README_DRP-AI_TVM_Compile.md                          |                                         | d1eea9a7a50ee22b460a5458fa59f5c1  | 2024/4/23  |
| yocto_dev_README_SD_Image.md                                    |                                         | af04909338577186bfcfac6ea05c6137  | 2024/4/23  |
| yocto_dev_README_DRP-AI_TVM_Compile.md                          |                                         | f6eae0b4e0b603322b8e2485f0ba12a7  | 2024/4/26  |
