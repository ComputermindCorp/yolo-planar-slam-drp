# OpenCVA組み込み版のYOLO-Planar-SLAM動作マニュアル

## 前提条件

- [SDカード作成マニュアル](README_SD_Image.md)を読み終わっていること
- [SDカード作成マニュアル](README_SD_Image.md)の前提条件を満たしていること
- [SDカード作成マニュアル](README_SD_Image.md)の作業が完了していること
- [Boot loader更新マニュアル](README_Boot_Loader.md)を読み終わっていること
- [Boot loader更新マニュアル](README_Boot_Loader.md)の前提条件を満たしていること
- [Boot loader更新マニュアル](README_Boot_Loader.md)の作業が完了していること
- [Yolo-Planar-SLAMビルドマニュアル](README_Build_YOLO-Planar-SLAM.md)を読み終わっていること
- [Yolo-Planar-SLAMビルドマニュアル](README_Build_YOLO-Planar-SLAM.md)の前提条件を満たしていること
- [Yolo-Planar-SLAMビルドマニュアル](README_Build_YOLO-Planar-SLAM.md)の作業が完了していること
- DRP-AI Translatorを使用する場合は、V2xボードの`$HOME/yolo-planar-slam/YOLOX_S_dense_640x640_RGB_10271351`にDRP-AI TranslatorのYOLOX-Sのオブジェクトファイル一式（`YOLOX_S_dense_640x640_RGB_10271351`）が配置されていること
- DRP-AI TVMを使用する場合は、V2xボードの`$HOME/yolo-planar-slam/yolox_cam`にDRP-AI TVMのYOLOX-Sのファイル一式（`yolox_cam`）が配置されていること

## USBカメラの接続確認

使用するUSBカメラを、V2xボードのUSBのポートに接続する。  
V2xボード上で以下のコマンドを実行し、USBカメラが正しく接続されているのかを確認する。

```shell
lsusb
```

上記のコマンドを実行すると、USB接続されているデバイスの一覧が表示される。

ELPカメラの場合は、一覧の中に、vendor idが`32e4`のデバイスがあることを確認する。  
USBカメラが正しく接続されている場合は、例えば以下のように表示される。

```shell
Bus 002 Device 002: ID 32e4:0144 Global Shutter Camera Global Shutter Camera
```

USBカメラがUSB接続されているデバイスの一覧に表示されていない場合、USBカメラがV2xボードのUSBポートに正しく接続されていることを確認し、再起動を行った上で再度確認を行う。

## ビルド済みのYolo-Planar-SLAMの配置

[Yolo-Planar-SLAMビルドマニュアル](README_Build_YOLO-Planar-SLAM.md)の`ビルド`のビルド生成物のうち、以下のディレクトリをV2xボード上の`$HOME/yolo-planar-slam/`以下にコピーする。

- /yocto_rzv2x_ver1_workdir/yolo-planar-slam/Examples
- /yocto_rzv2x_ver1_workdir/yolo-planar-slam/lib
- /yocto_rzv2x_ver1_workdir/yolo-planar-slam/build
- /yocto_rzv2x_ver1_workdir/yolo-planar-slam/Thirdparty

## LD_LIBRARY_PATHの設定

V2xボード上で以下のコマンドを実行し、ホームディレクトリ以下のYolo-Planar-SLAMのライブラリがリンクされるようにする。

```shell
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam/Thirdparty/g2o/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam/Thirdparty/DBoW2/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam/build/drp_ai_modules/translator:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam/build/drp_ai_modules/tvm:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam/build/drp_modules:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam/build/image_load_modules:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam/build/image_proc_modules:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam/build/opencva_modules:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam/build/socket_modules:$LD_LIBRARY_PATH
```

V2xボード上で以下のコマンドを実行し、意図した通りにリンクされているのかを確認する。

```shell
/lib64/ld-linux-aarch64.so.1 --list $HOME/yolo-planar-slam/Examples/Monocular/mono_tum | \
  grep -E 'modules|SLAM|g2o|DBoW2'
```

以下のように、Yolo-Planar-SLAMのライブラリのリンク先が`/home/root`以下のファイルとなっていれば問題ない。

```shell
        libORB_SLAM2.so.2.12.0 => /home/root/yolo-planar-slam/lib/libORB_SLAM2.so.2.12.0 (0x0000ffffb63cd000)
        libsocket_modules.so.2.12.0 => /home/root/yolo-planar-slam/build/socket_modules/libsocket_modules.so.2.12.0 (0x0000ffffb5dd1000)
        libimage_load_modules.so.2.12.0 => /home/root/yolo-planar-slam/build/image_load_modules/libimage_load_modules.so.2.12.0 (0x0000ffffb5d9f000)
        libimage_proc_modules.so.2.12.0 => /home/root/yolo-planar-slam/build/image_proc_modules/libimage_proc_modules.so.2.12.0 (0x0000ffffb5270000)
        libopencva_modules.so.2.12.0 => /home/root/yolo-planar-slam/build/opencva_modules/libopencva_modules.so.2.12.0 (0x0000ffffb523d000)
        libtvm.so.2.12.0 => /home/root/yolo-planar-slam/build/drp_ai_modules/tvm/libtvm.so.2.12.0 (0x0000ffffb51ee000)
        libdrp_modules.so.2.12.0 => /home/root/yolo-planar-slam/build/drp_modules/libdrp_modules.so.2.12.0 (0x0000ffffb4906000)
        libDBoW2.so.2.12.0 => /home/root/yolo-planar-slam/Thirdparty/DBoW2/lib/libDBoW2.so.2.12.0 (0x0000ffffb48e8000)
        libg2o.so.2.12.0 => /home/root/yolo-planar-slam/Thirdparty/g2o/lib/libg2o.so.2.12.0 (0x0000ffffb485b000)
```

以下のようにerrorが出た場合には、意図したライブラリにリンクされていない。  
手順を再確認する必要がある。

```shell
/home/root/yolo-planar-slam/Examples/Monocular/mono_tum: error while loading shared libraries: libORB_SLAM2.so.2.12.0: cannot open shared object file: No such file or directory
```

## 実行

`rgbd_dataset_freiburg3_walking_xyz`を使用する場合の設定ファイルは`$HOME/yolo-planar-slam/Examples/Monocular/TUM3.yaml`にある。  
`GRAY_rgbd_dataset_freiburg3_walking_xyz`も同じ設定ファイルを使用する。

SocketViewerを使用する場合は`Viewer.Type`に`SocketViewer`を設定する。  
ヴィジュアライザを使用しない場合は`Viewer.Type`に`None`を設定する。

DRPを使用する場合には`UseDrp`に`true`を設定する。  
DRPを使用しない場合には`UseDrp`に`false`を設定する。

2023年11月時点でDRP-AIを使用しない場合は実行できないため、`UseDrpAI`に`true`を設定する。

`UseDrp`を`true`に設定した上で、OpenCVAでDRPを使用する場合には`UseOpenCVA`に`true`を設定する。  
ただし、`true`に設定した場合でもcomputeOrbDescriptorsについてはOpenCVAに対応するAPIが実装されていないため、OpenCVAを使用せずDRPドライバネイティブで実行される。

OpenCVAでDRPを使用しない場合には`UseOpenCVA`に`false`を設定する。  
ただし、`UseDrp`を`true`、`UseOpenCVA`を`false`に指定することはできない。

RGB-Dで`rgbd_dataset_freiburg3_walking_xyz`を使用する場合は、V2xボード上で以下のコマンドを実行する。

```shell
cd $HOME/yolo-planar-slam/
./Examples/RGB-D/rgbd_tum \
  Vocabulary/ORBvoc.txt \
  Examples/RGB-D/TUM3.yaml \
  /opt/dataset/tum/rgbd_dataset_freiburg3_walking_xyz \
  /opt/dataset/tum/rgbd_dataset_freiburg3_walking_xyz/associate.txt
```

単眼で`rgbd_dataset_freiburg3_walking_xyz`を使用する場合は、V2xボード上で以下のコマンドを実行する。

```shell
cd $HOME/yolo-planar-slam/
./Examples/Monocular/mono_tum \
  Vocabulary/ORBvoc.txt \
  Examples/Monocular/TUM3.yaml \
  /opt/dataset/tum/rgbd_dataset_freiburg3_walking_xyz
```

単眼で`GRAY_rgbd_dataset_freiburg3_walking_xyz`を使用する場合は、V2xボード上で以下のコマンドを実行する。

```shell
cd $HOME/yolo-planar-slam/
./Examples/Monocular/mono_tum \
  Vocabulary/ORBvoc.txt \
  Examples/Monocular/TUM3.yaml \
  /opt/dataset/tum/GRAY_rgbd_dataset_freiburg3_walking_xyz
```

単眼でELPカメラを使用する場合は、V2xボード上で以下のコマンドを実行する。  
ここでは設定ファイルに`Examples/Monocular/ELP_rns-2022-0901.yaml`を指定している。

```shell
cd $HOME/yolo-planar-slam/
./Examples/Monocular/mono_usbcam \
  Vocabulary/ORBvoc.txt \
  Examples/Monocular/ELP_rns-2022-0901.yaml
```

SocketViewerを使用する場合はV2xボード上の2つ目のterminalでV2xボード上で以下のコマンドを実行する。

```shell
cd $HOME/yolo-planar-slam/viewer
node app.js
```

## メモリアドレスマップ

DRPのメモリアドレスマップは以下の通り。

| メモリ種別 | 開始アドレス    | サイズ     | 内容                              |
|-------|-----------|--------:|-----------------------------------------------|
| DRAM  | 8B98_0000 | A0      | ディスクリプタ                                 |
| DRAM  | 8BC0_0000 | 18_0000 | コンフィギュレーションコード                    |
| DRAM  | 8B80_0000 | 40_0000 | 7x7のGaussianBlurの入力                       |
| DRAM  | 8B80_0000 | 40_0000 | FASTの入力                                    |
| DRAM  | 8B00_0000 | 40_0000 | computeOrbDescriptorsの入力（画像）            |
| DRAM  | 8BA0_0000 | 2_0000  | computeOrbDescriptorsの入力（特徴点配列）      |
| DRAM  | 8B80_0000 | 40_0000 | resizeの入力                                  |
| DRAM  | 8B00_0000 | 40_0000 | 7x7のGaussianBlurの出力                       |
| DRAM  | 8B40_0000 | 40_0000 | FASTの出力（特徴点配列）                       |
| DRAM  | 8BD8_0000 | 2       | FASTの出力（特徴点配列のサイズ）                |
| DRAM  | 8BB0_0000 | 5_0000  | computeOrbDescriptorsの出力（特徴点配列）      |
| DRAM  | 8B80_0000 | 40_0000 | resizeの出力                                  |
| DRAM  | 9200_0000 |         | `ioctl(DRP_SET_SEQ)`用の領域                  |
