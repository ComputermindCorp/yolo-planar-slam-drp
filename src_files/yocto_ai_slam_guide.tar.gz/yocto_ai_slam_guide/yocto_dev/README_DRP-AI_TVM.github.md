# DRP-AI TVMマニュアル（GitHub版）

## 前提条件

- [BitBakeマニュアル](README_BitBake.md)を読み終わっていること
- [BitBakeマニュアル](README_BitBake.md)の前提条件を満たしていること
- [BitBakeマニュアル](README_BitBake.md)の作業が完了していること
- `yocto_ai_slam_guide`リポジトリが対象のコンピュータ上に展開されていること
    - gitを使用して本案件のGitLabサーバーからクローンする場合は[リポジトリのクローンマニュアル](../README_Clone.md)の手順を参照すること

## 注意事項

**2024年5月時点で、本マニュアルの手順による動作確認は行っていない。**

## 環境変数の設定

以下のコマンドを実行し、環境変数の設定を行う。

```shell
export YOCTO_DIR=/yocto_rzv2x_ver1_workdir
```

## DRP-AI TVM向けの環境構築

<https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v2.2.1/setup/SetupV2H.md#requirements>  
の記載に従って環境構築を行う。
以下、章番号はこのURLと同じ番号を使用する。

## １．事前準備

必要なソフトウエアをインストールする。

```shell
sudo apt update && DEBIAN_FRONTEND=noninteractive sudo apt install -y git wget unzip curl \
libboost-all-dev libeigen3-dev build-essential python3-pip libgl1-mesa-dev
```

以下URLからr20ut5460ej0101-drp-ai-translator-i8.zipをダウンロードする。  
<https://www.renesas.com/jp/ja/software-tool/drp-ai-translator-i8>

ダウンロードしたr20ut5460ej0101-drp-ai-translator-i8.zipを解凍し、その中のDRP-AI_Translator_i8-v1.00-Linux-x86_64-Installを/tmpに格納する。

```shell
unzip r20ut5460ej0101-drp-ai-translator-i8.zip DRP-AI_Translator_i8-v1.01-Linux-x86_64-Install -d /tmp/
```

以下のコマンドを実行し、AI_Translatorをインストールする。

```shell
cd /opt
sudo chmod 777 /opt/
yes | /tmp/DRP-AI_Translator_i8-v1.01-Linux-x86_64-Install
rm /tmp/DRP-AI_Translator_i8-v1.01-Linux-x86_64-Install

export PYTHONPATH=${PWD}/DRP-AI_Translator_i8/drpAI_Quantizer:${PYTHONPATH}
```

## ２．最小限の前提条件をインストールする

```shell
sudo apt update
DEBIAN_FRONTEND=noninteractive sudo apt install -y software-properties-common
sudo add-apt-repository ppa:ubuntu-toolchain-r/test
sudo apt update
DEBIAN_FRONTEND=noninteractive sudo apt install -y build-essential cmake \
libomp-dev libgtest-dev libgoogle-glog-dev libtinfo-dev zlib1g-dev libedit-dev \
libxml2-dev llvm-8-dev g++-9 gcc-9
sudo apt install -y libboost-all-dev libeigen3-dev
sudo apt install -y libgl1-mesa-dev

pip3 install --upgrade pip
pip3 install scipy==1.5.4 psutil
pip3 install cython==0.29.32
pip3 install decorator attrs
pip3 install torchvision==0.16.2 tqdm
pip3 install tensorflow tflite

# Install onnx runtime
wget https://github.com/microsoft/onnxruntime/releases/download/v1.16.1/onnxruntime-linux-x64-1.16.1.tgz -O /tmp/onnxruntime.tar.gz
tar -xvzf /tmp/onnxruntime.tar.gz -C /tmp/
mv /tmp/onnxruntime-linux-x64-1.16.1/ /opt/
```

## ３．リポジトリのクローンを作成する

```shell
cd ${YOCTO_DIR:?}
git clone --recursive https://github.com/renesas-rz/rzv_drp-ai_tvm.git drp-ai_tvm
cd drp-ai_tvm
```

## ４．環境変数を設定する

次のコマンドを実行して、環境変数を設定する。 環境変数は、端末を開くたびに設定する必要があることに注意する。

```shell
export TVM_ROOT=${YOCTO_DIR:?}/drp-ai_tvm
export TVM_HOME=${TVM_ROOT}/tvm
export PYTHONPATH=$TVM_HOME/python:${PYTHONPATH}
export SDK=${YOCTO_DIR:?}/weston_sdk
export TRANSLATOR=/opt/DRP-AI_Translator_i8/translator/
export QUANTIZER=/opt/DRP-AI_Translator_i8/drpAI_Quantizer/
export PRODUCT=V2H
```

## ５．DRP-AI TVMのセットアップ環境

```shell
cd ${TVM_ROOT:?}
bash setup/make_drp_env.sh

cd ${YOCTO_DIR:?}/yocto_ai_slam_guide
./scripts/drp-ai_tvm/install.sh
```

## ６．Yolox-Sモデル(画像サイズ640x480)の作成

 <https://github.com/renesas-rz/rzv_drp-ai_tvm/tree/main/how-to/sample_app_v2h#readme>
の記載に従って作成する。

```shell
cd $TVM_ROOT/tutorials
sed -i -e 's/256/640/g' compile_onnx_model_quant.py
sed -i -e 's/ 224/ 640/g' compile_onnx_model_quant.py
sed -i -e 's/to_tensor/pil_to_tensor/g' compile_onnx_model_quant.py
sed -i -e '/std = stdev/d' compile_onnx_model_quant.py
sed -i -e '/F.normalize/d' compile_onnx_model_quant.py
sed -i -e 's/480, 640, 3/640, 640, 3/g' compile_onnx_model_quant.py
sed -i -e '/cof_add/d' compile_onnx_model_quant.py
sed -i -e '/cof_mul/d' compile_onnx_model_quant.py

python3 compile_onnx_model_quant.py \
$TVM_ROOT/how-to/sample_app_v2h/yolox-S_VOC.onnx \
-o yolox_cam \
-t $SDK \
-d $TRANSLATOR \
-c $QUANTIZER \
-s 1,3,640,640 \
-v 100 \
--images $TRANSLATOR/../GettingStarted/tutorials/calibrate_sample/ 
```
