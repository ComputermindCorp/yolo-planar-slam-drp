# DRP単体環境動作マニュアル

## 前提条件

- [SDカード作成マニュアル](README_SD_Image.md)を読み終わっていること
- [SDカード作成マニュアル](README_SD_Image.md)の前提条件を満たしていること
- [SDカード作成マニュアル](README_SD_Image.md)の作業が完了していること
- [Boot loader更新マニュアル](README_Boot_Loader.md)を読み終わっていること
- [Boot loader更新マニュアル](README_Boot_Loader.md)の前提条件を満たしていること
- [Boot loader更新マニュアル](README_Boot_Loader.md)の作業が完了していること
- Yocto環境を構築したコンピュータの`/yocto_rzv2x_beta_workdir`以下に`drp_cv_lib`リポジトリが展開されていること
    - gitを使用して本案件のGitLabサーバーからクローンする場合は[リポジトリのクローンマニュアル](../README_Clone.md)の手順を参照すること
- Yocto環境を構築したコンピュータの`/yocto_rzv2x_beta_workdir/bsp_sdk`にSDKがインストールされていること

以降では、画像のレベルとは以下を示す。

- 0レベル：もっともサイズの大きい画像
    - Yolo-Planar-SLAMの入力画像と同じサイズとなる
- 1レベル：0レベルの画像の縦横のサイズをそれぞれ`1/1.2`倍にリサイズした画像
- 2レベル：1レベルの画像の縦横のサイズをそれぞれ`1/1.2`倍にリサイズした画像
- 3レベル：2レベルの画像の縦横のサイズをそれぞれ`1/1.2`倍にリサイズした画像
- 4レベル：3レベルの画像の縦横のサイズをそれぞれ`1/1.2`倍にリサイズした画像
- 5レベル：4レベルの画像の縦横のサイズをそれぞれ`1/1.2`倍にリサイズした画像
- 6レベル：5レベルの画像の縦横のサイズをそれぞれ`1/1.2`倍にリサイズした画像
- 7レベル：6レベルの画像の縦横のサイズをそれぞれ`1/1.2`倍にリサイズした画像

**2024年3月時点で、CIP Linux上では、DRP単体環境の動作確認はされていない。**

## computeOrbDescriptors

### ビルド

Yocto環境を構築したコンピュータ上で以下のコマンドを実行して、単体環境をビルドする。

```shell
ALGORITHM=orb_descriptors
cd /yocto_rzv2x_beta_workdir/drp_cv_lib/drp/${ALGORITHM}
source /yocto_rzv2x_beta_workdir/bsp_sdk/environment-setup-aarch64-poky-linux
${CXX} \
  -O3 -Wall -Wextra -W -g \
  -I../util \
  -I/yocto_rzv2x_beta_workdir/bsp_sdk/sysroots/aarch64-poky-linux/usr/include \
  board.cpp \
  -o board.exe \
  -lm
```

ビルドされた`board.exe`はV2xボードの`$HOME/drp_cv_lib/drp/orb_descriptors/`へコピーする。

### データの準備

Musketeerで生成したバイナリファイルを用意する。  
Yocto環境を構築したコンピュータ上の`/yocto_rzv2x_beta_workdir/drp_cv_lib/drp/orb_descriptors/musketeer_orb_descriptors/`に以下のバイナリファイルが存在していることを確認する。  
ここで、`<frame id>`はフレーム番号、`<level>`は画像のレベルを表す。

- `orb_descriptors_<frame id>_<level>_TB_mem_in_csim_00100000.bin`
- `orb_descriptors_<frame id>_<level>_TB_mem_in_csim_02000000.bin`
- `Embedded/orb_descriptors_drp_out.bin`

`/yocto_rzv2x_beta_workdir/drp_cv_lib/drp/orb_descriptors/musketeer_orb_descriptors`をV2xボードの`$HOME/drp_cv_lib/drp/orb_descriptors/musketeer_orb_descriptors`へコピーする。

### 実行

V2xボード上の`$HOME/drp_cv_lib/drp/orb_descriptors/`で以下を実行する。  
以下は上記のバイナリファイルの7レベルの`210x134`の画像と`keypts_at_level_2849_7.csv`に含まれている特徴点の個数を入力として`/dev/drp1`を使用して10000回連続で単体環境を実行する場合の例である。

```shell
./board.exe 1 2849 7  210 134 $((`wc -l testbench/orb-slam2/keypts_at_level/keypts_at_level_2849_7.csv | awk '{printf $1}'`-1)) 10000
```

実行すると、以下が行われる。

- 処理時間の計測結果の表示
    - 単位は\[ms\]で表示される
    - `all_sum / 実行回数`に表示される値が、単体環境全体の平均処理時間である
- 出力ファイルの生成
    - `board_result.pgm`が出力される

## CVアセット用のFAST

### ビルド

Yocto環境を構築したコンピュータ上で以下のコマンドを実行して、単体環境をビルドする。

```shell
ALGORITHM=fast
cd /yocto_rzv2x_beta_workdir/drp_cv_lib/drp/${ALGORITHM}
source /yocto_rzv2x_beta_workdir/bsp_sdk/environment-setup-aarch64-poky-linux
${CXX} \
  -O3 -Wall -Wextra -W -g \
  -I../util \
  -I/yocto_rzv2x_beta_workdir/bsp_sdk/sysroots/aarch64-poky-linux/usr/include \
  board.cpp \
  -o board.exe \
  -lm
```

ビルドされた`board.exe`はV2xボードの`$HOME/drp_cv_lib/drp/fast/`へコピーする。

### データの準備

Musketeerで生成したバイナリファイルを用意する。  
Yocto環境を構築したコンピュータ上の`/yocto_rzv2x_beta_workdir/drp_cv_lib/drp/fast/musketeer_fast/`に以下のバイナリファイルが存在していることを確認する。  
ここで、`<frame id>`はフレーム番号、`<level>`は画像のレベルを、`<vertical index>`と`<horizonal index>`はそれぞれ入力画像をセル分割した時の、上から何番目、左から何番目のセル画像なのかを表す。

- `fast_<frame id>_<level>_<vertical index>_<horizonal index>_TB_mem_in_csim_00100000.bin`
- `Embedded/fast_drp_out.bin`

`/yocto_rzv2x_beta_workdir/drp_cv_lib/drp/fast/musketeer_fast`をV2xボードの`$HOME/drp_cv_lib/drp/fast/musketeer_fast`へコピーする。

### 実行

V2xボード上の`$HOME/drp_cv_lib/drp/fast/`で以下を実行する。  
以下は上記のバイナリファイルの7レベルの`42x40`の画像を入力として`/dev/drp1`を使用して10000回連続で単体環境を実行する場合の例である。  
なお、`<vertical index>`と`<horizonal index>`はそれぞれ`1`と`0`を指定している。

```shell
./board.exe 1 2849 7 1  0 42 40 10000
```

実行すると、以下が行われる。

- 処理時間の計測結果の表示
    - 単位は\[ms\]で表示される
    - `all_sum / 実行回数`に表示される値が、単体環境全体の平均処理時間である
- 出力ファイルの生成
    - `board_result.csv`が出力される

## resize

### ビルド

Yocto環境を構築したコンピュータ上で以下のコマンドを実行して、単体環境をビルドする。

```shell
ALGORITHM=resize
cd /yocto_rzv2x_beta_workdir/drp_cv_lib/drp/${ALGORITHM}
source /yocto_rzv2x_beta_workdir/bsp_sdk/environment-setup-aarch64-poky-linux
${CXX} \
  -O3 -Wall -Wextra -W -g \
  -I../util \
  -I/yocto_rzv2x_beta_workdir/bsp_sdk/sysroots/aarch64-poky-linux/usr/include \
  board.cpp \
  -o board.exe \
  -lm
```

ビルドされた`board.exe`はV2xボードの`$HOME/drp_cv_lib/drp/resize/`へコピーする。

### データの準備

Musketeerで生成したバイナリファイルを用意する。  
Yocto環境を構築したコンピュータ上の`/yocto_rzv2x_beta_workdir/drp_cv_lib/drp/resize/musketeer_resize/`に以下のバイナリファイルが存在していることを確認する。  
ここで、`<frame id>`はフレーム番号、`<level>`は出力画像のレベルを表す。

- `resize_<frame id>_<level>_TB_mem_in_csim_00100000.bin`
- `Embedded/resize_drp_out.bin`

`/yocto_rzv2x_beta_workdir/drp_cv_lib/drp/resize/musketeer_resize`をV2xボードの`$HOME/drp_cv_lib/drp/resize/musketeer_resize`へコピーする。

### 実行

V2xボード上の`$HOME/drp_cv_lib/drp/resize/`で以下を実行する。  
以下は上記のバイナリファイルの6レベルの画像を入力として`/dev/drp1`を使用して10000回連続で単体環境を実行する場合の例である。  
なお、コマンドで指定するのは0レベルの画像のサイズである`752x480`とする必要があるため、注意する。

```shell
./board.exe 1 2849 7  752 480 10000
```

実行すると、以下が行われる。

- 処理時間の計測結果の表示
    - 単位は\[ms\]で表示される
    - `all_sum / 実行回数`に表示される値が、単体環境全体の平均処理時間である
- 出力ファイルの生成
    - `board_result.pgm`が出力される
