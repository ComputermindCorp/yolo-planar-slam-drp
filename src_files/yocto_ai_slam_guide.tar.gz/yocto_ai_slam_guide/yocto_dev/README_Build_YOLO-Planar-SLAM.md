# Yolo-Planar-SLAMビルドマニュアル

## 前提条件

- [DRP-AI TVMインストールマニュアル](README_DRP-AI_TVM.md)または[DRP-AI TVMマニュアル（GitHub版）](README_DRP-AI_TVM.github.md)を読み終わっていること
- [DRP-AI TVMインストールマニュアル](README_DRP-AI_TVM.md)または[DRP-AI TVMマニュアル（GitHub版）](README_DRP-AI_TVM.github.md)の前提条件を満たしていること
- [DRP-AI TVMインストールマニュアル](README_DRP-AI_TVM.md)または[DRP-AI TVMマニュアル（GitHub版）](README_DRP-AI_TVM.github.md)の作業が完了していること
- YOLO-Planar-SLAMのリポジトリがYocto環境を構築したコンピュータ上に展開されていること
    - gitを使用して本案件のGitLabサーバーからクローンする場合は[リポジトリのクローンマニュアル](../README_Clone.md)の手順を参照すること

## Yolo-Planar-SLAMリポジトリの配置

`/yocto_rzv2x_ver1_workdir`以下に本案件の`yolo-planar-slam`を配置する。

## USBカメラのキャプチャ設定

2024年5月時点で、特定のハードウェア・ソフトウェアの組み合わせでUSBカメラが正常に初期化できない不具合が判明している。  
本不具合を回避するために、Yolo-Planar-SLAMは`v4l2src`を使用してUSBカメラを初期化する実装に変更した。  
関連して、USBカメラのキャプチャ設定の一部もソースコードにハードコーディングされている。  
`image_load_modules/MonocularCameraImageLoading.cc`にハードコーディングされている設定値は以下の通り。

- USBカメラのデバイス番号
- キャプチャ画像のカラーフォーマット

デフォルト設定から変更する場合には、`image_load_modules/MonocularCameraImageLoading.cc`の以下の記述のうち、それぞれ`device`と`format`の設定値を変更する必要がある。

```cpp
    // Workaround #222
    // Cannot be set to cv::VideoCapture::set due to hardware problem, use v4l2src instead
    std::stringstream ss;
    ss << "v4l2src device=/dev/video" << 0
       << " ! "
       << "video/x-raw, "
       << "format=YUY2, "
       << "width=" << camera_width << ", "
       << "height=" << camera_height << ", "
       << "framerate=(fraction)" << (uint16_t)(fps) << "/1"
       << " ! "
       << "appsink";
```

## ビルド

以下のコマンドを実行し、ビルド設定を行う。

```shell
export YOCTO_DIR=/yocto_rzv2x_ver1_workdir
source ${YOCTO_DIR:?}/weston_sdk/environment-setup-aarch64-poky-linux
source ${YOCTO_DIR:?}/yolo-planar-slam/script/setup.sh
```

DRP-AI TVMを使用する場合には、以下のコマンドを実行し、Yolo-Planar-SLAMをビルドする。  
なお、ビルドされた実行ファイルのFAST処理ではOpenCVAまたはDRP無しが使用できる。

```shell
cd ${YOCTO_DIR:?}/yolo-planar-slam
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release \
  -DENABLE_MEASURE_TIME=ON \
  -DENABLE_DUMP=OFF \
  -DENABLE_DRP=ON \
  -DENABLE_DRP_AI_TRANSLATOR=OFF \
  -DENABLE_DRP_AI_TVM=ON \
  -DENABLE_REALSENSE2=OFF \
  -DENABLE_GOOGLE_PERF=OFF \
  -DENABLE_SLAMFAST=OFF \
  -DOpenMP_C_FLAGS='-fopenmp' \
  -DOpenMP_CXX_FLAGS='-fopenmp' \
  -DOpenMP_C_LIB_NAMES='gomp;pthread' \
  -DOpenMP_CXX_LIB_NAMES='gomp;pthread' \
  -DOpenMP_gomp_LIBRARY=${SDKTARGETSYSROOT}/usr/lib64/libgomp.so \
  -DOpenMP_pthread_LIBRARY=${SDKTARGETSYSROOT}/usr/lib64/libpthread.so \
  -DYOLO_PLANAR_SLAM_VERSION=${YOLO_PLANAR_SLAM_VERSION} \
  ..
make -j
```

DRP-AI Translatorを使用する場合には、以下のコマンドを実行し、Yolo-Planar-SLAMをビルドする。  
なお、ビルドされた実行ファイルのFAST処理ではOpenCVAまたはDRP無しが使用できる。

```shell
cd ${YOCTO_DIR:?}/yolo-planar-slam
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release \
  -DENABLE_MEASURE_TIME=ON \
  -DENABLE_DUMP=OFF \
  -DENABLE_DRP=ON \
  -DENABLE_DRP_AI_TRANSLATOR=ON \
  -DENABLE_DRP_AI_TVM=OFF \
  -DENABLE_REALSENSE2=OFF \
  -DENABLE_GOOGLE_PERF=OFF \
  -DENABLE_SLAMFAST=OFF \
  -DOpenMP_C_FLAGS='-fopenmp' \
  -DOpenMP_CXX_FLAGS='-fopenmp' \
  -DOpenMP_C_LIB_NAMES='gomp;pthread' \
  -DOpenMP_CXX_LIB_NAMES='gomp;pthread' \
  -DOpenMP_gomp_LIBRARY=${SDKTARGETSYSROOT}/usr/lib64/libgomp.so \
  -DOpenMP_pthread_LIBRARY=${SDKTARGETSYSROOT}/usr/lib64/libpthread.so \
  -DYOLO_PLANAR_SLAM_VERSION=${YOLO_PLANAR_SLAM_VERSION} \
  ..
make -j
```
