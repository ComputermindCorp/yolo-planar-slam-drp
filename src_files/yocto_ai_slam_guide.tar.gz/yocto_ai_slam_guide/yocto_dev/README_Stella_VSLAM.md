# stella_vslam動作マニュアル

## 前提条件

- [SDカード作成マニュアル](README_SD_Image.md)を読み終わっていること
- [SDカード作成マニュアル](README_SD_Image.md)の前提条件を満たしていること
- [SDカード作成マニュアル](README_SD_Image.md)の作業が完了していること
- [Boot loader更新マニュアル](README_Boot_Loader.md)を読み終わっていること
- [Boot loader更新マニュアル](README_Boot_Loader.md)の前提条件を満たしていること
- [Boot loader更新マニュアル](README_Boot_Loader.md)の作業が完了していること
- [stella_vslamビルドマニュアル](README_Build_Stella_VSLAM.md)を読み終わっていること
- [stella_vslamビルドマニュアル](README_Build_Stella_VSLAM.md)の前提条件を満たしていること
- [stella_vslamビルドマニュアル](README_Build_Stella_VSLAM.md)の作業が完了していること
- V2xボードの`$HOME/stella_vslam_examples/yolox_cam`にDRP-AI TVMのYOLOX-Sのファイル一式（`yolox_cam`）が配置されていること

## USBカメラの接続確認

使用するUSBカメラを、V2xボードのUSBのポートに接続する。  
V2xボード上で以下のコマンドを実行し、USBカメラが正しく接続されているのかを確認する。

```shell
lsusb
```

上記のコマンドを実行すると、USB接続されているデバイスの一覧が表示される。

ELPカメラの場合は、一覧の中に、vendor idが`32e4`のデバイスがあることを確認する。  
USBカメラが正しく接続されている場合は、例えば以下のように表示される。

```shell
Bus 002 Device 002: ID 32e4:0144 Global Shutter Camera Global Shutter Camera
```

USBカメラがUSB接続されているデバイスの一覧に表示されていない場合、USBカメラがV2xボードのUSBポートに正しく接続されていることを確認し、再起動を行った上で再度確認を行う。

## ビルド済みのstella_vslamの配置

[stella_vslamビルドマニュアル](README_Build_Stella_VSLAM.md)の`stella_vslamのビルド`までのビルド生成物のうち、以下のディレクトリをV2xボード上の`$HOME/local/`以下にコピーする。

- /yocto_rzv2x_ver1_workdir/local/lib

[stella_vslamビルドマニュアル](README_Build_Stella_VSLAM.md)の`stella_vslam_examplesのビルド`のビルド生成物のうち、以下のディレクトリをV2xボード上の`$HOME/stella_vslam_examples/`以下にコピーする。

- /yocto_rzv2x_ver1_workdir/stella_vslam_examples/build

## LD_LIBRARY_PATHの設定

V2xボード上で以下のコマンドを実行し、ホームディレクトリ以下のstella_vslamの依存ライブラリがリンクされるようにする。

```shell
export LD_LIBRARY_PATH=~/local/lib:$LD_LIBRARY_PATH
```

V2xボード上で以下のコマンドを実行し、意図した通りにリンクされているのかを確認する。

```shell
/lib64/ld-linux-aarch64.so.1 --list ~/stella_vslam_examples/build/run_tum_rgbd_slam | \
  grep -E 'vslam|g2o|socket_publisher|tvm|yaml-cpp|sioclient|fbow'
```

以下のように、stella_vslamのライブラリのリンク先が`/home/root`以下のファイルとなっていれば問題ない。

```shell
        libsocket_publisher.so => /home/root/local/lib/libsocket_publisher.so (0x0000ffff93c2b000)
        libstella_vslam.so => /home/root/local/lib/libstella_vslam.so (0x0000ffff938ce000)
        libyaml-cpp.so.0.8 => /usr/lib64/libyaml-cpp.so.0.8 (0x0000ffff93856000)
        libsioclient.so.1 => /usr/lib64/libsioclient.so.1 (0x0000ffff93390000)
        libg2o_solver_csparse.so => /home/root/local/lib/libg2o_solver_csparse.so (0x0000ffff92c10000)
        libfbow.so.0.0 => /home/root/local/lib/libfbow.so.0.0 (0x0000ffff92be4000)
        libtvm_runtime.so => /usr/lib64/libtvm_runtime.so (0x0000ffff929dd000)
        libg2o_core.so => /home/root/local/lib/libg2o_core.so (0x0000ffff9296b000)
        libg2o_stuff.so => /home/root/local/lib/libg2o_stuff.so (0x0000ffff9293e000)
        libg2o_csparse_extension.so => /home/root/local/lib/libg2o_csparse_extension.so (0x0000ffff92041000)
```

以下のようにerrorが出た場合には、意図したライブラリにリンクされていない。  
手順を再確認する必要がある。

```shell
/home/root/stella_vslam_examples/build/run_tum_rgbd_slam: error while loading shared libraries: libsocket_publisher.so: cannot open shared object file: No such file or directory
```

同様に、V2xボード上で以下のコマンドを実行し、意図した通りにリンクされているのかを確認する。

```shell
/lib64/ld-linux-aarch64.so.1 --list ~/local/lib/libstella_vslam.so | \
  grep -E 'vslam|g2o|socket_publisher|tvm|yaml-cpp|sioclient|fbow'
```

以下のように、stella_vslamのライブラリのリンク先が`/home/root`以下のファイルとなっていれば問題ない。

```shell
        libyaml-cpp.so.0.8 => /usr/lib64/libyaml-cpp.so.0.8 (0x0000ffffa79a7000)
        libg2o_solver_csparse.so => /home/root/local/lib/libg2o_solver_csparse.so (0x0000ffffa781b000)
        libfbow.so.0.0 => /home/root/local/lib/libfbow.so.0.0 (0x0000ffffa77ef000)
        libtvm_runtime.so => /usr/lib64/libtvm_runtime.so (0x0000ffffa75e8000)
        libg2o_core.so => /home/root/local/lib/libg2o_core.so (0x0000ffffa7547000)
        libg2o_stuff.so => /home/root/local/lib/libg2o_stuff.so (0x0000ffffa751a000)
        libg2o_csparse_extension.so => /home/root/local/lib/libg2o_csparse_extension.so (0x0000ffffa6703000)
```

以下のようにerrorが出た場合には、意図したライブラリにリンクされていない。  
手順を再確認する必要がある。

```shell
/home/root/local/lib/libstella_vslam.so: error while loading shared libraries: libg2o_solver_csparse.so: cannot open shared object file: No such file or directory
```

## 実行

単眼モードで`rgbd_dataset_freiburg3_walking_halfsphere`を使用する場合の設定ファイルは`~/stella_vslam/example/tum_rgbd/TUM_RGBD_mono_3.yaml`にある。  
ステレオモードで`V1_01_easy`を使用する場合の設定ファイルは`~/stella_vslam/example/euroc/EuRoC_stereo.yaml`にある。  
RGB-Dモードで`rgbd_dataset_freiburg3_walking_halfsphere`を使用する場合の設定ファイルは`~/stella_vslam/example/tum_rgbd/TUM_RGBD_rgbd_3.yaml`にある。

OpenCVAを使用する場合には`OpenCVA`のすべての項目を`true`を設定する。  
OpenCVAを使用しない場合には`OpenCVA`のすべての項目を`false`を設定する。  
なお、OpenCVAのアルゴリズムごとに`true`と`false`を個別に設定して実行することは想定されていない。  
例えば`resize`のみを`true`に設定し、他のアルゴリズムを`false`に設定することは想定されていない。

DRPドライバネイティブ実装を使用する場合には`DRP-Driver-Native`の以下の項目を`true`を設定する。

- resize
- gaussian_blur
- orb_descriptors

なお、DRPドライバネイティブ実装のSLAM組み込み用のFASTを使用する場合には`DRP-Driver-Native`の`slamfast`も`true`に設定する。  
もしくは、DRPドライバネイティブ実装のCVアセット用のFASTを使用する場合には`DRP-Driver-Native`の`cvfast`も`true`に設定する。  
使用しない方のFASTの項目は`false`に設定する。

DRPドライバネイティブ実装を使用しない場合には`DRP-Driver-Native`のすべての項目を`false`に設定する。  
なお、FASTの項目を除いて、DRPドライバネイティブ実装のアルゴリズムごとに`true`と`false`を個別に設定して実行することは想定されていない。  
例えば`resize`のみを`true`に設定し、他のアルゴリズムを`false`に設定することは想定されていない。

DRP-AIを使用する場合には`DRP-AI`の`use_yolo`を`true`に設定する。  
DRP-AIを使用しない場合には`DRP-AI`の`use_yolo`を`false`に設定する。

なお、同一のアルゴリズムについて、OpenCVAとDRPドライバネイティブ実装の両方で`true`が設定されている場合にはOpenCVAが使用される。

中間データのダンプを行う場合には`Debug`の`use_dump`を`true`に設定する。  
中間データのダンプを行わない場合には`Debug`の`use_dump`を`false`に設定する。

ヴィジュアライザを使用する場合に、描画するフレーム画像の下部に`tracking time`を出力したい場合には`Viewer`の`draw_tracking_time`を`true`に設定する。  
出力しない場合には`Viewer`の`draw_tracking_time`を`false`に設定する。

SocketViewerを使用する場合は、環境変数の`VIEWER`に`socket_publisher`を設定する。  
ヴィジュアライザを使用しない場合は、環境変数の`VIEWER`に`none`を設定する。

単眼で`rgbd_dataset_freiburg3_walking_halfsphere`を使用する場合は、V2xボード上で以下のコマンドを実行する。

```shell
cd ~/stella_vslam_examples
~/stella_vslam_examples/build/run_tum_rgbd_slam \
    --vocab ~/stella_vslam_examples/orb_vocab.fbow \
    --data-dir /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/ \
    --config ~/stella_vslam/example/tum_rgbd/TUM_RGBD_mono_3.yaml \
    --no-sleep \
    --auto-term \
    --viewer ${VIEWER:?} \
    --eval-log-dir ~/stella_vslam_examples/eval/
```

ステレオで`V1_01_easy`を使用する場合は、V2xボード上で以下のコマンドを実行する。

```shell
cd ~/stella_vslam_examples
~/stella_vslam_examples/build/run_euroc_slam \
    --vocab ~/stella_vslam_examples/orb_vocab.fbow \
    --data-dir /opt/dataset/V1_01_easy/mav0/ \
    --config ~/stella_vslam/example/euroc/EuRoC_stereo.yaml \
    --no-sleep \
    --auto-term \
    --viewer ${VIEWER:?} \
    --eval-log-dir ~/stella_vslam_examples/eval/
```

RGB-Dで`rgbd_dataset_freiburg3_walking_halfsphere`を使用する場合は、V2xボード上で以下のコマンドを実行する。

```shell
cd ~/stella_vslam_examples
~/stella_vslam_examples/build/run_tum_rgbd_slam \
    --vocab ~/stella_vslam_examples/orb_vocab.fbow \
    --data-dir /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/ \
    --config ~/stella_vslam/example/tum_rgbd/TUM_RGBD_rgbd_3.yaml \
    --no-sleep \
    --auto-term \
    --viewer ${VIEWER:?} \
    --eval-log-dir ~/stella_vslam_examples/eval/
```

単眼でELPカメラを使用する場合は、V2xボード上で以下のコマンドを実行する。  
ここでは設定ファイルに`stella_vslam/example/cam/ELP_rel.yaml`を指定している。

```shell
cd ~/stella_vslam_examples
~/stella_vslam_examples/build/run_camera_slam \
    --vocab ~/stella_vslam_examples/orb_vocab.fbow \
    --number 0 \
    --config ~/stella_vslam/example/cam/ELP_rel.yaml \
    --viewer ${VIEWER:?} \
    --eval-log-dir ~/stella_vslam_examples/eval/
```

SocketViewerを使用する場合はV2xボード上の2つ目のterminalで以下を実行する。

```shell
cd $HOME/socket_viewer
node app.js
```

評価結果は`~/stella_vslam_examples/eval`以下に格納される。

## メモリアドレスマップ

DRPのメモリアドレスマップは以下の通り。

| メモリ種別 | 開始アドレス    | サイズ     | 内容                              |
|-------|-----------|--------:|-----------------------------------------------|
| DRAM  | 8B98_0000 | A0      | ディスクリプタ                                 |
| DRAM  | 8BC0_0000 | 18_0000 | コンフィギュレーションコード                    |
| DRAM  | 8B80_0000 | 40_0000 | 7x7のGaussianBlurの入力                       |
| DRAM  | 8B80_0000 | 40_0000 | FASTの入力                                    |
| DRAM  | 8B00_0000 | 40_0000 | compute_orb_descriptorsの入力（画像）          |
| DRAM  | 8BA0_0000 | 2_0000  | compute_orb_descriptorsの入力（特徴点配列）    |
| DRAM  | 8B80_0000 | 40_0000 | resizeの入力                                  |
| DRAM  | 8B00_0000 | 40_0000 | 7x7のGaussianBlurの出力                       |
| DRAM  | 8B40_0000 | 40_0000 | FASTの出力（特徴点配列）                       |
| DRAM  | 8BD8_0000 | 2       | FASTの出力（特徴点配列のサイズ）                |
| DRAM  | 8BB0_0000 | 5_0000  | compute_orb_descriptorsの出力（特徴点配列）    |
| DRAM  | 8B80_0000 | 40_0000 | resizeの出力                                  |
| DRAM  | 9200_0000 |         | `ioctl(DRP_SET_SEQ)`用の領域                  |
