# 補足資料

2024年5月時点の実装について、補足情報を記載する。

## 開発系統

本案件で開発した、主なSLAMプログラムの開発系統は以下の通り。

| リポジトリ名           | 開発系統                 | 画像入力のワークアラウンドは適用済みか？ | 備考         |
|------------------|----------------------|----------------------|------------|
| orb-slam2        | main                 | -                    | 2023年7月に開発停止、V2xボード非対応 |
| yolo-planar-slam | main                 | Yes                  |            |
| yolo-planar-slam | opencva              | **No**               | 2023年10月に開発停止、OpenCVA差し替え版 |
| yolo-planar-slam | serialize-drp-module | **No**               | 直列動作版      |
| stella_vslam     | main                 | Yes                  |            |
| stella_vslam     | serialize-drp-module | **No**               | 直列動作版      |

OpenCVA差し替え版とは、BitBakeのレシピとしてSLAMプログラムをビルドするために、GitHubのオリジナル実装に対してパッチファイルを適用して本案件のSLAMプログラム相当に変更するようにした実装である。  
なお、

直列動作版とは、`/dev/drp1`を使用せず、DRP実装とDRP-AI実装の両方を`/dev/drpai0`で実行することを仮定した性能評価用の実装である。  
このとき、DRP実装とDRP-AI実装は並列に実行されないように排他制御される。

## 動作モードの対応状況

本案件で開発した、主なSLAMプログラムの動作モードは以下の通り。

| リポジトリ名           | 単眼モード | ステレオモード | RGB-Dモード |
|------------------|-------|---------|----------|
| yolo-planar-slam | 可能    | **非対応** | 可能       |
| stella_vslam     | 可能    | 可能      | 可能       |

## DRP連携

本案件で開発した、主なSLAMプログラムのDRP処理の対応状況は以下の通り。

| リポジトリ名           | アルゴリズム名                 | OpenCVAモードの動作 | DRPドライバネイティブモードの動作 | CPUモードの動作 |
|------------------|-------------------------|---------------|--------------------|-----------|
| yolo-planar-slam | resize                  | OpenCVA       | DRPドライバネイティブ       | CPU       |
| yolo-planar-slam | GaussianBlur            | OpenCVA※1    | DRPドライバネイティブ       | CPU       |
| yolo-planar-slam | FAST                    | OpenCVA※2    | DRPドライバネイティブ       | CPU       |
| yolo-planar-slam | computeOrbDescriptors   | **DRPドライバネイティブ**  | DRPドライバネイティブ       | CPU       |
| stella_vslam     | resize                  | OpenCVA       | DRPドライバネイティブ       | CPU       |
| stella_vslam     | GaussianBlur            | OpenCVA※1    | DRPドライバネイティブ       | CPU       |
| stella_vslam     | FAST                    | OpenCVA※2    | DRPドライバネイティブ       | CPU       |
| stella_vslam     | compute_orb_descriptors | **CPU**           | DRPドライバネイティブ       | CPU       |

※1 OpenCVAのGaussianBlurでは入力画像の縦サイズ、横サイズのいずれも偶数の場合のみDRPが使用されるため、上記のSLAMプログラムではDRPが使用されない可能性がある  
※2 OpenCVAのFASTでは入力画像の縦サイズ、横サイズのいずれも16以上の偶数の場合のみDRPが使用されるため、上記のSLAMプログラムではDRPが使用されない可能性がある

## DRP-AI連携

本案件で開発した、主なSLAMプログラムのDRP-AIのYOLO処理の対応状況は以下の通り。

| リポジトリ名           | YOLO   | YOLOの影響範囲 |
|------------------|--------|-----------|
| orb-slam2        | 無し     | -         |
| yolo-planar-slam | あり     | 特徴点間引きに使用 |
| stella_vslam     | 切り替え可能 | 描画のみに使用   |

## 最速動作の実行条件

### YOLO無し

stella_vslamについては、[Stella VSLAM+AI連携アプリ 実装・評価報告書](./report/step3/Stella%20VSLAM+AI連携アプリ実装・評価報告書.md#7-stella_vslamの画像処理のスレッド分割)の`7 stella_vslamの画像処理のスレッド分割`の評価結果が最も高速に動作している。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2428
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：無効
- FASTのDRP実装：SLAM組みこみ用のFAST
- compute_orb_descriptorsのDRP実装：FP16
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

平均処理時間は`55.07`\[ms/frame\]である。

### YOLOあり

Yolo-Planar-SLAMについては、[Stella VSLAM+AI連携アプリ 実装・評価報告書](./report/step2/Stella%20VSLAM+AI連携アプリ実装・評価報告書.md#3-バージョン1移行)の`3 バージョン1移行`の評価結果が最も高速に動作している。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1000
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- compute_orb_descriptorsのDRP実装：FP32
- DRP-AIオブジェクトファイル：RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-bsp`

平均処理時間は`68.277`\[ms/frame\]である。

stella_vslamについては、[Stella VSLAM+AI連携アプリ 実装・評価報告書](./report/step3/Stella%20VSLAM+AI連携アプリ実装・評価報告書.md#92-単眼--slam組み込み用のfast)の`9.2 単眼 + SLAM組み込み用のFAST`の評価結果が最も高速に動作している。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2428
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：有効
- FASTのDRP実装：SLAM組みこみ用のFAST
- compute_orb_descriptorsのDRP実装：FP16
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

平均処理時間は`68.156`\[ms/frame\]である。

## DRP実装のコンフィギュレーションコード

本案件で実装した、Yolo-Planar-SLAMおよびstella_vslam向けのDRP実装は以下の通り。  
なお、fastについてはCVアセット用のFAST（drp_cv_lib）とSLAM組み込み用のFAST（yolo-planar-slam、stella_vslam）が混在しているため、注意する。  
また、SLAM組み込み用のFASTについてはyolo-planar-slamの実装とstella_vslamの実装で動作原理が異なるため、注意する。

| No | 提供者 | リポジトリ名           | DRP実装名          | コンフィギュレーションコードのMD5ハッシュ値          | 備考             |
|----|-----|------------------|-----------------|----------------------------------|----------------|
| 1  | FAT | drp_cv_lib       | resize          |                                  | 未使用           |
| 2  | FAT | drp_cv_lib       | gaussian_blur   | a7f6484990d8c1861558ca2b5303d129 |                |
| 3  | FAT | drp_cv_lib       | orb_descriptors | 61eb17382e9aea44a1fd7c21de335ff3 | FP16実装         |
| 4  | FAT | drp_cv_lib       | fast            | 51d67ecfcd2ef9a9c8fe3d40e939c752 | 入力画像の制約条件緩和版   |
| 5  | FAT | drp_cv_lib       | fast            | 528d825a8a61b51837c53ac35d1cdcd4 |                |
| 6  | FAT | yolo-planar-slam | fast            |                                  | SLAM組み込み用のFAST、未使用 |
| 7  | FAT | stella_vslam     | fast            | 3ee562fe9283071f0abe5be168f063e0 | SLAM組み込み用のFAST |
| 8  | REL | drp_cv_lib       | resize          | af6838be44807f1033ba267c9e3359a1 |                |
| 9  | REL | drp_cv_lib       | gaussian_blur   | 695be7c77f4522f1a2260a2aa5f8c19c |                |
| 10 | REL | drp_cv_lib       | orb_descriptors | f26481fc5c486f96bb5afbe1d59e78c1 | FP32実装         |
| 11 | REL | yolo-planar-slam | fast            | 9402233cc529b5517d5ce008e3a94bab | SLAM組み込み用のFAST |

drp_cv_libリポジトリのDRP実装のAPI仕様については、drp_cv_libリポジトリの`drp/README.md`を参照すること。  
yolo-planar-slamリポジトリのfastのAPI仕様については、yolo-planar-slamリポジトリの`drp/fast/README.md`を参照すること。  
stella_vslamリポジトリのfastのAPI仕様については、stella_vslamリポジトリの`drp/fast/README.md`を参照すること。

## SLAMで使用するDRP実装

Yolo-Planar-SLAMとstella_vslamで使用しているDPR実装は以下の通り。  
なお、`DRP実装のコンフィギュレーションコード`の表の番号との対応を記載した。  
また、CVアセット用のFAST（drp_cv_lib）はcvfast、SLAM組み込み用のFAST（yolo-planar-slam、stella_vslam）はslamfastと表記しているため、注意する。

| リポジトリ名           | resize  | gaussian_blur | orb_descriptors | cvfast  | slamfast |
|------------------|---------|---------------|-----------------|---------|----------|
| yolo-planar-slam | No.8 | No.9       | No.10        | No.4 | No.11 |
| stella_vslam     | No.8 | No.2       | No.3         | No.5 | No.7  |

## DRP連携のポーリング周期

Yolo-Planar-SLAMとstella_vslamのCPU-DRP連携における、終了判定のポーリング周期は以下の通り。  
なお、CVアセット用のFAST（drp_cv_lib）はcvfast、SLAM組み込み用のFAST（yolo-planar-slam、stella_vslam）はslamfastと表記しているため、注意する。

| リポジトリ名           | resize | gaussian_blur | orb_descriptors | cvfast | slamfast | DRP-AI Translator | 備考             |
|------------------|-------:|--------------:|----------------:|-------:|---------:|------------------:|----------------|
| yolo-planar-slam | 0.0    | 0.0           | 0.0             | 0.0    | 0.0      | 1.0               | フレーム並列化から派生した実装 |
| stella_vslam     | 0.0    | **0.5**       | **0.5**         | 0.0    | 0.0      | -                 |                            |

## DRP実装の仕様・性能

### 実装仕様

本案件で実装した、Yolo-Planar-SLAMおよびstella_vslam向けのDRP実装は以下の通り。  
なお、fastについてはCVアセット用のFAST（drp_cv_lib）とSLAM組み込み用のFAST（yolo-planar-slam、stella_vslam）が混在しているため、注意する。  
また、SLAM組み込み用のFASTについてはyolo-planar-slamの実装とstella_vslamの実装で動作原理が異なるため、注意する。

| No | 提供者 | リポジトリ名           | DRP実装名          | OpenCV実装と厳密に一致する？ | 反復合成済み？ | Musketeerバージョン | 備考             |
|----|-----|------------------|-----------------|-------------------|---------|----------------|----------------|
| 1  | FAT | drp_cv_lib       | resize          | No                | No      |                | 未使用          |
| 2  | FAT | drp_cv_lib       | gaussian_blur   | No                | Yes     | Ver.20230724   |                |
| 3  | FAT | drp_cv_lib       | orb_descriptors | No                | Yes     | Ver.20230724   | FP16実装         |
| 4  | FAT | drp_cv_lib       | fast            | Yes               | No      | Ver.20230724   | 入力画像の制約条件緩和版   |
| 5  | FAT | drp_cv_lib       | fast            | Yes               | No      | Ver.20230123   |                |
| 6  | FAT | yolo-planar-slam | fast            | -                 | No      |                | SLAM組み込み用のFAST、未使用 |
| 7  | FAT | stella_vslam     | fast            | -                 | Yes     | Ver.20230724   | SLAM組み込み用のFAST |
| 8  | REL | drp_cv_lib       | resize          | No                | 不明      |                |                |
| 9  | REL | drp_cv_lib       | gaussian_blur   | No                | 不明      |                |                |
| 10 | REL | drp_cv_lib       | orb_descriptors | No                | 不明      |                | FP32実装         |
| 11 | REL | yolo-planar-slam | fast            | Yes               | 不明      |                | SLAM組み込み用のFAST |

### RTレベルシミュレーションの性能評価の結果

`実装仕様`の表のうち、FAT提供のDRP実装についてRTレベルシミュレーションの性能評価の結果は以下の通り。  
なお、fastについてはCVアセット用のFAST（drp_cv_lib）とSLAM組み込み用のFAST（stella_vslam）が混在しているため、注意する。  

| リポジトリ名           | DRP実装                        | Exec   | Hold  | 動作周波数（MHz） | 処理時間（us） | 備考 |
|--------------------|------------------------------|-------:|------:|-----------:|---------:|-----|
| drp_cv_lib       | gaussian_blur        | 107408 | 18416 | 314.387    | 400.2    |      |
| drp_cv_lib       | fast                 | 6177   | 98    | 315.128    | 19.9     |      |
| drp_cv_lib       | orb_descriptors      | 220105 | 15962 | 216.381    | 1091.0   | FP32実装 |
| drp_cv_lib       | orb_descriptors      | 60235  | 10651 | 344.466    | 205.8    | FP16実装 |
| stella_vslam     | fast                 | 755229 | 5843  | 411.164    | 1851.0   |      |

### 入出力仕様

`実装仕様`の表に記載したDRP実装について入力チャネルで読み込むデータは以下の通り。  
ここで、ディスクリプタ入力するパラメータの読み込みにのみ使用しているチャネルには`desc`と記載した。  
なお、fastについてはCVアセット用のFAST（drp_cv_lib）とSLAM組み込み用のFAST（yolo-planar-slam、stella_vslam）が混在しているため、注意する。  

| リポジトリ名           | DRP実装名          | CH0  | CH1 | CH2 | CH3 | 備考             |
|------------------|-----------------|------|-----|-----|-----|----------------|
| drp_cv_lib       | resize          | desc | 画像  | 画像  | -   | 画像は2チャネルで分割して読み込む               |
| drp_cv_lib       | gaussian_blur   | desc | 画像  | -   | -   |                |
| drp_cv_lib       | orb_descriptors | desc | 画像  | 特徴点配列 | 画像  | FP16実装、画像は2チャネルで分割して読み込む         |
| drp_cv_lib       | fast            | desc | 画像  | -   | -   | 入力画像の制約条件緩和版   |
| drp_cv_lib       | fast            | desc | 画像  | -   | -   |                |
| yolo-planar-slam | fast            | desc | 画像  | -   | -   | SLAM組み込み用のFAST |
| stella_vslam     | fast            | desc | 画像  | -   | -   | SLAM組み込み用のFAST |

同じく、出力チャネルで書き込むデータは以下の通り。

| リポジトリ名           | DRP実装名          | CH0    | CH1    | CH2 | CH3 | 備考             |
|------------------|-----------------|--------|--------|-----|-----|----------------|
| drp_cv_lib       | resize          | -      | -      | 画像  | -   |                |
| drp_cv_lib       | gaussian_blur   | 画像     | -      | -   | -   |                |
| drp_cv_lib       | orb_descriptors | ORB特徴量 | -      | -   | -   | FP16実装         |
| drp_cv_lib       | fast            | 特徴点配列  | 特徴点の個数 | -   | -   | 入力画像の制約条件緩和版   |
| drp_cv_lib       | fast            | 特徴点配列  | 特徴点の個数 | -   | -   |                |
| yolo-planar-slam | fast            | 特徴点配列  | 特徴点の個数 | -   | -   | SLAM組み込み用のFAST |
| stella_vslam     | fast            | 特徴点配列  | 特徴点の個数 | -   | -   | SLAM組み込み用のFAST |

`実装仕様`の表に記載したDRP実装について入力チャネルと、その読み込みバイト数（`STP_WIDTH`）は以下の通り。  
ここで、ディスクリプタ入力するパラメータの読み込みにのみ使用しているチャネルには`desc`と記載した。  
なお、fastについてはCVアセット用のFAST（drp_cv_lib）とSLAM組み込み用のFAST（yolo-planar-slam、stella_vslam）が混在しているため、注意する。  

| リポジトリ名           | DRP実装名          | CH0  | CH1 | CH2 | CH3 | 備考             |
|------------------|-----------------|-----:|----:|----:|----:|----------------|
| drp_cv_lib       | resize          | desc | 2   | 2   | -   |                |
| drp_cv_lib       | gaussian_blur   | desc | 4   | -   | -   |                |
| drp_cv_lib       | orb_descriptors | desc | 8   | 8   | 8   | FP16実装         |
| drp_cv_lib       | fast            | desc | 1   | -   | -   | 入力画像の制約条件緩和版   |
| drp_cv_lib       | fast            | desc | 1   | -   | -   |                |
| yolo-planar-slam | fast            | desc | 1   | -   | -   | SLAM組み込み用のFAST |
| stella_vslam     | fast            | desc | 1   | -   | -   | SLAM組み込み用のFAST |

同じく、出力チャネルと、その書き込みバイト数（`STP_WIDTH`）は以下の通り。  

| リポジトリ名           | DRP実装名          | CH0 | CH1 | CH2 | CH3 | 備考             |
|------------------|-----------------|-----:|----:|----:|----:|----------------|
| drp_cv_lib       | resize          | -   | -   | 4   | -   |                |
| drp_cv_lib       | gaussian_blur   | 4   | -   | -   | -   |                |
| drp_cv_lib       | orb_descriptors | 1   | -   | -   | -   | FP16実装         |
| drp_cv_lib       | fast            | 5   | 2   | -   | -   | 入力画像の制約条件緩和版   |
| drp_cv_lib       | fast            | 5   | 2   | -   | -   |                |
| yolo-planar-slam | fast            | 5   | 2   | -   | -   | SLAM組み込み用のFAST |
| stella_vslam     | fast            | 5   | 2   | -   | -   | SLAM組み込み用のFAST |

なお、上記の表のすべてのDRP実装について、画像読み込み処理は`DII=1`のフォールディングループで実行される。  
ただし、orb_descriptorsのORB特徴量計算は乗算器が不足するため`DII=4`のフォールディングループで実行される。

## SLAM動作原理

### マルチスレッド動作

Yolo-Planar-SLAMのマルチスレッドの動作原理については、`ai_slam_guide`の納品ドキュメントの以下の章に記載がある。

- `report/step5`ディレクトリの、`SLAM/CNN連携アプリ（Yocto）実装・評価報告書`の`5.2 マルチスレッド動作の概要`

記載されている内容の一部を以下に示す。  
ただし、以下は**2023年9月時点の内容である点に注意する。**  
特に、投機実行と画像入力のワークアラウンドに関する排他制御については記載されていない点に注意する。  
また、stella_vslamで行われている排他制御とは異なる点について、注意する。

---

まず、オリジナルのYolo-Planar-SLAMに対して追加したスレッドを以下の図に示す。

![スレッド分割の概要](image/multi_thread/threads.png)

Image loadingスレッドは、Trackingスレッドの中の画像読み込みの処理を別スレッドに分割したものである。  
Image processingスレッドは、Trackingスレッドの中の画像処理を別スレッドに分割したものである。  
Inferenceスレッドは、DRP-AI TranslatorのYOLOモデルを使用して、CPU-DRP-AI連携を行うために追加したスレッドである。

Image processingスレッドのブロックは、直前のTrackingスレッドの結果で決定される`max_features`の値に依存しない前半処理と、依存する後半処理に2分割している。

キーフレームの挿入が発生した場合のスレッド間の入出力について以下の図に示す。

![キーフレーム挿入が発生した場合](image/multi_thread/insert_keyframe.png)

キーフレームの挿入が発生した場合には、Local mappingスレッドとLoop closingスレッドがkickされる。

並列動作しないと仮定した場合の、スレッド間の排他制御とタイムチャートを以下の図に示す。

![並列動作しない場合](image/multi_thread/serial.png)

各スレッドの排他制御用の変数の真偽値によって、各スレッドの動作が制御されていることがわかる。

並列動作する場合の、スレッド間の排他制御とタイムチャートを以下の図に示す。

![並列動作する場合](image/multi_thread/parallel.png)

並列動作しないと仮定した場合と比較して、点線で示した矢印の部分の時間が短縮できていることがわかる。

### YOLOのバウンディングボックスによる特徴点間引き

Yolo-Planar-SLAMの特徴点間引きの動作原理については、`ai_slam_guide`の納品ドキュメントの以下の章に記載がある。

- `report/step2`ディレクトリの、`SLAM/CNN連携アプリ実装報告書`の`12 Yolo-Planar-SLAMのYOLO連携の組み替え検討`

記載されている「特徴点の間引き処理を組み替え」については、2024年5月時点のYolo-Planar-SLAMに適用されている。

記載されている内容の一部を以下に示す。  
ただし、以下は**2022年11月時点の内容である点に注意する。**

---

最大特徴点数を`5000`に設定しないと十分な精度で単眼SLAMが実行できないため、最大特徴点数は`1000`から`5000`に変更している。  
Yolo-Planar-SLAMの最大特徴点の設定値を大きくすることによる処理時間の増加を軽減するために、YOLOで得られたバウンディングボックスによる特徴点の間引き処理の組み替えに関する検討内容について記載する。

単眼の場合に最大特徴点数を減らすための対応案には、以下の候補がある。

1. 最大特徴点数が十分に小さくてもSLAMできるデータセットを探す
    - 十分にカメラが移動している必要がある
    - 十分に人が映っている必要がある
    - Loop closingが含まれていない必要がある（軌跡出力のため）
2. Yolo-Planar-SLAMの、YOLOの検出結果による特徴点の間引き処理を組み替える
    - 組み替え前：`DistributeOctTree` → `RemoveMovingKeyPoints` → `computeOrbDescriptors`
    - 組み替え後：`RemoveMovingKeyPoints` → `DistributeOctTree` → `computeOrbDescriptors`

ここでは2について説明を行う。  
`ORBextractor::DistributeOctTree`では、最大特徴点数以下になるまで特徴点を間引く。  
`Frame::RemoveMovingKeyPoints`では、人のバウンディングボックスの中の特徴点をすべて間引く。

例えば、画像に占める人のバウンディングボックスの面積比率が全体の半分である場合を考える。  
`組み替え前`ではトラッキング対象となる`computeOrbDescriptors`の入力特徴点の個数は、典型的には最大特徴点数の半分になることが想定される。  
`組み替え後`ではトラッキング対象となる`computeOrbDescriptors`の入力特徴点の個数は、最大特徴点数に近い個数になることが想定される。

以下の例では`N`をその時点でのトラッキング候補の特徴点の個数、最大特徴点数を`16`としている。

組み替え前の概要の図を以下に示す。

![組み替え前](image/filter/before.png)

上記の場合ではFASTで検出できた特徴点は`N = 29`個、`ORBextractor::DistributeOctTree`による間引き処理で間引かれなかった特徴点は`N = 16`個、人のバウンディングボックスを使用して間引かれなかった特徴点は`N = 13`個となっている。

組み替え後の概要の図を以下に示す。

![組み替え後](image/filter/after.png)

上記の場合ではFASTで検出できた特徴点は`N = 29`個、人のバウンディングボックスを使用して間引かれなかった特徴点は`N = 24`個、そこから`ORBextractor::DistributeOctTree`による間引き処理で間引かれなかった特徴点は`N = 16`個となっている。

上記の例では、組み替え後の実装の方がトラッキングに使用できる特徴点の個数が多いことがわかる。  
また、人のバウンディングボックスが大きいほど、典型的には組み替え前と後のトラッキング可能な特徴点の個数の差は大きくなると考えられる。  
したがって、組み替え後の方がトラッキングに有利であると想定される。

### CVアセット用のFAST

Yolo-Planar-SLAMのCVアセット用のFASTの動作原理については、`ai_slam_guide`の納品ドキュメントの以下の章に記載がある。

- `report/step5`ディレクトリの、`SLAM/CNN連携アプリ（Yocto）実装・評価報告書`の`13.2.1.7 FASTの実行回数について`

記載されている内容の一部を以下に示す。  
ただし、以下は**2023年9月時点の内容である点に注意する。**

---

DRPドライバネイティブ動作の場合のDRP/DRP-AIプログラムの実行回数を以下に示す。  
CVアセット用のFASTについては入力画像のサイズによって実行回数が変わるため、ここでは`640x480`の場合について記載した。  
なお、TUMデータセットとELPカメラの画像サイズは`640x480`である。

![DRP/DRP-AIプログラムの実行回数](image/cell/count_0.png)

SLAM組みこみ用のFASTの場合では1フレームあたりのDRPプログラムの実行回数は`7 + 8 + 8 + 8 = 31`回となる。  
CVアセット用のFASTの場合では1フレームあたりのDRPプログラムの実行回数は`7 + 8 + 815 + 8 = 838`回となる。

同様にCPU動作、OpenCVA動作動作の場合のDRP/DRP-AIプログラムの実行回数を以下に示す。

![CPU/OpenCVAプログラムの実行回数](image/cell/count_1.png)

CVアセット用のFASTの場合は閾値を2つ指定できるため、`threshold=20`と`threshold=7`の実行を1度に行える。  
一方でCPU（OpenCV）のFASTとOpenCVAのFASTでは閾値を1つだけ指定するため、`threshold=20`と`threshold=7`の最大で2回実行する必要がある。

入力画像のサイズが`640x480`である場合について、各レベルのセル画像のサイズを整理した結果を以下に示す。

![VGA入力の場合のセル画像のサイズ](image/cell/cell_size.png)

例えば、5レベルの画像のサイズは`257x193`となり、これを横方向に7分割、縦方向に5分割してセル画像を作成する。  
セル画像1枚あたりのサイズは`39x39`となる。  
ただし、右端、下端、右下端については入力画像のサイズによってはセル画像のサイズが異なることがある。

また、2023年9月時点ではOpenCVAのFASTは入力画像の縦横サイズがいずれも偶数の場合のみDRPで実行可能である。  
従って本案件のYolo-Planar-SLAMでOpenCVAを有効にした場合も、ほとんどのケースではOpenCVAのFASTではDRPは使用されていない。

セル画像の分割は、以下の図のようにオーバーラップを含めて行われる。

![セル画像のオーバーラップ箇所](image/cell/overlap.png)

例えば、あるセル画像Aの右端の画素領域は、セル画像Aの右となりのセル画像Bの左端の画像領域と重複する。  
オーバーラップする画素領域の幅は縦横ともに幅6pixelで指定されている。  
これは、オリジナルのORB-SLAM2およびYolo-Planar-SLAMの実装を踏襲しているためである。

## バージョン

本案件で開発した、主なSLAMプログラムのバージョンについて以下に示す。  
なお、`-opencva`がついているバージョンは、OpenCVA差し替え版（パッチ版）の開発系統である。  
また、`-serialize-drp-module`がついているバージョンは、直列動作版の開発系統である。

| バージョン                | 説明                                        | 日付         |
|----------------------|-------------------------------------------|------------|
| 2.12.0               | 納品物                               | 2024/5/20  |
| 2.12.0-serialize-drp-module | 成果物                               | 2024/5/20  |
| 2.11.1               | 納品物（マニュアルの修正）                       | 2024/3/18  |
| 2.11.0               | 納品物                               | 2024/3/18  |
| 2.10.2               | 中間リリース（マニュアルの修正）                   | 2024/3/7   |
| 2.10.1               | 中間リリース（マニュアルの修正）                   | 2024/3/6   |
| 2.10.0               | 中間リリース                             | 2024/3/5   |
| 2.9.0                | 納品物                               | 2023/12/15 |
| 2.8.0                | 中間リリース（高速化対応）                      | 2023/12/6  |
| 2.7.0                | 中間リリース（YOLOモデル変更マニュアルの追加）         | 2023/11/27 |
| 2.6.0                | 中間リリース（投機実行対応）                     | 2023/11/15 |
| 2.5.1-opencva        | 中間リリース（検討会のフィードバック対応）              | 2023/10/31 |
| 2.5.0-opencva        | 中間リリース（OpenCVA差し替え版の検討会向け）         | 2023/10/24 |
| 2.4.0                | 中間リリース（resizeの不具合修正）               | 2023/10/16 |
| 2.3.0                | 納品物                               | 2023/9/21  |
| 2.2.0                | 中間リリース（Yolo-Planar-SLAMの動作確認用）     | 2023/9/14  |
| 2.1.1                | 中間リリース（手順書の修正）                  | 2023/9/8   |
| 2.1.0                | 中間リリース（Yolo-Planar-SLAMのOpenCVA動作） | 2023/9/7   |
| 2.0.0                | 中間リリース（Yolo-Planar-SLAMのα2動作）      | 2023/9/6   |
| original             | そのリポジトリをGitHubからcloneした時点のcommit id       |
