# Dockerインストールマニュアル

## 前提条件

- [DRPプログラムガイド](README.md)を読み終わっていること
- [DRPプログラムガイド](README.md)の前提条件を満たしていること
- 使用するマシンがUbuntu 18.04マシンであること

## sshサーバーの設定

ヴィジュアライザの画面をX転送する時に、通信負荷が上がりsshのセッションが切断されることを防ぐために、以下の設定を行う。

`/etc/ssh/sshd_config`をroot権限で編集する。  
例えば`vim`を使用する場合には、以下のコマンドを実行する。

```shell
sudo vim /etc/ssh/sshd_config
```

`/etc/ssh/sshd_config`にある`変更前`の記述を`変更後`のように変更する。

変更前

```shell
#ClientAliveInterval 0
```

変更後

```shell
#ClientAliveInterval 0
ClientAliveInterval 15
```

設定の変更を反映するために、以下のコマンドを実行しsshサービスを再起動する。

```shell
sudo /etc/init.d/ssh restart
```

## Dockerリポジトリの設定

以下のコマンドを実行し、必要なパッケージをインストールする。

```shell
sudo apt update
sudo apt install apt-transport-https ca-certificates curl gnupg lsb-release
```

以下のコマンドを実行し、公開鍵を登録する。

```shell
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
```

以下のコマンドを実行し、Dockerリポジトリの情報を取得する。

```shell
sudo apt update
```

## インストール

以下のコマンドを実行し、インストール可能なDocker CE（Community Edition）のバージョンを確認する。

```shell
apt-cache madison docker-ce
```

本マニュアルでは`5:20.10.6~3-0~ubuntu-bionic`をインストールするため、`5:20.10.6~3-0~ubuntu-bionic`が一覧に含まれているのかを確認する。

以下のコマンドを実行し、Docker CEをインストールする。

```shell
sudo apt install docker-ce=5:20.10.6~3-0~ubuntu-bionic docker-ce-cli=5:20.10.6~3-0~ubuntu-bionic containerd.io
```

以下のコマンドを実行し、アカウントをdockerグループに追加する。

```shell
sudo gpasswd -a $USER docker
```

実行後にterminalを閉じ、再度開きなおしてグループ設定の変更を反映する。

## 確認

以下のコマンドを実行し、意図したバージョンのDocker CEがインストールされたのかを確認する。

```shell
docker --version
```

`Docker version 20.10.6, build 370c289`と表示されることを確認する。

以下のコマンドを実行し、hell-worldコンテナを起動する。

```shell
docker run hello-world
```

正常に起動できた場合は、以下のような標準出力が表示される。

```shell
Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
    (amd64)
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which sent it
    to your terminal.

To try something more ambitious, you can run an Ubuntu container with:
 $ docker run -it ubuntu bash

Share images, automate workflows, and more with a free Docker ID:
 https://hub.docker.com/

For more examples and ideas, visit:
 https://docs.docker.com/get-started/
```

なお、初めてhello-worldコンテナを起動した時には、以下のような標準出力も表示されることがある。

```shell
Unable to find image 'hello-world:latest' locally
latest: Pulling from library/hello-world
256ab8fe8778: Pull complete
Digest: sha256:9f6ad537c5132bcce57f7a0a20e317228d382c3cd61edae14650eec68b2b345c
Status: Downloaded newer image for hello-world:latest
```

## 参考リンク

- <https://docs.docker.com/engine/install/ubuntu/>
