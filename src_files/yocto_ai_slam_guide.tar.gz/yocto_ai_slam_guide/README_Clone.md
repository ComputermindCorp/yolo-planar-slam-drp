# リポジトリのクローンマニュアル

## 前提条件

- 使用するプログラムの`動作マニュアル`を読み終わっていること
- 使用するプログラムの`動作マニュアル`の前提条件を満たしていること
- DRP評価ボードに`git`がインストールされていること
- 本案件のGitLabサーバーにSSHキーを登録済みであること

## リポジトリの指定

SLAM-YOLOv5のリポジトリをクローンする場合には以下を実行する。

```shell
REPO=slam_yolov5
```

orb-slam2_with_semantic_labellingのリポジトリをクローンする場合には以下を実行する。

```shell
REPO=orb-slam2_with_semantic_labelling
```

YOLO-Planar-SLAMのリポジトリをクローンする場合には以下を実行する。

```shell
REPO=yolo-planar-slam
```

Crowd-SLAMのリポジトリをクローンする場合には以下を実行する。

```shell
REPO=crowd-slam
```

DRP-AIを使用したサンプルプログラムのリポジトリをクローンする場合には以下を実行する。

```shell
REPO=drp_ai_lib_samples
```

## 実行手順

以下を実行し、gitの設定を行う。  
`xxx`の箇所には適切なユーザー名を、`yyy@example.com`の箇所には適切なメールアドレスを入力する。

```shell
git config --global user.name xxx
git config --global user.email yyy@example.com
```

ホームディレクトリで以下を実行し、使用するプログラムを含むリポジトリをクローンする。

```shell
cd ${HOME}
git clone --recursive git@10.166.252.135:drp-vslam/${REPO}.git
```

2022年9月20日時点のリポジトリデータを参照したい場合は以下のコマンドを実行する。

```shell
cd ${HOME}/${REPO}
git checkout 0.10.0
git submodule update --init
```
