# DRPプログラムガイド

## 1 Yocto環境でビルドしたYOLO-Planar-SLAMを使用する

### 1.1 開発者向け

[Yocto導入ガイド](yocto_dev/README.md)に手順が記載されている。

## 2 Yocto環境でビルドしたstella_vslamを使用する

### 2.1 開発者向け

[Yocto導入ガイド](yocto_dev/README.md)に手順が記載されている。

## 3 GitHubからcloneしたYOLO-Planar-SLAMをカスタマイズする

[AI+SLAM 導入・カスタマイズガイド](custom/README.md)に手順が記載されている。

## 4 Dockerをインストールする

[Dockerインストールマニュアル](README_Docker.md)に記載されている。

## 5 ROS1 noetic用のDockerイメージの作成マニュアル

[ROS1 noetic用のDockerイメージの作成マニュアル](README_Noetic.md)に記載されている。  
`4 Dockerをインストールする`の作業が完了している必要がある。

## 6 カメラキャリブレーションマニュアル

[カメラキャリブレーションマニュアル](README_Calibration_Docker.md)に記載されている。  
`5 ROS1 noetic用のDockerイメージの作成マニュアル`の作業が完了している必要がある。

[カメラキャリブレーションマニュアル](README_Calibration_Docker.md)では、カメラキャリブレーションの他にも`ORB-SLAM2用のカメラ設定ファイルの作成`の中でフレームレートと画像サイズの設定も行う。

## 7 補足資料一覧

### 7.1 補足資料

[補足資料](README_Supplementary.md)に記載されている。

### 7.2 トラブルシューティングマニュアル

[トラブルシューティングマニュアル](README_Trouble_Shooting.md)に記載されている。
