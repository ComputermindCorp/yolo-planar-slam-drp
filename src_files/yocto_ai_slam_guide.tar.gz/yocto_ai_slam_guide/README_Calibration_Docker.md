# カメラキャリブレーションマニュアル

## 前提条件

- [ROS1 noetic用のDockerイメージの作成マニュアル](README_Noetic.md)を読み終わっていること
- [ROS1 noetic用のDockerイメージの作成マニュアル](README_Noetic.md)の前提条件を満たしていること
- 使用するマシンにキャリブレーションを行うUSBカメラとして、ELPカメラ1台のみが接続されていること
- [キャリブレーション用の画像](http://opencv.jp/sample/pics/chesspattern_7x10.pdf)を印刷し、板などの平面に貼り、キャリブレーションボードを作成してあること

## キャリブレーションボードのサイズ確認

`前提条件`に記載したキャリブレーションボードのサイズを確認する。

キャリブレーションボードのマス目の一辺のサイズを測る。  
また、マス目の縦と横のサイズが等しいことを確認する。

以降では、マス目の一辺のサイズが`24`\[mm\]であると仮定して手順を記載する。

## USBカメラの接続確認

USBカメラへの接続を行うために、以下のコマンドを実行し、ユーザーをvideoグループに追加する。

```shell
sudo gpasswd -a $USER video
```

上記の変更を反映するために、再起動する。

以下のコマンドを実行し、USBカメラが正しく接続されているのかを確認する。

```shell
lsusb
```

上記のコマンドを実行すると、USB接続されているデバイスの一覧が表示される。

一覧の中に、vendor idが`32e4`のデバイスがあることを確認する。  
USBカメラが正しく接続されている場合は、例えば以下のように表示される。

```shell
Bus 001 Device 021: ID 32e4:0144
```

以下のコマンドを実行し、videoデバイスのパスを確認する。

```shell
v4l2-ctl --list-devices
```

以下のような出力が得られる。

```shell
Global Shutter Camera: Global S (usb-0000:00:14.0-7):
        /dev/video0
        /dev/video1
```

## 使用可能なパラメータの確認

以下のコマンドを実行し、使用可能なフォーマット、画像サイズ、フレームレートの組み合わせを確認する。  
`USBカメラの接続確認`で`/dev/video*`に該当するデバイスパスが複数確認できた場合には、それぞれについて確認を行う。

`USBカメラの接続確認`の例では`/dev/video0`と`/dev/video1`が確認できたため、これらについて順に確認を行う。

`/dev/video0`について、以下のコマンドを実行し、使用可能なフォーマット、画像サイズ、フレームレートの組み合わせを確認する。

```shell
v4l2-ctl -d /dev/video0 --list-formats-ext
```

上記のコマンドを実行すると、以下のような出力が得られる。

```shell
ioctl: VIDIOC_ENUM_FMT
        Index       : 0
        Type        : Video Capture
        Pixel Format: 'MJPG' (compressed)
        Name        : Motion-JPEG
                Size: Discrete 1280x720
                        Interval: Discrete 0.017s (60.000 fps)
                        Interval: Discrete 0.020s (50.000 fps)
                        Interval: Discrete 0.033s (30.000 fps)
                        Interval: Discrete 0.040s (25.000 fps)
                        Interval: Discrete 0.050s (20.000 fps)
                        Interval: Discrete 0.067s (15.000 fps)
                        Interval: Discrete 0.100s (10.000 fps)
                        Interval: Discrete 0.200s (5.000 fps)
                Size: Discrete 800x600
                        Interval: Discrete 0.017s (60.000 fps)
                        Interval: Discrete 0.020s (50.000 fps)
                        Interval: Discrete 0.033s (30.000 fps)
                        Interval: Discrete 0.040s (25.000 fps)
                        Interval: Discrete 0.050s (20.000 fps)
                        Interval: Discrete 0.067s (15.000 fps)
                        Interval: Discrete 0.100s (10.000 fps)
                        Interval: Discrete 0.200s (5.000 fps)
                Size: Discrete 640x480
                        Interval: Discrete 0.017s (60.000 fps)
                        Interval: Discrete 0.020s (50.000 fps)
                        Interval: Discrete 0.033s (30.000 fps)
                        Interval: Discrete 0.040s (25.000 fps)
                        Interval: Discrete 0.050s (20.000 fps)
                        Interval: Discrete 0.067s (15.000 fps)
                        Interval: Discrete 0.100s (10.000 fps)
                        Interval: Discrete 0.200s (5.000 fps)

        Index       : 1
        Type        : Video Capture
        Pixel Format: 'YUYV'
        Name        : YUYV 4:2:2
                Size: Discrete 1280x720
                        Interval: Discrete 0.100s (10.000 fps)
                        Interval: Discrete 0.200s (5.000 fps)
                Size: Discrete 800x600
                        Interval: Discrete 0.050s (20.000 fps)
                        Interval: Discrete 0.067s (15.000 fps)
                        Interval: Discrete 0.100s (10.000 fps)
                        Interval: Discrete 0.200s (5.000 fps)
                Size: Discrete 640x480
                        Interval: Discrete 0.033s (30.000 fps)
                        Interval: Discrete 0.040s (25.000 fps)
                        Interval: Discrete 0.050s (20.000 fps)
                        Interval: Discrete 0.067s (15.000 fps)
                        Interval: Discrete 0.100s (10.000 fps)
                        Interval: Discrete 0.200s (5.000 fps)
```

`/dev/video1`について、以下のコマンドを実行し、使用可能なフォーマット、画像サイズ、フレームレートの組み合わせを確認する。

```shell
v4l2-ctl -d /dev/video1 --list-formats-ext
```

上記のコマンドを実行すると、以下のような出力が得られる。

```shell
ioctl: VIDIOC_ENUM_FMT
```

以上の結果から、画像入力には`/dev/video0`が使用されると推測できる。  

フォーマットについては圧縮フォーマットである`MJPG`と非圧縮フォーマットである`YUYV`が使用可能である。  
`MJPG`だとフレーム画像が不可逆圧縮され、SLAM精度に影響を及ぼす可能性があるため、ここでは`YUYV`を使用する。

`YUYV`のうち、画像サイズは以下のものが使用可能となっている。

- `1280x720`
- `800x600`
- `640x480`

ここでは`800x600`を使用する。

`YUYV`かつ`800x600`のうち、フレームレートは以下のものが使用可能となっている。

- `20`\[fps\]
- `15`\[fps\]
- `10`\[fps\]
- `5`\[fps\]

ここでは`10`\[fps\]を使用する。

## Dockerコンテナの起動

以下のコマンドを実行しDockerコンテナを起動する。

```shell
docker_run_noetic.sh
```

また、上記の1つ目のターミナルとは別にさらにもう2つターミナルを起動し、以下のコマンドを実行してDockerコンテナにログインする。

```shell
docker exec -it noetic /bin/bash
```

```shell
docker exec -it noetic /bin/bash
```

## キャリブレーション

Dockerコンテナの中からELPカメラを使用するために、Dockerコンテナの中で以下のコマンドを実行する。

```shell
sudo ./script/docker/chmod_elp.sh
```

ELPカメラ以外のUSBカメラを使用する場合には、上記のコマンドの代わりに`lsusb`を実行し、使用するUSBカメラの`Bus`と`Device`の値を確認し、Dockerコンテナの中で以下のコマンドを実行する。  
ここで、`${BUS_NUMBER}`と`${DEVICE_NUMBER}`にはそれぞれ`Bus`の値と`Device`の値を指定する。

```shell
chmod 666 /dev/bus/usb/${BUS_NUMBER}/${DEVICE_NUMBER}
```

`Dockerコンテナの起動`の1つ目のターミナルで、Dockerコンテナの中で以下を実行する。

```shell
roscore
```

`Dockerコンテナの起動`の2つ目のターミナルで、Dockerコンテナの中で以下を実行する。  
ここでは、フォーマットを`YUYV`、画像サイズを`800x600`、フレームレートを`10`\[fps\]としている。

```shell
rosrun libuvc_camera camera_node \
    _width:=800 \
    _height:=600 \
    _video_mode:=yuyv \
    _frame_rate:=10
```

`Dockerコンテナの起動`の3つ目のターミナルで、Dockerコンテナの中で以下を実行する。  
ここでは、キャリブレーションボードのマス目の一辺のサイズが`24`\[mm\]であるため、`--square`の値は`0.024`としている。

```shell
rosrun camera_calibration cameracalibrator.py \
    --size 10x7 \
    --square 0.024 \
    image:=/image_raw
```

上記のコマンドを実行すると、GUI画面が起動する。  

USBカメラにキャリブレーションボードが映るようにしながら、キャリブレーションボードの位置や向きを変える。  
`X`、`Y`、`Skew`のバロメータは最大まで、`Size`のバロメータも半分以上になるまで行うことが望ましい。  
一般的に、各バロメータが大きいほどキャリブレーションの精度は良くなると考えられるためである。

`CARIBRATE`ボタンが青色になり、各バロメータが十分に大きくなったと判断できれば、`CARIBRATE`ボタンを押してキャリブレーションを開始する。  
ここで、キャリブレーションに採用されたサンプル画像が150枚を超えていると、30分以上かかることがある。

キャリブレーションが完了すると、例えば以下のような出力が得られる。

```shell
**** Calibrating ****
mono pinhole calibration...
D = [-0.41023196735321144, 0.28956684489599543, 0.0021092455287242884, -0.0005875510419201505, 0.0]
K = [1050.1369274057517, 0.0, 385.0708584209296, 0.0, 1050.4996952459458, 311.5707947241254, 0.0, 0.0, 1.0]
R = [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]
P = [985.96923828125, 0.0, 382.409889475457, 0.0, 0.0, 1013.0247802734375, 312.4734243852399, 0.0, 0.0, 0.0, 1.0, 0.0]
None
# oST version 5.0 parameters


[image]

width
800

height
600

[narrow_stereo]

camera matrix
1050.136927 0.000000 385.070858
0.000000 1050.499695 311.570795
0.000000 0.000000 1.000000

distortion
-0.410232 0.289567 0.002109 -0.000588 0.000000

rectification
1.000000 0.000000 0.000000
0.000000 1.000000 0.000000
0.000000 0.000000 1.000000

projection
985.969238 0.000000 382.409889 0.000000
0.000000 1013.024780 312.473424 0.000000
0.000000 0.000000 1.000000 0.000000
```

キャリブレーションに使用された画像を保存したい場合には、`SAVE`ボタンを押すと、画像の圧縮ファイルが`/tmp/calibrationdata.tar.gz`に保存される。  
Dockerコンテナの終了後にもホスト側で参照したい場合には、以下のコマンドをDockerコンテナの中で実行し、ホストの`$HOME/drp_cv_lib/output/`ディレクトリにコピーしておく必要がある。

```shell
cp /tmp/calibrationdata.tar.gz $HOME/output/
```

キャリブレーションを終了する場合には、3つ目、2つ目、1つ目の順でターミナルで`Ctrl-C`を実行し、ROSノードを終了する。  
その後に、3つ目と2つ目のターミナルで以下のコマンドを実行し、Dockerコンテナから抜ける。

```shell
exit
```

その後に、1つ目のターミナルで以下のコマンドを実行し、Dockerコンテナを終了する。

```shell
exit
```

2つ目と3つ目のターミナルはこれ以降使用しないため、終了しても良い。

## Yolo-Planar-SLAM用のカメラ設定ファイルの作成

Yolo-Planar-SLAM用のカメラ設定ファイルの作成を行う。  
ここでは、作成する設定ファイルの名前を`ELP_rns.yaml`とする。

ホストで以下のコマンドを実行し、`ELP_rns.yaml`の元となるファイルを複製する。

```shell
cp $HOME/yolo-planar-slam/Examples/Monocular/ELP.yaml $HOME/yolo-planar-slam/Examples/Monocular/ELP_rns.yaml
```

`$HOME/yolo-planar-slam/Examples/Monocular/ELP_rns.yaml`をエディタで開き、キャリブレーションパラメータに該当する項目を書き換える。  
`キャリブレーション`で取得したキャリブレーションパラメータの`camera matrix`と`distortion`にある値の場合、以下のようになる。  
また、画像サイズとフレームレートも`キャリブレーション`で使用した値に設定する。

```yaml
# Camera calibration and distortion parameters (ROS1) 
Camera.fx: 1050.136927
Camera.fy: 1050.499695
Camera.cx: 385.070858
Camera.cy: 311.570795

Camera.k1: -0.410232
Camera.k2: 0.289567
Camera.p1: 0.002109
Camera.p2: -0.000588
# Camera.k3 : 0.000000

# Camera frames per second 
Camera.fps: 10.0

# Camera input size
Camera.width: 800
Camera.height: 600
```
