# ROS1 noetic用のDockerイメージの作成マニュアル

## 前提条件

- [Dockerインストールマニュアル](README_Docker.md)を読み終わっていること
- [Dockerインストールマニュアル](README_Docker.md)の前提条件を満たしていること
- Ubuntu 18.04マシンのホームディレクトリ以下に`drp_cv_lib`リポジトリが展開されていること

## script実行のためのセットアップ

以下のコマンドを実行し、以降の手順で使用するscriptへパスを通し、ビルドするDockerイメージのバージョン情報を読み込む。

```shell
source $HOME/drp_cv_lib/script/setup.sh
```

## パスワードの設定

Dockerコンテナの中で、ユーザーにパスワードを設定する場合には、`Dockerfile.noetic`に以下の変更を加える必要がある。  
なお、以下の例ではパスワードを`passw0rd`に設定している。

変更前

```dockerfile
# Set password
# RUN echo "${USER_NAME}:passw0rd" | chpasswd

# Do not set a password
RUN sed -i -e 's/%sudo\tALL=(ALL:ALL) ALL/%sudo   ALL=(ALL:ALL) NOPASSWD:ALL/' /etc/sudoers
```

変更後

```dockerfile
# Set password
RUN echo "${USER_NAME}:passw0rd" | chpasswd

# Do not set a password
# RUN sed -i -e 's/%sudo\tALL=(ALL:ALL) ALL/%sudo   ALL=(ALL:ALL) NOPASSWD:ALL/' /etc/sudoers
```

## Dockerイメージのビルド

以下のコマンドを実行しDockerイメージをビルドする。

```shell
cd $HOME/drp_cv_lib
docker_build_noetic.sh
```

正常にDockerイメージのビルドが完了した場合には、以下の標準出力が表示される。  
なお`latest`の部分はバージョンの値になる。

```shell
Successfully tagged rns/ros-noetic:latest
```
