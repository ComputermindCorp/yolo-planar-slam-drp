# AI+SLAM連携アプリ 実装・評価報告書

株式会社Fixstars Autonomous Technologies  
v1.0, 2023-12-18

## 1 はじめに

本書は案件「DRP-AIアプリ応用（AI+SLAM連携）高速・機能拡張コーディングおよび検証」におけるAI+SLAM連携アプリ 実装・評価報告書である。  
本書ではYolo-Planar-SLAMに関する作業について、下記の点を記載する。

- 評価環境
- Musketeerリグレッションテスト
- Yolo-Planar-SLAMの諸変更
- OpenCVAの実装の確認
- OpenCVA差し替え版のYolo-Planar-SLAMの実装
- α2版のDRP-AIドライバのDDR2チャネル対応
- 投機実行対応
- β版移行
- YOLOX-Sのデモプログラムの確認
- DRP-AI TranslatorによるYOLOX-Sの組み込み
- DRP-AI TranslatorによるDenseのYOLOX-Sの組み込み
- 最大特徴点数の削減のための調査
- クロスコンパイル対応
- DRP-AI TVMによるSLAMへのモデル組み込みの実装可能性調査
- 高速化試行
- バージョン1移行検討
- 最終評価
- 今後の懸念

## 2 評価環境

本章では、本案件で使用した評価環境（ハードウェア、ソフトウェア）の情報を記載する。

### 2.1 ハードウェア

#### 2.1.1 Intel CPU搭載PC

- CPU：Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz
    - 物理コア数：6
    - コアあたりのスレッド数：2
- メモリ：48GB

#### 2.1.2 V2xボード（α2、EVK-α、電力改善版）

- CPU：Cortex-A55 @ 1.7GHz
    - 物理コア数：4
    - コアあたりのスレッド数：1
- メモリ：16GB
- S/N number：33001049

### 2.2 ソフトウェア

#### 2.2.1 Intel CPU搭載PC

- OS：Ubuntu 18.04 64bit
- Musketeer：Ver.20230724
- CVC：7.00b(open_src_cvc_700c_tar.bz2)

#### 2.2.2 V2xボード（α2、EVK-α、電力改善版）

- OS：CIP Linux
- gcc：8.3.0
- OpenCV：4.1.0
- PCL：1.9.1
- Eigen：3.3.7
- flann：1.9.1
- Boost：1.72.0
- socket.io-client-cpp：1.6.0
- Node.js：12.22.12
- socket.io：2.0.4
- express：4.16.2
- ejs：2.5.7

### 2.3 評価データ

RGB画像とDepth画像を含み、ORB-SLAM2およびYolo-Planar-SLAMが対応している形式である[TUM Dataset](https://vision.in.tum.de/data/datasets/rgbd-dataset/download)の`fr3/walking_xyz`を使用する。  
以降では`rgbd_dataset_freiburg3_walking_xyz`と記載する。  
また、このデータセットの画像をグレースケールに変換したデータセットである`GRAY_rgbd_dataset_freiburg3_walking_xyz`を受領した。  
合わせて使用する。

## 3 Musketeerリグレッションテスト

Musketeer Ver.20230724でリグレッションテストを行った結果について記載する。

### 3.1 resize

評価に使用したテストベンチファイルは以下の通り。

- ディスクリプタファイル：`drp_cv_lib/drp/resize/testbench/orb-slam2/resize_2849_1_TB_desc_in_csim.txt`
- メモリ初期値ファイル：`drp_cv_lib/drp/resize/testbench/orb-slam2/resize_2849_1_TB_mem_in_csim.txt`
- メモリ期待値ファイル：`drp_cv_lib/drp/resize/testbench/orb-slam2/resize_2849_1_TB_mem_out_ref.STP4C.txt`

RTレベルシミュレーションによる評価結果は以下の通り。

```shell
[DRP    ] all=249067, exec=238425, hold=10642 (din=1320, dout=0, rollb=4800, cfgcw=5335, end=0)
[BUSDin ] all=241168, dma =18754, stop= 1323, data=600120[Byte]
[BUSDout] all=241168, dma = 8000, stop=  800, data=250800[Byte]
exec time =602.920000 [us]
```

### 3.2 7x7のGaussianBlur

評価に使用したテストベンチファイルは以下の通り。

- ディスクリプタファイル：`drp_cv_lib/drp/gaussian_blur/testbench/yolo-planar-slam/gaussian_blur_0004_0_TB_desc_in_csim.txt`
- メモリ初期値ファイル：`drp_cv_lib/drp/gaussian_blur/testbench/yolo-planar-slam/gaussian_blur_0004_0_TB_mem_in_csim.txt`
- メモリ期待値ファイル：`drp_cv_lib/drp/gaussian_blur/testbench/yolo-planar-slam/gaussian_blur_0004_0_TB_mem_out_exp.txt`

RTレベルシミュレーションによる評価結果は以下の通り。

```shell
[DRP    ] all=126008, exec=107408, hold=18600 (din=204, dout=0, rollb=7700, cfgcw=12647, end=4)
[BUSDin ] all=159736, dma =10561, stop= 1165, data=312976[Byte]
[BUSDout] all=159736, dma =10080, stop=  960, data=311040[Byte]
exec time =399.340000 [us]
```

### 3.3 SLAM組みこみ用のFAST

評価に使用したテストベンチファイルは以下の通り。

- ディスクリプタファイル：`yolo-planar-slam/drp/fast/testbench/yolo-planar-slam/fast_0004_0_TB_desc_in_csim.txt`
- メモリ初期値ファイル：`yolo-planar-slam/drp/fast/testbench/yolo-planar-slam/fast_0004_0_TB_mem_in_csim.txt`
- メモリ期待値ファイル：`yolo-planar-slam/drp/fast/testbench/yolo-planar-slam/fast_0004_0_TB_mem_out_exp.txt`

RTレベルシミュレーションによる評価結果は以下の通り。

```shell
[DRP    ] all=1481708, exec=1462194, hold=19514 (din=14710, dout=0, rollb=4494, cfgcw=351, end=0)
[BUSDin ] all=1651585, dma =41029, stop=61372, data=780600[Byte]
[BUSDout] all=1651585, dma = 3764, stop= 3764, data=18817[Byte]
exec time =4128.962500 [us]
```

### 3.4 CVアセット用のFAST

評価に使用したテストベンチファイルは以下の通り。

- ディスクリプタファイル：`drp_cv_lib/drp/fast/fast_2849_0_8_10_TB_desc_in_csim.txt`
- メモリ初期値ファイル：`drp_cv_lib/drp/fast/fast_2849_0_8_10_TB_mem_in_csim.txt`
- メモリ期待値ファイル：`drp_cv_lib/drp/fast/fast_2849_0_8_10_TB_mem_out_exp.txt`

RTレベルシミュレーションによる評価結果は以下の通り。

```shell
[DRP    ] all= 5463, exec= 5367, hold=   96 (din=57, dout=8, rollb=12, cfgcw=30, end=0)
[BUSDin ] all= 6934, dma =   97, stop=  134, data= 3096[Byte]
[BUSDout] all= 6934, dma =   56, stop=   56, data=  277[Byte]
exec time =17.335000 [us]
```

### 3.5 computeOrbDescriptors

評価に使用したテストベンチファイルは以下の通り。

- ディスクリプタファイル：`drp_cv_lib/drp/orb_descriptors/testbench/yolo-planar-slam/orb_descriptors_0150_0_TB_desc_in_csim.txt`
- メモリ初期値ファイル：`drp_cv_lib/drp/orb_descriptors/testbench/yolo-planar-slam/orb_descriptors_0150_0_TB_mem_in_csim.txt`
- メモリ期待値ファイル：`drp_cv_lib/drp/orb_descriptors/testbench/yolo-planar-slam/orb_descriptors_0150_0_TB_mem_out_exp.STP4C.txt`

RTレベルシミュレーションによる評価結果は以下の通り。

```shell
[DRP    ] all=126110, exec=93961, hold=32149 (din=8474, dout=0, rollb=2628, cfgcw=21940, end=0)
[BUSDin ] all=515564, dma =16643, stop=16585, data=333632[Byte]
[BUSDout] all=515564, dma =  219, stop=   14, data= 7008[Byte]
exec time =1288.910000 [us]
```

### 3.6 比較結果

Musketeer Ver.20230123における評価結果と合わせて、グラフにプロットした。

![プロット結果](image/musketeer/20230724_vs_20230123.png)

CVアセット用のFAST以外のすべてで性能が悪化していることがわかる。

なお、本案件のYolo-Planar-SLAMでは本案件で生成したコンフィギュレーションコードではなく、受領したコンフィギュレーションコードを使用する。

## 4 Yolo-Planar-SLAMの諸変更

本案件のYolo-Planar-SLAMへ行った変更・修正について記載する。

### 4.1 computeOrbDescriptorsのDRPライブラリ実装の不具合修正

computeOrbDescriptorsのDRPライブラリ実装で、入力特徴点が`0`個の場合の例外処理に不具合があったため修正を行った。  
変更対象のファイルは以下の通り。

- drp_modules/ORBextractor_drp.cc
- opencva_modules/ORBextractor_opencva.cc

変更内容は以下の通り。

```diff
-    if (nkeypointsLevel == 0)
-        return false;
+    if (nkeypointsLevel == 0) {
+        fprintf(stderr, "Input keypoints to ORBextractor_drp::OperatorOrbDescriptorsStart(level=%d) is empty.\n", level);
+        return true;
+    }
```

上記の修正を行った上で、`cv::Mat::zeros`で作成した画像をデータセットに一時的に含めて動作確認を行った。  
動作確認の結果は以下の通り。

```shell
Measurement result of   24 frame
    System::TrackMonocular                 :   55.775[ms]
    Sleep specified at execution           :    0.000[ms]
    Sleep while waiting for the next frame :    0.000[ms]
Input keypoints to ORBextractor_opencva::OperatorOrbDescriptorsStart(level=0) is empty.
Input keypoints to ORBextractor_opencva::OperatorOrbDescriptorsStart(level=1) is empty.
Input keypoints to ORBextractor_opencva::OperatorOrbDescriptorsStart(level=2) is empty.
Input keypoints to ORBextractor_opencva::OperatorOrbDescriptorsStart(level=3) is empty.
Input keypoints to ORBextractor_opencva::OperatorOrbDescriptorsStart(level=4) is empty.
Input keypoints to ORBextractor_opencva::OperatorOrbDescriptorsStart(level=5) is empty.
Input keypoints to ORBextractor_opencva::OperatorOrbDescriptorsStart(level=6) is empty.
Input keypoints to ORBextractor_opencva::OperatorOrbDescriptorsStart(level=7) is empty.
Track lost soon after initialisation, reseting...
Measurement result of   25 frame
    System::TrackMonocular                 :    8.164[ms]
    Sleep specified at execution           :    0.000[ms]
    Sleep while waiting for the next frame :   29.910[ms]
System Reseting
Reseting Local Mapper... done
Reseting Loop Closing... done
Reseting Database... done
Measurement result of   26 frame
    System::TrackMonocular                 :   45.225[ms]
    Sleep specified at execution           :    0.000[ms]
    Sleep while waiting for the next frame :    0.000[ms]
```

`cv::Mat::zeros`で作成した画像が処理されたタイミングでも正常に動作していることがわかる。  
また、意図した警告が出ていることがわかる。

### 4.2 TrackingのStateの出力対応

TrackingのStateを確認できるようにするために、標準出力するための変更を行った。  
変更後の動作確認の結果は以下の通り。

```shell
Measurement result of   21 frame
    System::TrackMonocular                 :  139.465[ms]
    Sleep specified at execution           :    0.000[ms]
    Sleep while waiting for the next frame :    0.000[ms]
    Tracking state                         : NOT_INITIALIZED
Measurement result of   22 frame
    System::TrackMonocular                 :  134.876[ms]
    Sleep specified at execution           :    0.000[ms]
    Sleep while waiting for the next frame :    0.000[ms]
    Tracking state                         : NOT_INITIALIZED
New Map created with 126 points
Measurement result of   23 frame
    System::TrackMonocular                 :  202.977[ms]
    Sleep specified at execution           :    0.000[ms]
    Sleep while waiting for the next frame :    0.000[ms]
    Tracking state                         : OK
Measurement result of   24 frame
    System::TrackMonocular                 :   59.575[ms]
    Sleep specified at execution           :    0.000[ms]
    Sleep while waiting for the next frame :    0.000[ms]
    Tracking state                         : OK
```

`Tracking state`には`Tracking::mState`の値を出力している。  
`New Map created`の前後で`Tracking state`が変化していることから、正常に出力できていることがわかる。

### 4.3 resizeのDRPライブラリ実装の不具合修正

OpenCVA組み込み版のYolo-Planar-SLAMの実装に不具合があったため修正を行った。

#### 4.3.1 不具合が判明した経緯

OpenCVA**差し替え版**のOpenCVAのresizeの出力と、OpenCVA**組み込み版**のOpenCVAのresizeの出力が厳密には一致していなかったため、確認したところ本不具合が判明した。

OpenCVA**組み込み版**の、2レベルのOpenCVAのresizeの出力は以下の通り。

![OpenCVA組み込み版の、2レベルのOpenCVAのresizeの出力](image/resize/built-in.png)

OpenCVA**差し替え版**の、2レベルのOpenCVAのresizeの出力は以下の通り。

![OpenCVA差し替え版の、2レベルのOpenCVAのresizeの出力](image/resize/replacement.png)

目視では差異は確認できなかったが、一部の画素値で`±N`の誤差がある。

#### 4.3.2 修正内容

OpenCVAのresizeの入力画像がすべて0レベルの画像となっている不具合が含まれていた。  
よって、以下のように実装されていた。

- 0レベルの画像にresizeを適用して、1レベルの画像を生成する
- 0レベルの画像にresizeを適用して、2レベルの画像を生成する
- 0レベルの画像にresizeを適用して、3レベルの画像を生成する
- 0レベルの画像にresizeを適用して、4レベルの画像を生成する
- 0レベルの画像にresizeを適用して、5レベルの画像を生成する
- 0レベルの画像にresizeを適用して、6レベルの画像を生成する
- 0レベルの画像にresizeを適用して、7レベルの画像を生成する

しかし、<https://github.com/BZDOLiVE/YoloPlanarSLAM/blob/45510b59d41eb6bcd28e2657c39cb6ab664b5c1f/src/ORBextractor.cc#L1185>の通りYolo-Planar-SLAMのオリジナル実装では直前のレベルの画像を入力としてresizeを実行しているため、正しくは以下のように実装されるべきであった。

- 0レベルの画像にresizeを適用して、1レベルの画像を生成する
- **1レベル**の画像にresizeを適用して、2レベルの画像を生成する
- **2レベル**の画像にresizeを適用して、3レベルの画像を生成する
- **3レベル**の画像にresizeを適用して、4レベルの画像を生成する
- **4レベル**の画像にresizeを適用して、5レベルの画像を生成する
- **5レベル**の画像にresizeを適用して、6レベルの画像を生成する
- **6レベル**の画像にresizeを適用して、7レベルの画像を生成する

以上から、`opencva_modules/ORBextractor_opencva.cc`に対して以下の修正を行った。

```diff
-    bool opencva_succeed = opencva::resize(in_image, input_level, output_image_size, mvImagePyramid[input_level + 1]);
+    bool opencva_succeed = opencva::resize(mvImagePyramid[input_level], input_level, output_image_size, mvImagePyramid[input_level + 1]);
```

第一引数で指定する入力画像を変更している。

#### 4.3.3 評価

上記の修正を行った上で、評価を行った。

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1050
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：2023/8/31受領版

##### 4.3.3.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1013.mono.opencva.ai.3wx.1050.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.150718
      mean      0.025807
    median      0.021138
       min      0.003085
      rmse      0.033083
       sse      0.914985
       std      0.020699

```

##### 4.3.3.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

###### 4.3.3.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |             9.16  |
| `　　cv::imread` |    99.8 |             9.15  |

###### 4.3.3.2.2 Image processingスレッド

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            66.985 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     1   |             0.694 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     0.6 |             0.427 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     5.4 |             3.678 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     5.9 |             3.963 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0.1 |             0.075 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.8 |             3.905 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.034 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.321 |
| `　　　　postprocess CV FAST[0-7]`  　　　　　　　　　　　　　　　　|     0   |             0.014 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    50.3 |            33.708 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.7 |             2.529 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     5   |             3.415 |
| `　　ORBextractor::DistributeOctTree[0-7]`  　　　　　　　　　　　　|     4.9 |             3.294 |
| `　　computeOrientation[0-7]`   　　　　　　　　　　　　　　　　　　|     4.5 |             3.054 |
| `　　computeDescriptors[0-7]`   　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0-7]`  　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0-7]`　　　　　　　　　　|     0   |             0.021 |
| `　　　　copy parameter using MemcpyU2P[0-7]`   　　　　　　　　　　|     0   |             0.025 |
| `　　　　copy input image using MemcpyU2P[0-7]` 　　　　　　　　　　|     0.7 |             0.514 |
| `　　　　copy input keypoints using MemcpyU2P[0-7]` 　　　　　　　　|     0   |             0.023 |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.041 |
| `　　　　Start[0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.305 |
| `　　　　DRP time[0-7]★`　　　　　　　　　　　　　　　　　　　　　　|     6.4 |             4.304 |
| `　　　　MemcpyP2U[0-7]`　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　postprocess[0-7]`  　　　　　　　　　　　　　　　　　　　　|     0   |             0.018 |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            66.985 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    72.9 |            48.848 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.7 |             2.529 |
| `　　Image processing(second)`  　　　　　　　　　　　　　　　　　　|    23.2 |            15.603 |

###### 4.3.3.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            72.373 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.012 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.7 |            72.168 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    43.5 |            31.497 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    56.1 |            40.641 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.7 |             0.521 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    55.4 |            40.114 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     2.7 |             2.01  |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.8 |             2.761 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.9 |             0.668 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    16.1 |            11.678 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9.5 |             6.911 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     6.3 |             4.573 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    30.3 |            21.992 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     2.9 |             2.12  |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9.5 |             6.921 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    17.6 |            12.8   |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    14.4 |            10.44  |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     3.1 |             2.248 |

###### 4.3.3.2.4 修正前との比較

2023年9月時点の`SLAM/CNN連携アプリ（Yocto）実装・評価報告書`の`11 OpenCVAの組み込み対応`の評価結果と比較する。

SLAM精度の最大誤差は約`16`\[cm\]から約`15`\[cm\]に改善されている。  
ただし、本修正によるものなのか実行再現性が無いため発生した差異なのかは区別できていない。

`Image processing`の平均処理時間は`70.815`\[ms/frame\]から`66.985`\[ms/frame\]に改善されている。  
このうち`Resize[0-7]●`の平均処理時間は`6.109`\[ms/frame\]から`3.678`\[ms/frame\]に改善されている。  
`Main loop`の平均処理時間は`76.227`\[ms/frame\]から`72.373`\[ms/frame\]に改善されている。  
以上から、SLAM全体としての平均処理時間は少なくとも`2.431`\[ms/frame\]だけ減少していることがわかる。

## 5 OpenCVAの実装の確認

本案件のYolo-Planar-SLAMへの組み込みを想定して、α2版のOpenCVAの実装の確認を行った。

α2版のOpenCVAを確認したところ、以下のことがわかった。

`resize_drp`では、入力画像の`cv::Mat::isContinuous`の値を確認し、`false`の場合は`cv::Mat::clone`で`cv::Mat::isContinuous`が`true`になるようにインスタンスを作り直している。

```shell
imgproc/src/resize.cpp:3828:    /* check continuous */
imgproc/src/resize.cpp-3829-    if(!src_mat.isContinuous())
imgproc/src/resize.cpp-3830-    {
imgproc/src/resize.cpp-3831-        src_mat = src_mat.clone();
imgproc/src/resize.cpp-3832-    }
```

`GaussianBlur_drp`も同様であった。

```shell
imgproc/src/smooth.dispatch.cpp:682:    /* check continuous */
imgproc/src/smooth.dispatch.cpp-683-    if(!src_mat.isContinuous())
imgproc/src/smooth.dispatch.cpp-684-    {
imgproc/src/smooth.dispatch.cpp-685-        src_mat = src_mat.clone();
imgproc/src/smooth.dispatch.cpp-686-    }
imgproc/src/smooth.dispatch.cpp-687-
```

しかし`FAST_drp`には同等の処理が含まれていなかった。

`EPSD-IMB-23-0064-01_OpenCVアクセラレータ_IF仕様.pdf`からは`cv::Mat::isContinuous`に関する記載は見つけられなかった。  
`FAST_drp`でも`resize_drp`などと同様に入力画像の`cv::Mat::isContinuous`は`true`である必要があると考えられる。  
必要な場合、α2版のOpenCVAを使用するOpenCVA差し替え版では以下のような変更が必須となる。

```diff
--- a/src/ORBextractor.cc
+++ b/src/ORBextractor.cc
@@ -808,12 +808,13 @@ void ORBextractor::ComputeKeyPointsOctTree(vector<vector<KeyPoint> >& allKeypoin
                     maxX = maxBorderX;

                 vector<cv::KeyPoint> vKeysCell;
-                FAST(mvImagePyramid[level].rowRange(iniY,maxY).colRange(iniX,maxX),
+                const cv::Mat cellImage = mvImagePyramid[level].rowRange(iniY, maxY).colRange(iniX, maxX).clone();
+                FAST(cellImage,
                      vKeysCell,iniThFAST,true);

                 if(vKeysCell.empty())
                 {
-                    FAST(mvImagePyramid[level].rowRange(iniY,maxY).colRange(iniX,maxX),
+                    FAST(cellImage,
                          vKeysCell,minThFAST,true);
                 }

```

なお、β版のOpenCVAでは`FAST_drp`でも`resize_drp`や`GaussianBlur_drp`と同様に入力画像の`cv::Mat::isContinuous`の値を確認する処理が追加された。

## 6 OpenCVA差し替え版のYolo-Planar-SLAMの実装

OpenCVA差し替え版のYolo-Planar-SLAMの実装を行った。  
また、GitHubで公開されているオリジナルのYolo-Planar-SLAMを、OpenCVA差し替え版のYolo-Planar-SLAMに変更するパッチを作成し、マニュアルの整備と動作確認を行った。

パッチによる変更の内容は以下の通り。

- OpenCVのC APIからC++ APIへの変更
- OpenCV 3.2.0から4.1.0への変更
- ncnnへの依存の削除
- ヴィジュアライザの無効化とPangolinへの依存の削除
- ビルドオプションから`-march=native`の削除
- 警告抑制のためのビルドオプションの追加
    - `-Wno-deprecated-declarations`
    - `-Wno-pragmas`
    - `-Wno-class-memaccess`
- C++11からC++17への変更
    - 取り込んだ、受領したDRP-AIのデモプログラムの実装がC++17必須であるため
- OpenCVA対応
- computeOrbDescriptorsのDRPドライバネイティブ対応
- DRP-AI対応

評価結果は以下の通り。

### 6.1 OpenCVAあり、DRPドライバネイティブあり

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- モード：RGB-D
- オプション：ヴィジュアライザ無し
- 最大特徴点数：1000
- OpenCVA：有効
- DRPドライバネイティブ：有効
- DRP-AI：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt CameraTrajectory.v2x.2023.1013_2.rgbd.opencva.drp.ai.3wx.1000.rep.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.093283
      mean      0.015270
    median      0.013087
       min      0.001715
      rmse      0.018115
       sse      0.268768
       std      0.009746

```

SLAM精度は破綻していないことがわかる。

処理時間は以下の通り。

```shell
median tracking time: 0.168539
mean tracking time: 0.171617
```

### 6.2 OpenCVAあり、DRPドライバネイティブ無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- モード：RGB-D
- オプション：ヴィジュアライザ無し
- 最大特徴点数：1000
- OpenCVA：有効
- DRPドライバネイティブ：無効
- DRP-AI：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt CameraTrajectory.v2x.2023.1013_2.rgbd.opencva.cpu.ai.3wx.1000.rep.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.052132
      mean      0.013736
    median      0.011183
       min      0.001419
      rmse      0.016469
       sse      0.222126
       std      0.009085

```

SLAM精度は破綻していないことがわかる。

処理時間は以下の通り。

```shell
median tracking time: 0.176417
mean tracking time: 0.176475
```

### 6.3 OpenCVA無し、DRPドライバネイティブ無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- モード：RGB-D
- オプション：ヴィジュアライザ無し
- 最大特徴点数：1000
- OpenCVA：無効
- DRPドライバネイティブ：無効
- DRP-AI：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt CameraTrajectory.v2x.2023.1013_2.rgbd.cpu.cpu.ai.3wx.1000.rep.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.083960
      mean      0.017714
    median      0.015044
       min      0.001131
      rmse      0.020998
       sse      0.361112
       std      0.011275

```

SLAM精度は破綻していないことがわかる。

処理時間は以下の通り。

```shell
median tracking time: 0.181819
mean tracking time: 0.182457
```

### 6.4 考察

`OpenCVA無し、DRPドライバネイティブ無し`と比較して`OpenCVAあり、DRPドライバネイティブあり`で削減できた処理時間の割合を確認した。  
`median tracking time`については、`0.168539 / 0.181819 ≒ 0.926`であり約`7`%の処理時間を削減できている。  
`mean tracking time`については、`0.171617 / 0.182457 ≒ 0.940`であり約`6`%の処理時間を削減できている。

OpenCVA組み込み版（性能優先版）のYolo-Planar-SLAMの単眼かつDRP無しの評価結果は以下の通り。  
なお、最大特徴点数は`1050`であることに注意する。

- `Image processing`：`83.686`\[ms/frame\]
    - `Resize[0-7]`：`6.355`\[ms/frame\]
    - `GaussianBlur[0-7]`：`10.586`\[ms/frame\]
    - `FAST[0-7]`：`33.394`\[ms/frame\]
    - `computeDescriptors[0-7]`：`17.501`\[ms/frame\]

OpenCVA組み込み版（性能優先版）のYolo-Planar-SLAMの単眼かつOpenCVA動作（OpenCVA組み込み版）の結果は以下の通り。  
なお、最大特徴点数は`1050`であることに注意する。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

- `Image processing`：`70.815`\[ms/frame\]
    - `Resize[0-7]●`：`6.109`\[ms/frame\]
    - `GaussianBlur[0-7]●`：`4.331`\[ms/frame\]
    - `FAST[0-7]●`：`34.215`\[ms/frame\]
    - `computeDescriptors[0-7]`の`DRP time★`：`4.31`\[ms/frame\]

ただし、FASTはほとんどのケースでOpenCVAのDRP動作のための制約条件を満たしていないため、CPUで動作している点に注意する必要がある。

CPU動作とOpenCVA動作の間の平均処理時間を比較する。  
resizeの平均処理時間はほぼ同じである。  
GaussianBlurの平均処理時間は`10.586 - 4.331 = 6.255`\[ms/frame\]だけ削減できている。  
FASTの平均処理時間はほぼ同じである。  
computeDescriptors（DRPドライバネイティブ動作）の平均処理時間は`17.501 - 4.31 = 13.191`\[ms/frame\]だけ削減できている。  
ただし、DRPドライバを含むCPU-DRP連携にかかる処理時間は無視している。

以上からOpenCVA動作の対象範囲の平均処理時間はOpenCVA組み込み版では`6.255 + 13.191 = 19.446 ≒ 19.44`\[ms/frame\]だけ削減できていたことがわかる。

今回評価したRGB-DかつOpenCVA動作で削減できた平均処理時間は`0.182457 - 0.171617 = 0.01084`\[sec/frame\]となっている。  
つまり`10.84`\[ms/frame\]だけ削減できている。

OpenCVA組み込み版ではOpenCVAを使用することで`19.44`\[ms/frame\]だけ削減できていた。  
OpenCVA差し替え版ではOpenCVAを使用することで`10.84`\[ms/frame\]だけ削減できている。  
この差は、間引き処理の順序の差と`computeDescriptors[0-7]`の入力特徴点数の差に由来する。  
OpenCVA組み込み版では木構造による間引きの後に、バウンディングボックスによる間引きを適用する。  
OpenCVA組み込み版ではバウンディングボックスによる間引きの後に、木構造による間引きを適用する。

OpenCVA組み込み版かつRGB-D動作の場合の`computeDescriptors[0-7]`の入力特徴点の個数は、以下の通り。

- 0番フレーム：`1005`個
- 1番フレーム：`1005`個
- 2番フレーム：`1006`個

OpenCVA差し替え版かつRGB-D動作の場合の`computeDescriptors[0-7]`の入力特徴点の個数は、以下の通り。

- 0番フレーム：`319`個
- 1番フレーム：`359`個
- 2番フレーム：`375`個

中央値である1番フレームについて比較すると、`1005 / 359 ≒ 2.8`倍の差があることがわかる。  
よって、OpenCVA組み込み版かつ単眼動作と比較して、OpenCVA差し替え版かつRGB-D動作ではcomputeDescriptorsで削減された平均処理時間も`13.191 / 2.8 ≒ 4.7`\[ms/frame\]程度になっていると想定される。  
この場合、OpenCVA動作の対象範囲の平均処理時間は`6.255 + 4.7 = 10.955 ≒ 11`\[ms/frame\]となり、前述の実測値と整合する。

OpenCVA差し替え版において、CPU動作と比較してOpenCVA動作で`25`%の処理時間を削減するためには約`46`\[ms/frame\]削減する必要がある。  
GaussianBlurは`10.586 / 4.331 ≒ 2.44`倍だけ高速化できている。  
よってGaussianBlurの入力画像の画素数を、現状の`2.7`倍以上に増やしてGaussianBlurの処理の占める処理時間の割合を増やすことで、CPU動作と比較してOpenCVA動作で`25`%の処理時間を削減することを達成できると考えられる。

なお、最大特徴点数を増やしてcomputeDescriptorsの処理時間の割合を増やしても`Tracking::Track`の処理時間も増えることが予想されるため、CPU動作と比較してOpenCVA動作で`25`%の処理時間を削減することは達成できないと考えられる。  
また、computeDescriptorsはOpenCVAではなくDRPドライバネイティブで動作している。

## 7 α2版のDRP-AIドライバのDDR2チャネル対応

受領したα2版のBSPファイル一式を使用して、Yocto環境を構築し、ビルドしたCIP Linuxを使用してV2xボード（α2、EVK-α、電力改善版）が正常に動作するのかを確認した結果を記載する。

### 7.1 受領したDRP-AIのサンプルプログラムの確認

受領したDRP-AIドライバのDDR2チャネル対応済みの`YoloExecutor.cpp`と`recognize_base.cpp`の実装を確認した。

#### 7.1.1 入力画像のメモリ空間のメモリアドレス値について

受領した`recognize_base.cpp`では、メモリアドレス値は`0xB0000000`としてハードコーディングされていた。

```shell
// proc[DRPAI_INDEX_INPUT].address = me->drpai_address.data_in_addr;
proc[DRPAI_INDEX_INPUT].address = 0xB0000000;
proc[DRPAI_INDEX_INPUT].size = me->drpai_address.data_in_size;
```

受領した`YoloExecutor.cpp`には`/sys/class/u-dma-buf/udmabuf0/phys_addr`からメモリアドレス値を取得する処理が含まれている。

```cpp
/* Obtain udmabuf memory area starting address */
uint64_t udmabuf_address = 0;
int8_t fd = 0;
  char addr[1024];
int32_t read_ret = 0;

errno = 0;
fd = open("/sys/class/u-dma-buf/udmabuf0/phys_addr", O_RDONLY);
if (0 > fd)
{
    fprintf(stderr, "[ERROR] Failed to open udmabuf0/phys_addr : errno=%d\n", errno);
    return -1;
}
read_ret = read(fd, addr, 1024);
if (0 > read_ret)
{
    fprintf(stderr, "[ERROR] Failed to read udmabuf0/phys_addr : errno=%d\n", errno);
    close(fd);
    return -1;
}
sscanf(addr, "%lx", &udmabuf_address);
close(fd);

udmabuf_address &=0xFFFFFFFF;

printf("udmabuf_address = %lx \n", udmabuf_address);
```

ただし、取得したメモリアドレス値は`udmabuf_address`に格納されたあと、どこからも参照されていなかった。  
本案件のYolo-Planar-SLAMでは、`proc[DRPAI_INDEX_INPUT].address`には、`udmabuf_address`を設定するように変更した。

#### 7.1.2 /dev/udmabuf0のopenについて

受領した`YoloExecutor.cpp`には以下の処理が含まれている。

```cpp
udmabuf_fd = open("/dev/udmabuf0", O_RDWR );
// 略
ssize_t rw_udma_ret = write(udmabuf_fd, rgb_image.data, bgr_image.rows * bgr_image.cols * bgr_image.channels());
```

`/dev/udmabuf0`を指定して`open`したファイルディスクリプタに対して`write`を実行している。

ここで、このファイルディスクリプタに対して250回程度`write`を実行すると、エラーとなった。  
`write`が正常に完了した場合には`rw_udma_ret`の値は`640 * 480 * 3 = 921600`が設定される。  
しかし、250回程度実行すると`753664`などが設定されることがあり、以降は`write`を実行しても`0`となり、正常に動作していない。  
なお、`write`を1回実行するごとに毎回`open`と`close`を実行する場合は本エラーは発生しない。

以上から、本案件のYolo-Planar-SLAMでは`write`ごとに毎回`open`と`close`を実行するように変更した。

#### 7.1.3 入力画像のデータの書き込み方法について

受領した`YoloExecutor.cpp`には以下の処理が含まれている。

```cpp
img_buffer =(uint8_t*) mmap(NULL, bgr_image.rows * bgr_image.cols * bgr_image.channels() ,PROT_READ|PROT_WRITE, MAP_SHARED,  udmabuf_fd, 0);
// 略
ssize_t rw_udma_ret = write(udmabuf_fd, rgb_image.data, bgr_image.rows * bgr_image.cols * bgr_image.channels());
```

次に、DRP-AIのサンプルプログラム（`rzv2h_drpai-sample-application_ver0.80`の`app_yolov2_cam`）の実装を確認した。

DRP-AIのサンプルプログラムでは、以下の3か所で`/dev/udmabuf0`を`open`されていた。

```shell
$ grep -rn -I 'open("/dev/udmabuf0"' app_yolov2_cam/
app_yolov2_cam/src/image.cpp:122:    udmabuf_fd = open("/dev/udmabuf0", O_RDWR );
app_yolov2_cam/src/camera.cpp:88:    udmabuf_file = open("/dev/udmabuf0", O_RDWR);
app_yolov2_cam/src/main.cpp:649:    udmabuf_fd0 = open("/dev/udmabuf0", O_RDWR );
```

`open`された上記3つのファイルディスクリプタに対しては、いずれも`write`は実行されていなかった。

```shell
$ grep -rn -I 'write(udmabuf_fd' app_yolov2_cam/
$ grep -rn -I 'write(udmabuf_file' app_yolov2_cam/
$ grep -rn -I 'write(udmabuf_fd0' app_yolov2_cam/
$
```

`open`された上記3つのファイルディスクリプタを指定して`mmap`を実行している処理は3か所にあった。

```shell
$ grep -rn -I 'mmap(' app_yolov2_cam/
app_yolov2_cam/src/image.cpp:136:        img_buffer[i] =(unsigned char*) mmap(NULL, out_size ,PROT_READ|PROT_WRITE, MAP_SHARED,  udmabuf_fd, udmabuf_offset);
app_yolov2_cam/src/camera.cpp:99:        buffer[n] =(uint8_t *) mmap(NULL, imageLength ,PROT_READ|PROT_WRITE, MAP_SHARED,  udmabuf_file, n* offset);
app_yolov2_cam/src/main.cpp:654:    img_buffer0 = (unsigned char*) mmap(NULL, CAM_IMAGE_WIDTH * CAM_IMAGE_HEIGHT * CAM_IMAGE_CHANNEL_YUY2 ,PROT_READ|PROT_WRITE, MAP_SHARED,  udmabuf_fd0, _cap_offset + _img_offset);
```

以上から、DRP-AIのサンプルプログラムでは`write`ではなく、`mmap`で確保したポインタを経由して入力画像のデータを書き込んでいると考えられる。  
例えば、受領した`YoloExecutor.cpp`の`write`の処理は、以下のように書き換えることでも入力画像のデータを書き込むことができると考えられる。

```cpp
memcpy(img_buffer, rgb_image.data, bgr_image.rows * bgr_image.cols * bgr_image.channels());
```

また、`memcpy`を使用する場合には`7.1.2 /dev/udmabuf0のopenについて`に記載した250回程度実行するとエラーになる現象は再現できなかった。

以上から、本案件のYolo-Planar-SLAMでは`memcpy`による実装を採用した。

### 7.2 コヒーレンシについて

DRP-AIドライバのDDR2チャネル対応済みのDRP-AIのサンプルプログラムの開発者から以下のコメントがあった。

> ```markdown
> memcpyでコピーする場合、コピー後にキャッシュに残っているデータを吐き出す必要がありそうですが、  
> devicetreeをみると、`dma-coherent`とある
> ```

<https://github.com/ikwzm/udmabuf/blob/v4.5.2/Readme.ja.md#ハードウェアでコヒーレンシを保証できる場合>には以下の記載があった。

> ```markdown
> デバイスツリーで dma-coherent プロパティを設定した場合、ハードウェアでコヒーレンシを保証できることを指定します。
> ```

少なくともα2版のLinuxイメージ（のデバイスツリー）ではCPU（のキャッシュ）とメインメモリ（のDMAバッファ）の間のコヒーレンシは保証されていると考えられる。  
ただし、これがV2xボード（α2、EVK-α、電力改善版）の仕様で保証されているのかは判断できなかった。  
仕様として保証されていない場合は、将来的に変更される可能性が残る。

また、<https://github.com/ikwzm/udmabuf/blob/v4.5.2/Readme.ja.md#dma-coherent>には以下の記載があった。

> ```markdown
> /sys/class/u-dma-buf/<device-name>/dma_coherent は DMAバッファとCPUキャッシュのコヒーレンシをハードウェアで保証できるか否かを読み取ることができます。デバイスツリーで dma-coherent プロパティでハードウェアで保証できるか否かを指定することができますが、このデバイスファイルは読み取り専用です。
> 
> この値が1の時は、DMAバッファとCPUキャッシュのコヒーレンシはハードウェアで保証できることを示します。
> ```

上記について、α2版のLinuxイメージを書き込んだmicroSDカードを使用して、V2xボード（α2、EVK-α、電力改善版）上で確認した。

```shell
root@rzv2h-evk-alpha:~# cat /sys/class/u-dma-buf/udmabuf0/dma_coherent
1
```

「DMAバッファとCPUキャッシュのコヒーレンシはハードウェアで保証できる」が成立していることがわかる。

<https://github.com/ikwzm/udmabuf/blob/v4.5.2/Readme.ja.md#sync_mode>には以下の記載があった。

> ```markdown
> /sys/class/u-dma-buf/<device-name>/sync_mode はu-dma-bufをopenする際にO_SYNCを指定した場合の動作を指定します。
> ```

上記について、同じく確認した。

```shell
root@rzv2h-evk-alpha:~# cat /sys/class/u-dma-buf/udmabuf0/sync_mode
1
```

「sync_mode=1: O_SYNCフラグが設定された場合、CPUキャッシュを無効にします。O_SYNCフラグが設定されなかった場合、CPUキャッシュは有効です。」が成立していることがわかる。

仮にV2xボード（α2、EVK-α、電力改善版）の仕様として`dma-coherent`であることが将来的には保証されていない場合でも、以下のように`O_SYNC`フラグを指定して`/dev/udmabuf0`を`open`すればCPU（のキャッシュ）とメインメモリ（のDMAバッファ）の間のコヒーレンシは保証できると考えられる。

```diff
- udmabuf_fd = open("/dev/udmabuf0", O_RDWR);
+ udmabuf_fd = open("/dev/udmabuf0", O_RDWR | O_SYNC);
```

また、以下のように`msync`を使用して明示的にコヒーレンシを保証する方法も考えられる。

```diff
     memcpy(img_buffer, imgRGB.data, input_image_size);
+    errno = 0;
+    int ret = msync(img_buffer, input_image_size, MS_SYNC);
+    if (ret != 0) {
+        fprintf(stderr, "Failed to msync. Return code is %d, errno is %d\n", ret, errno);
+        return false;
+    }
```

しかし、α2版のLinuxイメージを書き込んだmicroSDカードを使用したV2xボード（α2、EVK-α、電力改善版）上ではエラーとなった。

```shell
Failed to msync. Return code is -1, errno is 22
```

`MS_ASYNC`フラグを指定した場合にはエラーとならないため、メモリ関連のドライバが`msync`または`fsync`などの同期関連の動作の一部をサポートしていない可能性が考えられる。

以上から、本案件のYolo-Planar-SLAMでは以下のように対応することとした。

1. `O_SYNC`フラグを指定して`/dev/udmabuf0`を`open`することで、CPU（のキャッシュ）とメインメモリ（のDMAバッファ）の間のコヒーレンシは将来的にも保証されると見なす
2. 本案件のYolo-Planar-SLAMでは、`O_SYNC`フラグを指定して`/dev/udmabuf0`を`open`する

`O_SYNC`フラグを指定することによる処理時間への影響を確認した。  
ここでは、単体プログラムを使用して簡易的に比較を行った。

`O_SYNC`無しの場合は以下の通り。

- 全体：`9.63`\[ms/frame\]
    - `memcpy`：`0.31`\[ms/frame\]
    - `polling`：`8.78`\[ms/frame\]

`O_SYNC`ありの場合は以下の通り。

- 全体：`11.78`\[ms/frame\]
    - `memcpy`：`3.31`\[ms/frame\]
    - `polling`：`7.92`\[ms/frame\]

単体プログラムでは、約`2`\[ms/frame\]だけ平均処理時間が増加していることがわかる。  
ただし、メモリアクセスの回数とデータ量にも依存するため、単体プログラムの結果がYolo-Planar-SLAMでも同様に当てはまるのかは判断できない。

以上から、V2xボード（α2、EVK-α、電力改善版）でハードウェアとしてCPU（のキャッシュ）とメインメモリ（のDMAバッファ）の間のコヒーレンシが保証されている場合には、`O_SYNC`フラグを指定せずに`/dev/udmabuf0`を`open`した方が、処理時間の観点では有利だと想定される。  
ただし、V2xボード（α2、EVK-α、電力改善版）の仕様として`dma-coherent`であることが将来的には保証されているのかについては、2023年12月時点では回答を得られていない。

### 7.3 0003-modify-memory-map-for-drpai.patchの適用

受領したYocto環境構築の手順のうち、`0003-modify-memory-map-for-drpai.patch`を適用しないように変更する手順を無効化した。  
また、Yocto環境構築を行い、CIP Linuxイメージをビルドした。

### 7.4 Yolo-Planar-SLAMのDDR2チャネル対応

#### 7.4.1 OpenCVA組み込み版

OpenCVA組み込み版のYolo-Planar-SLAMについて、α2版のDDR2チャネル対応を行った。

また、評価を行った。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1050
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版
- `0003-modify-memory-map-for-drpai.patch`適用済み

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1020.mono.opencva.ai.3wx.1050.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.101227
      mean      0.022619
    median      0.020086
       min      0.002980
      rmse      0.026002
       sse      0.565238
       std      0.012825

```

SLAM精度は破綻していないことがわかる。

また、DRP-AIのYOLOの結果が正常に取得できているのかを確認するために、Socket Viewerを有効化して目視確認した。  
目視で確認した限りでは不自然な点は無かった。

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

##### 7.4.1.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            10.197 |
| `　　cv::imread` |    99.9 |            10.19  |

##### 7.4.1.2 Image processingスレッド

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            69.887 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             0.683 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     5.1 |             3.593 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.8 |             3.415 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     5.3 |             3.764 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0.1 |             0.071 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.6 |             3.917 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.035 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.32  |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    48   |            33.595 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.7 |             2.618 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     4.8 |             3.423 |
| `　　ORBextractor::DistributeOctTree[0-7]`  　　　　　　　　　　　　|     4.8 |             3.369 |
| `　　computeOrientation[0-7]`   　　　　　　　　　　　　　　　　　　|     4.4 |             3.099 |
| `　　computeDescriptors[0-7]`   　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0-7]`  　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0-7]`　　　　　　　　　　|     0   |             0.021 |
| `　　　　copy parameter using MemcpyU2P[0-7]`   　　　　　　　　　　|     0   |             0.026 |
| `　　　　copy input image using MemcpyU2P[0-7]` 　　　　　　　　　　|     0.8 |             0.585 |
| `　　　　copy input keypoints using MemcpyU2P[0-7]` 　　　　　　　　|     0   |             0.023 |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.044 |
| `　　　　Start[0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.306 |
| `　　　　DRP time[0-7]★`　　　　　　　　　　　　　　　　　　　　　　|     6.1 |             4.305 |
| `　　　　MemcpyP2U[0-7]`　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.044 |
| `　　　　postprocess[0-7]`  　　　　　　　　　　　　　　　　　　　　|     0   |             0.02  |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            69.887 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    73.5 |            51.427 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.7 |             2.618 |
| `　　Image processing(second)`  　　　　　　　　　　　　　　　　　　|    22.6 |            15.838 |

##### 7.4.1.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            75.347 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.6 |            75.118 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    45.4 |            34.253 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    54.1 |            40.836 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.7 |             0.541 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    53.4 |            40.289 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     3   |             2.306 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.6 |             2.752 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.8 |             0.66  |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    14.9 |            11.272 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     8.6 |             6.53  |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     6   |             4.546 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    29.5 |            22.271 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.1 |             2.341 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9   |             6.803 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    17.2 |            12.976 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    14.1 |            10.678 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     2.8 |             2.18  |

2023年9月時点の`SLAM/CNN連携アプリ（Yocto）実装・評価報告書`の`11 OpenCVAの組み込み対応`の結果と比較して、平均処理時間に有意な差は無かった。

#### 7.4.2 OpenCVA差し替え版

OpenCVA差し替え版のYolo-Planar-SLAMについて、α2版のDDR2チャネル対応を行った。

また、評価を行った。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_xyz
- モード：RGB-D
- オプション：ヴィジュアライザ無し
- 最大特徴点数：1000
- OpenCVA：有効
- DRPドライバネイティブ：有効
- DRP-AI：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版
- `0003-modify-memory-map-for-drpai.patch`適用済み

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt CameraTrajectory.v2x.2023.1020.rgbd.opencva.drp.ai.3wx.1000.rep.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.076590
      mean      0.017881
    median      0.015447
       min      0.001827
      rmse      0.020836
       sse      0.355557
       std      0.010695

```

SLAM精度は破綻していないことがわかる。

計測結果は以下の通り。

```shell
median tracking time: 0.176026
mean tracking time: 0.176656
```

また、α2版のDDR2チャネル対応前の計測結果は以下の通り。

```shell
median tracking time: 0.168539
mean tracking time: 0.171617
```

α2版のDDR2チャネル対応によって、`median tracking time`は約`7`\[ms/frame\]だけ処理時間が増加していることがわかる。  
また`mean tracking time`は約`5`\[ms/frame\]だけ処理時間が増加していることがわかる。  
これはコヒーレンシを保証するために`O_SYNC`フラグを指定して`/dev/udmabuf0`を`open`することでCPUのキャッシュが無効化されているためだと考えられる。

## 8 投機実行対応

OpenCVA組み込み版（性能優先版）の投機実行対応について記載する。  
また、評価を行った結果について記載する。  
なお比較のために投機実行対応の前にも、OpenCVAありで評価した。

### 8.1 投機実行対応前

投機実行対応前の評価結果は以下の通り。

#### 8.1.1 OpenCVAあり、最大特徴点数1050

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**1050**
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版
- `0003-modify-memory-map-for-drpai.patch`適用済み

##### 8.1.1.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.1050.before.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.144945
      mean      0.041842
    median      0.035648
       min      0.002375
      rmse      0.049735
       sse      2.067885
       std      0.026885

```

最大誤差が`14`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.1050.before.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.1050.before
infos:  836 poses, 10.857m path length, 28.090s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/speculation/evo/opencva.1050.before/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/speculation/evo/opencva.1050.before/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/speculation/evo/opencva.1050.before/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 8.1.1.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

###### 8.1.1.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            10.002 |
| `　　cv::imread` |    99.9 |             9.996 |

###### 8.1.1.2.2 Image processingスレッド

`[0-7]`は全レベルの合算値であることを示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            70.061 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.552 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     4.9 |             3.455 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     5.1 |             3.605 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     6   |             4.211 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.068 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.5 |             3.881 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.036 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.317 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    47.9 |            33.573 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.9 |             2.765 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     4.8 |             3.418 |
| `　　ORBextractor::DistributeOctTree[0-7]`  　　　　　　　　　　　　|     4.7 |             3.313 |
| `　　computeOrientation[0-7]`   　　　　　　　　　　　　　　　　　　|     4.3 |             3.062 |
| `　　computeDescriptors[0-7]`   　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0-7]`  　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0-7]`　　　　　　　　　　|     0   |             0.021 |
| `　　　　copy parameter using MemcpyU2P[0-7]`   　　　　　　　　　　|     0   |             0.026 |
| `　　　　copy input image using MemcpyU2P[0-7]` 　　　　　　　　　　|     0.7 |             0.507 |
| `　　　　copy input keypoints using MemcpyU2P[0-7]` 　　　　　　　　|     0   |             0.023 |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　Start[0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.304 |
| `　　　　DRP time[0-7]★`　　　　　　　　　　　　　　　　　　　　　　|     6.1 |             4.307 |
| `　　　　MemcpyP2U[0-7]`　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　postprocess[0-7]`  　　　　　　　　　　　　　　　　　　　　|     0   |             0.018 |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            70.061 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    73.7 |            51.658 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.9 |             2.765 |
| `　　Image processing(second)`  　　　　　　　　　　　　　　　　　　|    22.3 |            15.633 |

###### 8.1.1.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            75.454 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.7 |            75.244 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    42.9 |            32.438 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    56.6 |            42.777 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.7 |             0.529 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    55.9 |            42.243 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     3.3 |             2.552 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.6 |             2.765 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.8 |             0.676 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    16.1 |            12.151 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9.4 |             7.149 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     6.3 |             4.772 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    30.6 |            23.151 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.5 |             2.668 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9.4 |             7.124 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    17.4 |            13.202 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    14.3 |            10.841 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     2.9 |             2.221 |

#### 8.1.2 OpenCVAあり、最大特徴点数3000

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**3000**
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版
- `0003-modify-memory-map-for-drpai.patch`適用済み

##### 8.1.2.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.3000.before.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.117522
      mean      0.023697
    median      0.019107
       min      0.001537
      rmse      0.029771
       sse      0.750694
       std      0.018021

```

最大誤差が`11`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.3000.before.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.3000.before
infos:  847 poses, 10.852m path length, 28.458s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/speculation/evo/opencva.3000.before/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/speculation/evo/opencva.3000.before/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/speculation/evo/opencva.3000.before/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 8.1.2.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

###### 8.1.2.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |             9.876 |
| `　　cv::imread` |    99.9 |             9.869 |

###### 8.1.2.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           111.617 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             0.602 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     3.1 |             3.55  |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     3.1 |             3.556 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     3.5 |             3.914 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.078 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     3.5 |             3.923 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.039 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.2 |             0.322 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    30.1 |            33.67  |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |    27.3 |            30.512 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3   |             3.43  |
| `　　ORBextractor::DistributeOctTree[0-7]`  　　　　　　　　　　　　|     6.1 |             6.881 |
| `　　computeOrientation[0-7]`   　　　　　　　　　　　　　　　　　　|     5.3 |             5.999 |
| `　　computeDescriptors[0-7]`   　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0-7]`  　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0-7]`　　　　　　　　　　|     0   |             0.044 |
| `　　　　copy parameter using MemcpyU2P[0-7]`   　　　　　　　　　　|     0   |             0.027 |
| `　　　　copy input image using MemcpyU2P[0-7]` 　　　　　　　　　　|     0.4 |             0.487 |
| `　　　　copy input keypoints using MemcpyU2P[0-7]` 　　　　　　　　|     0   |             0.03  |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.046 |
| `　　　　Start[0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.305 |
| `　　　　DRP time[0-7]★`　　　　　　　　　　　　　　　　　　　　　　|    10.2 |            11.438 |
| `　　　　MemcpyP2U[0-7]`　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.063 |
| `　　　　postprocess[0-7]`  　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           111.617 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    46.2 |            51.618 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |    27.3 |            30.512 |
| `　　Image processing(second)`  　　　　　　　　　　　　　　　　　　|    26.4 |            29.482 |

###### 8.1.2.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           117.398 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |           117.242 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    27.2 |            32.03  |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    72.5 |            85.161 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.7 |             0.908 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    71.7 |            84.245 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     3.2 |             3.773 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     2.7 |             3.215 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.9 |             1.143 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    26.3 |            30.982 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    11.7 |            13.805 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|    14.3 |            16.875 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    36.4 |            42.817 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.2 |             3.838 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    13.6 |            15.982 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    19.2 |            22.64  |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    14.4 |            16.974 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     4.5 |             5.4   |

### 8.2 投機実行対応後

投機実行対応後の評価結果は以下の通り。

#### 8.2.1 OpenCVA無し、最大特徴点数1050

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**1050**
- DRP：無効
- DRP-AI：有効
- OpenCVA：無効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版
- `0003-modify-memory-map-for-drpai.patch`適用済み

##### 8.2.1.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.speculation.mono.cpu.ai.3wx.1050.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.471375
      mean      0.055417
    median      0.039056
       min      0.001910
      rmse      0.081891
       sse      5.706933
       std      0.060292

```

最大誤差が`47`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.speculation.mono.cpu.ai.3wx.1050.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.speculation.mono.cpu.ai.3wx.1050
infos:  851 poses, 11.123m path length, 28.594s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/speculation/evo/cpu.1050/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/speculation/evo/cpu.1050/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/speculation/evo/cpu.1050/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 8.2.1.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  

###### 8.2.1.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            14.434 |
| `　　cv::imread` |    99.9 |            14.421 |

###### 8.2.1.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            84.609 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.592 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     4   |             3.414 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　|     7.9 |             6.764 |
| `　　　　cv::copyMakeBorder[0-7]`   　　　　　　　　　　　　　　　　|     0.9 |             0.765 |
| `　　　　Resize[0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     6.9 |             5.864 |
| `　　GaussianBlur[0-7]` 　　　　　　　　　　　　　　　　　　　　　　|    12.3 |            10.479 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　|    39.9 |            33.791 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.041 |
| `　　　　FAST[0-7]` 　　　　　　　　　　　　　　　　　　　　　　　　|    39.4 |            33.404 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     0.3 |             0.264 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.9 |             3.372 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     3.7 |             3.179 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.006 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     3.8 |             3.246 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0][0-7]`　　　　　　　　　　　　　　　　　　|    20.7 |            17.538 |
| `　　computeDescriptors[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.025 |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            84.609 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    66.7 |            56.473 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     0.3 |             0.264 |
| `　　Image processing(second)[0-1]` 　　　　　　　　　　　　　　　　|    32.8 |            27.832 |

###### 8.2.1.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            90.02  |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.7 |            89.787 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    53.6 |            48.309 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    46   |            41.45  |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.5 |             0.53  |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    45.4 |            40.914 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     2.1 |             1.938 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     1.1 |             1.077 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.2 |             0.234 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    12.7 |            11.452 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     7.4 |             6.687 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     5   |             4.527 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    27.5 |            24.784 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.2 |             2.897 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     7.8 |             7.059 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    16.2 |            14.67  |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    13.3 |            12.057 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     2.7 |             2.446 |

#### 8.2.2 OpenCVAあり、最大特徴点数1050

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**1050**
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版
- `0003-modify-memory-map-for-drpai.patch`適用済み

なお、投機実行の後に`max_features`が更新され、再実行が発生した回数は、859フレーム中1回だった。

##### 8.2.2.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.1050.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.174151
      mean      0.024523
    median      0.021171
       min      0.003370
      rmse      0.030977
       sse      0.802228
       std      0.018927

```

最大誤差が`17`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.1050.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.1050
infos:  836 poses, 10.957m path length, 28.090s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/speculation/evo/opencva.1050/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/speculation/evo/opencva.1050/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/speculation/evo/opencva.1050/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 8.2.2.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

###### 8.2.2.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            10.251 |
| `　　cv::imread` |    99.9 |            10.245 |

###### 8.2.2.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.648 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.608 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     5.1 |             3.503 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     5.1 |             3.512 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     5.7 |             3.922 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.038 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.8 |             4.012 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.036 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.323 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    49   |            33.646 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     2.1 |             1.45  |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     4.9 |             3.382 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.7 |             3.264 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.005 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.4 |             3.05  |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.02  |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.026 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.7 |             0.495 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.023 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.305 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     6.2 |             4.309 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.018 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.648 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    75   |            51.499 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     2.1 |             1.45  |
| `　　Image processing(second)[0-1]` 　　　　　　　　　　　　　　　　|    22.8 |            15.664 |

###### 8.2.2.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            74.051 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.022 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.6 |            73.789 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    42.3 |            31.331 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    57.2 |            42.43  |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.7 |             0.526 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    56.5 |            41.898 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     3.1 |             2.359 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.7 |             2.809 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.9 |             0.693 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    16.1 |            11.993 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9.5 |             7.075 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     6.3 |             4.695 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    31.1 |            23.069 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.5 |             2.618 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9.5 |             7.089 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    17.8 |            13.21  |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    14.6 |            10.839 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     3   |             2.236 |

#### 8.2.3 OpenCVA無し、最大特徴点数3000

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**3000**
- DRP：無効
- DRP-AI：有効
- OpenCVA：無効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版
- `0003-modify-memory-map-for-drpai.patch`適用済み

##### 8.2.3.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.speculation.mono.cpu.ai.3wx.3000.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.127849
      mean      0.043245
    median      0.038040
       min      0.002096
      rmse      0.050873
       sse      2.171415
       std      0.026795

```

最大誤差が`12`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.speculation.mono.cpu.ai.3wx.3000.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.speculation.mono.cpu.ai.3wx.3000
infos:  839 poses, 10.161m path length, 28.190s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/speculation/evo/cpu.3000/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/speculation/evo/cpu.3000/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/speculation/evo/cpu.3000/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 8.2.3.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。

###### 8.2.3.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            15.523 |
| `　　cv::imread` |    99.9 |            15.516 |

###### 8.2.3.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           121.939 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.605 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     2.7 |             3.383 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　|     5.5 |             6.828 |
| `　　　　cv::copyMakeBorder[0-7]`   　　　　　　　　　　　　　　　　|     0.6 |             0.766 |
| `　　　　Resize[0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     4.8 |             5.933 |
| `　　GaussianBlur[0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     8.9 |            10.894 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　|    27.7 |            33.779 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　FAST[0-7]` 　　　　　　　　　　　　　　　　　　　　　　　　|    27.3 |            33.395 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     2.4 |             2.979 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     2.7 |             3.4   |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     5.5 |             6.745 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.011 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     5.1 |             6.306 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.01  |
| `　　computeDescriptors[0][0-7]`　　　　　　　　　　　　　　　　　　|    36.8 |            44.888 |
| `　　computeDescriptors[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.066 |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           121.939 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    46.7 |            56.989 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     2.4 |             2.979 |
| `　　Image processing(second)[0-1]` 　　　　　　　　　　　　　　　　|    50.7 |            61.932 |

###### 8.2.3.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           127.705 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |           127.516 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    36   |            46.059 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    63.7 |            81.394 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.7 |             0.907 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    63   |            80.479 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     2.1 |             2.684 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.6 |             4.652 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     1.3 |             1.737 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    21.7 |            27.767 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    10.1 |            12.922 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|    11.3 |            14.547 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    32.8 |            41.952 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     2.8 |             3.696 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    11.9 |            15.227 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    17.7 |            22.671 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    13.2 |            16.913 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     4.3 |             5.52  |

#### 8.2.4 OpenCVAあり、最大特徴点数3000

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**3000**
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：α2版
- `0003-modify-memory-map-for-drpai.patch`適用済み

なお、投機実行の後に`max_features`が更新され、再実行が発生した回数は、859フレーム中1回だった。

##### 8.2.4.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.3000.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.097824
      mean      0.018144
    median      0.015721
       min      0.001131
      rmse      0.021655
       sse      0.397199
       std      0.011821

```

最大誤差が`9`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.3000.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.speculation.mono.opencva.ai.3wx.3000
infos:  847 poses, 10.663m path length, 28.458s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/speculation/evo/opencva.3000/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/speculation/evo/opencva.3000/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/speculation/evo/opencva.3000/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 8.2.4.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

###### 8.2.4.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |             9.825 |
| `　　cv::imread` |    99.9 |             9.819 |

###### 8.2.4.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            93.73  |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.66  |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     3.7 |             3.525 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     3.8 |             3.587 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.4 |             4.132 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.033 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     4.2 |             4.011 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.036 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.3 |             0.321 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    35.8 |            33.597 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |    12.6 |            11.819 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.6 |             3.399 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     7.4 |             7.019 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.011 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     6.4 |             6.051 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.009 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.046 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.027 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.5 |             0.538 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.031 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.048 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             0.309 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|    12.2 |            11.448 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.017 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.068 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.047 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            93.73  |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    55.4 |            51.938 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |    12.6 |            11.819 |
| `　　Image processing(second)[0-1]` 　　　　　　　　　　　　　　　　|    31.9 |            29.933 |

###### 8.2.4.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            99.468 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |            99.287 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    10.5 |            10.47  |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    89.2 |            88.754 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.9 |             0.901 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    88.3 |            87.845 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     3.8 |             3.801 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.2 |             3.237 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     1.1 |             1.156 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    31.8 |            31.67  |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    13.9 |            13.833 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|    17.6 |            17.535 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    45.5 |            45.308 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.8 |             3.867 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    17   |            17.006 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    24.1 |            24.042 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    17.8 |            17.797 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     6   |             5.982 |

#### 8.2.5 考察

評価結果から、今回の評価条件では投機実行の後に`max_features`が更新されて再実行が必要となるケースは十分に少なく、再実行にかかる処理時間も十分に小さいことがわかる。

投機実行の動作原理と、ボトルネック解析結果について説明する。

並列動作しないと仮定した場合の比較結果を以下の図に示す。  
なお、括弧内の値は最大特徴点数を表す。

![Yolo-Planar-SLAMの処理時間の比較](image/speculation/consider/serial.png)

いずれのケースでも3つのスレッドの中で、Trackingスレッドの平均処理時間がもっとも大きい。

最大特徴点数が同じかつOpenCVA無しの場合と比較したときの高速化倍率を以下の図に示す。

![高速化倍率](image/speculation/consider/scale.png)

いずれのケースでも3つのスレッドの中で、Trackingスレッドの平均処理時間がもっとも大きいため、SLAMの性能としての高速化倍率はTrackingスレッドの高速化倍率となる。  
TUMデータセットを使用した場合では最大特徴点数が`3000`の場合がOpenCVAによる高速化の効果を得られていることがわかる。

##### 8.2.5.1 Image loadingスレッド

Image loadingスレッドの処理時間を以下の図に示す。  
なお、括弧内の値は最大特徴点数を表す。

![Image loadingスレッドの処理時間](image/speculation/consider/image_loading.png)

OpenCVAでDRPを使用している場合と比較して、OpenCVAを使用しない場合の方が平均処理時間が大きいことがわかる。  
CPU処理の負荷が高いほど、Image loadingスレッドの平均処理時間が増加すると考えられる。

##### 8.2.5.2 Image processingスレッド

Image processingスレッドの処理時間を以下の図に示す。  
なお、括弧内の値は最大特徴点数を表す。

![Image processingスレッドの処理時間](image/speculation/consider/image_processing_0.png)

最大特徴点数が約3倍になると、Image processingスレッド全体の平均処理時間は約1.4倍になる。

Image processingスレッドの処理時間の内訳を以下の図に示す。

![Image processingスレッドの処理時間の内訳](image/speculation/consider/image_processing_1.png)

一番下のケースのみmax_featuresの待機時間が比較的大きいことがわかる。  
最大特徴点数が約3倍になると、Image processingの後半の平均処理時間は約2倍となっている。

Image processingスレッドの処理時間の比率を以下の図に示す。

![Image processingスレッドの処理時間の比率](image/speculation/consider/image_processing_2.png)

max_featuresの待機時間が大きいケースと十分に小さいケースが混在していることがわかる。

##### 8.2.5.3 Trackingスレッド

Trackingスレッドの処理時間を以下の図に示す。  
なお、括弧内の値は最大特徴点数を表す。

![Trackingスレッドの処理時間](image/speculation/consider/tracking_0.png)

最大特徴点数が約3倍になると、Trackingスレッド全体の平均処理時間は約1.4倍になる。

Trackingスレッドの処理時間の内訳を以下の図に示す。

![Trackingスレッドの処理時間の内訳](image/speculation/consider/tracking_1.png)

最大特徴点数が約3倍になると、`Tracking::GrabImage*`の平均処理時間は約2倍になる。

Trackingスレッドの処理時間の比率を以下の図に示す。

![Trackingスレッドの処理時間の比率](image/speculation/consider/tracking_2.png)

##### 8.2.5.4 SLAM全体

Image loadingスレッド、Image processingスレッド、Trackingスレッドの処理時間の概要を以下の図に示す。  
なお、括弧内の値は最大特徴点数を表す。

![スレッドごとの処理時間の内訳](image/speculation/consider/summary.png)

Image processingスレッドとTrackingスレッドの平均処理時間がほぼ同じであることがわかる。  
ただし、排他制御による待ち時間も含まれているため注意する必要がある。

max_featuresに関する排他制御について、投機実行対応**前**の概要を以下の図に示す。

![投機実行対応前のmax_featuresに関する排他制御](image/speculation/consider/max_features_0.png)

各スレッドの依存関係を矢印で示している。  
Image processingスレッドでは、前半と後半の処理の間にmax_featuresの待機処理が発生する。

同じく投機実行対応**後**かつ、Trackingよりも、待機時間を除くImage processingの処理時間の方が**大きい**ケースの概要を以下の図に示す。

![投機実行対応後のmax_featuresに関する排他制御（1）](image/speculation/consider/max_features_1.png)

Image processingスレッドでは、前半と後半の処理の後にmax_featuresの待機処理が発生する。  
Image processingの前半の処理時間が大きい場合は、投機実行による効果が得られていない。

同じく投機実行対応**後**かつ、Trackingよりも、待機時間を除くImage processingの処理時間の方が**小さい**ケースの概要を以下の図に示す。

![投機実行対応後のmax_featuresに関する排他制御（2）](image/speculation/consider/max_features_2.png)

Image processingの前半の処理時間が小さい場合は、Trackingスレッドの排他制御による待ち時間を削減できることがわかる。

Image processingスレッドの前半の処理と、max_featuresの待機処理と、`Tracking::GrabImage*`の処理の関係を以下の図に示す。

![max_featuresの待機処理と処理時間の関係](image/speculation/consider/max_features_3.png)

最大特徴点数が1050の場合は、Image processingの前半の処理時間が`Tracking::GrabImage*`を超えている。  
したがって、max_featuresの待機時間は多くのフレームで0で、Image processingの前半の処理が終わる時点ではmax_featuresを受け取れていると思われる。

Image processingスレッドとTrackingスレッドの処理時間を以下の図に示す。

![Image processingスレッドとTrackingスレッドの処理時間](image/speculation/consider/result_0.png)

最大特徴点数が`1050`の場合では、Image processingの前半の方が`Tracking::GrabImage*`よりも平均処理時間が大きいため、投機実行の効果を得られていない。  
最大特徴点数が`3000`かつCPUの場合では、Image processingの方がTrackingよりも平均処理時間が大きいため、投機実行の効果を得られていない。  
青枠で囲った最大特徴点数が`3000`かつOpenCVAの場合では、投機実行の効果を得られている。

![投機実行の対応前後の平均処理時間の比較](image/speculation/consider/result_1.png)

投機実行によって、Image processingスレッドとTrackingスレッドの排他制御による待機時間を削減できていることがわかる。  
なお、投機実行の対応後の赤色で示した部分の右側には、2回目のImage processingの後半の処理時間があるが、無視できるほど小さいため記載を省略した。

##### 8.2.5.5 DRP移植範囲

DRPへ処理を移植されているresize、GaussianBlur、FAST、computeDescriptorsに着目した時のImage processingの処理時間を以下の図に示す。  
なお、括弧内の値は最大特徴点数を表す。

![DRP移植範囲についての処理時間](image/speculation/cpu-drp-performance.png)

`単眼+CPU`はCPU処理時間を記載している。  
また、`単眼+OpenCVA`はCPU処理時間とDRP処理時間を区別できないため合算した値を記載している。  
ただし、computeDescriptorsのみはDRPドライバネイティブ動作のためDRP処理時間を記載した。

なお、OpenCVAのFASTはほとんどのケースでDRP動作のための制約条件を満たせていないため、CPUで動作している点に注意する必要がある。

FAST以外については、DRP動作による高速化の効果が得られていることがわかる。

## 9 β版移行

受領したβ版のBSPファイル一式を使用して、Yocto環境を構築し、ビルドしたCIP Linuxを使用してV2xボード（α2、EVK-α、電力改善版）が正常に動作するのかを確認した結果を記載する。

### 9.1 2023年10月10日時点のβ版のYocto環境構築

受領した`Linux.zip`、`DRP-AI.zip`を使用して、`EPSD-IMB-23-0095-01_RZV2H_GettingStarted_ForBeta.pdf`の手順の通りにYocto環境の構築を行い動作確認した。  
しかしDRPドライバとOpenCVAドライバが認識できなかった。

#### 9.1.1 受領時点のLinuxイメージでの動作確認

まず、受領した時点のV2xボード（α2、EVK-α、電力改善版）のmicroSDカードに書き込まれていたイメージを使用して、CIP Linuxが起動できることを確認した。  
また、`/dev`以下の下記のデバイスパスが認識されていることを確認した。

```shell
root@rzv2h-evk-alpha:~# ls /dev/drp*
/dev/drp1  /dev/drpai0
root@rzv2h-evk-alpha:~# ls /dev/opencva*
/dev/opencva0
```

次に、`EPSD-IMB-23-0095-01_RZV2H_GettingStarted_ForBeta.pdf`のp16に記載されているSW2の設定と、受領時点での設定が異なっていたため変更を行った。  
受領時点ではSW2は`OFF,OFF,OFF,ON,OFF,OFF`であった。  
これを`ON,ON,OFF,ON,OFF,OFF`に変更した。
変更後に同じくCIP Linuxが起動できることを確認した。  
また、`/dev`以下のデバイスパスが同じく認識されていることを確認した。

#### 9.1.2 β版のLinuxイメージでの動作確認

次に`EPSD-IMB-23-0095-01_RZV2H_GettingStarted_ForBeta.pdf`のp21までの手順を実行した。  
ただし`STEP3 WRITE FLASH WRITER AND LOADER SW FOR eMMC BOOT`の手順は受領時点で完了していたため省略した。  
なおデバイスツリーファイルの名前のみ`Image-r9a09g057h4-evk-alpha.dtb`から`Imager9a09g057h4-evk.dtb`に変更されていたため、U-bootで以下のコマンドを実行した。

```shell
setenv imgdtb 'Image-r9a09g057h4-evk.dtb'
saveenv
```

なお、`printenv`で確認した`bootcmd`の設定値は以下の通り。

```shell
bootcmd=i2c dev 8; i2c mw 0x6a 0x24 0x00; i2c md 0x6a 0x00 0x30; i2c mw 0x12 0x8D 0x02; i2c md 0x12 0x2D 0x80; mmc dev 1; fatload mmc 1:1 ${ocaaddr} ${ocabin}; fatload mmc 1:1 0x48080000 Image-rzv2h-evk-alpha.bin; fatload mmc 1:1 0x48000000 ${imgdtb}; booti 0x48080000 - 0x48000000
```

作成したmicroSDカードをV2xボード（α2、EVK-α、電力改善版）に入れてCIP Linuxを起動した。  
しかし、`/dev/drp1`と`/dev/opencva0`が認識されていなかった。

```shell
root@rzv2h-evk-alpha:~# ls /dev/drp*
/dev/drpai0
root@rzv2h-evk-alpha:~# ls /dev/opencva*
ls: cannot access /dev/opencva*: No such file or directory
```

確認したところ、デバイスツリーには`drp1`と`opencva`が含まれていなかった。

```shell
$ dtc -I dtb -O dts -o Image-r9a09g057h4-evk.2023-1010.dts \
>   images.2023-1010/rzv2h-evk-alpha/Image-r9a09g057h4-evk.dtb
$ grep drp Image-r9a09g057h4-evk.2023-1010.dts
                drpai@16800000 {
                        compatible = "renesas,rzv2h-drpai";
$ grep opencva Image-r9a09g057h4-evk.2023-1010.dts
$
```

なお、受領時点でmicroSDカードに書き込まれていたデバイスツリーには`drp1`と`opencva`が含まれていた。

```shell
$ dtc -I dtb -O dts -o Image-r9a09g057h4-evk-alpha.2023-0901.dts \
>   images.2023-0901/rzv2h-evk-alpha/Image-r9a09g057h4-evk-alpha.dtb
$ grep drp Image-r9a09g057h4-evk-alpha.2023-0901.dts
                drp1@18000000 {
                        compatible = "renesas,rzv2h-drp";
                drpai@16800000 {
                        compatible = "renesas,rzv2h-drpai";
$ grep opencva Image-r9a09g057h4-evk-alpha.2023-0901.dts
                opencva@C0000000 {
                        compatible = "renesas,rzv2h-opencva";
```

以上から、β版へのアップデートに伴ってDRPドライバとOpenCVAドライバがデバイスツリーに含まれなくなったと考えられる。

なお、β版の開発者からは以下の回答が得られた。

> ```markdown
> 共有させていただきました環境にはDRPドライバ、OpenCVAが含まれておりません。
> ```

### 9.2 2023年10月31日時点のβ版のYocto環境構築

受領した`20231027_RZV2H_linux_drpドライバ_レシピ_OpenCV一式.zip`を使用して、`RZV2H_linux_VLP_beta版_drpドライバ_OpenCV_組み込み手順書.txt`の手順の通りにYocto環境の構築を行い動作確認した。

#### 9.2.1 glib-2.0

`glib-2.0`のビルドでエラーとなった。

`MACHINE=rzv2h-evk-alpha bitbake core-image-bsp`を実行すると以下のエラーとなった。

```shell
WARNING: glib-2.0-native-2.58.3-r0 do_fetch: Failed to fetch URL https://security.debian.org/debian-security/pool/updates/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.debian.tar.xz;name=glib2.0_2.58.3-2+deb10u4.debian.tar.xz, attempting MIRRORS if available
ERROR: glib-2.0-native-2.58.3-r0 do_fetch: Fetcher failure: Fetch command export PSEUDO_DISABLED=1; export PATH="/yocto_rzv2x_beta_workdir/poky/scripts/native-intercept:/yocto_rzv2x_beta_workdir/build/tmp/sysroots-uninative/x86_64-linux/usr/bin:/yocto_rzv2x_beta_workdir/build/tmp/work/x86_64-linux/glib-2.0-native/2.58.3-r0/recipe-sysroot-native/usr/bin/python3-native:/yocto_rzv2x_beta_workdir/poky/scripts:/yocto_rzv2x_beta_workdir/build/tmp/work/x86_64-linux/glib-2.0-native/2.58.3-r0/recipe-sysroot-native/usr/bin/x86_64-linux:/yocto_rzv2x_beta_workdir/build/tmp/work/x86_64-linux/glib-2.0-native/2.58.3-r0/recipe-sysroot-native/usr/bin:/yocto_rzv2x_beta_workdir/build/tmp/work/x86_64-linux/glib-2.0-native/2.58.3-r0/recipe-sysroot-native/usr/sbin:/yocto_rzv2x_beta_workdir/build/tmp/work/x86_64-linux/glib-2.0-native/2.58.3-r0/recipe-sysroot-native/usr/bin:/yocto_rzv2x_beta_workdir/build/tmp/work/x86_64-linux/glib-2.0-native/2.58.3-r0/recipe-sysroot-native/sbin:/yocto_rzv2x_beta_workdir/build/tmp/work/x86_64-linux/glib-2.0-native/2.58.3-r0/recipe-sysroot-native/bin:/yocto_rzv2x_beta_workdir/poky/bitbake/bin:/yocto_rzv2x_beta_workdir/build/tmp/hosttools"; export HOME="/home/pokyuser"; /usr/bin/env wget -t 2 -T 30 --passive-ftp --no-check-certificate -O /yocto_rzv2x_beta_workdir/build/downloads/glib2.0_2.58.3-2+deb10u4.debian.tar.xz.tmp -P /yocto_rzv2x_beta_workdir/build/downloads 'https://security.debian.org/debian-security/pool/updates/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.debian.tar.xz' --progress=dot -v failed with exit code 8, no output
ERROR: glib-2.0-native-2.58.3-r0 do_fetch: Bitbake Fetcher Error: FetchError('Unable to fetch URL from any source.', 'https://security.debian.org/debian-security/pool/updates/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.debian.tar.xz;name=glib2.0_2.58.3-2+deb10u4.debian.tar.xz')
```

`glib2.0_2.58.3-2+deb10u4.debian.tar.xz`をダウンロードできていないことがわかる。

`DEBIAN_SECURITY_UPDATE_MIRROR`を`DEBIAN_MIRROR`に変更してエラーが解消されるのかを確認した。  
`meta-renesas/meta-rz-common/recipes-debian/buster/sources/glib2.0.inc`の変更内容は以下の通り。

```diff
 DEBIAN_SRC_URI = " \
-    ${DEBIAN_SECURITY_UPDATE_MIRROR}/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.dsc;name=glib2.0_2.58.3-2+deb10u4.dsc \
-    ${DEBIAN_SECURITY_UPDATE_MIRROR}/main/g/glib2.0/glib2.0_2.58.3.orig.tar.xz;name=glib2.0_2.58.3.orig.tar.xz \
-    ${DEBIAN_SECURITY_UPDATE_MIRROR}/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.debian.tar.xz;name=glib2.0_2.58.3-2+deb10u4.debian.tar.xz \
+    ${DEBIAN_MIRROR}/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.dsc;name=glib2.0_2.58.3-2+deb10u4.dsc \
+    ${DEBIAN_MIRROR}/main/g/glib2.0/glib2.0_2.58.3.orig.tar.xz;name=glib2.0_2.58.3.orig.tar.xz \
+    ${DEBIAN_MIRROR}/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.debian.tar.xz;name=glib2.0_2.58.3-2+deb10u4.debian.tar.xz \
 "
```

しかしエラーは解消されなかった。

```shell
WARNING: glib-2.0-2.58.3-r0 do_fetch: Failed to fetch URL http://ftp.debian.org/debian/pool/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.debian.tar.xz;name=glib2.0_2.58.3-2+deb10u4.debian.tar.xz, attempting MIRRORS
 if available
ERROR: glib-2.0-2.58.3-r0 do_fetch: Fetcher failure: Fetch command export PSEUDO_DISABLED=1; export PATH="/yocto_rzv2x_beta_workdir/build/tmp/sysroots-uninative/x86_64-linux/usr/bin:/yocto_rzv2x_beta_workdir/build/tmp/work/aarch64-poky-linux/glib-2.0/2.58.3-r0/recipe-sysroot-native/usr/bin/python3-native:/yocto_rzv2x_beta_workdir/poky/scripts:/yocto_rzv2x_beta_workdir/build/tmp/work/aarch64-poky-linux/glib-2.0/2.58.3-r0/recipe-sysroot-native/usr/bin/aarch64-poky-linux:/yocto_rzv2x_beta_workdir/build/tmp/work/aarch64-poky-linux/glib-2.0/2.58.3-r0/recipe-sysroot/usr/bin/crossscripts:/yocto_rzv2x_beta_workdir/build/tmp/work/aarch64-poky-linux/glib-2.0/2.58.3-r0/recipe-sysroot-native/usr/sbin:/yocto_rzv2x_beta_workdir/build/tmp/work/aarch64-poky-linux/glib-2.0/2.58.3-r0/recipe-sysroot-native/usr/bin:/yocto_rzv2x_beta_workdir/build/tmp/work/aarch64-poky-linux/glib-2.0/2.58.3-r0/recipe-sysroot-native/sbin:/yocto_rzv2x_beta_workdir/build/tmp/work/aarch64-poky-linux/glib-2.0/2.58.3-r0/recipe-sysroot-native/bin:/yocto_rzv2x_beta_workdir/poky/bitbake/bin:/yocto_rzv2x_beta_workdir/build/tmp/hosttools"; export HOME="/home/pokyuser"; /usr/bin/env wget -t 2 -T 30 --passive-ftp --no-check-certificate -O /yocto_rzv2x_beta_workdir/build/downloads/glib2.0_2.58.3-2+deb10u4.debian.tar.xz.tmp -P /yocto_rzv2x_beta_workdir/build/downloads 'http://ftp.debian.org/debian/pool/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.debian.tar.xz' --progress=dot -v failed with exit code 8, no output
ERROR: glib-2.0-2.58.3-r0 do_fetch: Bitbake Fetcher Error: FetchError('Unable to fetch URL from any source.', 'http://ftp.debian.org/debian/pool/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.debian.tar.xz;name=glib2.0_2.58.3-2+deb10u4.debian.tar.xz')
```

<https://security.debian.org/debian-security/pool/updates/main/g/glib2.0/>を確認したところ、`deb10u4`に該当するファイルは存在しなかった。

そこで、`deb10u5`へ変更して、エラーが解消されるのかを確認した。  
`meta-renesas/meta-rz-common/recipes-debian/buster/sources/glib2.0.inc`の変更内容は以下の通り。

```diff
 # This is generated by debian-source.bbclass
-DPV = "2.58.3-2+deb10u4"
+DPV = "2.58.3-2+deb10u5"
 DPV_EPOCH = ""
 REPACK_PV = "2.58.3"
 PV = "2.58.3"

 DEBIAN_SRC_URI = " \
-    ${DEBIAN_SECURITY_UPDATE_MIRROR}/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.dsc;name=glib2.0_2.58.3-2+deb10u4.dsc \
+    ${DEBIAN_SECURITY_UPDATE_MIRROR}/main/g/glib2.0/glib2.0_2.58.3-2+deb10u5.dsc;name=glib2.0_2.58.3-2+deb10u5.dsc \
     ${DEBIAN_SECURITY_UPDATE_MIRROR}/main/g/glib2.0/glib2.0_2.58.3.orig.tar.xz;name=glib2.0_2.58.3.orig.tar.xz \
-    ${DEBIAN_SECURITY_UPDATE_MIRROR}/main/g/glib2.0/glib2.0_2.58.3-2+deb10u4.debian.tar.xz;name=glib2.0_2.58.3-2+deb10u4.debian.tar.xz \
+    ${DEBIAN_SECURITY_UPDATE_MIRROR}/main/g/glib2.0/glib2.0_2.58.3-2+deb10u5.debian.tar.xz;name=glib2.0_2.58.3-2+deb10u5.debian.tar.xz \
 "

-SRC_URI[glib2.0_2.58.3-2+deb10u4.dsc.md5sum] = "78b940369a5ab3a395497cb88dabc18d"
+SRC_URI[glib2.0_2.58.3-2+deb10u5.dsc.md5sum] = "c9c7fe5ccab432f00a2e92c73620ea68"
 SRC_URI[glib2.0_2.58.3.orig.tar.xz.md5sum] = "8058c7bde846dcffe5fa453eca366d73"
-SRC_URI[glib2.0_2.58.3-2+deb10u4.debian.tar.xz.md5sum] = "2d384cdac5f483e3e80544505c1b4788"
+SRC_URI[glib2.0_2.58.3-2+deb10u5.debian.tar.xz.md5sum] = "e8ad6cbb292b5a3662ff4d03046c968c"

-SRC_URI[glib2.0_2.58.3-2+deb10u4.dsc.sha256sum] = "8a2b7d98dd7f3e5ed4908d06d13b919989f1712e3a5e348be45e266fb72a2cb9"
+SRC_URI[glib2.0_2.58.3-2+deb10u5.dsc.sha256sum] = "59c25e933d20f4f711c4b6685fbfeb46f1df344aa0e09c862b77fcaef94c57d3"
 SRC_URI[glib2.0_2.58.3.orig.tar.xz.sha256sum] = "8f43c31767e88a25da72b52a40f3301fefc49a665b56dc10ee7cc9565cbe7481"
-SRC_URI[glib2.0_2.58.3-2+deb10u4.debian.tar.xz.sha256sum] = "2a62cdccabd2bdcac1015913599cf04966895fadd76424790a687652f7e53277"
+SRC_URI[glib2.0_2.58.3-2+deb10u5.debian.tar.xz.sha256sum] = "5c9d1dc438c0a8923eaf65391e04906230d06a71426dc1aa6df785b12a4d21d4"
```

上記の変更を適用した状態で、エラーが解消されることを確認できた。

レシピの開発者からは以下の回答が得られた。

> ```markdown
> 本件について弊社でも本日問題と対策(patch)の連絡がありました。
> patch:  
> `0001-rz-common-debian-buster-Update-glib2.0-to-2.58.3-2-d.patch`
> 
> 適用手順:  
> >  $ cd meta-renesas  
> >  $ patch -p1 < <patch file dir>/0001-rz-common-debian-buster-Update-glib2.0-to-2.58.3-2-d.patch  
> >  $ cd ..
> ```

前述の変更内容と、`0001-rz-common-debian-buster-Update-glib2.0-to-2.58.3-2-d.patch`の内容は厳密に一致していた。

#### 9.2.2 OpenCVAドライバ

`RZV2H_linux_VLP_beta版_drpドライバ_OpenCV_組み込み手順書.txt`には以下の記載がある。

> ・OpenCVAドライバが削除されました

また、β版のOpenCVAの実装を確認した。

`opencv/4.1.0-r0/git/modules/imgproc/include/rzv2ma_drp.h`に以下の記述がある。

```cpp
#define DRV_DEV_NAME "/dev/opencva0"
```

`DRV_DEV_NAME`は`opencv/4.1.0-r0/git/modules/imgproc/src/rzv2ma_drp.cpp`の`rzv2m_drp::initialize`から参照されている。

```cpp
void rzv2m_drp::initialize(void)
{
    fd_drv = 0;
    int ret = 0;
    drp_data_t local_drp_data;

    /* opencva driver open */
    if ((fd_drv = open(DRV_DEV_NAME, O_RDWR)) < 0)
    {
        return;
    }
// 略
```

`rzv2m_drp::initialize`は`rzv2m_drp::get_instance`から呼び出されている。

```cpp
rzv2m_drp* rzv2m_drp::get_instance()
{
    drp_initialize_mutex.lock();

    /* check initialize if not exec initialize */
    if(_singleton == NULL)
    {
        _singleton = new rzv2m_drp();
        _singleton->initialize();
// 略
```

`rzv2m_drp::get_instance`は`cv::resize_drp`から呼び出されている。

```cpp
int resize_drp(InputArray _src, OutputArray _dst, Size dsize, double inv_scale_x, double inv_scale_y, int interpolation)
{
    CV_LOG_INFO(nullptr, "resize_drp start.");

    /* get single instance */
    rzv2m_drp *drp = rzv2m_drp::get_instance();
    if(NULL == drp)
    {
        CV_LOG_INFO(nullptr, "resize_drp get instance");
        return DRP_NOT_EXECUTE;
    }
// 略
```

以上から、`/dev/opencva0`が無い状態では、OpenCVAの中でDRPが使用されないと考えられる。

確認のために`20231027_RZV2H_linux_drpドライバ_レシピ_OpenCV一式.zip`に含まれていた`OCA_sample`を実行した。

```shell
root@rzv2h-evk-alpha:~/OCA_sample# ./OCA_sample
RZ/V2MA OPENCV SAMPLE
[1] resize             FHD(BGR) -> XGA(BGR)
[2] cvtColor           FHD(YUV) -> FHD(BGR)
[3] cvtColorTwoPlane   FHD(NV)  -> FHD(BGR)
[4] gaussian           FHD(BGR) [7x7]
[4-1] gaussian         FHD(gray)[7x7,sigma=2]
[5] erode              FHD(BGR) [iteration=100]
[6] dilate             FHD(BGR) [iteration=200]
[7] Opening            FHD(BGR) [iteration= 50]
[8] Adaptive Threshold FHD(gray)[kernel= 99x99]
[9] filter2D           FHD(BGR)
[10] Sobel             FHD(BGR)
[11] matchTemplate 640x360(BGR) [template 16x16]
[12] affine            FHD(BGR) [rotate PI/4]
[13] pyramid down      FHD(BGR) -> QFHD(BGR)
[14] pyramid up        QFHD(BGR) -> FHD(BGR)
[15] perspective       FHD(BGR)
[16] FAST              FHD(gray)
[99] NO LOAD(Sobel*10) FHD(BGR)


[1] resize             FHD(BGR) -> XGA(BGR)
[CPU]13.392013msec
[OCA]11.290459msec
[CPU] / [OCA] = 1.186135 times
# 略
```

`resize`の`CPU`と`OCA`の処理時間がほぼ同じであるため、`OCA`でもDRPが使用されていないと考えられる。

OpenCVAドライバの開発者からは以下の回答が得られた。

> ```markdown
> OpenCVAドライバ(/dev/opencva0)の件、確認しましたところご提供させていただきましたパッチに問題があることがわかりました。OpenCVAのソースコードが古い状態となっておりました。
> ```

#### 9.2.3 DRPドライバ

DRPプログラムが正常に動作するのかを確認した。  
ここではresizeの単体環境で確認した。  
実行したところ、以下のエラーとなった。

```shell
Failed to Start(DRP_START). Return code is -1, errno is 22
Failed to Start.
```

`ioctl(DRP_START)`でエラーとなっていることがわかる。

β版のYocto環境の`build/tmp/work-shared/rzv2h-evk-alpha/kernel-source/drivers/drp/drp-if.c`を確認した。  
`drp_ioctl_start`の以下の処理で前述のエラーとなっている可能性がある。

```cpp
/* Check Argument */
for (i = 0; i < (desc_info->seq.num * 2); i++)
{
    if (0 != (proc[i].address & DRP_64BYTE_ALIGN))
    {
        result = -EINVAL;
        goto end;
    }

    if( proc[i].address + proc[i].size >= VAL_40BIT_OVER )
    {
        result = -EINVAL;
        goto end;
    }

    if( proc[i+1].address + proc[i+1].size >= VAL_40BIT_OVER )
    {
        result = -EINVAL;
        goto end;
    }

    if( proc[i].size > VAL_16M )
    {
        result = -EINVAL;
        goto end;
    }

    if( proc[i+1].size > VAL_16M )
    {
        result = -EINVAL;
        goto end;
    }
}
```

`proc`の走査範囲は`[0, seq.num * 2]`となっている。  
しかし、正しくは`[0, seq.num * 2)`だと考えられる。  
したがって、`proc[i+1]`に関するif文は不要だと考えられる。

確認のために、以下のワークアラウンドを適用して`proc[seq.num * 2]`に相当する変数にもダミー値を設定するように変更して、確認した。  
なお、`v2x::drp_driver_api::Start`は`ioctl(DRP_START)`を実行する関数である。

```diff
@@ -49,7 +49,8 @@ std::vector<std::pair<measure_time_t *, std::string>> mt_list = {
     {&mt_polling, "busy wait"},
     {&mt_p2u, "P2U output"}};

-drp_data_t proc[2];
+// Workaround
+drp_data_t proc[2 + 1];

 #define PROC_RESIZE_CONFIG 0
 #define PROC_RESIZE_PARAM 1
@@ -232,6 +233,10 @@ int main(int argc, char **argv) {
       return false;
     }

+    // Workaround
+    proc[PROC_RESIZE_PARAM + 1].address = 0x0;
+    proc[PROC_RESIZE_PARAM + 1].size    = 0;
+
     MT_START(mt_start);
     bool start_succeed = v2x::drp_driver_api::Start(v2x::drp_driver_api::drp_fd, &proc[PROC_RESIZE_CONFIG]);
     MT_FINISH(mt_start);
```

上記の変更を加えた状態では正常に動作することを確認できた。

DRPドライバの開発者からは以下の回答が得られた。

> ```markdown
> ご指摘の通り、引数チェックが冗長になっておりました。  
> 対策としましては、  
> for (i = 0; i < (desc_info->seq.num * 2); i++)  
> を  
> for (i = 0; i < (desc_info->seq.num ); i++)  
> に変更します。
> ```

### 9.3 2023年11月8日時点のβ版のYocto環境構築

受領したβ版のファイルを使用してLinuxイメージをビルドした。  
また、α2版とβ版のLinuxの間で性能への影響が無いのかを確認した。

#### 9.3.1 OpenCVA組み込み版

##### 9.3.1.1 OpenCVAあり、DRPドライバネイティブあり

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1050
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：**β版**

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1114.mono.opencva.ai.3wx.1050.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.115461
      mean      0.036033
    median      0.028941
       min      0.001966
      rmse      0.043199
       sse      1.560073
       std      0.023827

```

最大誤差が`11`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1114.mono.opencva.ai.3wx.1050.txt --correct_scale --align 
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1114.mono.opencva.ai.3wx.1050
infos:  836 poses, 10.809m path length, 28.090s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
--------------------------------------------------------------------------------
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/beta/opencva.1050/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/beta/opencva.1050/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/beta/opencva.1050/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

###### 9.3.1.1.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            14.01  |
| `　　cv::imread` |    99.9 |            14.004 |

###### 9.3.1.1.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.924 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             0.672 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     5.6 |             3.882 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.9 |             3.387 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     5.4 |             3.75  |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　|     --- |             ----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.034 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.7 |             3.961 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.039 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.326 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    48.7 |            33.583 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     1.8 |             1.287 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     4.9 |             3.401 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.7 |             3.294 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.005 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.4 |             3.099 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.021 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.026 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.8 |             0.573 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.023 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.308 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     6.2 |             4.307 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.044 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.019 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

Image processingスレッドの前半・後半の処理時間と、`max_features`の待機時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.924 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    75   |            51.736 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     1.8 |             1.287 |
| `　　Image processing(second)[0-1]` 　　　　　　　　　　　　　　　　|    23   |            15.864 |

α2版の時点では、`Image processing`は`68.648`\[ms/frame\]となっていた。  
よって処理時間に有意な差は無い。

###### 9.3.1.1.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            74.317 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.02  |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.5 |            73.986 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    45.4 |            33.791 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    54   |            40.165 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.7 |             0.535 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    53.3 |            39.625 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     2.4 |             1.853 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.8 |             2.836 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.9 |             0.719 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    15.8 |            11.804 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9.6 |             7.196 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     5.9 |             4.392 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    28.9 |            21.492 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.2 |             2.401 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     8.9 |             6.66  |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    16.5 |            12.278 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    13.4 |            10.02  |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     2.8 |             2.134 |

α2版の時点では、`Main loop`は`74.051`\[ms/frame\]となっていた。  
よって処理時間に有意な差は無い。

##### 9.3.1.2 OpenCVA無し、DRPドライバネイティブ無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1050
- DRP：無効
- DRP-AI：有効
- OpenCVA：無効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：**β版**

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1114.mono.cpu.ai.3wx.1050.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.154668
      mean      0.026063
    median      0.019171
       min      0.001435
      rmse      0.034638
       sse      1.021009
       std      0.022814

```

最大誤差が`15`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1114.mono.cpu.ai.3wx.1050.txt     --correct_scale --align 
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1114.mono.cpu.ai.3wx.1050
infos:  851 poses, 11.334m path length, 28.594s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
--------------------------------------------------------------------------------
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/beta/cpu.1050/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/beta/cpu.1050/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/beta/cpu.1050/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

ボトルネック解析結果は以下の通り。  

###### 9.3.1.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            15.016 |
| `　　cv::imread` |    99.9 |            15.003 |

###### 9.3.1.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            85.097 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.707 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     4.5 |             3.837 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　|     7   |             6.033 |
| `　　　　cv::copyMakeBorder[0-7]`   　　　　　　　　　　　　　　　　|     0.8 |             0.725 |
| `　　　　Resize[0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     6   |             5.19  |
| `　　GaussianBlur[0-7]` 　　　　　　　　　　　　　　　　　　　　　　|    12.5 |            10.652 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　|    40.1 |            34.134 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　FAST[0-7]` 　　　　　　　　　　　　　　　　　　　　　　　　|    39.6 |            33.76  |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     0.1 |             0.169 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.9 |             3.387 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     3.7 |             3.175 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.006 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     3.8 |             3.263 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0][0-7]`　　　　　　　　　　　　　　　　　　|    20.7 |            17.628 |
| `　　computeDescriptors[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.026 |

Image processingスレッドの前半・後半の処理時間と、`max_features`の待機時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            85.097 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    66.8 |            56.927 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     0.1 |             0.169 |
| `　　Image processing(second)[0-1]` 　　　　　　　　　　　　　　　　|    32.8 |            27.962 |

α2版の時点では、`Image processing`は`84.609`\[ms/frame\]となっていた。  
よって処理時間に有意な差は無い。

###### 9.3.1.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            90.517 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.002 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.7 |            90.256 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    53.7 |            48.626 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    45.9 |            41.598 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.6 |             0.56  |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    45.3 |            41.033 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     2.2 |             2.048 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     1.2 |             1.096 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.2 |             0.25  |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    13.5 |            12.267 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     8   |             7.257 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     5.3 |             4.799 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    26.3 |            23.831 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     2.6 |             2.376 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     7.9 |             7.219 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    15.5 |            14.074 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    12.7 |            11.529 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     2.6 |             2.412 |

α2版の時点では、`Main loop`は`90.02`\[ms/frame\]となっていた。  
よって処理時間に有意な差は無い。

#### 9.3.2 OpenCVA差し替え版

##### 9.3.2.1 OpenCVAあり、DRPドライバネイティブあり

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_xyz
- モード：RGB-D
- オプション：ヴィジュアライザ無し
- 最大特徴点数：1000
- OpenCVA：有効
- DRPドライバネイティブ：有効
- DRP-AI：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：**β版**

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt CameraTrajectory.v2x.2023.1114.rgbd.opencva.drp.ai.3wx.1000.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.060044
      mean      0.015967
    median      0.013774
       min      0.001870
      rmse      0.018418
       sse      0.277817
       std      0.009180

```

SLAM精度は破綻していないことがわかる。

計測結果は以下の通り。

```shell
median tracking time: 0.171324
mean tracking time: 0.171
```

α2版のDDR2チャネル対応**後**の計測結果は以下の通りであった。

```shell
median tracking time: 0.176026
mean tracking time: 0.176656
```

以上から、有意な性能の悪化は見られなかった。

##### 9.3.2.2 OpenCVAあり、DRPドライバネイティブ無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_xyz
- モード：RGB-D
- オプション：ヴィジュアライザ無し
- 最大特徴点数：1000
- OpenCVA：有効
- DRPドライバネイティブ：無効
- DRP-AI：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：**β版**

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt CameraTrajectory.v2x.2023.1114.rgbd.opencva.cpu.ai.3wx.1000.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.080152
      mean      0.014036
    median      0.012358
       min      0.000952
      rmse      0.016825
       sse      0.231851
       std      0.009278

```

SLAM精度は破綻していないことがわかる。

計測結果は以下の通り。

```shell
median tracking time: 0.188325
mean tracking time: 0.189017
```

α2版のDDR2チャネル対応**前**の計測結果は以下の通り。

```shell
median tracking time: 0.176417
mean tracking time: 0.176475
```

コヒーレンシを保証するための`O_SYNC`フラグの有無による処理時間の増加の影響を除いて、有意な性能の悪化は見られなかった。

##### 9.3.2.3 OpenCVA無し、DRPドライバネイティブ無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_xyz
- モード：RGB-D
- オプション：ヴィジュアライザ無し
- 最大特徴点数：1000
- OpenCVA：無効
- DRPドライバネイティブ：無効
- DRP-AI：有効
- DRP-AIオブジェクトファイル：RGB入力（`YoloV2_sp90_VGA_RGB_0726`）
- DRP/DRP-AIドライバ：**β版**

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt CameraTrajectory.v2x.2023.1114.rgbd.cpu.cpu.ai.3wx.1000.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.066531
      mean      0.019256
    median      0.016797
       min      0.001623
      rmse      0.022231
       sse      0.404769
       std      0.011110

```

SLAM精度は破綻していないことがわかる。

計測結果は以下の通り。

```shell
median tracking time: 0.192001
mean tracking time: 0.190128
```

α2版のDDR2チャネル対応**前**の計測結果は以下の通り。

```shell
median tracking time: 0.181819
mean tracking time: 0.182457
```

コヒーレンシを保証するための`O_SYNC`フラグの有無による処理時間の増加の影響を除いて、有意な性能の悪化は見られなかった。

## 10 YOLOX-Sのデモプログラムの確認

`app_yolox_cam`の動作確認結果について記載する。

### 10.1 USBカメラ入力への変更

まず、`app_yolox_cam`をUSBカメラを使用して実行するために、`app_yolox_cam/src/define.h`に以下の変更を加えた。

```diff
 /* Input Camera support */
 /* n = 0: USB Camera, n = 1: eCAM22 */
-#define INPUT_CAM_TYPE 1
+#define INPUT_CAM_TYPE 0
```

この変更の後にビルドしなおし、V2xボードに実行ファイルを配置した。  
そして実行したところ、以下のエラーとなった。

```shell
root@rzv2h-evk-alpha:~/app_yolox_cam/exe# ./app_yolox_cam
RZ/V2H DRP-AI Sample Application
Model : Megvii-Base Detection YOLOX | yolox_cam
Input : USB Camera
Argument : <DRP0_max_freq_factor> = 2
Argument : <AI-MAC_freq_factor> = 2
Loading : yolox_cam/drp_desc.bin
Loading : yolox_cam/drp_config.mem
Loading : yolox_cam/drp_param.bin
Loading : yolox_cam/aimac_desc.bin
Loading : yolox_cam/weight.bin
Loading : yolox_cam/aimac_cmd.bin
Loading : yolox_cam/aimac_param_desc.bin
Loading : yolox_cam/aimac_param_cmd.bin
[INFO] USB Camera: /dev/video0
Key Hit Thread Starting
************************************************
* Press ENTER key to quit. *
************************************************
Capture Thread Starting
Inference Thread Starting
Inference Loop Starting
Main Loop Starts
Image Thread Starting
Display Thread Starting
[  651.078472] (mali-cmar-backe) NOTE: The GFX library has the time limitation by reason of an evaluation module.
Segmentation fault
```

ELPカメラは画像サイズに`1920x1080`を指定できないため、エラーとなっていることがわかる。

デモプログラムの開発者からは以下の回答が得られた。

> ```markdown
> VGA入力にするためにはDRP-AIオブジェクト、アプリの変更が必要になります
> ```

### 10.2 パディングの有効化

本案件で使用するYOLOX-Sでは、入力画像のアスペクト比の保持のために入力画像の下端をパディングする必要がある。  
`app_yolox_cam/src/main.cpp`では以下のように実装されている。

```cpp
    bool padding = false;
#ifdef CAM_INPUT_VGA
    padding = true;
#endif // CAM_INPUT_VGA
```

`CAM_INPUT_VGA`がdefineされている場合にのみ、パディングが有効になると考えられる。  
なお、受領時点の実装では`CAM_INPUT_VGA`はdefineされていなかった。

`CAM_INPUT_VGA`をdefineするように変更を加えた状態で、動作確認を行ったが、`Segmentation fault`となった。

デモプログラムの開発者からは以下の回答が得られた。

> ```markdown
> app_yolox_cam をUSBカメラ設定でビルドしたもの（CAM_INPUT_VGA defineなし）で確認しました。  
> CAM_INPUT_VGA defineなし　→ 正常動作  
> CAM_INPUT_VGA define　→ Segmentation fault
> ```

そこで、`Segmentation fault`の原因を調査した。

`Image::convert_size`で`is_padding == true`の場合に実行される`memcpy`の第2引数の配列サイズが`1920x720x4`になっている。  
しかしコピーサイズは`out_w * out_h * out_c == 1920 * 1080 * 4`になっており、`Segmentation fault`になっていると考えられる。  
よって、以下のような修正が必要だと考えられる。

```diff
@@ -546,7 +546,14 @@ void Image::convert_size(int in_w, int resize_w, bool is_padding)
     if (is_padding)
     {
         cv::Mat dst_image;
-        copyMakeBorder(resize_image, dst_image, 0, 0, (out_w - resize_w) / 2, (out_w - resize_w) / 2, cv::BORDER_CONSTANT, cv::Scalar(0, 0, 0, 255));
+        copyMakeBorder(resize_image, dst_image,
+            0,
+            (out_h - resize_image.rows),
+            (out_w - resize_image.cols) / 2,
+            (out_w - resize_image.cols) / 2,
+            cv::BORDER_CONSTANT,
+            cv::Scalar(0, 0, 0, 255));
+
         memcpy(img_buffer[buf_id], dst_image.data, out_w * out_h * out_c);
     }
     else
```

上記の修正では`cv::copyMakeBorder`の`top`は`0`のまま、`bottom`を`(out_h - resize_image.rows)`とした。  
`top`を`(out_h - resize_image.rows) / 2`、`bottom`を`(out_h - resize_image.rows) / 2`に修正するのが正しい可能性も考えられる。  
いずれの場合も、配列サイズとコピーサイズの不整合が解消できれば`Segmentation fault`は解消できる。  
上記の修正を加えてELPカメラ、`CAM_INPUT_VGA`ありで`Segmentation fault`が解消できることは確認できた。

なお、デモプログラムの開発者からは以下の回答が得られた。

> ```markdown
> Image::convert_size の件でお知らせします。  
> こちらの関数はDRP-AIの画像入力の経路には影響しないことを確認しました。
> ```

### 10.3 出力の確認

`app_yolox_cam`を実行し、出力を確認した。  
`app_yolox_cam`はカメラ入力の機能のみが提供されており、データセットを入力とする機能は無い。  
そのため、ここでは簡易的に特定の画像を読み込んでDRP-AIで処理できるように変更を行った。

主な変更点は以下の通り。

- 使用するDRP-AIオブジェクトファイルを`yolox_cam`から`YOLOX_S_sp70_640x640_RGB_10271351`へ変更する
- `INPUT_CAM_TYPE`を`1(eCAM22)`から`0(USB Camera)`へ変更する
- `CAM_INPUT_VGA`をdefineする
- DRP-AIの入力画像のサイズを変更する（`1920x1920` → `640x640`）
- DRP-AIの入力画像のチャネル数を変更する（`2(YUYV)` → `3(RGB)`）
- `cv::imread`で指定した画像ファイルを読み込み、DRP-AIの入力画像を上書きする
- `Image::convert_size`で`Segmentation fault`が発生しないように変更する

`src/define.h`の変更内容は以下の通り。

```diff
@@ -36,10 +36,11 @@
 ******************************************/
 /* Input Camera support */
 /* n = 0: USB Camera, n = 1: eCAM22 */
-#define INPUT_CAM_TYPE 1
+#define INPUT_CAM_TYPE 0

 /* Output Camera Size */
-#define CAM_INPUT_FHD
+// #define CAM_INPUT_FHD
+#define CAM_INPUT_VGA
 #define IMAGE_OUTPUT_FHD
 #define MIPI_CAM_RES "1920x1080"

@@ -61,7 +62,7 @@
 *  - drpai_prefix0 = directory name of DRP-AI Object files (DRP-AI Translator output)
 ******************************************/
 /* Directory name of DRP-AI Object files (DRP-AI Translator output) */
-const static std::string drpai_prefix0 = "yolox_cam";
+const static std::string drpai_prefix0 = "YOLOX_S_sp70_640x640_RGB_10271351";
 /* Anchor box information */
 const static double anchors[] =
 {
@@ -114,6 +115,7 @@ const static uint32_t num_inf_out =  (NUM_CLASS + 5) * NUM_BB * num_grids[0] * n
 #endif

 #define CAM_IMAGE_CHANNEL_YUY2      (2)
+#define CAM_IMAGE_CHANNEL_RGB       (3)
 #define CAM_IMAGE_SIZE              (CAM_IMAGE_WIDTH * CAM_IMAGE_HEIGHT * CAM_IMAGE_CHANNEL_YUY2)

 /*Camera:: Capture Information */
@@ -130,12 +132,12 @@ const static uint32_t num_inf_out =  (NUM_CLASS + 5) * NUM_BB * num_grids[0] * n
 /*** DRP-AI input is assigned to the buffer having the size of CAM_IMAGE_WIDTH^2 */
 #define DRPAI_IN_WIDTH              (CAM_IMAGE_WIDTH)
 #define DRPAI_IN_HEIGHT             (CAM_IMAGE_WIDTH)
-#define DRPAI_IN_CHANNEL_YUY2       (CAM_IMAGE_CHANNEL_YUY2)
+#define DRPAI_IN_CHANNEL_RGB        (CAM_IMAGE_CHANNEL_RGB)
 #else
 /** DRP-AI input is assigned to the buffer having the size of camera image. */
 #define DRPAI_IN_WIDTH              (CAM_IMAGE_WIDTH)
 #define DRPAI_IN_HEIGHT             (CAM_IMAGE_HEIGHT)
-#define DRPAI_IN_CHANNEL_YUY2       (CAM_IMAGE_CHANNEL_YUY2)
+#define DRPAI_IN_CHANNEL_RGB        (CAM_IMAGE_CHANNEL_RGB)
 #endif

 /*Wayland:: Wayland Information */
@@ -161,7 +163,7 @@ const static uint32_t num_inf_out =  (NUM_CLASS + 5) * NUM_BB * num_grids[0] * n

 /*udmabuf memory area Information*/
 #define UDMABUF_IMAGE               (IMAGE_OUTPUT_WIDTH * IMAGE_OUTPUT_HEIGHT * IMAGE_CHANNEL_BGRA)
-#define UDMABUF_OFFSET              (CAM_IMAGE_WIDTH * CAM_IMAGE_HEIGHT * CAM_IMAGE_CHANNEL_YUY2 * CAP_BUF_NUM)
+#define UDMABUF_OFFSET              (CAM_IMAGE_WIDTH * CAM_IMAGE_HEIGHT * CAM_IMAGE_CHANNEL_RGB * CAP_BUF_NUM)
 #define UDMABUF_INFIMAGE_OFFSET     (IMAGE_OUTPUT_WIDTH * IMAGE_OUTPUT_HEIGHT * IMAGE_CHANNEL_BGRA * WL_BUF_NUM + UDMABUF_OFFSET)

 /*Image:: Text information to be drawn on image*/
```

`src/drpai_ctl.cpp`の変更内容は以下の通り。  
なお、以下の差分では`GRAY_rgbd_dataset_freiburg3_walking_xyz`を使用する場合の変更を示している。

```diff
@@ -11,6 +11,8 @@
 * Includes
 ******************************************/
 #include "drpai_ctl.h"
+#include <opencv2/imgcodecs.hpp>
+#include <opencv2/imgproc.hpp>

 using namespace std;

@@ -477,6 +479,46 @@ end:
     return drpai_obj_info;
 }

+#define DRP_FUNC_NUM (16)
+#define OPENCVA_FUNC_DISABLE (0)
+bool finalize() {
+    unsigned long OCA_f[DRP_FUNC_NUM];
+    for (size_t i = 0; i < DRP_FUNC_NUM; i++) {
+        OCA_f[i] = OPENCVA_FUNC_DISABLE;
+    }
+
+    /* Disable OpenCV Accelerator */
+    int activate_succeed = OCA_Activate(&OCA_f[0]);
+    if (activate_succeed != 0) {
+        fprintf(stderr, "Failed to opencva::finalize.\n");
+        return false;
+    }
+
+    return true;
+}
+
+void YUVtoYUYV(const cv::Mat& yuv, cv::Mat& yuyv) {
+    for (int iy = 0; iy < yuv.rows; iy++) {
+        for (int ix = 0; ix < yuv.cols; ix += 2) {
+            uint8_t y0 = yuv.at<cv::Vec3b>(iy, ix)[0];
+            uint8_t u0 = yuv.at<cv::Vec3b>(iy, ix)[1];
+            uint8_t v0 = yuv.at<cv::Vec3b>(iy, ix)[2];
+            uint8_t y1 = yuv.at<cv::Vec3b>(iy, ix + 1)[0];
+            uint8_t u1 = yuv.at<cv::Vec3b>(iy, ix + 1)[1];
+            uint8_t v1 = yuv.at<cv::Vec3b>(iy, ix + 1)[2];
+
+            uint8_t u = (u0 + u1 + 1) >> 1;
+            uint8_t v = (v0 + v1 + 1) >> 1;
+
+            yuyv.at<cv::Vec2b>(iy, ix)[0] = y0;
+            yuyv.at<cv::Vec2b>(iy, ix)[1] = u;
+            yuyv.at<cv::Vec2b>(iy, ix + 1)[0] = y1;
+            yuyv.at<cv::Vec2b>(iy, ix + 1)[1] = v;
+        }
+    }
+}
+
+
 /*****************************************
 * Function Name     : start_drpai
 * Description       : Start AI inference via DRP-AI Driver.
@@ -548,6 +590,34 @@ int8_t start_drpai(drpai_handle_t* drpai_obj_info, uint64_t data_in, uint32_t ma
         goto end;
     }

+    {
+        finalize();
+
+        uint8_t udmabuf_fd = open("/dev/udmabuf0", O_RDWR | O_SYNC);
+        if (udmabuf_fd < 0) {
+            fprintf(stderr, "Failed to open /dev/udmabuf0.\n");
+            exit(EXIT_FAILURE);
+        }
+
+        // cv::Mat file_image = cv::imread("/opt/dataset/tum/rgbd_dataset_freiburg3_walking_xyz/rgb/1341846318.546259.png", cv::IMREAD_COLOR);
+        cv::Mat file_image = cv::imread("/opt/dataset/tum/GRAY_rgbd_dataset_freiburg3_walking_xyz/gray/1341846318.546259.png", cv::IMREAD_GRAYSCALE);
+        const cv::Size sz(640, 480);
+        cv::Mat resized_image; // 640x480
+        const uint32_t drpai_input_size = sz.width * sz.height * 3;
+        cv::resize(file_image, resized_image, sz);
+
+        cv::cvtColor(resized_image, resized_image, cv::COLOR_GRAY2BGR);
+        cv::cvtColor(resized_image, resized_image, cv::COLOR_BGR2RGB);
+
+        uint8_t* udma_buffer = (uint8_t*)mmap(NULL, drpai_input_size, PROT_READ | PROT_WRITE, MAP_SHARED, udmabuf_fd, 0x02166000);
+        memcpy(udma_buffer, resized_image.data, drpai_input_size);
+        munmap(udma_buffer, drpai_input_size);
+        close(udmabuf_fd);
+    }
+
+    fprintf(stderr, "data_in      : 0x%lx\n", data_in);
+    fprintf(stderr, "data_in_size : %lu\n", drpai_obj_info->drpai_address.data_in_size);
+
     /* Set DRP-AI Driver Input (DRP-AI Object files address and size)*/
     proc[DRPAI_INDEX_INPUT].address       = data_in;
     proc[DRPAI_INDEX_INPUT].size          = drpai_obj_info->drpai_address.data_in_size;
```

`src/image.cpp`の変更内容は以下の通り。

```diff
@@ -546,7 +546,14 @@ void Image::convert_size(int in_w, int resize_w, bool is_padding)
     if (is_padding)
     {
         cv::Mat dst_image;
-        copyMakeBorder(resize_image, dst_image, 0, 0, (out_w - resize_w) / 2, (out_w - resize_w) / 2, cv::BORDER_CONSTANT, cv::Scalar(0, 0, 0, 255));
+        copyMakeBorder(resize_image, dst_image,
+            0,
+            (out_h - resize_image.rows),
+            (out_w - resize_image.cols) / 2,
+            (out_w - resize_image.cols) / 2,
+            cv::BORDER_CONSTANT,
+            cv::Scalar(0, 0, 0, 255));
+
         memcpy(img_buffer[buf_id], dst_image.data, out_w * out_h * out_c);
     }
     else
```

`src/main.cpp`の変更内容は以下の通り。

```diff
@@ -717,21 +717,17 @@ void *R_Capture_Thread(void *threadid)

 #if (1) == DRPAI_INPUT_PADDING
     /** Allocate a square buffer (width * width) */
-    img_buffer0 = (unsigned char*) mmap(NULL, CAM_IMAGE_WIDTH * CAM_IMAGE_WIDTH * CAM_IMAGE_CHANNEL_YUY2 ,PROT_READ|PROT_WRITE, MAP_SHARED,  udmabuf_fd0, _cap_offset + _img_offset);
+    img_buffer0 = (unsigned char*) mmap(NULL, CAM_IMAGE_WIDTH * CAM_IMAGE_WIDTH * CAM_IMAGE_CHANNEL_RGB ,PROT_READ|PROT_WRITE, MAP_SHARED,  udmabuf_fd0, _cap_offset + _img_offset);

     /** Fill buffer with the brightness 114. */
-    for( uint32_t i = 0; i < CAM_IMAGE_WIDTH * CAM_IMAGE_WIDTH * CAM_IMAGE_CHANNEL_YUY2; i += 4 )
+    for( uint32_t i = 0; i < CAM_IMAGE_WIDTH * CAM_IMAGE_WIDTH * CAM_IMAGE_CHANNEL_RGB; i += 3 )
     {
-        /// Y =  0.299R + 0.587G + 0.114B
         img_buffer0[i]   = 114;
+        img_buffer0[i+1] = 114;
         img_buffer0[i+2] = 114;
-        /// U = -0.169R - 0.331G + 0.500B + 128
-        img_buffer0[i+1] = 128;
-        /// V =  0.500R - 0.419G - 0.081B + 128
-        img_buffer0[i+3] = 128;
     }
 #else
-    img_buffer0 = (unsigned char*) mmap(NULL, CAM_IMAGE_WIDTH * CAM_IMAGE_HEIGHT * CAM_IMAGE_CHANNEL_YUY2 ,PROT_READ|PROT_WRITE, MAP_SHARED,  udmabuf_fd0, _cap_offset + _img_offset);
+    img_buffer0 = (unsigned char*) mmap(NULL, CAM_IMAGE_WIDTH * CAM_IMAGE_HEIGHT * CAM_IMAGE_CHANNEL_RGB ,PROT_READ|PROT_WRITE, MAP_SHARED,  udmabuf_fd0, _cap_offset + _img_offset);
 #endif

     capture_address = udmabuf_address + _cap_offset + _img_offset;
@@ -833,7 +829,7 @@ err:
     goto capture_end;

 capture_end:
-    munmap(img_buffer0, CAM_IMAGE_WIDTH * CAM_IMAGE_HEIGHT * CAM_IMAGE_CHANNEL_YUY2);
+    munmap(img_buffer0, CAM_IMAGE_WIDTH * CAM_IMAGE_HEIGHT * CAM_IMAGE_CHANNEL_RGB);
     /*To terminate the loop in AI Inference Thread.*/
     inference_start.store(1);

@@ -1269,7 +1265,7 @@ int32_t main(int32_t argc, char * argv[])
     }

     /*Initialize Image object.*/
-    ret = img.init(CAM_IMAGE_WIDTH, CAM_IMAGE_HEIGHT, CAM_IMAGE_CHANNEL_YUY2, IMAGE_OUTPUT_WIDTH, IMAGE_OUTPUT_HEIGHT, IMAGE_CHANNEL_BGRA);
+    ret = img.init(CAM_IMAGE_WIDTH, CAM_IMAGE_HEIGHT, CAM_IMAGE_CHANNEL_RGB, IMAGE_OUTPUT_WIDTH, IMAGE_OUTPUT_HEIGHT, IMAGE_CHANNEL_BGRA);
     if (0 != ret)
     {
         fprintf(stderr, "[ERROR] Failed to initialize Image object.\n");
```

`rgbd_dataset_freiburg3_walking_xyz`の`rgb/1341846318.546259.png`を読み込み`cv::cvtColor`で`cv::COLOR_BGR2RGB`を指定して変換した後に、DRP-AIの入力とした場合の結果は以下の通り。

```shell
Bounding Box Number : 8
Bounding Box        : (X, Y, W, H) = (500, 308, 125, 117)
Detected Class      : tvmonitor (Class 19)
Probability         : 58.7 %
Bounding Box Number : 11
Bounding Box        : (X, Y, W, H) = (294, 318, 98, 95)
Detected Class      : tvmonitor (Class 19)
Probability         : 87.2 %
Bounding Box Number : 16
Bounding Box        : (X, Y, W, H) = (210, 265, 154, 414)
Detected Class      : person (Class 14)
Probability         : 74.3 %
Bounding Box Count  : 3
```

`GRAY_rgbd_dataset_freiburg3_walking_xyz`の`gray/1341846318.546259.png`を読み込み`cv::cvtColor`で`cv::COLOR_GRAY2BGR`と`cv::COLOR_BGR2RGB`を順に指定して変換した後に、DRP-AIの入力とした場合の結果は以下の通り。

```shell
Bounding Box Number : 6
Bounding Box        : (X, Y, W, H) = (497, 304, 132, 104)
Detected Class      : tvmonitor (Class 19)
Probability         : 68.7 %
Bounding Box Number : 7
Bounding Box        : (X, Y, W, H) = (290, 316, 92, 90)
Detected Class      : tvmonitor (Class 19)
Probability         : 87.5 %
Bounding Box Number : 15
Bounding Box        : (X, Y, W, H) = (206, 281, 154, 376)
Detected Class      : bird (Class 2)
Probability         : 51.7 %
Bounding Box Count  : 3
```

`person`として検出されるべき箇所が`bird`と検出されていることがわかる。

`rgbd_dataset_freiburg3_walking_xyz`の`rgb/1341846318.546259.png`を読み込み`cv::cvtColor`で`cv::COLOR_BGR2GRAY`と`cv::COLOR_GRAY2BGR`と`cv::COLOR_BGR2RGB`を指定して変換した後に、DRP-AIの入力とした場合の結果は以下の通り。

```shell
Bounding Box Number : 14
Bounding Box        : (X, Y, W, H) = (498, 306, 132, 111)
Detected Class      : tvmonitor (Class 19)
Probability         : 81.9 %
Bounding Box Number : 16
Bounding Box        : (X, Y, W, H) = (292, 317, 95, 95)
Detected Class      : tvmonitor (Class 19)
Probability         : 84.6 %
Bounding Box Number : 20
Bounding Box        : (X, Y, W, H) = (207, 281, 149, 401)
Detected Class      : person (Class 14)
Probability         : 69.2 %
Bounding Box Count  : 3
```

`bird`は検出されていないことがわかる。

## 11 DRP-AI TranslatorによるYOLOX-Sの組み込み

OpenCVA組み込み版のYolo-Planar-SLAMで、受領した`YOLOX_S_sp70_640x640_RGB_10271351`を使用するように組み込みを行った内容について記載する。  
また、動作確認と評価を行った結果についても記載する。

### 11.1 コンソール出力の確認

入力画像を`/opt/dataset/tum/GRAY_rgbd_dataset_freiburg3_walking_xyz/gray/1341846318.546259.png`に固定して、デモプログラムと同等の結果が得られるのかを確認した。  
`rzv2h_yolov2_demo_src_20230508`のソースコードに含まれていた`COUT_INFERENCE_RESULT_ON`をdefineした状態で、バウンディングボックスの取得結果を確認した。  
確認結果は以下の通り。

```shell
Bounding Box Number : 6
Bounding Box        : (X, Y, W, H) = (497, 304, 132, 104)
Detected Class      : tvmonitor (Class 19)
Probability         : 68.7 %
Bounding Box Number : 7
Bounding Box        : (X, Y, W, H) = (290, 316, 92, 90)
Detected Class      : tvmonitor (Class 19)
Probability         : 87.5 %
Bounding Box Number : 15
Bounding Box        : (X, Y, W, H) = (206, 281, 154, 376)
Detected Class      : bird (Class 2)
Probability         : 51.7 %
Bounding Box Count  : 3
```

デモプログラムと厳密に同じ結果が得られていることがわかる。

### 11.2 グレースケールのデータセットによる評価

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：**GRAY_rgbd_dataset_freiburg3_walking_xyz**
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**1350**
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：**RGB入力（`YOLOX_S_sp70_640x640_RGB_10271351`）**
- DRP/DRP-AIドライバ：β版

#### 11.2.1 SLAM精度評価

最大特徴点数が`1000`以下では、ほとんど軌跡が得られなかった。  
`1350`まで上げたところで、十分な軌跡が得られた。

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.mono.opencva.ai.3wx.1350.yoloxs.gray.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.273399
      mean      0.036075
    median      0.026707
       min      0.001591
      rmse      0.050845
       sse      2.163786
       std      0.035830

```

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.mono.opencva.ai.3wx.1350.yoloxs.gray.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.mono.opencva.ai.3wx.1350.yoloxs.gray
infos:  837 poses, 10.741m path length, 28.122s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/translator/opencva.1350.yoloxs.gray/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/translator/opencva.1350.yoloxs.gray/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/translator/opencva.1350.yoloxs.gray/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 11.2.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

##### 11.2.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |             9.473 |
| `　　cv::imread` |    99.9 |             9.464 |

##### 11.2.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            71.597 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.5 |             0.406 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.643 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             0.803 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     7   |             5.07  |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.017 |
| `　　　　YoloV2Sp90Model::get_object_detection` 　　　　　　　　　　|     0   |             0.014 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.4 |             3.213 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.3 |             3.146 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.035 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.6 |             4.029 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.034 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.32  |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    47   |            33.691 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     2.5 |             1.811 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     1.9 |             1.415 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     5.8 |             4.21  |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.006 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     5.2 |             3.762 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.025 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.027 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.8 |             0.579 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.024 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.045 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.308 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     7.6 |             5.5   |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.008 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.049 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.024 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

Image processingスレッドの前半・後半の処理時間と、`max_features`の待機時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            71.597 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    73.9 |            52.972 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     2.5 |             1.811 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    23.4 |            16.776 |

##### 11.2.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            77.063 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.012 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.7 |            76.835 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    40.5 |            31.214 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0.001 |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    59.1 |            45.587 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.8 |             0.628 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    58.3 |            44.953 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     2.9 |             2.301 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.8 |             2.984 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     1.2 |             0.975 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    17.9 |            13.823 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    10.4 |             8.018 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     7.2 |             5.57  |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    30.8 |            23.782 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.4 |             2.673 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    10   |             7.768 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    17   |            13.164 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    13.2 |            10.222 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     3.6 |             2.802 |

YOLOv2（`YoloV2_sp90_VGA_RGB_0726`）を使用する場合と比較して、Image loadingスレッド以外に有意な差は見られなかった。  
なお、YOLOX-S（`YOLOX_S_sp70_640x640_RGB_10271351`）の組み込みのために追加したDRP-AIの入力画像の下端のパディング処理`bottom padding`の平均処理時間は`0.803`\[ms/frame\]となっており、十分に短い。

### 11.3 TUMデータセットによる評価

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：**rgbd_dataset_freiburg3_walking_xyz**
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**1000**
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：**RGB入力（`YOLOX_S_sp70_640x640_RGB_10271351`）**
- DRP/DRP-AIドライバ：β版

#### 11.3.1 SLAM精度評価

最大特徴点数と、軌跡の点数の関係は以下のとおり。

- `800`：`0`
- `850`：`116`
- `900`：`751`
- `950`：`836`
- `1000`：`835`
- `1050`：`783`
- `1100`：`834`
- `1150`：`381`
- `1200`：`851`
- `1250`：`725`
- `1300`：`767`
- `1350`：`850`

最大特徴点数の値がわずかに変更されるだけで、十分なSLAM軌跡が得られるのかが変わっていることがわかる。  
また、最大特徴点数が大きいほど十分なSLAM軌跡が得られているとは限らず、SLAM精度が不安定である点に注意する必要がある。

最大特徴点数が`1050`の時のSLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.mono.opencva.ai.3wx.1050.yoloxs.rgb.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      2.476188
      mean      0.176467
    median      0.163811
       min      0.030309
      rmse      0.215186
       sse      36.256734
       std      0.123143

```

最大誤差が`247`\[cm\]であることから、SLAM精度が破綻していることがわかる。

最大特徴点数が`1000`の時のSLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.mono.opencva.ai.3wx.1000.yoloxs.rgb.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.129545
      mean      0.023226
    median      0.017576
       min      0.001281
      rmse      0.029955
       sse      0.749256
       std      0.018917

```

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.mono.opencva.ai.3wx.1000.yoloxs.rgb.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.mono.opencva.ai.3wx.1000.yoloxs
infos:  835 poses, 11.000m path length, 28.058s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
--------------------------------------------------------------------------------
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/translator/opencva.1000.yoloxs.rgb/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/translator/opencva.1000.yoloxs.rgb/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/translator/opencva.1000.yoloxs.rgb/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。  
ただし、前述の通りSLAM精度が不安定である点に注意する必要がある。

#### 11.3.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

##### 11.3.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            26.536 |
| `　　cv::imread` |    99.9 |            26.526 |

##### 11.3.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            70.244 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.9 |             0.669 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.629 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             0.782 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     7.4 |             5.245 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.019 |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.016 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.7 |             3.369 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.7 |             3.366 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.036 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.7 |             4.033 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.037 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.326 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    48.3 |            33.941 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     1.7 |             1.254 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     2.6 |             1.85  |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.7 |             3.314 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.005 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.3 |             3.038 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.02  |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.026 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.8 |             0.572 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.023 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.044 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.308 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     5.8 |             4.113 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.044 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.018 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

Image processingスレッドの前半・後半の処理時間と、`max_features`の待機時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            70.244 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    78.1 |            54.908 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     1.7 |             1.254 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    19.9 |            14.046 |

##### 11.3.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            75.649 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.017 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |            75.567 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    47.2 |            35.731 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    52.6 |            39.807 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.6 |             0.522 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    51.9 |            39.28  |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     2.6 |             1.973 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.8 |             2.897 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.9 |             0.716 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    14.4 |            10.918 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     8.9 |             6.803 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     5.1 |             3.895 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    28.8 |            21.818 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.5 |             2.696 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     8.2 |             6.249 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    16.8 |            12.724 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    13.6 |            10.321 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     2.9 |             2.257 |

YOLOv2（`YoloV2_sp90_VGA_RGB_0726`）を使用する場合と比較して、Image loadingスレッド以外に有意な差は見られなかった。  
なお、YOLOX-S（`YOLOX_S_sp70_640x640_RGB_10271351`）の組み込みのために追加したDRP-AIの入力画像の下端のパディング処理`bottom padding`の平均処理時間は`0.782`\[ms/frame\]となっており、十分に短い。

### 11.4 考察

Socket Viewerの描画結果を目視確認した限りでは、YOLOv2（`YoloV2_sp90_VGA_RGB_0726`）を使用する場合と比較して、YOLOX-S（`YOLOX_S_sp70_640x640_RGB_10271351`）を使用する場合の方が人の検出精度が悪いように見える。

処理時間への影響は、ほぼ無かった。

受領した`GRAY_rgbd_dataset_freiburg3_walking_xyz`の`gray/1341846318.546259.png`のサイズは、`148144`\[B\]だった。  
一方で、`rgbd_dataset_freiburg3_walking_xyz`の`rgb/1341846318.546259.png`を、以下の処理でグレースケール画像に変換した場合のpng画像のサイズは`170267`\[B\]だった。

```cpp
cv::Mat bgr_image = cv::imread("/opt/dataset/tum/rgbd_dataset_freiburg3_walking_xyz/rgb/1341846318.546259.png", cv::IMREAD_COLOR);
cv::Mat result_image;

cv::cvtColor(bgr_image, result_image, cv::COLOR_BGR2GRAY);
cv::imwrite("temporary.png", result_image);
```

`10.3 出力の確認`に記載した通り、受領した`GRAY_rgbd_dataset_freiburg3_walking_xyz`を直接使用する場合と`rgbd_dataset_freiburg3_walking_xyz`を一度グレースケール画像に変換して使用する場合で検出結果が異なる。

よって、受領した`GRAY_rgbd_dataset_freiburg3_walking_xyz`の画像は、画質が劣化している可能性がある。  
そのため、RGB画像からグレースケール画像への変換の仮定で画質が劣化している場合、SLAM精度への悪影響が懸念される。  
特に、`デモプログラム`にも記載した通り、YOLOX-S（`YOLOX_S_sp70_640x640_RGB_10271351`）では`GRAY_rgbd_dataset_freiburg3_walking_xyz`よりも`rgbd_dataset_freiburg3_walking_xyz`を使用した場合の方が精度が良い可能性がある。

以上から、YOLOX-Sを使用する場合のSLAM精度を改善する方法として、以下が考えられる。

- 最大特徴点数を増やす
    - Trackingスレッドの処理時間は増加する懸念がある
- `GRAY_rgbd_dataset_freiburg3_walking_xyz`ではなく`rgbd_dataset_freiburg3_walking_xyz`を使用する
    - `cv::imread`の処理時間は増加する
- `app_yolox_cam`と同じ値に設定した、YOLOX-Sのパラメータをチューニングする
    - `TH_PROB`：`0.5f`
    - `TH_NMS`：`0.5f`
- YOLOX-SのDRP-AIオブジェクトファイルを、条件を変えて作成して使用する
    - 枝刈り、量子化などが行われている場合には精度が低下しないようにチューニングする
- 画質の劣化が無いグレースケールのデータセットを作成して使用する

## 12 DRP-AI TranslatorによるDenseのYOLOX-Sの組み込み

OpenCVA組み込み版のYolo-Planar-SLAMで、受領した`YOLOX_S_dense_640x640_RGB_10271351`を使用するように組み込みを行った内容について記載する。  
また、動作確認と評価を行った結果についても記載する。

前処理・後処理については`YOLOX_S_sp70_640x640_RGB_10271351`と同等であったため、`YOLOX_S_sp70_640x640_RGB_10271351`用の実装を踏襲した。

### 12.1 Socket Viewerによる確認

`GRAY_rgbd_dataset_freiburg3_walking_xyz`を使用する場合と、`rgbd_dataset_freiburg3_walking_xyz`を使用する場合について、Socket Viewerを使用して目視確認を行った。

いずれの場合も、`YOLOX_S_sp70_640x640_RGB_10271351`を使用した場合と比較して検出精度が良いように見える。  
特に、`GRAY_rgbd_dataset_freiburg3_walking_xyz`の場合では人を別の物体として検出する現象が改善されているように見える。

### 12.2 グレースケールのデータセットによる評価

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：**GRAY_rgbd_dataset_freiburg3_walking_xyz**
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**1050**
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：**RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）**
- DRP/DRP-AIドライバ：β版

#### 12.2.1 SLAM精度評価

最大特徴点数と、軌跡の点数の関係は以下の通り。

- `800`：`2`
- `850`：`219`
- `900`：`764`
- `950`：`825`
- `1000`：`831`
- `1050`：`839`
- `1100`：`828`
- `1150`：`786`
- `1200`：`793`
- `1250`：`849`
- `1300`：`836`
- `1350`：`834`

`YOLOX_S_sp70_640x640_RGB_10271351`を使用した場合と比較して、少ない最大特徴点数で十分な数の軌跡の点が得られていることがわかる。

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1122_2.mono.opencva.ai.3wx.1050.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.093705
      mean      0.026718
    median      0.023912
       min      0.003076
      rmse      0.030799
       sse      0.795861
       std      0.015321

```

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1122_2.mono.opencva.ai.3wx.1050.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1122_2.mono.opencva.ai.3wx.1050
infos:  839 poses, 11.297m path length, 28.594s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/dense/opencva.1050.gray_dataset/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/dense/opencva.1050.gray_dataset/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/dense/opencva.1050.gray_dataset/evo_traj_rpy_view.png)

最大特徴点数を`1350`から`1050`に変更しても、目視した限りではSLAM精度の破綻が無いことがわかる。

#### 12.2.2 処理時間

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

##### 12.2.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            13.406 |
| `　　cv::imread` |    99.9 |            13.395 |

##### 12.2.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.923 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.7 |             0.512 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             0.638 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             0.804 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     7.5 |             5.179 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.021 |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.018 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.8 |             3.308 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.6 |             3.198 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.035 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.7 |             3.962 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.039 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.314 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    48.7 |            33.61  |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     1.2 |             0.864 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.6 |             2.493 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.8 |             3.312 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.006 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.4 |             3.045 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.02  |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.026 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.8 |             0.559 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.023 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.308 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     6.1 |             4.235 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.018 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

Image processingスレッドの前半・後半の処理時間と、`max_features`の待機時間はそれぞれ以下の通り。

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.923 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　　　　　|    77.1 |            53.185 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` 　　　　|     1.2 |             0.864 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　　　　　|    21.5 |            14.838 |

##### 12.2.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            74.338 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.05  |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |            74.226 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    46.3 |            34.429 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    53.4 |            39.767 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.7 |             0.548 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    52.7 |            39.213 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     2.8 |             2.084 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     1.5 |             1.168 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.3 |             0.264 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    15.9 |            11.891 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9.7 |             7.239 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     5.9 |             4.444 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    28.9 |            21.536 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.2 |             2.446 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9   |             6.742 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    16.3 |            12.188 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    13.3 |             9.891 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     2.9 |             2.163 |

### 12.3 TUMデータセットによる評価

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：**rgbd_dataset_freiburg3_walking_xyz**
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**1000**
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：**RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）**
- DRP/DRP-AIドライバ：β版

#### 12.3.1 SLAM精度評価

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1122.mono.opencva.ai.3wx.1000.rgbd_dataset.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.073927
      mean      0.017759
    median      0.015806
       min      0.002035
      rmse      0.020160
       sse      0.338961
       std      0.009541

```

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1122.mono.opencva.ai.3wx.1000.rgbd_dataset.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1122.mono.opencva.ai.3wx.1000.rgbd_dataset
infos:  834 poses, 11.043m path length, 28.020s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/dense/opencva.1000.rgb_dataset/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/dense/opencva.1000.rgb_dataset/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/dense/opencva.1000.rgb_dataset/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 12.3.2 処理時間

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

##### 12.3.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            20.701 |
| `　　cv::imread` |    99.9 |            20.694 |

##### 12.3.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            69.913 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.9 |             0.693 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             0.698 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             0.79  |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     7.2 |             5.08  |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.021 |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.018 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.5 |             3.208 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.6 |             3.272 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.037 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.6 |             3.971 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.038 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.319 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    48   |            33.617 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     1.5 |             1.113 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.8 |             2.673 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.5 |             3.212 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.005 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.2 |             2.954 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.02  |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.025 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.8 |             0.585 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.022 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.308 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     5.8 |             4.115 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.017 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

Image processingスレッドの前半・後半の処理時間と、`max_features`の待機時間はそれぞれ以下の通り。

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            69.913 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　　　　　|    77.3 |            54.066 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` 　　　　|     1.5 |             1.113 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　　　　　|    21   |            14.698 |

##### 12.3.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            75.3   |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.013 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.6 |            75.019 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    47.6 |            35.855 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    51.9 |            39.134 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.6 |             0.513 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    51.2 |            38.616 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     2.3 |             1.752 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.9 |             2.971 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.9 |             0.708 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    14.5 |            10.968 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     8.9 |             6.721 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     5.3 |             4.025 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    28.2 |            21.257 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.5 |             2.658 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     8.4 |             6.376 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    16   |            12.072 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    13   |             9.829 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     2.7 |             2.104 |

## 13 最大特徴点数の削減のための調査

OpenCVA組み込み版のYolo-Planar-SLAMで、受領した`YOLOX_S_dense_640x640_RGB_10271351`を使用する場合について、最大特徴点数を変更した場合の結果を調査した。  
SLAM精度のボトルネック解析結果について記載する。

### 13.1 グレースケールのデータセットによる評価

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：**GRAY_rgbd_dataset_freiburg3_walking_xyz**
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**850～1000**
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：**RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）**
- DRP/DRP-AIドライバ：β版

#### 13.1.1 SLAM精度評価

最大特徴点数を`50`ずつ変更し、5回ずつ評価を行った。  
`rmse`（root mean squared error : 二乗平均平方根誤差）がもっとも大きい評価結果を目視確認し、SLAM精度が破綻しているのかの判断を行った。

##### 13.1.1.1 最大特徴点数1000

最大特徴点数が`1000`の場合には3回目の評価で`rmse`が`0.079686`となり、最も大きかった。

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1124_2.mono.opencva.ai.3wx.1000.yoloxs-dense.gray_dataset.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.401157
      mean      0.057342
    median      0.046762
       min      0.006140
      rmse      0.079686
       sse      5.276774
       std      0.055334

```

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1124_2.mono.opencva.ai.3wx.1000.yoloxs-dense.gray_dataset.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1124_2.mono.opencva.ai.3wx.1000.yoloxs-dense.gray_dataset
infos:  831 poses, 10.541m path length, 27.922s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/dense/opencva.1000.gray_dataset/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/dense/opencva.1000.gray_dataset/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/dense/opencva.1000.gray_dataset/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 13.1.1.2 最大特徴点数950

最大特徴点数が`950`の場合には2回目の評価で`rmse`が`0.105177`となり、最も大きかった。

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1124_1.mono.opencva.ai.3wx.950.yoloxs-dense.gray_dataset.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.375332
      mean      0.085784
    median      0.071789
       min      0.007777
      rmse      0.105177
       sse      8.672714
       std      0.060855

```

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1124_1.mono.opencva.ai.3wx.950.yoloxs-dense.gray_dataset.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1124_1.mono.opencva.ai.3wx.950.yoloxs-dense.gray_dataset
infos:  784 poses, 9.736m path length, 27.954s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/dense/opencva.950.gray_dataset/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/dense/opencva.950.gray_dataset/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/dense/opencva.950.gray_dataset/evo_traj_rpy_view.png)

初期化直後以外でも誤差が大きくなっている箇所がある。  
SLAM精度は破綻していないが、十分なSLAM精度は出ていない可能性がある。

##### 13.1.1.3 最大特徴点数900

最大特徴点数が`900`の場合には4回目の評価で`rmse`が`0.082946`となり、最も大きかった。

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1124_3.mono.opencva.ai.3wx.900.yoloxs-dense.gray_dataset.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.274459
      mean      0.069723
    median      0.059448
       min      0.003870
      rmse      0.082946
       sse      5.724180
       std      0.044930

```

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1124_3.mono.opencva.ai.3wx.900.yoloxs-dense.gray_dataset.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1124_3.mono.opencva.ai.3wx.900.yoloxs-dense.gray_dataset
infos:  832 poses, 10.252m path length, 28.090s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/dense/opencva.900.gray_dataset/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/dense/opencva.900.gray_dataset/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/dense/opencva.900.gray_dataset/evo_traj_rpy_view.png)

初期化直後以外でも誤差が大きくなっている箇所がある。  
SLAM精度は破綻していないが、十分なSLAM精度は出ていない可能性がある。

##### 13.1.1.4 最大特徴点数850

最大特徴点数が`850`の場合には3回目の評価で`rmse`が`0.209230`となり、最も大きかった。

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1124_2.mono.opencva.ai.3wx.850.yoloxs-dense.gray_dataset.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      1.451540
      mean      0.169836
    median      0.174083
       min      0.025579
      rmse      0.209230
       sse      9.587225
       std      0.122201

```

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1124_2.mono.opencva.ai.3wx.850.yoloxs-dense.gray_dataset.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1124_2.mono.opencva.ai.3wx.850.yoloxs-dense.gray_dataset
infos:  219 poses, 3.683m path length, 28.020s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/dense/opencva.850.gray_dataset/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/dense/opencva.850.gray_dataset/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/dense/opencva.850.gray_dataset/evo_traj_rpy_view.png)

SLAM精度は破綻している。

#### 13.1.2 ボトルネック解析結果

##### 13.1.2.1 最大特徴点数1000

最大特徴点数が`1000`の場合のボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

###### 13.1.2.1.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            13.251 |
| `　　cv::imread` |    99.9 |            13.244 |

###### 13.1.2.1.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            69.761 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.7 |             0.513 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             0.671 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             0.828 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     7.4 |             5.201 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.02  |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.018 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.7 |             3.321 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.6 |             3.23  |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.5 |             2.491 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.034 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.6 |             3.967 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.038 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.313 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    48.2 |            33.633 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     2.5 |             1.773 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.6 |             3.231 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.005 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.2 |             2.996 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.02  |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.026 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.8 |             0.586 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.023 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.307 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     5.9 |             4.129 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.044 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.018 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

Image processingスレッドの前半・後半の処理時間と、`max_features`の待機時間はそれぞれ以下の通り。

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            69.761 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　　　　　|    76.4 |            53.349 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` 　　　　|     2.5 |             1.773 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　　　　　|    20.9 |            14.603 |

###### 13.1.2.1.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            75.149 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.034 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |            75.055 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    40.8 |            30.679 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    59   |            44.346 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.6 |             0.515 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    58.3 |            43.825 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     3.5 |             2.655 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     4.4 |             3.33  |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     1   |             0.813 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    16.6 |            12.541 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    10   |             7.583 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     6.3 |             4.745 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    31.3 |            23.56  |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.4 |             2.611 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9.3 |             7.059 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    18.2 |            13.726 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    14.9 |            11.241 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     3.1 |             2.344 |

##### 13.1.2.2 最大特徴点数900

最大特徴点数が`900`の場合のボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

###### 13.1.2.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            13.232 |
| `　　cv::imread` |    99.9 |            13.222 |

###### 13.1.2.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.004 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.7 |             0.507 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.6   |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             0.779 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     7.6 |             5.199 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.021 |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.018 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.9 |             3.339 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.6 |             3.184 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.6 |             2.495 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.037 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.8 |             3.964 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.039 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.317 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    49.3 |            33.584 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     1.5 |             1.036 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.5 |             3.085 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.005 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.1 |             2.825 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.004 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.019 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.026 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.8 |             0.558 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.023 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.308 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     5.4 |             3.709 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.017 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

Image processingスレッドの前半・後半の処理時間と、`max_features`の待機時間はそれぞれ以下の通り。

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.004 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　　　　　|    78.1 |            53.133 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` 　　　　|     1.5 |             1.036 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　　　　　|    20.2 |            13.798 |

###### 13.1.2.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            73.395 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.047 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |            73.275 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    46   |            33.825 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    53.7 |            39.423 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.6 |             0.49  |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    53   |            38.928 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     3   |             2.248 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     3.5 |             2.581 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     0.7 |             0.554 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    14.5 |            10.688 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     8.8 |             6.509 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     5.4 |             3.971 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    29.4 |            21.636 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.3 |             2.446 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     8.6 |             6.384 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    17.2 |            12.654 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    14.2 |            10.448 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     2.8 |             2.07  |

### 13.2 TUMデータセットによる評価

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：**rgbd_dataset_freiburg3_walking_xyz**
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：**950～1000**
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：**RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）**
- DRP/DRP-AIドライバ：β版

#### 13.2.1 SLAM精度評価

最大特徴点数を`50`ずつ変更し、5回ずつ評価を行った。  
`rmse`（root mean squared error : 二乗平均平方根誤差）がもっとも大きい評価結果を目視確認し、SLAM精度が破綻しているのかの判断を行った。

##### 13.2.1.1 最大特徴点数1000

最大特徴点数が`1000`の場合には2回目の評価で`rmse`が`0.019361`となり、最も大きかった。

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1124_1.mono.opencva.ai.3wx.1000.yoloxs-dense.rgb_dataset.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.071003
      mean      0.017014
    median      0.015388
       min      0.001094
      rmse      0.019361
       sse      0.312617
       std      0.009239

```

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1124_1.mono.opencva.ai.3wx.1000.yoloxs-dense.rgb_dataset.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1124_1.mono.opencva.ai.3wx.1000.yoloxs-dense.rgb_dataset
infos:  834 poses, 10.977m path length, 28.020s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/dense/opencva.1000.rgb_dataset-2/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/dense/opencva.1000.rgb_dataset-2/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/dense/opencva.1000.rgb_dataset-2/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 13.2.1.2 最大特徴点数950

最大特徴点数が`950`の場合には5回すべての評価で`rmse`が`0.168201`となった。  
また、キーフレームは取得できなかった。

SLAM精度評価の結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1124_0.mono.opencva.ai.3wx.950.yoloxs-dense.rgb_dataset.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.210488
      mean      0.164410
    median      0.167925
       min      0.111303
      rmse      0.168201
       sse      0.113167
       std      0.035511

```

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1124_0.mono.opencva.ai.3wx.950.yoloxs-dense.rgb_dataset.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1124_0.mono.opencva.ai.3wx.950.yoloxs-dense.rgb_dataset
infos:  4 poses, 0.641m path length, 20.574s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/dense/opencva.950.rgb_dataset/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/dense/opencva.950.rgb_dataset/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/dense/opencva.950.rgb_dataset/evo_traj_rpy_view.png)

SLAM精度は破綻している。

#### 13.2.2 ボトルネック解析結果

最大特徴点数が`1000`の場合のボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

##### 13.2.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            26.453 |
| `　　cv::imread` |    99.9 |            26.446 |

##### 13.2.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            70.95  |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.9 |             0.686 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB`　　　　　　　　　　　　　　　　　　　　　　|     1   |             0.719 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             0.8   |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     7.3 |             5.223 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.021 |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.018 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.7 |             3.344 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.6 |             3.325 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.7 |             2.675 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.035 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     5.7 |             4.07  |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.038 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.323 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    47.6 |            33.824 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     1.8 |             1.324 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.5 |             3.242 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.005 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.1 |             2.977 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.02  |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.026 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.8 |             0.57  |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.022 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.307 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     5.7 |             4.114 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.018 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

Image processingスレッドの前半・後半の処理時間と、`max_features`の待機時間はそれぞれ以下の通り。

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            70.95  |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　　　　　|    77.3 |            54.848 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` 　　　　|     1.8 |             1.324 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　　　　　|    20.7 |            14.742 |

##### 13.2.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            76.354 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.014 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |            76.274 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    44.2 |            33.821 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0.001 |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    55.5 |            42.423 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     0.6 |             0.533 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    54.8 |            41.884 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     2.8 |             2.166 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     4.1 |             3.177 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     1.1 |             0.897 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    15.4 |            11.788 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     9.6 |             7.383 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     5.4 |             4.188 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    30.1 |            22.993 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3.7 |             2.869 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|     8.7 |             6.674 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    17.4 |            13.294 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    14   |            10.749 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     3.1 |             2.393 |

### 13.3 考察

ボトルネック解析結果について説明する。

並列動作しないと仮定した場合の比較結果を以下の図に示す。

![Yolo-Planar-SLAMの処理時間の比較](image/dense/serial.png)

いずれのケースでも3つのスレッドの中で、Trackingスレッドの平均処理時間がもっとも大きい。

最大特徴点数が同じかつOpenCVA無しの場合と比較したときの高速化倍率を以下の図に示す。

![高速化倍率](image/dense/scale.png)

いずれのケースでも3つのスレッドの中で、Trackingスレッドの平均処理時間がもっとも大きいため、SLAMの性能としての高速化倍率はTrackingスレッドの高速化倍率となる。  
いずれの場合もOpenCVAによる高速化の効果の度合いに有意な差は無い。

Image loadingスレッド、Image processingスレッド、Trackingスレッドの処理時間の概要を以下の図に示す。

![スレッドごとの処理時間の内訳](image/dense/summary.png)

最大特徴点数による処理時間の差は`3`\[ms/frame\]未満となっている。  
RGB画像を読み込む場合では、Image loadingスレッド以外の処理時間もわずかに増加していることがわかる。

## 14 クロスコンパイル対応

Yolo-Planar-SLAMのビルド時に`Protobuf_PROTOC_EXECUTABLE`を明示的に指定せずにビルドできるように変更を行った内容について記載する。

本案件のYolo-Planar-SLAM向けのメタパッケージ`meta-yolo-planar-slam`の`recipes-core/images/core-image-%.bbappend`に対して、以下の変更を行った。

```diff
 IMAGE_INSTALL_append = " ssh sshd tmux vim"
+
+TOOLCHAIN_HOST_TASK_append = " nativesdk-protobuf-compiler"
+
```

上記の変更によって、Yocto環境でビルドしたSDKの`sysroots/x86_64-pokysdk-linux/usr/bin`に`protoc`が含まれる。

また、OpenCVA組み込み版のYolo-Planar-SLAMビルドマニュアルに以下の変更を行った。

```diff
   -DOpenMP_pthread_LIBRARY=${SDKTARGETSYSROOT}/usr/lib64/libpthread.so \
-  -DProtobuf_PROTOC_EXECUTABLE=/yocto_rzv2x_beta_workdir/build/tmp/sysroots-components/x86_64/protobuf-native/usr/bin/protoc \
   -DYOLO_PLANAR_SLAM_VERSION=${YOLO_PLANAR_SLAM_VERSION} \
   ..
 make -j
```

上記の変更を加えた状態で、OpenCVA組み込み版のYolo-Planar-SLAMが正常にビルドできることを確認した。

## 15 DRP-AI TVMによるSLAMへのモデル組み込みの実装可能性調査

GitHubで公開されているDRP-AI TVM v1.1.1とDRP-AI Translator V1.83を使用し、<https://github.com/renesas-rz/rzv_drp-ai_tvm>に記載されているチュートリアルの確認を行った結果を記載する。

### 15.1 SDKインストーラーのビルド

<https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/README.md>の手順に従ってDRP-AI TVMの動作環境を構築しようとした。  
バージョンはv1.1.1を使用した。  
ここで、[Installation](https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/setup/README.md#requirements)にはDRP-AI TVMの動作のためにSDKインストーラーが必要であると記載されている。

> Build image/SDK according to the DRP-AI Support Package Release Note to generate following files.

まず、[RZ/V Verified Linux Package v3.0.4](https://www.renesas.com/us/en/software-tool/rzv-verified-linux-package)をダウンロードした。  
ファイルのMD5ハッシュ値は以下の通り。

```shell
$ md5sum RTK0EF0045Z0024AZJ-v3.0.4.zip
5a54e1f09d30a301223dbc5edb3382c3  RTK0EF0045Z0024AZJ-v3.0.4.zip
```

#### 15.1.1 RZ/V2MAの場合

OpenCVAの拡張実装を含むヘッダーファイルが`rzv2ma_drp.h`であるため、ここではRZ/V2MA向けのSDKインストーラーをビルドして使用しようとした。

[RZ/V2MA DRP-AI Support Package Version 7.40](https://www.renesas.com/jp/ja/products/microcontrollers-microprocessors/rz-arm-based-high-end-32-64-bit-mpus/rzv2ma-drp-ai-support-package)をダウンロードした。  
ファイルのMD5ハッシュ値は以下の通り。

```shell
$ md5sum r11an0592ej0740-rzv2ma-drpai-sp.zip
bcdabffa948654ede826c1bac3399d5d  r11an0592ej0740-rzv2ma-drpai-sp.zip
```

[RZ/V2MA DRP-AI Support Package Version 7.40 Release Note](https://www.renesas.com/jp/ja/document/rln/rzv2ma-drp-ai-support-package-version-740-release-note?r=1730826)の`3.2 Build Instructions`の手順に従って、Yocto環境を構築した。  
ここでは`/yocto_rzv_workdir`に構築した。

```shell
cd /yocto_rzv_workdir

unzip RTK0EF0045Z0024AZJ-v3.0.4.zip
tar xzvf RTK0EF0045Z0024AZJ-v3.0.4/rzv_vlp_v3.0.4.tar.gz
```

同じく`3.2.5 Build`に記載されている手順の通り、ビルドを実行した。

```shell
cd /yocto_rzv_workdir
export WORK=/yocto_rzv_workdir
TEMPLATECONF=$PWD/meta-renesas/meta-rzv2m/docs/template/conf/ \
  source poky/oe-init-build-env build

cd /yocto_rzv_workdir/build
MACHINE=rzv2ma bitbake core-image-bsp
```

しかし、以下のエラーとなった。

```shell
ERROR: openssl-native-1.1.1n-r0 do_fetch: Bitbake Fetcher Error: FetchError('Unable to fetch URL from any source.', 'https://security.debian.org/debian-security/pool/updates/main/o/openssl/openssl_1.1.1n-0+deb10u5.dsc;name=openssl_1.1.1n-0+deb10u5.dsc')
ERROR: Logfile of failure stored in: /yocto_rzv_workdir/build/tmp/work/x86_64-linux/openssl-native/1.1.1n-r0/temp/log.do_fetch.240
ERROR: Task (virtual:native:/yocto_rzv_workdir/build/../meta-renesas/meta-rz-common/recipes-debian/buster/openssl/openssl_debian.bb:do_fetch) failed with exit code '1'
```

また、`DEBIAN_SECURITY_UPDATE_MIRROR`を`DEBIAN_MIRROR`に変更してエラーが解消されるのかを確認した。  
しかし、解消できなかった。

2023年3月時点で<https://github.com/renesas-rz/meta-renesas/issues/8>に同様のエラーが報告されている。

[GitHubのmeta-renesasリポジトリ](https://github.com/renesas-rz/meta-renesas)の`dunfell/rz`（`f067822`）ブランチの`meta-rz-common/recipes-debian/buster/sources/openssl.inc`で、上記のYocto環境の`meta-renesas/meta-rz-common/recipes-debian/buster/sources/openssl.inc`を上書きすることでエラーを解消できた。

再びビルドを実行したが、以下のエラーとなった。

```shell
| ninja: build stopped: subcommand failed.
| WARNING: /yocto_rzv_workdir/build/tmp/work/aarch64-poky-linux/glib-2.0/2.58.3-r0/temp/run.do_compile.5774:1 exit 1 from 'ninja -v -j 12'
| ERROR: Execution of '/yocto_rzv_workdir/build/tmp/work/aarch64-poky-linux/glib-2.0/2.58.3-r0/temp/run.do_compile.5774' failed with exit code 1
ERROR: Task (/yocto_rzv_workdir/build/../meta-renesas/meta-rz-common/recipes-debian/buster/glib-2.0/glib-2.0_debian.bb:do_compile) failed with exit code '1'
```

2万行以上のログが出ている。  
エラーメッセージの一部を以下の示す。

```shell
error: unknown type name 'size_t'
error: unknown type name 'timer_t'
error: unknown type name 'time_t'
error: unknown type name '__u64'
```

何らかの不整合が発生して、ビルドが正常にできなくなっている可能性がある。  
なお、以下のコマンドを実行してDRP-AI Support Packageを追加しても解消されなかった。

```shell
cd /yocto_rzv_workdir
unzip r11an0592ej0740-rzv2ma-drpai-sp.zip
tar xzvf rzv2ma_drpai-driver/meta-rz-drpai.tar.gz

TEMPLATECONF=$PWD/meta-renesas/meta-rzv2m/docs/template/conf/ \
  source poky/oe-init-build-env build
bitbake-layers add-layer ../meta-rz-features/meta-rz-drpai
```

#### 15.1.2 ビルド可能なターゲットの調査

DRP-AI TVMのターゲットのうち、`MACHINE`に設定可能なパラメータは以下の通り。

- rzv2m
- rzv2ma
- smarc-rzv2l
- rzv2l-dev

これら4つについて、`core-image-bsp`がビルド可能かを確認した。  
結果は以下の通り。

- rzv2m：エラー
- rzv2ma：エラー
- smarc-rzv2l：ビルド可能
- rzv2l-dev：ビルド可能

以上から、ここではRZ/V2MおよびRZ/V2MA向けのSDKインストーラーをビルドすることは断念し、RZ/V2L向けのSDKインストーラーをビルドして使用する。

#### 15.1.3 RZ/V2Lの場合

RZ/V2L SMARCボードをターゲットと仮定してSDKインストーラーをビルドした。  
DRP-AI Support Packageは[RZ/V2L DRP-AI Support Package [V7.40]](https://www.renesas.com/jp/ja/products/microcontrollers-microprocessors/rz-arm-based-high-end-32-64-bit-mpus/rzv2l-drp-ai-support-package)を使用した。  
MD5ハッシュ値は以下の通り。

```shell
$ md5sum r11an0549ej0740-rzv2l-drpai-sp.zip
476cbc9f4608650fb300483fe96d5ab8  r11an0549ej0740-rzv2l-drpai-sp.zip
```

以下のコマンドを実行して、RZ/V2L SMARCボードをターゲットと仮定してSDKインストーラーをビルドした。

```shell
cd /yocto_rzv_workdir

unzip r11an0549ej0740-rzv2l-drpai-sp.zip
tar xzvf rzv2l_drpai-driver/meta-rz-drpai.tar.gz

TEMPLATECONF=$PWD/meta-renesas/meta-rzv2l/docs/template/conf/ \
  source poky/oe-init-build-env build.rzv2l

bitbake-layers add-layer ../meta-rz-features/meta-rz-drpai

MACHINE=smarc-rzv2l bitbake core-image-bsp
MACHINE=smarc-rzv2l bitbake core-image-bsp -c populate_sdk
```

ビルドしたSDKインストーラーを使用して`${HOME}/smarc_rzv2l_bsp_sdk`にSDKをインストールした。

### 15.2 DRP-AI Translatorの環境構築

[DRP-AI Translator [V1.83]](https://www.renesas.com/jp/ja/products/microcontrollers-microprocessors/rz-arm-based-high-end-32-64-bit-mpus/drp-ai-translator)をダウンロードしてインストールした。  
MD5ハッシュ値は以下の通り。

```shell
$ md5sum r20ut5035ej0183-drp-ai-translator.zip
2af6b99d18026f61f0dc4f4a563872c5  r20ut5035ej0183-drp-ai-translator.zip
```

また、[DRP-AI Translator V1.83 User‘s Manual](https://www.renesas.com/jp/ja/document/mat/drp-ai-translator-v183-user-s-manual?r=1763086)の手順に従って環境構築を行った。

### 15.3 DRP-AI TVMの環境構築

[Installation](https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/setup/README.md#requirements)に従ってパッケージをインストールした。

```shell
## Install packagess
sudo apt update
sudo DEBIAN_FRONTEND=noninteractive apt install -y software-properties-common
sudo add-apt-repository ppa:ubuntu-toolchain-r/test
sudo apt update
sudo DEBIAN_FRONTEND=noninteractive apt install -y build-essential cmake \
  libomp-dev libgtest-dev libgoogle-glog-dev libtinfo-dev zlib1g-dev libedit-dev \
  libxml2-dev llvm-8-dev g++-9 gcc-9 wget

sudo apt-get install -y python3-pip
python3 -m pip install --upgrade pip
sudo apt-get -y install unzip vim
python3 -m pip install decorator attrs scipy numpy==1.23.5 pytest
python3 -m pip install torch==1.8.0 torchvision==0.9.0 tensorflow tflite psutil

## Install onnx runtime
wget https://github.com/microsoft/onnxruntime/releases/download/v1.8.1/onnxruntime-linux-x64-1.8.1.tgz -O /tmp/onnxruntime.tar.gz
tar -xvzf /tmp/onnxruntime.tar.gz -C /tmp/
sudo mv /tmp/onnxruntime-linux-x64-1.8.1/ /opt/
```

また、環境変数を設定した。

```shell
export TVM_ROOT=${HOME}/drp-ai_tvm
export TVM_HOME=${TVM_ROOT}/tvm
export PYTHONPATH=${TVM_HOME}/python:${PYTHONPATH}
export SDK=${HOME}/smarc_rzv2l_bsp_sdk
export TRANSLATOR=${HOME}/drp-ai_translator_release
export PRODUCT=V2L
```

### 15.4 DRP-AI TVMの動作確認

[Compile AI models](https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/tutorials/README.md)の手順に従ってDRP-AI TVMを実行した。

```shell
cd ${TVM_ROOT}/tutorials/
wget https://github.com/onnx/models/raw/main/vision/classification/resnet/model/resnet18-v1-7.onnx

cd ${TVM_ROOT}
bash setup/make_drp_env.sh

cd ${TVM_ROOT}/tutorials/
python3
```

[Compile AI models](https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/tutorials/README.md)に記載されているPythonコードを入力したが、以下のエラーとなった。

```python
>>> input_shape     =s[1,3,224,224]
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 's' is not defined
```

`=`の後の`s`はtypoだと想定されるため、取り除いて再度実行した。  
以下のエラーとなった。

```python
>>> drp.build(mod, \
...           params, \
...          "arm", \
...           drp_config_runtime, \
...           output_dir=output_dir, \
...           disable_concat = opts["disable_concat"]
... )
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'drp' is not defined
```

記載されているPythonコードに`from tvm.relay.mera import drp`が不足していると想定されるため、importしてから再度実行した。

```python
>>> drp.build(mod, \
...           params, \
...          "arm", \
...           drp_config_runtime, \
...           output_dir=output_dir, \
...           disable_concat = opts["disable_concat"]
... )
Traceback (most recent call last):
  File "<stdin>", line 6, in <module>
NameError: name 'opts' is not defined
```

`opts`は定義されていない。
`disable_concat`について、[Compile Reference](https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/docs/Compile_API.md#sample-code)には以下のように記載がある。

> ```markdown
> 6    disable_concat  Compile optimization option. Default: False
> ```

以上から、`False`に置き換えた。

上記の修正を加えた状態で、以下のPythonコードからDRP-AI TVMを使用して、`resnet18-v1-7.onnx`を変換した。

```python
import os
import onnx
import tvm
import sys
import numpy as np

from tvm import relay, runtime
from tvm.relay import mera
from tvm.relay.mera import drp
from tvm.contrib import graph_executor
from google.protobuf.json_format import MessageToDict
from optparse import OptionParser

onnx_model = onnx.load_model("./resnet18-v1-7.onnx")

input_node_name = "data"
## input_shape     =s[1,3,224,224]
input_shape     = [1,3,224,224]
shape_dict = {input_node_name:input_shape}
mod, params = relay.frontend.from_onnx(onnx_model, shape_dict)

drp_config_runtime = {
    "interpreter": False,
    "addr_map_start": 0x0,
    "toolchain_dir": "/home/rel/drp-ai_translator_release",
    "sdk_root": "/home/rel/smarc_rzv2l_bsp_sdk"
}

## Define output directory name
output_dir = "./resnet18_onnx"
## Run build operation of TVM backend
drp.build(mod, \
          params, \
         "arm", \
          drp_config_runtime, \
          output_dir=output_dir, \
          disable_concat = False # opts["disable_concat"]
)
```

生成物は以下の通り。

```shell
$ ls resnet18_onnx/
deploy.json  deploy.params  deploy.so
```

`${TVM_ROOT}/tutorials/resnet18_onnx/preprocess`が生成されて**いない**ことがわかる。

なお、[Compile AI models](https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/tutorials/README.md#compile-ai-models)の手順に**従わず**、[1.1. Example using Resnet from the official ONNX model zoo](https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/tutorials/README.md#11-example-using-resnet-from-the-official-onnx-model-zoo)の手順に従って`tutorials/compile_onnx_model.py`を使用した場合には、以下の通り`${TVM_ROOT}/tutorials/resnet18_onnx/preprocess`が生成される。

```shell
$ ls ${TVM_ROOT}/tutorials/resnet18_onnx/preprocess
aimac_desc.bin  drp_param.bin       pp_addrmap_intm.txt  pp_weight.dat
drp_desc.bin    drp_param_info.txt  pp_drpcfg.mem
```

### 15.5 DRP-AI TVMのサンプルプログラムのビルド確認

[DRP-AI TVM Application Example](https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/apps/README.md)の手順に従ってサンプルプログラムをビルドした。

```shell
cd $TVM_ROOT/apps
mkdir build
cd build

cmake -DCMAKE_TOOLCHAIN_FILE=./toolchain/runtime.cmake ..
make -j$(nproc)
```

正常にビルドできた。

なお、`rzv_drp-ai_tvm/apps/tutorial_app.cpp`では`/sys/class/u-dma-buf/udmabuf0/phys_addr`を参照している。  
入力画像をDRP-AI Translatorで指定した場所ではなく、他のメモリ空間に配置している可能性が高い。

### 15.6 DRP-AI TVMの実行時の設定の確認

DRP-AI TVMの生成物を使用してYOLOX-Sを実行する時に指定する`device_type`について確認した。

[rzv_drp-ai_tvm](https://github.com/renesas-rz/rzv_drp-ai_tvm/tree/v1.1.1)のサンプルプログラムでは以下のように実装されている。

[MeraDrpRuntimeWrapper::MeraDrpRuntimeWrapper](https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/apps/MeraDrpRuntimeWrapper.cpp#L58-L61)

```cpp
MeraDrpRuntimeWrapper::MeraDrpRuntimeWrapper() {
  device_type = kDLCPU;
  device_id = 0;
};
```

また、[docs/Runtime_API.md](https://github.com/renesas-rz/rzv_drp-ai_tvm/blob/v1.1.1/docs/Runtime_API.md#return-3)には以下のように記載がある。

> ```markdown
> - If a CPU-only model is loaded into a device other than a kDLCPU device, false is returned.
>     - true : Success. There were no problems.
>     - false : CPU-only model was specified. Therefore, device_type must be set to kDLCPU.
> ```

以上から、`device_type`には`kDLCPU`ではなく`kDLDrpAi`を指定しないとDRP-AIが使用されない可能性がある。  
DRP-AI TVMの開発者からは以下の回答が得られた。

> ```markdown
>  　下記の設定でDRP-AIも使用される仕様になっています。kDLCPUでご使用ください。  
> 　device_type = kDLCPU;  
> ```

また、`kDLDrpAi`についての説明は[rzv_drp-ai_tvm](https://github.com/renesas-rz/rzv_drp-ai_tvm/tree/v1.1.1)には含まれていなかった。  
DRP-AI TVMの開発者からは以下の回答が得られた。

> ```markdown
> 　最新仕様使用に対応したドキュメントは現状ありません。今後UPDATEいたします。
> ```

調査結果の概要は以下の通り。

| ターゲット                                   | V2M | V2MA | V2L |
|-----------------------------------------|-----|------|-----|
| SDKインストーラーのビルド                          | ×   | ×    | ○   |
| Compile AI modelsの手順によるビルド              | -   | -    | △※ |
| DRP-AI TVM Application Exampleの手順によるビルド | -   | -    | ○   |

※公式の手順ではエラーとなるため、`15.4 DRP-AI TVMの動作確認`に記載した修正が必要となる。  
また、`${TVM_ROOT}/tutorials/resnet18_onnx/preprocess`が生成されない問題がある。

### 15.7 DRP-AI TVMのResNetのサンプルプログラムの確認

受領したDRP-AI TVMのResNetのサンプルプログラム`drp-tvm_v2x_apps.zip`と`drp-tvm_v2x_samples.zip`について確認を行った。

#### 15.7.1 マニュアルの確認

マニュアルとして、以下の2つが含まれていた。

- drp-tvm_v2x_apps/apps/README.md
- drp-tvm_v2x_apps/apps/build_appV2H.md

上記2つのマニュアルに記載されている内容には差分がある。  
以降では`build_appV2H.md`を正として確認を行った。  
なお、`build_appV2H.md`から参照されていた`drp-tvm_v2x_apps/setup/SetupV2H.md`は同梱されていなかった。

#### 15.7.2 動作確認

まず、`drp-tvm_v2x_samples`に同梱されていた実行ファイルを使用して、V2xボード（α2、EVK-α、電力改善版）上で正常に動作するのかを確認した。

`build_appV2H.md`の手順を参考に、実行に必要なファイルをV2xボード（α2、EVK-α、電力改善版）上の`${HOME}/tvm`に配置した。

```shell
cd ${HOME}
mkdir tvm

cp -r \
  drp-tvm_v2x_samples/libtvm_runtime.so \
  drp-tvm_v2x_samples/resnet50_v1_onnx \
  drp-tvm_v2x_samples/sample.bmp \
  drp-tvm_v2x_samples/synset_words_imagenet.txt \
  drp-tvm_v2x_samples/tutorial_app \
  ${HOME}/tvm/

cd ${HOME}/tvm
export LD_LIBRARY_PATH=.
mkdir resnet18_onnx
cp -r resnet50_v1_onnx/* resnet18_onnx/
```

実行結果は以下の通り。

```shell
root@rzv2h-evk-alpha:~/tvm# ./tutorial_app
[INFO] Input  (H, W, C, unit byte_size)=(480, 640, 3, 1)
[INFO] Output (H, W, C, unit byte_size)=(224, 224, 3, 4)
PreProcessing Parameter List
  pre_in_shape_w =      640
  pre_in_shape_h =      480
  pre_in_addr    = 5c000000
  pre_in_format  =     fffe(RGB)
  pre_out_format =     fffd(BGR)
  resize_alg     =        1
  resize_w       =      224
  resize_h       =      224
  crop_tl_x      =    65535
  crop_tl_y      =    65535
  crop_w         =    65535
  crop_h         =    65535
[03:05:40] /home/knonono/AI_proj/example/rzv2x/drp-tvm_dev-v2.0.0_RC_231111/apps/MeraDrpRuntimeWrapper.cpp:67: Loading json data...
[03:05:40] /home/knonono/AI_proj/example/rzv2x/drp-tvm_dev-v2.0.0_RC_231111/apps/MeraDrpRuntimeWrapper.cpp:77: Loading runtime module...
[03:05:41] /home/knonono/AI_proj/example/rzv2x/drp-tvm_dev-v2.0.0_RC_231111/apps/MeraDrpRuntimeWrapper.cpp:82: Loading parameters...
[TIME] Pre Processing Time: 52.96 msec.
[03:05:41] /home/knonono/AI_proj/example/rzv2x/drp-tvm_dev-v2.0.0_RC_231111/apps/MeraDrpRuntimeWrapper.cpp:98: Loading input...
Running tvm runtime
[TIME] AI Processing Time: 6.59 msec.
Output data type : FP16.
Result -----------------------
  Top 1 [ 40.3%] : [beagle]
  Top 2 [ 29.3%] : [English foxhound]
  Top 3 [ 21.3%] : [Walker hound, Walker foxhound]
  Top 4 [  3.1%] : [basset, basset hound]
  Top 5 [  1.6%] : [bloodhound, sleuthhound]
```

正常に動作しているように見える。  
また、何度か連続して`tutorial_app`を実行した場合も同じ結果が得られることを確認した。

#### 15.7.3 ソースコードの確認

`drp-tvm_v2x_apps/apps`に含まれるソースコードの確認を行った。  
含まれていたソースコードは以下の通り。

- PreRuntime.h
- PreRuntime.cpp
- PreRuntimeV2H.cpp
- PreRuntimeOcv.cpp
- MeraDrpRuntimeWrapper.h
- MeraDrpRuntimeWrapper.cpp
- tutorial_app.cpp

`drp-tvm_v2x_apps/apps/CMakeLists.txt`には以下の記述がある。

```cmake
if(OCV)
  set(SRC tutorial_app.cpp MeraDrpRuntimeWrapper.cpp PreRuntimeOcv.cpp)
  find_package(OpenCV REQUIRED)
elseif(V2H)
  set(SRC tutorial_app.cpp MeraDrpRuntimeWrapper.cpp PreRuntimeV2H.cpp)
else()
  set(SRC tutorial_app.cpp MeraDrpRuntimeWrapper.cpp PreRuntime.cpp)
endif()
```

`cmake`で指定するビルドスイッチによって、前処理（`PreRuntime`）で使用される実装が切り替わることがわかる。  
`build_appV2H.md`には以下のように記載されている。

```shell
#cmake -DCMAKE_TOOLCHAIN_FILE=./toolchain/runtime.cmake -DV2H=ON ..
cmake -DCMAKE_TOOLCHAIN_FILE=./toolchain/runtime.cmake -DOCV=ON ..
```

受領した実行ファイルが上記の通りにビルドされたものであれば、`PreRuntimeOcv.cpp`の実装が使用される。

##### 15.7.3.1 PreRuntime.cppについて

`PreRuntime.cpp`と`PreRuntimeV2H.cpp`の差分の一部を以下に示す。

```diff
@@ -951,9 +933,9 @@ uint8_t PreRuntime::LoadParamInfo()
 * Return value  : start address for Pre-Runtime Object files
 *                 INVALID_ADDR if user input is invalid
 ******************************************/
-uint32_t PreRuntime::GetStartAddress(uint32_t addr, drpai_data_t drpai_data)
+uint64_t PreRuntime::GetStartAddress(uint64_t addr, drpai_data_t drpai_data)
 {
-    uint32_t drpai_mem_addr_end = drpai_data.address+drpai_data.size - 1;
+    uint64_t drpai_mem_addr_end = drpai_data.address+drpai_data.size - 1;
     if (INVALID_ADDR == addr)
     {
         /*If user did not specify the start_addr, use DRP-AI memory area start address.*/
```

`PreRuntime.cpp`は「DRPドライバの40bit対応」が行われていないことがわかる。  
また`ioctl(DRPAI_SET_ADRCONV)`も使用されていなかった。

##### 15.7.3.2 PreRuntime::Preについて

`PreRuntimeV2H.cpp`の前処理（`PreRuntime::Pre`）はDRP-AIを使用するように実装されている。  
`PreRuntimeOcv.cpp`の前処理（`PreRuntime::Pre`）はOpenCVAのresizeを使用するように実装されている。

##### 15.7.3.3 device_typeについて

`MeraDrpRuntimeWrapper.cpp`の実装の一部を以下に示す。

```cpp
MeraDrpRuntimeWrapper::MeraDrpRuntimeWrapper() {
  //device_type = kDLCPU;
  device_type = kDLDrpAi;
  device_id = 0;
};
```

`device_type`に`kDLDrpAi`が指定されている。

一方でDRP-AI TVMの開発者からは以下の回答が得られた。

> ```plaintxt
> 下記の設定でDRP-AIも使用される仕様になっています。kDLCPUでご使用ください。
> device_type = kDLCPU;
> ```

#### 15.7.4 ビルド確認

[GitHubで公開されているDRP-AI TVM](https://github.com/renesas-rz/rzv_drp-ai_tvm)を使用して、受領したサンプルプログラムがビルド可能か確認した。  
バージョンは`v1.1.1`を使用した。

以下の変更を加えた状態で、DRP-AI TVMで**V2L**向けの設定を行った上で、**V2x**ボード（α2、EVK-α、電力改善版）用のSDKを指定することでビルドできることを確認した。

```shell
cd drp-tvm_v2x_apps/apps
sed -i 's/kDLDrpAi/36/g' MeraDrpRuntimeWrapper.cpp
sed -i 's/build_runtime/..\/obj\/build_runtime\/V2L/g' CMakeLists.txt
```

ただし、サポートされた設定・手順によるビルドではないため動作確認は行っていない。

### 15.8 Yolo-Planar-SLAMへのモデル組み込みの実装可能性調査

受領した`drp-tvm_v2x_apps`のコードをYolo-Planar-SLAMに組み込み、DRP-AI TVMのモデルをYolo-Planar-SLAMから実行するために必要な作業の調査を行った。  
また、DRP-AI TVMのResNetが正常に動作するのか確認を行った。

主な作業内容は以下の通り。

1. 受領した`drp-tvm_v2x_apps`のコードの取り込み
2. TVMのRuntimeへの依存関係の記述の追加
3. `YoloDetector_tvm`クラスの実装
4. DRP-AI TVMのResNetを実行するように変更
    - 依存関係の追記
    - DRP-AIの出力を受け取る処理のコメントアウト
        - ResNetからはバウンディングボックスが取得できないため
    - `YoloDetector_drp`クラス（DRP-AI Translator向けのクラス）ではなく、`YoloDetector_tvm`クラスを使用するように変更

1～3については本案件のYolo-Planar-SLAMリポジトリに反映した。  
4についてはV2xボード向けのDRP-AI TVMを受領していないため、本案件のYolo-Planar-SLAMリポジトリには反映していない。

4の`CMakeLists.txt`の変更内容は以下の通り。

```diff
 ${PCL_INCLUDE_DIRS}
 )

+if(ENABLE_TVM)
+  set(TVM_ROOT $ENV{TVM_HOME})
+  include_directories(
+    ${TVM_ROOT}/include
+    ${TVM_ROOT}/3rdparty/dlpack/include
+    ${TVM_ROOT}/3rdparty/dmlc-core/include
+    ${TVM_ROOT}/3rdparty/compiler-rt
+  )
+endif()
+
 add_subdirectory(Thirdparty/DBoW2)
```

4の`src/ORBextractor.cc`の変更内容は以下の通り。

```diff
     MT_FINISH(mt_drp_ai_yolo_polling);

-    SetYoloBoundingBoxList(mYoloDetector_->result_object_detection);
+    // SetYoloBoundingBoxList(mYoloDetector_->result_object_detection);

     MT_FINISH(mt_receive_yolo_output);
```

4の`src/Tracking.cc`の変更内容は以下の通り。

```diff
@@ -33,6 +33,12 @@
 #include "PnPsolver.h"
 #include "ConfigFile.h"

+#if defined(ENABLE_TVM)
+#include "tvm/YoloDetector_tvm.h"
+#else
+#include "YoloDetector_drp.h"
+#endif
+
 #include "Enum.h"

 #if !defined(ENABLE_SLAMFAST)
```

```diff
 #if defined(ENABLE_DRP_AI)
     if (use_drp_ai) {
+#if defined(ENABLE_TVM)
+        mYoloDetector = new YoloDetector_tvm();
+#else
         mYoloDetector = new YoloDetector_drp();
+#endif
     }
     else
 #endif
```

上記の変更を加えた状態で、DRP-AI TVMでV2L向けの設定を行った上で、V2xボード用のSDKを指定することでビルドできることを確認した。  
ただし、サポートされた設定・手順によるビルドではないため動作確認は行っていない。

### 15.9 今後確認が必要な点について

本案件のYolo-Planar-SLAMにDRP-AI TVMのモデルを組み込む場合に確認する必要がある点は以下の通り。

1. 本案件のYolo-Planar-SLAMにDRP-AI TVMのYOLOを組み込む場合に、前処理（`PreRuntime::Pre`）ではDRP-AIとOpenCVAのどちらを使用するのか
2. `device_type`に`kDLCPU`と`kDLDrpAi`のどちらを指定した場合にDRP-AIが使用されるのか
3. DRP-AI TVMのモデルをYolo-Planar-SLAMから実行する場合には、受領した`drp-tvm_v2x_samples/libtvm_runtime.so`に相当するファイルをどのディレクトリに配置するべきか
    - `libORB_SLAM2.so`は`${HOME}/yolo-planar-slam/lib/`に配置されているため、同じディレクトリに含めることで`LD_LIBRARY_PATH`への追加の設定が不要となる

## 16 高速化試行

Yolo-Planar-SLAMの高速化試行の内容について記載する。  
また、合わせてリファクタリングなどの性能へ影響しない変更も行ったため合わせて記載する。

高速化のために以下の変更を行った。

- OpenCVAのFASTの内部実装の不具合修正に伴う、呼び出し側での`cv::Mat::clone`の削除
- ポーリング周期の変更
    - DRP-AIの処理のポーリング周期の変更（`5`\[ms\]→`1`\[ms\]）
    - Image loadingスレッドの排他制御のポーリング周期の変更（`5`\[ms\]→`1`\[ms\]）
    - Image processingスレッドの排他制御のポーリング周期の変更（`5`\[ms\]→`1`\[ms\]）
    - Socket Viewerスレッドの停止命令のポーリング周期の変更（`3`\[ms\]→`1`\[ms\]）

合わせて、DRP-AIの処理時間を計測するために、以下の変更を行った。

- DRP-AIのポーリング時間の計測のための更新

また、性能へ影響しない変更として以下を行った。

- DRP-AIのデモプログラム由来の変数名の変更
    - `RecognizeBase::_inf_running`→`RecognizeBase::inference_thread_running_`
- `ImageLoading::GetFrame`の`override`関連のリファクタリング
- D435iについて実行できるように変更
    - ただし、動作確認されていない点を警告で表示

上記の変更の前後でダンプファイルが厳密に一致することを確認した。

また、評価を行った。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1000
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）
- DRP/DRP-AIドライバ：β版

### 16.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1130_6.mono.opencva.ai.3wx.1000.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.296848
      mean      0.036308
    median      0.029973
       min      0.003185
      rmse      0.049510
       sse      2.036983
       std      0.033659

```

最大誤差が`29`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1130_6.mono.opencva.ai.3wx.1000.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1130_6.mono.opencva.ai.3wx.1000
infos:  831 poses, 11.641m path length, 27.922s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/speed_up/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/speed_up/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/speed_up/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

### 16.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

#### 16.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |             9.574 |
| `　　cv::imread` |    99.8 |             9.563 |

#### 16.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            67.195 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.8 |             0.589 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB or YUYV`　　　　　　　　　　　　　　　　　　|     1.3 |             0.898 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             0.802 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     7.5 |             5.074 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.02  |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.017 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.7 |             3.163 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.6 |             3.146 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.033 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     0.5 |             0.4   |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.037 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.311 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    51.6 |            34.711 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.3 |             2.239 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.7 |             2.496 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.8 |             3.25  |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.005 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.4 |             3.012 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.02  |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.025 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.8 |             0.596 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.023 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.307 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     6.1 |             4.127 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.018 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            67.195 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    74.8 |            50.279 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.3 |             2.239 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    21.7 |            14.645 |

#### 16.2.3 Trackingスレッド

| 関数                                                                          |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Main loop` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.668 |
| `　　Sleep specified at execution`  　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`　　　　　　　　　　　　　　　　|     0   |             0.057 |
| `　　System::Track*`　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.5 |            68.386 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`   　　　　　　　　|    35   |            24.077 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true`  　　|     0   |             0     |
| `　　　　Tracking::GrabImage*`  　　　　　　　　　　　　　　　　　　　　　　|    64.4 |            44.278 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction`  |     1.1 |             0.777 |
| `　　　　　　Tracking::Track`   　　　　　　　　　　　　　　　　　　　　　　|    63.3 |            43.495 |
| `　　　　　　　　Map::mMutexMapUpdate`  　　　　　　　　　　　　　　　　　　|     3.7 |             2.592 |
| `　　　　　　　　Tracking::MonocularInitialization` 　　　　　　　　　　　　|     4.8 |             3.319 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`   　　　　　　　　|     1.1 |             0.809 |
| `　　　　　　　　Tracking::TrackWithMotionModel`　　　　　　　　　　　　　　|    19.5 |            13.424 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    10.3 |             7.095 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection`  　　　　　　　　|     8.8 |             6.067 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`   　　　　　　　　　　　　　　　　|    32.4 |            22.273 |
| `　　　　　　　　　　Tracking::UpdateLocalMap`  　　　　　　　　　　　　　　|     3   |             2.096 |
| `　　　　　　　　　　Optimizer::PoseOptimization`   　　　　　　　　　　　　|    10.2 |             7.056 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`   　　　　　　　　　　　　|    18.8 |            12.961 |
| `　　　　　　　　　　　　Project points in frame and check its visibility`  |    15.3 |            10.567 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`　　　　　　　　　　|     3.3 |             2.28  |

#### 16.2.4 Inferenceスレッド

| 関数                                |   割合(%) |   実測値(msec/frame) |
|:----------------------------------|--------:|------------------:|
| `RecognizeBase::inference_thread` |   100   |            20.856 |
| `　　polling` 　　　　　　　　　　|    90.7 |            18.922 |

### 16.3 考察

`13.1.2 ボトルネック解析結果`の評価結果と比較する。  
`Main loop`が`75.149`\[ms/frame\]から`68.668`\[ms/frame\]に減少しているため、高速化できていることがわかる。

また、`YOLOX_S_dense_640x640_RGB_10271351`のDRP-AIの処理時間が`18.922`\[ms/frame\]であることがわかる。

## 17 バージョン1移行検討

受領したバージョン1のBSPファイル一式を使用して、Yocto環境を構築し、ビルドしたCIP Linuxを使用してV2xボード（α2、EVK-α、電力改善版）が正常に動作するのかを確認した結果を記載する。  
ただしDRPドライバとOpenCVAは受領していないため、V2xボード（α2、EVK-α、電力改善版）上での動作確認は行っていない。

### 17.1 Yocto環境構築

受領した`20231206_RZV2H_DRP-AI_V1pre.zip`を使用して、バージョン1のYocto環境の構築を行った。

Yocto環境は`/yocto_rzv2x_ver1_workdir`に作成した。

まず、受領したファイルを展開した。

```shell
cd /yocto_rzv2x_ver1_workdir

unzip -Ocp932 20231206_RZV2H_DRP-AI_V1pre.zip
tar xzvf 20231206_RZV2H_DRP-AI_V1pre/meta-renesas-1201a.tar.gz
unzip 20231206_RZV2H_DRP-AI_V1pre/RTK0EF0045Z13001ZJ-v1.1.0a_EN.zip
tar xzvf RTK0EF0045Z13001ZJ-v1.1.0a_EN/meta-rz-features_graphics_v1.1.0.tar.gz
tar xzvf 20231206_RZV2H_DRP-AI_V1pre/rzv2h_drpai-driver_ver1.00pre2.tar.gz
mv rzv2h_drpai-driver_ver1.00pre2/meta-rz-features/meta-rz-drpai/ ./meta-rz-features/
```

次に、必要なリポジトリを`git clone`した。

```shell
cd /yocto_rzv2x_ver1_workdir

git clone https://git.yoctoproject.org/git/poky -b dunfell
cd poky
git checkout dunfell-23.0.21
cd ..
git clone https://github.com/openembedded/meta-openembedded -b dunfell
cd meta-openembedded
git checkout 7952135f650b4a754e2255f5aa03973a32344123
cd ..
git clone https://git.yoctoproject.org/git/meta-gplv2 -b dunfell
cd meta-gplv2 
git checkout 60b251c25ba87e946a0ca4cdc8d17b1cb09292ac
cd ..
```

`build手順.txt`に記載されていた手順に従って、パッチを適用した。

```shell
cd /yocto_rzv2x_ver1_workdir/meta-renesas

cp /yocto_rzv2x_ver1_workdir/20231206_RZV2H_DRP-AI_V1pre/0001-meta-renesas-Add-virtual-mapping-for-the-buffer-into.patch .
patch -p1 < ./0001-meta-renesas-Add-virtual-mapping-for-the-buffer-into.patch

cp \
  /yocto_rzv2x_ver1_workdir/20231206_RZV2H_DRP-AI_V1pre/mmngr_lib.inc \
  ./meta-rz-common/recipes-multimedia/mmngr-module/

cp \
  /yocto_rzv2x_ver1_workdir/20231206_RZV2H_DRP-AI_V1pre/0013-kernel-module-mmngr-bug-fix.patch \
  ./meta-rz-common/recipes-kernel/kernel-module-mmngr/kernel-module-mmngr/
cd ..
```

また、`/yocto_rzv2x_ver1_workdir/meta-renesas/meta-rz-common/recipes-kernel/kernel-module-mmngr/kernel-module-mmngr.bb`に以下の変更を加えた。

```diff
     file://0012-Add-RZ-V2L-into-rzg2l_match-to-not-parse-and-init-lo.patch \
+    file://0013-kernel-module-mmngr-bug-fix.patch \
 "

 SRC_URI_append_rzg2l = " \
```

最後にビルドを行った。

```shell
cd /yocto_rzv2x_ver1_workdir

TEMPLATECONF=${PWD}/meta-renesas/meta-rzv2/docs/template/conf/ \
  source poky/oe-init-build-env build
bitbake-layers add-layer ../meta-rz-features/meta-rz-graphics
bitbake-layers add-layer ../meta-rz-features/meta-rz-drpai

MACHINE=rzv2h-evk-alpha bitbake core-image-bsp
MACHINE=rzv2h-evk-alpha bitbake core-image-weston
MACHINE=rzv2h-evk-alpha bitbake core-image-bsp -c populate_sdk
MACHINE=rzv2h-evk-alpha bitbake core-image-weston -c populate_sdk
```

LinuxイメージとSDKインストーラーを正常にビルドできることを確認した。

### 17.2 ビルド生成物の確認

`build手順.txt`に記載されていた確認事項について、確認を行った。

> ```markdown
> 補足： MMNGRのインストール確認
> ------------------------------------------------------
> 
> <build_work>/build/tmp/work/rzv2h_evk_alpha-poky-linux/core-image-weston/1.0-r0/temp/log.do_rootfs
> に　mmngr、mmngr_bufが入っているか
> ```

上記について確認を行った。

```shell
$ grep -n mmngr build/tmp/work/rzv2h_evk_alpha-poky-linux/core-image-weston/1.0-r0/temp/log.do_rootfs
446:---> Package kernel-module-mmngr.rzv2h_evk_alpha 1.0-r0 will be installed
447:---> Package kernel-module-mmngrbuf.rzv2h_evk_alpha 1.0-r0 will be installed
607:---> Package libmmngr1.rzv2h_evk_alpha 1.0-r0 will be installed
608:---> Package libmmngrbuf1.rzv2h_evk_alpha 1.0-r0 will be installed
1465: kernel-module-mmngr                                      rzv2h_evk_alpha1.0-r0                            oe-repo 14 k
1466: kernel-module-mmngrbuf                                   rzv2h_evk_alpha1.0-r0                            oe-repo 12 k
1593: libmmngr1                                                rzv2h_evk_alpha1.0-r0                            oe-repo 10 k
1594: libmmngrbuf1                                             rzv2h_evk_alpha1.0-r0                            oe-repo 9.0 k
4027:  Installing       : libmmngrbuf1-1.0-r0.rzv2h_evk_alpha               336/1002
4028:  Running scriptlet: libmmngrbuf1-1.0-r0.rzv2h_evk_alpha               336/1002
4029:%post(libmmngrbuf1-1.0-r0.rzv2h_evk_alpha): scriptlet start
4030:%post(libmmngrbuf1-1.0-r0.rzv2h_evk_alpha): execv(/bin/sh) pid 1347
4033:%post(libmmngrbuf1-1.0-r0.rzv2h_evk_alpha): waitpid(1347) rc 1347 status 0
5902:  Installing       : libmmngr1-1.0-r0.rzv2h_evk_alpha                  738/1002
5903:  Running scriptlet: libmmngr1-1.0-r0.rzv2h_evk_alpha                  738/1002
5904:%post(libmmngr1-1.0-r0.rzv2h_evk_alpha): scriptlet start
5905:%post(libmmngr1-1.0-r0.rzv2h_evk_alpha): execv(/bin/sh) pid 7747
5908:%post(libmmngr1-1.0-r0.rzv2h_evk_alpha): waitpid(7747) rc 7747 status 0
6523:  Installing       : kernel-module-mmngr-1.0-r0.rzv2h_evk_alpha        855/1002
6524:  Running scriptlet: kernel-module-mmngr-1.0-r0.rzv2h_evk_alpha        855/1002
6525:%post(kernel-module-mmngr-1.0-r0.rzv2h_evk_alpha): scriptlet start
6526:%post(kernel-module-mmngr-1.0-r0.rzv2h_evk_alpha): execv(/bin/sh) pid 8966
6531:%post(kernel-module-mmngr-1.0-r0.rzv2h_evk_alpha): waitpid(8966) rc 8966 status 0
6533:  Installing       : kernel-module-mmngrbuf-1.0-r0.rzv2h_evk_alpha     856/1002
6534:  Running scriptlet: kernel-module-mmngrbuf-1.0-r0.rzv2h_evk_alpha     856/1002
6535:%post(kernel-module-mmngrbuf-1.0-r0.rzv2h_evk_alpha): scriptlet start
6536:%post(kernel-module-mmngrbuf-1.0-r0.rzv2h_evk_alpha): execv(/bin/sh) pid 8967
6541:%post(kernel-module-mmngrbuf-1.0-r0.rzv2h_evk_alpha): waitpid(8967) rc 8967 status 0
7872:  Verifying        : kernel-module-mmngr-1.0-r0.rzv2h_evk_alpha        390/1002
7873:  Verifying        : kernel-module-mmngrbuf-1.0-r0.rzv2h_evk_alpha     391/1002
8033:  Verifying        : libmmngr1-1.0-r0.rzv2h_evk_alpha                  551/1002
8034:  Verifying        : libmmngrbuf1-1.0-r0.rzv2h_evk_alpha               552/1002
9138:  kernel-module-mmngr-1.0-r0.rzv2h_evk_alpha
9139:  kernel-module-mmngrbuf-1.0-r0.rzv2h_evk_alpha
9266:  libmmngr1-1.0-r0.rzv2h_evk_alpha
9267:  libmmngrbuf1-1.0-r0.rzv2h_evk_alpha
```

意図された通りにインストールされていることがわかる。

> ```markdown
> バージョン
> mmngr_buf_drv.c　に以下の変更が入っているか
> build/tmp/work/rzv2h_evk_alpha-poky-linux/kernel-module-mmngrbuf/1.0-r0/git/mmngr_drv/mmngrbuf/mmngrbuf-module/files/mmngrbuf/drv/mmngr_buf_drv.c
> 
> + static void *dmabuf_vmap(struct dma_buf *buf)
> + {
> +-	return NULL;
> ++	struct MM_BUF_PRIVATE *priv = buf->priv;
> ++
> ++	return phys_to_virt(priv->hard_addr);
> + }
> ```

上記について確認を行った。

```shell
$ grep -n -A 5 'void \*dmabuf_vmap' build/tmp/work/rzv2h_evk_alpha-poky-linux/kernel-module-mmngrbuf/1.0-r0/git/mmngr_drv/mmngrbuf/mmngrbuf-module/files/mmngrbuf/drv/mmngr_buf_drv.c
308:static void *dmabuf_vmap(struct dma_buf *buf)
309-{
310-    struct MM_BUF_PRIVATE *priv = buf->priv;
311-
312-    return phys_to_virt(priv->hard_addr);
313-}
```

意図された変更が適用されていることがわかる。

> ```markdown
> kernel-module-mmngr flush関数バグ対策パッチが適用されているか、下記の確認を行う
> ・<作業ディレクトリ>/build/tmp/work/rzv2h_evk_alpha-poky-linux/kernel-module-mmngr/1.0-r0/git/mmngr_drv/mmngr/mmngr-module/files/mmngr/drv/mmngr_drv.cの
> ioctl関数のcase MM_IOC_FLUSHにてcachepに対してcopy_from_user関数を使ってargの値を渡している事
> 下記に追加した処理を記す
> 
> copy_from_user(&cachep, arg, sizeof(struct MM_CACHE_PARAM));
> ```

上記について確認を行った。

```shell
$ grep -n -A 5 'case MM_IOC_FLUSH' build/tmp/work/rzv2h_evk_alpha-poky-linux/kernel-module-mmngr/1.0-r0/git/mmngr_drv/mmngr/mmngr-module/files/mmngr/drv/mmngr_drv.c
1018:   case MM_IOC_FLUSH:
1019-       copy_from_user(&cachep, arg, sizeof(struct MM_CACHE_PARAM));
1020-       dma_sync_single_for_device(mm_dev, p->hard_addr + cachep.offset,
1021-                                      cachep.len, DMA_FROM_DEVICE);
1022-           break;
1023-   case MM_IOC_INVAL:
```

意図された変更が適用されていることがわかる。

また、`meta-rz-features/meta-rz-opencva`を受領していないため、以下の点を確認した。

- SDKに`drp.h`が**含まれていない**こと
- SDKの`usr/include/opencv4/opencv2/imgproc.hpp`に`resize_drp`が**実装されていない**こと

## 18 最終評価

2023年12月時点のYolo-Planar-SLAMの評価を行った結果について記載する。

### 18.1 単眼 + OpenCVAあり

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1000
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）
- DRP/DRP-AIドライバ：β版

なお、投機実行の後に`max_features`が更新され、再実行が発生した回数は、859フレーム中1回だった。

#### 18.1.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1214.mono.opencva.ai.3wx.1000.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.379276
      mean      0.034966
    median      0.026202
       min      0.002052
      rmse      0.053574
       sse      2.385132
       std      0.040590

```

最大誤差が`37`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1214.mono.opencva.ai.3wx.1000.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1214.mono.opencva.ai.3wx.1000
infos:  831 poses, 10.871m path length, 27.922s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/final/mono.opencva/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/final/mono.opencva/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/final/mono.opencva/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 18.1.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

##### 18.1.2.1 Image loadingスレッド

| 関数                                       |   割合(%) |   実測値(msec/frame) |
|:-----------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　|   100   |            10.272 |
| `　　cv::imread` 　　　　　　　　　　　　|    99.8 |            10.253 |

##### 18.1.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            70.863 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.8 |             0.616 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB or YUYV`　　　　　　　　　　　　　　　　　　|     1.2 |             0.895 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     1   |             0.775 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     6.6 |             4.679 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.02  |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.017 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     8.1 |             5.791 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     6   |             4.289 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.047 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     0.5 |             0.419 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.037 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.319 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    49.2 |            34.924 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.5 |             2.496 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.2 |             2.318 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.5 |             3.251 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.006 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.1 |             2.963 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.02  |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.025 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.7 |             0.511 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.023 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.041 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.306 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     5.8 |             4.13  |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.018 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            70.863 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    76.2 |            54.015 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    20.4 |            14.499 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.2 |             2.318 |

##### 18.1.2.3 Trackingスレッド

| 関数                                                                         |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            72.35  |
| `　　Sleep specified at execution` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`   　　　　　　　　　　　　　　|     0   |             0.015 |
| `　　System::Track*`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.6 |            72.107 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`  　　　　　　　　|    31.8 |            23.053 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true` 　　|     0   |             0     |
| `　　　　Tracking::GrabImage*` 　　　　　　　　　　　　　　　　　　　　　　|    67.7 |            49.025 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction` |     1   |             0.725 |
| `　　　　　　Tracking::Track`  　　　　　　　　　　　　　　　　　　　　　　|    66.7 |            48.293 |
| `　　　　　　　　Map::mMutexMapUpdate` 　　　　　　　　　　　　　　　　　　|     4.1 |             3.034 |
| `　　　　　　　　Tracking::MonocularInitialization`　　　　　　　　　　　　|     4.6 |             3.383 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`  　　　　　　　　|     1.2 |             0.897 |
| `　　　　　　　　Tracking::TrackWithMotionModel`   　　　　　　　　　　　　|    20.5 |            14.859 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|    12   |             8.682 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection` 　　　　　　　　|     7.9 |             5.778 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection`　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`  　　　　　　　　　　　　　　　　|    34.7 |            25.125 |
| `　　　　　　　　　　Tracking::UpdateLocalMap` 　　　　　　　　　　　　　　|     4.5 |             3.302 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     9.5 |             6.887 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`  　　　　　　　　　　　　|    20.4 |            14.776 |
| `　　　　　　　　　　　　Project points in frame and check its visibility` |    16.8 |            12.196 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`   　　　　　　　　|     3.3 |             2.426 |

##### 18.1.2.4 Inferenceスレッド

| 関数                                |   割合(%) |   実測値(msec/frame) |
|:----------------------------------|--------:|------------------:|
| `RecognizeBase::inference_thread` |   100   |            22.861 |
| `　　polling` 　　　　　　　　　　|    91.4 |            20.898 |

### 18.2 単眼 + OpenCVA無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1000
- DRP：無効
- DRP-AI：有効
- OpenCVA：無効
- DRP-AIオブジェクトファイル：RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）
- DRP/DRP-AIドライバ：β版

なお、投機実行の後に`max_features`が更新され、再実行が発生した回数は、859フレーム中1回だった。

#### 18.2.2 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2023.1214.mono.cpu.ai.3wx.1000.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.341980
      mean      0.026113
    median      0.019174
       min      0.000522
      rmse      0.037618
       sse      1.175969
       std      0.027078

```

最大誤差が`34`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2023.1214.mono.cpu.ai.3wx.1000.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2023.1214.mono.cpu.ai.3wx.1000
infos:  831 poses, 11.489m path length, 28.122s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/final/mono.cpu/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/final/mono.cpu/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/final/mono.cpu/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 18.2.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。

##### 18.2.2.1 Image loadingスレッド

| 関数                                       |   割合(%) |   実測値(msec/frame) |
|:-----------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　|   100   |             9.252 |
| `　　cv::imread` 　　　　　　　　　　　　|    99.8 |             9.236 |

##### 18.2.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            91.056 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.6 |             0.56  |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB or YUYV`　　　　　　　　　　　　　　　　　　|     1.1 |             1.084 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.792 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     5.1 |             4.659 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.02  |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.017 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　|     9.9 |             9.026 |
| `　　　　cv::copyMakeBorder[0-7]`   　　　　　　　　　　　　　　　　|     0.9 |             0.893 |
| `　　　　Resize[0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     8.7 |             7.961 |
| `　　GaussianBlur[0-7]` 　　　　　　　　　　　　　　　　　　　　　　|    12.3 |            11.267 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　|    37.6 |            34.285 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.041 |
| `　　　　FAST[0-7]` 　　　　　　　　　　　　　　　　　　　　　　　　|    37.2 |            33.902 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     2.7 |             2.493 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     1.3 |             1.22  |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     3.4 |             3.176 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.005 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     3.4 |             3.17  |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0][0-7]`　　　　　　　　　　　　　　　　　　|    18.6 |            17.024 |
| `　　computeDescriptors[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.024 |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            91.056 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    69.6 |            63.442 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    28.9 |            26.36  |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     1.3 |             1.22  |

##### 18.2.2.3 Trackingスレッド

| 関数                                                                         |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            92.512 |
| `　　Sleep specified at execution` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.7 |            92.274 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`  　　　　　　　　|    47   |            43.534 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true` 　　|     0   |             0     |
| `　　　　Tracking::GrabImage*` 　　　　　　　　　　　　　　　　　　　　　　|    52.6 |            48.708 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction` |     0.8 |             0.818 |
| `　　　　　　Tracking::Track`  　　　　　　　　　　　　　　　　　　　　　　|    51.7 |            47.885 |
| `　　　　　　　　Map::mMutexMapUpdate` 　　　　　　　　　　　　　　　　　　|     2.5 |             2.387 |
| `　　　　　　　　Tracking::MonocularInitialization`　　　　　　　　　　　　|     2.9 |             2.765 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`  　　　　　　　　|     0.7 |             0.659 |
| `　　　　　　　　Tracking::TrackWithMotionModel`   　　　　　　　　　　　　|    14.7 |            13.645 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     8.2 |             7.607 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection` 　　　　　　　　|     6.1 |             5.672 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection`　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`  　　　　　　　　　　　　　　　　|    27.9 |            25.875 |
| `　　　　　　　　　　Tracking::UpdateLocalMap` 　　　　　　　　　　　　　　|     3.7 |             3.475 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     7.4 |             6.885 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`  　　　　　　　　　　　　|    16.6 |            15.363 |
| `　　　　　　　　　　　　Project points in frame and check its visibility` |    13.7 |            12.697 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`   　　　　　　　　|     2.6 |             2.493 |

##### 18.2.2.4 Inferenceスレッド

| 関数                                |   割合(%) |   実測値(msec/frame) |
|:----------------------------------|--------:|------------------:|
| `RecognizeBase::inference_thread` |   100   |            22.997 |
| `　　polling` 　　　　　　　　　　|    91.7 |            21.09  |

### 18.3 RGB-D + OpenCVAあり

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_xyz
- モード：RGB-D
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1000
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）
- DRP/DRP-AIドライバ：β版

なお、投機実行の後に`max_features`が更新され、再実行が発生した回数は、827フレーム中0回だった。

#### 18.3.2 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt CameraTrajectory.v2x.2023.1214.rgbd.opencva.ai.3wx.1000.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.101280
      mean      0.013045
    median      0.011060
       min      0.000820
      rmse      0.015806
       sse      0.206354
       std      0.008924

```

最大誤差が`10`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt CameraTrajectory.v2x.2023.1214.rgbd.opencva.ai.3wx.1000.txt --align
--------------------------------------------------------------------------------
name:   CameraTrajectory.v2x.2023.1214.rgbd.opencva.ai.3wx.1000
infos:  826 poses, 11.612m path length, 28.762s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/final/rgbd.opencva/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/final/rgbd.opencva/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/final/rgbd.opencva/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 18.3.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

##### 18.3.2.1 Image loadingスレッド

| 関数                                       |   割合(%) |   実測値(msec/frame) |
|:-----------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　|   100   |            41.055 |
| `　　cv::imread` 　　　　　　　　　　　　|    99.9 |            41.043 |

##### 18.3.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           122.236 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     1.7 |             2.146 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB or YUYV`　　　　　　　　　　　　　　　　　　|     1.4 |             1.786 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.959 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     4   |             5     |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.021 |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.018 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     7.5 |             9.253 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.2 |             5.157 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     0.3 |             0.47  |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.039 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.2 |             0.359 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    29.9 |            36.661 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     2.2 |             2.7   |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |    31.3 |            38.338 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     2.7 |             3.395 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0     |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     2.4 |             2.978 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.021 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.026 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.4 |             0.559 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0     |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.022 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.045 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.309 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     3.2 |             4.004 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.044 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.019 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           122.236 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    56.4 |            69.021 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    12.1 |            14.842 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |    31.3 |            38.338 |

##### 18.3.2.3 Trackingスレッド

| 関数                                                                         |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           123.788 |
| `　　Sleep specified at execution` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |           123.641 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`  　　　　　　　　|     1   |             1.302 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true` 　　|     0   |             0     |
| `　　　　Tracking::GrabImage*` 　　　　　　　　　　　　　　　　　　　　　　|    98.8 |           122.308 |
| `　　　　　　PlaneDetector::Process`   　　　　　　　　　　　　　　　　　　|    38.6 |            47.809 |
| `　　　　　　　　PlaneDetector::organizePointCloudByCell`  　　　　　　　　|     9.1 |            11.368 |
| `　　　　　　　　Planar cell fitting`  　　　　　　　　　　　　　　　　　　|     4.7 |             5.904 |
| `　　　　　　　　PlaneDetector::projectPointCloud` 　　　　　　　　　　　　|    21.1 |            26.177 |
| `　　　　　　　　　　X of cv::Mat::mul`　　　　　　　　　　　　　　　　　　|     2.1 |             2.634 |
| `　　　　　　　　　　Y of cv::Mat::mul`　　　　　　　　　　　　　　　　　　|     2   |             2.513 |
| `　　　　　　　　　　X of cv::divide`  　　　　　　　　　　　　　　　　　　|     1.7 |             2.21  |
| `　　　　　　　　　　Y of cv::divide`  　　　　　　　　　　　　　　　　　　|     1.9 |             2.474 |
| `　　　　　　　　　　calculate U`  　　　　　　　　　　　　　　　　　　　　|     1   |             1.325 |
| `　　　　　　　　　　calculate V`  　　　　　　　　　　　　　　　　　　　　|     1.5 |             1.874 |
| `　　　　　　　　　　set cloud_array`  　　　　　　　　　　　　　　　　　　|     9.9 |            12.311 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction` |     0.6 |             0.797 |
| `　　　　　　Tracking::Track`  　　　　　　　　　　　　　　　　　　　　　　|    59.5 |            73.693 |
| `　　　　　　　　Map::mMutexMapUpdate` 　　　　　　　　　　　　　　　　　　|     2.4 |             3.023 |
| `　　　　　　　　Tracking::MonocularInitialization`　　　　　　　　　　　　|     0   |             0.039 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`  　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackWithMotionModel`   　　　　　　　　　　　　|    12   |            14.894 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     7.6 |             9.411 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection` 　　　　　　　　|     4.2 |             5.224 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection`　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`  　　　　　　　　　　　　　　　　|    41.7 |            51.744 |
| `　　　　　　　　　　Tracking::UpdateLocalMap` 　　　　　　　　　　　　　　|     3.8 |             4.823 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|    10.7 |            13.284 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`  　　　　　　　　　　　　|    26.9 |            33.387 |
| `　　　　　　　　　　　　Project points in frame and check its visibility` |    17.2 |            21.365 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`   　　　　　　　　|     9.5 |            11.877 |

##### 18.3.2.4 Inferenceスレッド

| 関数                                |   割合(%) |   実測値(msec/frame) |
|:----------------------------------|--------:|------------------:|
| `RecognizeBase::inference_thread` |     100 |            25.658 |
| `　　polling` 　　　　　　　　　　|      92 |            23.615 |

### 18.4 RGB-D + OpenCVA無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_xyz
- モード：RGB-D
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1000
- DRP：無効
- DRP-AI：有効
- OpenCVA：無効
- DRP-AIオブジェクトファイル：RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）
- DRP/DRP-AIドライバ：β版

なお、投機実行の後に`max_features`が更新され、再実行が発生した回数は、827フレーム中0回だった。

#### 18.4.2 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt CameraTrajectory.v2x.2023.1214.rgbd.cpu.ai.3wx.1000.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.102610
      mean      0.015377
    median      0.012121
       min      0.001068
      rmse      0.018845
       sse      0.293341
       std      0.010894

```

最大誤差が`10`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt CameraTrajectory.v2x.2023.1214.rgbd.cpu.ai.3wx.1000.txt --align
--------------------------------------------------------------------------------
name:   CameraTrajectory.v2x.2023.1214.rgbd.cpu.ai.3wx.1000
infos:  826 poses, 11.816m path length, 28.762s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/final/rgbd.cpu/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/final/rgbd.cpu/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/final/rgbd.cpu/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 18.4.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。

##### 18.4.2.1 Image loadingスレッド

| 関数                                       |   割合(%) |   実測値(msec/frame) |
|:-----------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　|   100   |            48.514 |
| `　　cv::imread` 　　　　　　　　　　　　|    99.9 |            48.505 |

##### 18.4.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           120.981 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     1.3 |             1.576 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB or YUYV`　　　　　　　　　　　　　　　　　　|     1.1 |             1.405 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.979 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     3.9 |             4.784 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.021 |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.018 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　|    11.7 |            14.206 |
| `　　　　cv::copyMakeBorder[0-7]`   　　　　　　　　　　　　　　　　|     1.1 |             1.354 |
| `　　　　Resize[0-7]`   　　　　　　　　　　　　　　　　　　　　　　|    10.4 |            12.597 |
| `　　GaussianBlur[0-7]` 　　　　　　　　　　　　　　　　　　　　　　|    12.4 |            15.057 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　|    28.4 |            34.385 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　FAST[0-7]` 　　　　　　　　　　　　　　　　　　　　　　　　|    28.1 |            33.997 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     2.2 |             2.68  |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |    13.2 |            16.057 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     2.6 |             3.256 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0     |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     2.6 |             3.179 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　computeDescriptors[0][0-7]`　　　　　　　　　　　　　　　　　　|    13.9 |            16.839 |
| `　　computeDescriptors[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0     |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           120.981 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    64.8 |            78.4   |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    21.8 |            26.489 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |    13.2 |            16.057 |

##### 18.4.2.3 Trackingスレッド

| 関数                                                                         |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           122.51  |
| `　　Sleep specified at execution` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |           122.354 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`  　　　　　　　　|     1.9 |             2.444 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true` 　　|     0   |             0.001 |
| `　　　　Tracking::GrabImage*` 　　　　　　　　　　　　　　　　　　　　　　|    97.8 |           119.88  |
| `　　　　　　PlaneDetector::Process`   　　　　　　　　　　　　　　　　　　|    39.6 |            48.594 |
| `　　　　　　　　PlaneDetector::organizePointCloudByCell`  　　　　　　　　|     8.5 |            10.517 |
| `　　　　　　　　Planar cell fitting`  　　　　　　　　　　　　　　　　　　|     4.5 |             5.633 |
| `　　　　　　　　PlaneDetector::projectPointCloud` 　　　　　　　　　　　　|    23   |            28.207 |
| `　　　　　　　　　　X of cv::Mat::mul`　　　　　　　　　　　　　　　　　　|     2.3 |             2.927 |
| `　　　　　　　　　　Y of cv::Mat::mul`　　　　　　　　　　　　　　　　　　|     2.1 |             2.653 |
| `　　　　　　　　　　X of cv::divide`  　　　　　　　　　　　　　　　　　　|     1.7 |             2.205 |
| `　　　　　　　　　　Y of cv::divide`  　　　　　　　　　　　　　　　　　　|     2.3 |             2.93  |
| `　　　　　　　　　　calculate U`  　　　　　　　　　　　　　　　　　　　　|     1.2 |             1.54  |
| `　　　　　　　　　　calculate V`  　　　　　　　　　　　　　　　　　　　　|     1.8 |             2.246 |
| `　　　　　　　　　　set cloud_array`  　　　　　　　　　　　　　　　　　　|    10.4 |            12.835 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction` |     0.6 |             0.744 |
| `　　　　　　Tracking::Track`  　　　　　　　　　　　　　　　　　　　　　　|    57.5 |            70.533 |
| `　　　　　　　　Map::mMutexMapUpdate` 　　　　　　　　　　　　　　　　　　|     1.8 |             2.209 |
| `　　　　　　　　Tracking::MonocularInitialization`　　　　　　　　　　　　|     0   |             0.037 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`  　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackWithMotionModel`   　　　　　　　　　　　　|    11.2 |            13.797 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     7.1 |             8.71  |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection` 　　　　　　　　|     3.9 |             4.833 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection`　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`  　　　　　　　　　　　　　　　　|    41.3 |            50.633 |
| `　　　　　　　　　　Tracking::UpdateLocalMap` 　　　　　　　　　　　　　　|     3.6 |             4.469 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|    10.6 |            13.022 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`  　　　　　　　　　　　　|    26.8 |            32.888 |
| `　　　　　　　　　　　　Project points in frame and check its visibility` |    16.8 |            20.666 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`   　　　　　　　　|     9.8 |            12.09  |

##### 18.4.2.4 Inferenceスレッド

| 関数                                |   割合(%) |   実測値(msec/frame) |
|:----------------------------------|--------:|------------------:|
| `RecognizeBase::inference_thread` |   100   |            26.242 |
| `　　polling` 　　　　　　　　　　|    91.9 |            24.136 |

### 18.5 ELPカメラ + OpenCVAあり

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：3000
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）
- DRP/DRP-AIドライバ：β版

なお、投機実行の後に`max_features`が更新され、再実行が発生した回数は、822フレーム中1回だった。

#### 18.5.2 SLAM精度評価

実環境でELPカメラを手で持ち、動かすことで動作確認を行ったため、groundtruthは得られていない。  
なお、[Vicon](http://www.vicon.jp/)などの機材を動作確認環境に導入すればgroundtruthは取得できるが、本案件では導入していない。  
よってSLAM精度評価は行っていない。

#### 18.5.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

##### 18.5.2.1 Image loadingスレッド

| 関数                                       |   割合(%) |   実測値(msec/frame) |
|:-----------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　|   100   |            30.328 |
| `　　cv::VideoCapture::read` 　　　　　　|    97.6 |            29.606 |
| `　　cv::cvtColor`   　　　　　　　　　　|     2.3 |             0.699 |

##### 18.5.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           118.614 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.5 |             0.674 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB or YUYV`　　　　　　　　　　　　　　　　　　|     0.6 |             0.816 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.878 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     3.9 |             4.698 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.016 |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.013 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.4 |             5.222 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     3.6 |             4.363 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     0.3 |             0.409 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.032 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.1 |             0.201 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    24.9 |            29.588 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     0.4 |             0.478 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |    36.6 |            43.453 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     5.7 |             6.842 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.01  |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     5.4 |             6.448 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.009 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.045 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.028 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.4 |             0.521 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.031 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.048 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.316 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     9.4 |            11.252 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.015 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.066 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.045 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           118.614 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    40.5 |            48.125 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    22.7 |            27.002 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |    36.6 |            43.453 |

##### 18.5.2.3 Trackingスレッド

| 関数                                                                         |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           128.485 |
| `　　Sleep specified at execution` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |           128.333 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`  　　　　　　　　|     8.6 |            11.076 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true` 　　|     0   |             0     |
| `　　　　Tracking::GrabImage*` 　　　　　　　　　　　　　　　　　　　　　　|    91.2 |           117.186 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction` |     1.8 |             2.351 |
| `　　　　　　Tracking::Track`  　　　　　　　　　　　　　　　　　　　　　　|    89.3 |           114.827 |
| `　　　　　　　　Map::mMutexMapUpdate` 　　　　　　　　　　　　　　　　　　|     1.3 |             1.689 |
| `　　　　　　　　Tracking::MonocularInitialization`　　　　　　　　　　　　|    27.7 |            35.685 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`  　　　　　　　　|    16.1 |            20.793 |
| `　　　　　　　　Tracking::TrackWithMotionModel`   　　　　　　　　　　　　|    28.6 |            36.767 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|    13.3 |            17.138 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection` 　　　　　　　　|    14.9 |            19.229 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection`　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`  　　　　　　　　　　　　　　　　|    28.5 |            36.706 |
| `　　　　　　　　　　Tracking::UpdateLocalMap` 　　　　　　　　　　　　　　|     3   |             3.901 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|    15.3 |            19.658 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`  　　　　　　　　　　　　|     9.8 |            12.687 |
| `　　　　　　　　　　　　Project points in frame and check its visibility` |     6.8 |             8.749 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`   　　　　　　　　|     2.7 |             3.561 |

##### 18.5.2.4 Inferenceスレッド

| 関数                                |   割合(%) |   実測値(msec/frame) |
|:----------------------------------|--------:|------------------:|
| `RecognizeBase::inference_thread` |   100   |            22.275 |
| `　　polling` 　　　　　　　　　　|    91.5 |            20.4   |

### 18.6 ELPカメラ + OpenCVA無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：3000
- DRP：無効
- DRP-AI：有効
- OpenCVA：無効
- DRP-AIオブジェクトファイル：RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）
- DRP/DRP-AIドライバ：β版

なお、投機実行の後に`max_features`が更新され、再実行が発生した回数は、996フレーム中5回だった。

#### 18.6.2 SLAM精度評価

実環境でELPカメラを手で持ち、動かすことで動作確認を行ったため、groundtruthは得られていない。  
なお、[Vicon](http://www.vicon.jp/)などの機材を動作確認環境に導入すればgroundtruthは取得できるが、本案件では導入していない。  
よってSLAM精度評価は行っていない。

#### 18.6.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。

##### 18.6.2.1 Image loadingスレッド

| 関数                                       |   割合(%) |   実測値(msec/frame) |
|:-----------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　|   100   |             2.437 |
| `　　cv::VideoCapture::read` 　　　　　　|    71.4 |             1.742 |
| `　　cv::cvtColor`   　　　　　　　　　　|    27.5 |             0.672 |

##### 18.6.2.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                      |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           124.343 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.4 |             0.507 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB or YUYV`　　　　　　　　　　　　　　　　　　|     0.7 |             0.966 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.866 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     3.6 |             4.593 |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.015 |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.012 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　|     6.9 |             8.695 |
| `　　　　cv::copyMakeBorder[0-7]`   　　　　　　　　　　　　　　　　|     0.6 |             0.822 |
| `　　　　Resize[0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     6.1 |             7.682 |
| `　　GaussianBlur[0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     8.7 |            10.891 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　|    23.1 |            28.748 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.034 |
| `　　　　FAST[0-7]` 　　　　　　　　　　　　　　　　　　　　　　　　|    22.8 |            28.46  |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     0.3 |             0.385 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     6.2 |             7.806 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     5.1 |             6.349 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.033 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     5.4 |             6.744 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.034 |
| `　　computeDescriptors[0][0-7]`　　　　　　　　　　　　　　　　　　|    36.5 |            45.424 |
| `　　computeDescriptors[1][0-7]`　　　　　　　　　　　　　　　　　　|     0.1 |             0.238 |

`max_features`の受け取りの前後の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           124.343 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    45.8 |            56.958 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    47.8 |            59.546 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     6.2 |             7.806 |

##### 18.6.2.3 Trackingスレッド

| 関数                                                                         |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           126.67  |
| `　　Sleep specified at execution` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |           126.526 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`  　　　　　　　　|    21.1 |            26.729 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true` 　　|     0   |             0     |
| `　　　　Tracking::GrabImage*` 　　　　　　　　　　　　　　　　　　　　　　|    78.5 |            99.52  |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction` |     2.1 |             2.774 |
| `　　　　　　Tracking::Track`  　　　　　　　　　　　　　　　　　　　　　　|    76.3 |            96.736 |
| `　　　　　　　　Map::mMutexMapUpdate` 　　　　　　　　　　　　　　　　　　|     0   |             0.02  |
| `　　　　　　　　Tracking::MonocularInitialization`　　　　　　　　　　　　|    37.6 |            47.671 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`  　　　　　　　　|    20.8 |            26.462 |
| `　　　　　　　　Tracking::TrackWithMotionModel`   　　　　　　　　　　　　|    18.5 |            23.464 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     7.2 |             9.246 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection` 　　　　　　　　|    11   |            13.982 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection`　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`  　　　　　　　　　　　　　　　　|    17.9 |            22.7   |
| `　　　　　　　　　　Tracking::UpdateLocalMap` 　　　　　　　　　　　　　　|     0.9 |             1.233 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     8.9 |            11.308 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`  　　　　　　　　　　　　|     7.8 |             9.914 |
| `　　　　　　　　　　　　Project points in frame and check its visibility` |     5.2 |             6.591 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`   　　　　　　　　|     2.5 |             3.188 |

##### 18.6.2.4 Inferenceスレッド

| 関数                                |   割合(%) |   実測値(msec/frame) |
|:----------------------------------|--------:|------------------:|
| `RecognizeBase::inference_thread` |   100   |            22.561 |
| `　　polling` 　　　　　　　　　　|    91.3 |            20.612 |

## 19 今後の懸念

今後の懸念について記載する。

### 19.1 屋外環境での利用について

Yolo-Planar-SLAMのユーザーから以下のコメントがあった。

> ```markdown
> 屋外の動画を撮ってSLAMを実行してみましたが、Initializeが完了しません。
> ```

同じく以下のコメントもあった。

> ```markdown
> 屋外の明るい場所での入力画像が白飛びしてしまう問題がある
> ```

そこで、ダイナミックレンジが大きいELPカメラを購入して、比較実験を行った。  
評価結果を記載する。

現行のELPカメラのスペックは以下の通り。

- 型番：ELP-USBGS720P02-L36
- センサー：AR0144
- ダイナミックレンジ：63.9dB
- レンズ：3.6mmレンズ

今回比較のために用意したELPカメラのスペックは以下の通り。

- 型番：ELP-USBGS800P03-L36
- センサー：OV9281
- ダイナミックレンジ：70db
- レンズ：3.6mmレンズ

現行のELPカメラで、`1280x720`の画像をキャプチャした結果は以下の通り。

![現行のELPカメラ（1280x720）](image/elp/32e4_0144-1280x720.png)

今回比較のために用意したELPカメラで、`1280x720`の画像をキャプチャした結果は以下の通り。

![新しいELPカメラ（1280x720）](image/elp/32e4_9281-1280x720.png)

明るい環境での白飛びを一定程度解消できていることがわかる。

現行のELPカメラで、`640x480`の画像をキャプチャした結果は以下の通り。

![現行のELPカメラ（640x480）](image/elp/32e4_0144-640x480.png)

今回比較のために用意したELPカメラで、`640x480`の画像をキャプチャした結果は以下の通り。

![新しいELPカメラ（640x480）](image/elp/32e4_9281-640x480.png)

今回比較のために用意したELPカメラでは、`640x480`の場合には視野が狭くなっていることがわかる。  
`1280x720`の画像の中央部分をクロップしていると考えられる。

現行のELPカメラは屋内環境を前提として調達したものであり、屋外環境でも必ずしも最適なUSBカメラとは言えない。  
ただし上記の調査の結果、屋外環境を想定したUSBカメラの選定・変更を行えば、屋外環境でも十分な精度でSLAMを実行できる可能性があることがわかった。

今後本案件のYolo-Planar-SLAMを屋外環境で利用する場合には、USBカメラの選定・変更が必要となる可能性がある。

### 19.2 β版とバージョン1の間の互換性について

V2xボードの開発者から、バージョン1のBSPファイルにはβ版との間で互換性のない変更が含まれていると回答があった。  
また、この点については互換性を維持する手段が無いのかを確認すると回答があった。  
互換性を維持する方法が無かった場合は、Yolo-Planar-SLAMなどのアプリケーション側でDRP/DRP-AI/OpenCVAとの連携処理に変更が必要となる可能性がある。

### 19.3 コヒーレンシについて

`7.2 コヒーレンシについて`に記載した通り、V2xボード（α2、EVK-α、電力改善版）でハードウェアとしてCPU（のキャッシュ）とメインメモリ（のDMAバッファ）の間のコヒーレンシが保証されている場合には、`O_SYNC`フラグを指定せずに`/dev/udmabuf0`を`open`した方が、処理時間の観点では有利だと想定される。  
ただし、V2xボード（α2、EVK-α、電力改善版）の仕様として`dma-coherent`であることが将来的には保証されているのかについては、2023年12月時点では回答を得られていない。
