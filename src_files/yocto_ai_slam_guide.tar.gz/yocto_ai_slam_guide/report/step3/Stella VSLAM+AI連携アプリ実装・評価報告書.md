# Stella VSLAM+AI連携アプリ 実装・評価報告書

株式会社Fixstars Autonomous Technologies  
v1.0, 2024-05-31

## 1 はじめに

本書は案件「DRP-AIアプリ（AI+SLAM連携）の最適化コーディング」におけるStella VSLAM+AI連携アプリ 実装・評価報告書である。  
本書ではYolo-Planar-SLAMとstella_vslamに関する作業について、下記の点を記載する。

- 評価環境
- stella_vslamの高速化試行
- 正式版のDRP-AI TVMのYOLOX-Sのサンプルプログラムの動作確認
- stella_vslamのDRP-AI TVMのYOLOX-Sの正式版への変更
- stella_vslamの画像読み込みのスレッド分割
- stella_vslamの画像処理のスレッド分割
- stella_vslamのDRP-AI TVMのスレッド分割
- stella_vslamのマルチスレッド対応後の評価
- Yolo-Planar-SLAMのDRP-AI TVMのYOLOX-Sの正式版への変更
- 直列動作検証
- 画像入力のワークアラウンド
- 高速化の実現可能性
- 今後の懸念

## 2 評価環境

本章では、本案件で使用した評価環境（ハードウェア、ソフトウェア）の情報を記載する。

### 2.1 ハードウェア

#### 2.1.1 Intel CPU搭載PC

- CPU：Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz
    - 物理コア数：6
    - コアあたりのスレッド数：2
- メモリ：48GB

#### 2.1.2 V2xボード（α2、EVK-α、電力改善版）

- CPU：Cortex-A55 @ 1.7GHz
    - 物理コア数：4
    - コアあたりのスレッド数：1
- メモリ：16GB
- S/N number：33001049

### 2.2 ソフトウェア

#### 2.2.1 Intel CPU搭載PC

- OS：Ubuntu 18.04 64bit
- Musketeer：Ver.20230724
- CVC：7.00b(open_src_cvc_700c_tar.bz2)

#### 2.2.2 V2xボード（α2、EVK-α、電力改善版）

- OS：CIP Linux
- gcc：8.3.0
- OpenCV：4.1.0
- PCL：1.9.1
- Eigen：3.3.7
- flann：1.9.1
- Boost：1.72.0
- socket.io-client-cpp：1.6.0
- g2o：20230223
- Node.js：12.22.12
- socket.io：2.0.4
- express：4.16.2
- ejs：2.5.7
- yaml-cpp：0.8.0
- suitesparse-config：5.4.0
- suitesparse-cxsparse：5.4.0
- socket_publisher：0.0.1
- socket_viewer：[e1e14ee](https://github.com/stella-cv/socket_viewer/tree/e1e14eec215f5022c84185781ba8d81de22a6f40)

### 2.3 評価データ

Yolo-Planar-SLAMの評価については、RGB画像とDepth画像を含み、ORB-SLAM2およびYolo-Planar-SLAMが対応している形式である[TUM Dataset](https://vision.in.tum.de/data/datasets/rgbd-dataset/download)の`fr3/walking_xyz`を使用する。  
以降では`rgbd_dataset_freiburg3_walking_xyz`と記載する。  
また、このデータセットの画像をグレースケールに変換したデータセットである`GRAY_rgbd_dataset_freiburg3_walking_xyz`を受領した。  
合わせて使用する。

stella_vslamの単眼モードとRGB-Dモードの評価については、RGB画像とDepth画像を含み、stella_vslamが対応している形式である[TUM Dataset](https://vision.in.tum.de/data/datasets/rgbd-dataset/download)の`fr3/walking_halfsphere`を使用する。  
以降では`rgbd_dataset_freiburg3_walking_halfsphere`と記載する。

stella_vslamのステレオモードの評価については、左右のカメラ画像を含み、stella_vslamが対応している形式である[The EuRoC MAV Dataset](https://projects.asl.ethz.ch/datasets/doku.php?id=kmavvisualinertialdatasets)の`vicon_room1/V1_01_easy`を使用する。  
以降では`V1_01_easy`と記載する。

## 3 stella_vslamの高速化試行

stella_vslamの高速化試行について記載する。

まず、compute_orb_descriptorsのDRP実装の反復合成を行った。

受領した`opt.top`に記述されている80通りのオプションについて、「遅延・面積両立」と「面数最小」のそれぞれで反復合成を行った。  
最も高速であったオプションは「遅延・面積両立」かつ`rap -yplace_opt --disperse_level=20`であり、処理時間は`205.785000`\[us\]であった。

次に、compute_orb_descriptorsのDRP実装を、FP32からFP16に変更した場合のSLAM精度と処理時間への影響を確認した。  
合わせて、GaussianBlurとSLAM組み込み用のFASTのコンフィギュレーションコードも[Stella VSLAM+AI連携アプリ 実装・評価報告書の17.3 反復合成](../step2/Stella%20VSLAM+AI連携アプリ実装・評価報告書.md#173-反復合成)で高速化したものに変更し、処理時間への影響を確認した。

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2428
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：無効
- FASTのDRP実装：SLAM組みこみ用のFAST
- compute_orb_descriptorsのDRP実装：**FP16**
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-bsp`

### 3.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.0318_2.mono.slamfast.none.3wh.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.271080
      mean      0.057924
    median      0.042894
       min      0.003869
      rmse      0.072061
       sse      5.514703
       std      0.042867

```

最大誤差が`27`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.0318_2.mono.slamfast.none.3wh.txt \
>   --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0318_2.mono.slamfast.none.3wh
infos:  1062 poses, 18.096m path length, 35.728s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/acc/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/acc/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/acc/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

### 3.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

| 関数                                                                               |         割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　| 100           |      93.968       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|  19.3         |      18.188       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|  80.6         |      75.745       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|   1.1         |       1.041       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|   0.6         |       0.626       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|   0.3         |       0.284       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|   0.8         |       0.786       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|  36.7         |      34.509       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|   3.3         |       3.13        |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|   3.3         |       3.115       |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|   0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|   0           |       0.023       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0.4         |       0.405       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.041       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0.2         |       0.274       |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|   1.9         |       1.834       |
| `　　　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|   0.2         |       0.236       |
| `　　　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　|   0.2         |       0.258       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.4         |       -----       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|  20.4         |      19.188       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|   8.4         |       7.975       |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|   0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|   0           |       0.029       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0.5         |       0.517       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.056       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0.3         |       0.316       |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|   6.2         |       5.844       |
| `　　　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　　　|   0           |       0.037       |
| `　　　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　　　|   0           |       0.048       |
| `　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　　　|   1.1         |       1.047       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|   6.1         |       5.799       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|   5.6         |       5.284       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|   6.3         |       5.939       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|   0           |       0.001       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0           |       0.027       |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|   0.4         |       0.449       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.048       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       0.315       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|   5           |       4.711       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0.3         |       0.341       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|   5.9         |       5.619       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|   0           |       0.001       |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　|   0           |       0.038       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0           |       0.027       |
| `　　　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|   0.4         |       0.452       |
| `　　　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　|   0           |       0.03        |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.028       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       0.304       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|   4.9         |       4.637       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0           |       0.061       |
| `　　　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.8         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|   0.8         |       0.77        |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|  37.8         |      35.522       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|   0.2         |       0.229       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|   0.3         |       0.34        |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|  34.9         |      32.85        |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|  10.5         |       9.898       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|  10.5         |       9.874       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|   5.1         |       4.849       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|   5.2         |       4.922       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|   0           |       0.003       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|  22.8         |      21.442       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|   7.1         |       6.726       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|   0           |       0.072       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   7.1         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|   7.9         |       7.432       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |   0.2         |       0.206       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |   2.4         |       2.297       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|   4.8         |       4.535       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.5         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|   7.7         |       7.28        |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|   7.4         |       6.963       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|   0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|   0           |       0.004       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   1.6         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   2.4         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   2.5         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |

### 3.3 考察

[高速化試行前の評価結果](../step2/Stella%20VSLAM+AI連携アプリ実装・評価報告書.md#154122-ボトルネック解析)と比較した。

`Main loop`の平均処理時間は以下の通り。

- 変更前：`104.577`\[ms/frame\]
- 変更後：`93.968`\[ms/frame\]

`orb_extractor::extract`の平均処理時間は以下の通り。

- 変更前：`43.188`\[ms/frame\]
- 変更後：`34.509`\[ms/frame\]

`GaussianBlur`の`DRP time`の平均処理時間は以下の通り。

- 変更前：`4.708`\[ms/frame\]
- 変更後：`4.711`\[ms/frame\]

`orb_extractor::compute_fast_keypoints`の`DRP time`の平均処理時間は以下の通り。

- 変更前：`7.453`\[ms/frame\]
- 変更後：`5.844`\[ms/frame\]

`compute_orb_descriptors`の`DRP time`の平均処理時間は以下の通り。

- 変更前：`11.705`\[ms/frame\]
- 変更後：`4.637`\[ms/frame\]

以上から、以下のことがいえる。

- GaussianBlurは、反復合成によって有意な高速化の効果は得られなかった
- SLAM組み込み用のFASTは、反復合成によって約`1.27`倍だけ高速化された
- compute_orb_descriptorsは、FP16への変更と反復合成によって約`2.52`倍だけ高速化された
- compute_orb_descriptorsのDRP実装の内部処理を、FP32からFP16に変更しても、SLAM精度は破綻していない

## 4 正式版のDRP-AI TVMのYOLOX-Sのサンプルプログラムの動作確認

受領したサンプルプログラム（`app_yolox-S_bgr640x640`）に含まれている`libtvm_runtime.so`の確認を行った。

2024年3月まで使用していた`libtvm_runtime.so`と、`app_yolox-S_bgr640x640`に含まれている`libtvm_runtime.so`の間で、依存関係には差分がある。

2024年1月時点の`libtvm_runtime.so`の依存関係は以下の通り。

```shell
root@rzv2h-evk-alpha:~/v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119/tvm/build_runtime# /lib64/ld-linux-aarch64.so.1 --list ./libtvm_runtime.so
        linux-vdso.so.1 (0x0000ffffa3563000)
        libdl.so.2 => /lib64/libdl.so.2 (0x0000ffffa331a000)
        libstdc++.so.6 => /usr/lib64/libstdc++.so.6 (0x0000ffffa318a000)
        libm.so.6 => /lib64/libm.so.6 (0x0000ffffa30cc000)
        libgcc_s.so.1 => /lib64/libgcc_s.so.1 (0x0000ffffa30a7000)
        libpthread.so.0 => /lib64/libpthread.so.0 (0x0000ffffa3078000)
        libc.so.6 => /lib64/libc.so.6 (0x0000ffffa2f0a000)
        /lib64/ld-linux-aarch64.so.1 (0x0000ffffa3535000)
```

`app_yolox-S_bgr640x640`に含まれている`libtvm_runtime.so`の依存関係は以下の通り。

```shell
root@rzv2h-evk-alpha:~/app_yolox-S_bgr640x640# /lib64/ld-linux-aarch64.so.1 --list ./libtvm_runtime.so
        linux-vdso.so.1 (0x0000ffff86a83000)
        libdl.so.2 => /lib64/libdl.so.2 (0x0000ffff86837000)
        libmmngr.so.1 => /usr/lib64/libmmngr.so.1 (0x0000ffff86824000)
        libmmngrbuf.so.1 => /usr/lib64/libmmngrbuf.so.1 (0x0000ffff86811000)
        libstdc++.so.6 => /usr/lib64/libstdc++.so.6 (0x0000ffff86681000)
        libm.so.6 => /lib64/libm.so.6 (0x0000ffff865c3000)
        libgcc_s.so.1 => /lib64/libgcc_s.so.1 (0x0000ffff8659e000)
        libpthread.so.0 => /lib64/libpthread.so.0 (0x0000ffff8656f000)
        libc.so.6 => /lib64/libc.so.6 (0x0000ffff86401000)
        /lib64/ld-linux-aarch64.so.1 (0x0000ffff86a55000)
```

`libmmngr.so.1`と`libmmngrbuf.so.1`への依存が増えていることがわかる。

本案件のメタパッケージ`meta-stella-vslam`では、MMNGRのうち、過去に受領したDRP-AI TVMのYOLOX-Sのサンプルプログラム（`v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119`）をビルドするために必要であったパッケージを`core-image-*`に追加している。

`meta-stella-vslam/recipes-core/images/core-image-%.bbappend`

```plaintxt
IMAGE_INSTALL_append = " mmngr-user-module mmngrbuf-user-module"
```

そのため、`core-image-bsp`の場合でもMMNGRへの依存関係は解決できている。

この状態で、今回受領したサンプルプログラム（`app_yolox-S_bgr640x640`）の簡易的な動作確認を行った。  
まず、`core-image-weston`ではなく`core-image-bsp`のLinuxイメージで実行した。  
実行結果は以下の通り。

```shell
root@rzv2h-evk-alpha:~# export LD_LIBRARY_PATH=~/app_yolox-S_bgr640x640:$LD_LIBRARY_PATH
root@rzv2h-evk-alpha:~# cd ~/app_yolox-S_bgr640x640
root@rzv2h-evk-alpha:~/app_yolox-S_bgr640x640# /lib64/ld-linux-aarch64.so.1 --list ./libtvm_runtime.so
        linux-vdso.so.1 (0x0000ffff86a83000)
        libdl.so.2 => /lib64/libdl.so.2 (0x0000ffff86837000)
        libmmngr.so.1 => /usr/lib64/libmmngr.so.1 (0x0000ffff86824000)
        libmmngrbuf.so.1 => /usr/lib64/libmmngrbuf.so.1 (0x0000ffff86811000)
        libstdc++.so.6 => /usr/lib64/libstdc++.so.6 (0x0000ffff86681000)
        libm.so.6 => /lib64/libm.so.6 (0x0000ffff865c3000)
        libgcc_s.so.1 => /lib64/libgcc_s.so.1 (0x0000ffff8659e000)
        libpthread.so.0 => /lib64/libpthread.so.0 (0x0000ffff8656f000)
        libc.so.6 => /lib64/libc.so.6 (0x0000ffff86401000)
        /lib64/ld-linux-aarch64.so.1 (0x0000ffff86a55000)
root@rzv2h-evk-alpha:~/app_yolox-S_bgr640x640# ./sample_app_drpai_tvm_usbcam_yolox
RZ/V2H DRP-AI Sample Application
Model : Megvii-Base Detection YOLOX | yolox_cam
Input : USB Camera
Argument : <DRP0_max_freq_factor> = 2
Argument : <AI-MAC_freq_factor> = 2
[06:47:49] /drp-ai_tvm/apps/MeraDrpRuntimeWrapper.cpp:73: Loading json data...
[06:47:49] /drp-ai_tvm/apps/MeraDrpRuntimeWrapper.cpp:91: Loading runtime module...
MMI open: No such file or directory
terminate called after throwing an instance of 'tvm::runtime::InternalError'
  what():  [06:47:49] /root/drp-tvm-share/src/runtime/drpai_device_api.cc:70: MMNGR allocated failed
Stack trace:
  [bt] (0) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::Backtrace[abi:cxx11]()+0x10) [0xffffa6f76aa0]
  [bt] (1) ./sample_app_drpai_tvm_usbcam_yolox(tvm::runtime::detail::LogFatal::Entry::Finalize()+0x70) [0xaaaad9c78da0]
  [bt] (2) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::MmngrWrapper::Allocate(unsigned long)+0x4b0) [0xffffa6f64488]
  [bt] (3) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::DrpAiDeviceAPI::AllocDataSpace(DLDevice, unsigned long, unsigned long, DLDataType)+0x28) [0xffffa6f64728]
  [bt] (4) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::DeviceAPI::AllocDataSpace(DLDevice, int, long const*, DLDataType, tvm::runtime::Optional<tvm::runtime::String>)+0x1b0) [0xffffa6f42800]
  [bt] (5) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::NDArray::Empty(tvm::runtime::ShapeTuple, DLDataType, DLDevice, tvm::runtime::Optional<tvm::runtime::String>)+0x178) [0xffffa6f879a0]
  [bt] (6) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::GraphExecutor::SetupStorage()+0xd44) [0xffffa701dc5c]
  [bt] (7) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::GraphExecutor::Init(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, tvm::runtime::Module, std::vector<DLDevice, std::allocator<DLDevice> > const&, tvm::runtime::PackedFunc)+0x1d4) [0xffffa701f39c]
  [bt] (8) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::GraphExecutorDebugCreate(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, tvm::runtime::Module const&, std::vector<DLDevice, std::allocator<DLDevice> > const&, tvm::runtime::PackedFunc)+0x114) [0xffffa703086c]


Aborted
```

正常に動作していないことがわかる。  
`core-image-weston`ではなく`core-image-bsp`のLinuxイメージで実行しているため、ディスプレイ出力に関するエラーが出る可能性があった。  
しかし、上記はディスプレイ出力に関するエラーではないように見える。

同様に、`core-image-weston`上で動作確認を行った。

```shell
root@rzv2h-evk-alpha:~# export LD_LIBRARY_PATH=~/app_yolox-S_bgr640x640:$LD_LIBRARY_PATH
root@rzv2h-evk-alpha:~# cd ~/app_yolox-S_bgr640x640
root@rzv2h-evk-alpha:~/app_yolox-S_bgr640x640# /lib64/ld-linux-aarch64.so.1 --list ./libtvm_runtime.so
        linux-vdso.so.1 (0x0000ffffb3a84000)
        libdl.so.2 => /lib64/libdl.so.2 (0x0000ffffb3838000)
        libmmngr.so.1 => /usr/lib64/libmmngr.so.1 (0x0000ffffb3825000)
        libmmngrbuf.so.1 => /usr/lib64/libmmngrbuf.so.1 (0x0000ffffb3812000)
        libstdc++.so.6 => /usr/lib64/libstdc++.so.6 (0x0000ffffb3682000)
        libm.so.6 => /lib64/libm.so.6 (0x0000ffffb35c4000)
        libgcc_s.so.1 => /lib64/libgcc_s.so.1 (0x0000ffffb359f000)
        libpthread.so.0 => /lib64/libpthread.so.0 (0x0000ffffb3570000)
        libc.so.6 => /lib64/libc.so.6 (0x0000ffffb3402000)
        /lib64/ld-linux-aarch64.so.1 (0x0000ffffb3a56000)
root@rzv2h-evk-alpha:~/app_yolox-S_bgr640x640# ./sample_app_drpai_tvm_usbcam_yolox
RZ/V2H DRP-AI Sample Application
Model : Megvii-Base Detection YOLOX | yolox_cam
Input : USB Camera
Argument : <DRP0_max_freq_factor> = 2
Argument : <AI-MAC_freq_factor> = 2
[07:47:49] /drp-ai_tvm/apps/MeraDrpRuntimeWrapper.cpp:73: Loading json data...
[07:47:49] /drp-ai_tvm/apps/MeraDrpRuntimeWrapper.cpp:91: Loading runtime module...
[07:47:49] /drp-ai_tvm/apps/MeraDrpRuntimeWrapper.cpp:96: Loading parameters...
[INFO] USB Camera: /dev/video0
Key Hit Thread Starting
************************************************
* Press ENTER key to quit. *
************************************************
Inference Thread Starting
Inference Loop Starting
Capture Thread Starting
Image Thread Starting
Main Loop Starts
Display Thread Starting
YUYV -> BGR
resize 1920x1920 -> 640x640
[TIME] PreRuntime DRP-AI processing time : 3.61 msec
[TIME] GetResult() Processing Time : 5.11 msec
[07:47:51] /drp-ai_tvm/apps/MeraDrpRuntimeWrapper.cpp:112: Loading input...
[ 1284.652705] (mali-cmar-backe) NOTE: The GFX library has the time limitation by reason of an evaluation module.
YUYV -> BGR
resize 1920x1920 -> 640x640
[TIME] PreRuntime DRP-AI processing time : 3.61 msec
[TIME] GetResult() Processing Time : 1.93 msec
[07:47:51] /drp-ai_tvm/apps/MeraDrpRuntimeWrapper.cpp:112: Loading input...
YUYV -> BGR
```

エラーなく動作していることがわかる。

以上から、`app_yolox-S_bgr640x640`に含まれている`libtvm_runtime.so`には本来不要であるはずの依存関係が含まれてしまっている可能性がある。

## 5 stella_vslamのDRP-AI TVMのYOLOX-Sの正式版への変更

正式版のDRP-AI TVMのYOLOX-Sを、stella_vslamで使用できるようにするための変更を行った。

暫定版のDRP-AI TVMのYOLOX-Sのための実装`stella_vslam/src/stella_vslam/drp_ai/yoloxs_provisional`をベースに、正式版のための実装を作成した。  
主な変更点は以下の通り。

1. 入力画像のサイズの差異に伴う変更
    - `1920x1920` → `640x640`
2. 入力画像のカラーフォーマットの差異に伴う変更
    - YUYV → BGR
3. メモリアドレスマップ（`yolox_cam/preprocess/addr_map.txt`）の差異に伴う、入力画像を配置するメモリアドレス空間の変更
    - `0x2_5E00_0000` → `0x2_5F00_0000`
4. 入力画像のサイズと、出力バウンディングボックスの座標系のスケールの不整合を補正するための変更
    - 暫定版では、入力画像と出力バウンディングボックスのスケールはともに`1920x1920`
    - 正式版では、入力画像のスケールは`640x640`、出力バウンディングボックスのスケールは`1920x1920`であるため、出力の座標値に対して1/3縮小が別途必要

上記の変更を行った上で、`yolox_cam`を暫定版から正式版に変更して動作確認を行った。  
また、stella_vslamのビルド時と実行時にリンクされる`libtvm_runtime.so`は`app_yolox-S_bgr640x640`に含まれていたものに変更した。  
なお、`正式版のDRP-AI TVMのYOLOX-Sのサンプルプログラムの動作確認`に記載した不具合を回避するために`core-image-weston`上で確認した点に注意する。

![SocketViewerの描画結果](image/stella_vslam/yoloxs/socket_viewer.png)

正常にバウンディングボックスを検出できていることがわかる。

次に、サンプルプログラムと同様に`core-image-bsp`上で正常に動作するのかを確認した。

```shell
[2024-04-03 06:03:31.874] [D] Loading json data...
[2024-04-03 06:03:31.874] [D] Loading runtime module...
MMI open: No such file or directory
terminate called after throwing an instance of 'tvm::runtime::InternalError'
  what():  [06:03:32] /root/drp-tvm-share/src/runtime/drpai_device_api.cc:70: MMNGR allocated failed
Stack trace:
  [bt] (0) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::Backtrace[abi:cxx11]()+0x10) [0xffffac33caa0]
  [bt] (1) /home/root/local/lib/libstella_vslam.so(tvm::runtime::detail::LogFatal::Entry::Finalize()+0x84) [0xffffad422aa4]
  [bt] (2) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::MmngrWrapper::Allocate(unsigned long)+0x4b0) [0xffffac32a488]
  [bt] (3) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::DrpAiDeviceAPI::AllocDataSpace(DLDevice, unsigned long, unsigned long, DLDataType)+0x28) [0xffffac32a728]
  [bt] (4) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::DeviceAPI::AllocDataSpace(DLDevice, int, long const*, DLDataType, tvm::runtime::Optional<tvm::runtime::String>)+0x1b0) [0xffffac308800]
  [bt] (5) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::NDArray::Empty(tvm::runtime::ShapeTuple, DLDataType, DLDevice, tvm::runtime::Optional<tvm::runtime::String>)+0x178) [0xffffac34d9a0]
  [bt] (6) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::GraphExecutor::SetupStorage()+0xd44) [0xffffac3e3c5c]
  [bt] (7) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::GraphExecutor::Init(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, tvm::runtime::Module, std::vector<DLDevice, std::allocator<DLDevice> > const&, tvm::runtime::PackedFunc)+0x1d4) [0xffffac3e539c]
  [bt] (8) /home/root/app_yolox-S_bgr640x640/libtvm_runtime.so(tvm::runtime::GraphExecutorDebugCreate(std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&, tvm::runtime::Module const&, std::vector<DLDevice, std::allocator<DLDevice> > const&, tvm::runtime::PackedFunc)+0x114) [0xffffac3f686c]


Aborted
```

サンプルプログラムと同様に`Aborted`でエラーとなった。

最後に`core-image-weston`に環境を戻し、評価を行った。

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2428
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：**有効**
- FASTのDRP実装：SLAM組みこみ用のFAST
- compute_orb_descriptorsのDRP実装：FP32
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

### 5.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.04.mono.slamfast.ai.3wh.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.269818
      mean      0.031677
    median      0.023521
       min      0.002156
      rmse      0.043179
       sse      1.981871
       std      0.029342
```

最大誤差が`26`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.04.mono.slamfast.ai.3wh.txt \
>   --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.04.mono.slamfast.ai.3wh
infos:  1063 poses, 17.334m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/yoloxs/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/yoloxs/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/yoloxs/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

### 5.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           141.883 |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    15.2 |            21.566 |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    84.7 |           120.302 |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.871 |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|     0.4 |             0.628 |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|     0.2 |             0.286 |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|     0.5 |             0.802 |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|    54.3 |            77.182 |
| `　　　　　　yolo_detector::start[LEFT]` 　　　　　　　　　　　　　　　　　　　　|    21.9 |            31.163 |
| `　　　　　　　　convert to RGB or YUYV[LEFT]`   　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　bottom padding[LEFT]`   　　　　　　　　　　　　　　　　　　　　|     0.5 |             0.748 |
| `　　　　　　　　copy input to physical memory[LEFT]`　　　　　　　　　　　　　　|     0.3 |             0.476 |
| `　　　　　　　　PreRuntime::Pre[LEFT]`  　　　　　　　　　　　　　　　　　　　　|     3.6 |             5.218 |
| `　　　　　　　　MeraDrpRuntimeWrapper::SetInput[LEFT]`  　　　　　　　　　　　　|     5.8 |             8.271 |
| `　　　　　　　　MeraDrpRuntimeWrapper::Run[LEFT]`   　　　　　　　　　　　　　　|    11.5 |            16.387 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|     2.2 |             3.222 |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|     2.2 |             3.207 |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|     0   |             0.024 |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0.3 |             0.454 |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.038 |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.274 |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|     1.2 |             1.835 |
| `　　　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|     0.1 |             0.249 |
| `　　　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　|     0.1 |             0.282 |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|    16.5 |            23.48  |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|     6.8 |             9.652 |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|     0   |             0.002 |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|     0   |             0.028 |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0.3 |             0.555 |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.058 |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.315 |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|     5.2 |             7.454 |
| `　　　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　　　|     0   |             0.037 |
| `　　　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　　　|     0   |             0.048 |
| `　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　　　|     0.7 |             1.071 |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|     4.2 |             6.051 |
| `　　　　　　　　yolo_detector::finish[LEFT]`　　　　　　　　　　　　　　　　　　|     1.6 |             2.27  |
| `　　　　　　　　　　Receive result[LEFT]`   　　　　　　　　　　　　　　　　　　|     1.5 |             2.262 |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|     3.7 |             5.322 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|     4.1 |             5.905 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.028 |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     0.3 |             0.459 |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.051 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.316 |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|     3.2 |             4.653 |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.347 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     8.9 |            12.717 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　|     0   |             0.039 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.027 |
| `　　　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|     0.3 |             0.486 |
| `　　　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　|     0   |             0.03  |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.03  |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.305 |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|     8.2 |            11.689 |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0   |             0.065 |
| `　　　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             ----- |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             0.837 |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|    26   |            36.936 |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.201 |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|     0.2 |             0.4   |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|    24   |            34.125 |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|     7.4 |            10.609 |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|     7.4 |            10.579 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|     3.5 |             5.103 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     3.7 |             5.365 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|     0   |             0.004 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|    15.6 |            22.199 |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|     4.9 |             6.98  |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|     0   |             0.075 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     4.9 |             ----- |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|     5.2 |             7.455 |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |     0.1 |             0.223 |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |     1.6 |             2.288 |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|     3.2 |             4.54  |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|     5.4 |             7.758 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     5.2 |             7.422 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|     0   |             0.004 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1   |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.7 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2.2 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

### 5.3 考察

[DRP-AI無しで計測した結果](../step2/Stella%20VSLAM+AI連携アプリ実装・評価報告書.md#154122-ボトルネック解析)と比較した。

DRPドライバネイティブで動作する4アルゴリズムの平均処理時間には、有意な差は無かった。

`Main loop`の平均処理時間は以下の通り。

- 暫定版：`104.577`\[ms/frame\]
- 正式版：`141.883`\[ms/frame\]

`orb_extractor::extract`の平均処理時間は以下の通り。

- 暫定版：`43.188`\[ms/frame\]
- 正式版：`77.182`\[ms/frame\]

`tracking_module::feed_frame`の平均処理時間は以下の通り。

- 暫定版：`37.742`\[ms/frame\]
- 正式版：`36.936`\[ms/frame\]

以上から、正式版のDRP-AI TVMのYOLOX-Sを使用することによって、Trackingスレッドの平均処理時間が約`37`\[ms/frame\]増加したことがわかる。  
ただし`orb_extractor::extract`の増分は約`33`\[ms/frame\]であるため、オーバーヘッドによる増分が約`4`\[ms/frame\]存在すると考えられる。

次に、DRP-AIの平均処理時間に着目する。

`yolo_detector::start[LEFT]`の平均処理時間は以下の通り。

- 正式版：`31.163`\[ms/frame\]

`yolo_detector::finish[LEFT]`の平均処理時間は以下の通り。

- 正式版：`2.27`\[ms/frame\]

`31.163 + 2.27 = 33.433`であるため、`orb_extractor::extract`の増分が約`33`\[ms/frame\]であることと整合する。

## 6 stella_vslamの画像読み込みのスレッド分割

stella_vslamの画像読み込みのスレッド分割を行った。

まず、中間データのダンプ結果の確認を行った。  
以下の2項目の組み合わせである計12パターンについて、DRP-AIを有効にしたときの、画像読み込みのスレッド分割前のダンプ結果と、画像読み込みのスレッド分割後のダンプ結果が0番と1番のフレームについて厳密に一致することを確認できた。

1. 単眼、ステレオ、RGB-Dの3モード
2. OpenCVA、DRPドライバネイティブ（CVアセット用のFAST）、DRPドライバネイティブ（SLAM組み込み用のFAST）、DRP無しの4モード

次に、SLAM精度と処理時間の評価を行った。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2428
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：無効
- FASTのDRP実装：SLAM組みこみ用のFAST
- compute_orb_descriptorsのDRP実装：FP16
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

### 6.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.04.mono.slamfast.none.3wh.image_loading.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.256009
      mean      0.038355
    median      0.029188
       min      0.003357
      rmse      0.047069
       sse      2.355057
       std      0.027284

```

最大誤差が`25`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.04.mono.slamfast.none.3wh.image_loading.txt \
>   --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.04.mono.slamfast.none.3wh.image_loading
infos:  1063 poses, 17.398m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/image_loading/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/image_loading/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/image_loading/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

### 6.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

#### 6.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            18.844 |
| `　　cv::imread` |    99.9 |            18.828 |
| `　　その他`  　　|     0.1 |             ----- |

#### 6.2.2 Trackingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            79.114 |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |            79.109 |
| `　　　　Wait for image_loading_module::loaded_images to true`   　　　　　　　　|     0   |             0.024 |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|     1.2 |             1.023 |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|     0.7 |             0.627 |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|     0.3 |             0.284 |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|     0.9 |             0.783 |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|    44.8 |            35.451 |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|     4   |             3.171 |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|     3.9 |             3.156 |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|     0   |             0.023 |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0.5 |             0.415 |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.041 |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0.3 |             0.274 |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|     2.3 |             1.838 |
| `　　　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|     0.3 |             0.245 |
| `　　　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　|     0.3 |             0.27  |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|    25.1 |            19.921 |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|    10.4 |             8.251 |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|     0   |             0.03  |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0.8 |             0.635 |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.064 |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.322 |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|     7.4 |             5.863 |
| `　　　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　　　|     0   |             0.038 |
| `　　　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　　　|     0   |             0.053 |
| `　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　　　|     1.4 |             1.157 |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|     7.8 |             6.187 |
| `　　　　　　　　yolo_detector::finish[LEFT]`　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　Receive result[LEFT]`   　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|     6.7 |             5.319 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|     7.5 |             5.964 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.026 |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     0.5 |             0.466 |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.049 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             0.314 |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|     5.9 |             4.715 |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.344 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     7.1 |             5.671 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　|     0   |             0.039 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.026 |
| `　　　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|     0.6 |             0.494 |
| `　　　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　|     0   |             0.029 |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.028 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             0.304 |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|     5.8 |             4.648 |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0   |             0.061 |
| `　　　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             ----- |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|     1   |             0.834 |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|    47.8 |            37.828 |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.2   |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|     0.7 |             0.609 |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|    43.9 |            34.809 |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|    13.2 |            10.464 |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|    13.1 |            10.434 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|     6.3 |             5.032 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     6.6 |             5.289 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|     0   |             0.004 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|    27.9 |            22.078 |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|     8.9 |             7.058 |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|     0   |             0.076 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     8.9 |             ----- |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|     9.3 |             7.415 |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |     0.2 |             0.218 |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |     2.9 |             2.298 |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|     5.6 |             4.485 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|     9.6 |             7.599 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     9.1 |             7.265 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|     0   |             0.004 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2.8 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     3   |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     3.2 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

### 6.3 考察

`3.2 ボトルネック解析結果`と比較する。  
比較結果は以下の表の通り。

| 項目                                                        | 変更前    | 変更後    |
|------------------------------------------------------------|-------:|-------:|
| `cv::imread`   　　　　　　　　　　　　　　　　　　　　　　|　　--- | 18.828 |
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　| 93.968 | 79.114 |
| `　　cv::imread`   　　　　　　　　　　　　　　　　　　　　| 18.188 |    --- |
| `　　orb_extractor::extract`   　　　　　　　　　　　　　　| 34.509 | 35.451 |
| `　　　　GaussianBlur　(DRP time)` 　　　　　　　　　　　　| 4.711  | 4.715  |
| `　　　　orb_extractor::compute_fast_keypoints (DRP time)` | 5.844  | 5.863  |
| `　　　　compute_orb_descriptors (DRP time)`   　　　　　　| 4.637  | 4.648  |
| `　　tracking_module::feed_frame`  　　　　　　　　　　　　| 35.522 | 37.828 |

以上から、画像読み込みの処理がTrackingスレッドから分割され、`cv::imread`の処理時間がTrackingスレッドから削減されたことがわかる。  
ただし、`tracking_module::feed_frame`の平均処理時間は約`2`\[ms/frame\]増加した。  
画像読み込みのスレッド分割によるオーバーヘッドに由来するものなのか、stella_vslamに実行再現性が無いためなのかは、切り分けできていない。

なお、本案件で評価の対象となっていない実行条件については動作確認していない。  
特に、以下の条件については動作確認していない点に注意する。

- `run_euroc_slam`と`run_kitti_slam`以外の実行ファイルを使用するケース
- 実行時オプションで`--equal-hist`を指定するケース
- 実行時オプションで`--scale`を指定するケース

また、2024年4月時点で`core-image-weston`上でUSBカメラが正常に動作しないため、ELPカメラを使用した場合の動作確認も行っていない。

## 7 stella_vslamの画像処理のスレッド分割

stella_vslamの画像処理のスレッド分割を行った。

まず、中間データのダンプ結果の確認を行った。  
以下の2項目の組み合わせである計12パターンについて、DRP-AIを有効にしたときの、画像処理のスレッド分割前のダンプ結果と、画像処理のスレッド分割後のダンプ結果が0番と1番のフレームについて厳密に一致することを確認できた。

1. 単眼、ステレオ、RGB-Dの3モード
2. OpenCVA、DRPドライバネイティブ（CVアセット用のFAST）、DRPドライバネイティブ（SLAM組み込み用のFAST）、DRP無しの4モード

次に、SLAM精度と処理時間の評価を行った。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2428
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：無効
- FASTのDRP実装：SLAM組みこみ用のFAST
- compute_orb_descriptorsのDRP実装：FP16
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

### 7.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.04_2.mono.slamfast.none.3wh.image_processing.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.341210
      mean      0.093448
    median      0.069261
       min      0.018832
      rmse      0.113757
       sse      13.742885
       std      0.064869

```

最大誤差が`34`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>    --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>    eval/frame_trajectory.v2x.2024.04_2.mono.slamfast.none.3wh.image_processing.txt \
>    --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.04_2.mono.slamfast.none.3wh.image_processing
infos:  1062 poses, 18.511m path length, 35.728s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/image_processing/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/image_processing/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/image_processing/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

### 7.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

#### 7.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            19.305 |
| `　　cv::imread` |    99.8 |            19.276 |
| `　　その他`  　　|     0.2 |             ----- |

#### 7.2.2 Image processingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            39.476 |
| `　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　　　|     3.6 |             1.422 |
| `　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　　　|     1.6 |             0.651 |
| `　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　　　|     0.7 |             0.293 |
| `　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　　　|     1.8 |             0.738 |
| `　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　　　|    89.1 |            35.203 |
| `　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　　　|     8.3 |             3.277 |
| `　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　　　|     8.2 |             3.256 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.024 |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     1   |             0.434 |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.046 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.287 |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|     4.7 |             1.875 |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.246 |
| `　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　|     0.7 |             0.295 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　　　|    49.2 |            19.44  |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　　　|    20.3 |             8.024 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.002 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.032 |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     1.6 |             0.64  |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.073 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.333 |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|    14.9 |             5.91  |
| `　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　　　　　|     0.1 |             0.05  |
| `　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　　　　　|     0.1 |             0.054 |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　　　　　|     2.1 |             0.837 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　　　|    14.6 |             5.779 |
| `　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　　　|    13.9 |             5.513 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|    15.1 |             5.978 |
| `　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     0   |             0.027 |
| `　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　　　|     1.1 |             0.466 |
| `　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.054 |
| `　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.32  |
| `　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　　　|    11.9 |             4.711 |
| `　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.349 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|    14.5 |             5.733 |
| `　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　　　|     0.1 |             0.04  |
| `　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     0   |             0.028 |
| `　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　　　|     1.2 |             0.507 |
| `　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|     0   |             0.03  |
| `　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.03  |
| `　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.311 |
| `　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　　　|    11.8 |             4.683 |
| `　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.066 |
| `　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2   |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     3.2 |             ----- |

#### 7.2.3 Trackingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            55.07  |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |            55.066 |
| `　　　　Wait for tracking_module::wait_for_next_frame_ to false`　　　　　　　　|    12.6 |             6.945 |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|     1.3 |             0.731 |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|    85.7 |            47.229 |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.238 |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|     1.9 |             1.086 |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|    82.2 |            45.312 |
| `　　　　　　　　std::lock_guard`　　　　　　　　　　　　　　　　　　　　　　　　|    10.6 |             5.868 |
| `　　　　　　　　tracking_module::update_last_frame` 　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　tracking_module::relocalize_by_pose`　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　data::frame::compute_bow`   　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|    19.6 |            10.829 |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|    19.6 |            10.802 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|     9.3 |             5.127 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    10   |             5.53  |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|     0   |             0.003 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|    51.8 |            28.552 |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|    17.5 |             9.692 |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|    19.1 |            10.549 |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |     0.4 |             0.232 |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |     5.9 |             3.299 |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|    11.4 |             6.29  |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     1.4 |             ----- |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|    15   |             8.306 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    14.3 |             7.912 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             ----- |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|     0   |             0.004 |
| `　　　　　　　　data::map_database::update_frame_statistics`　　　　　　　　　　|     0   |             0.02  |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.2 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

### 7.3 考察

`6.2 ボトルネック解析結果`と比較した。

| 項目                                                        | 変更前    | 変更後    |
|------------------------------------------------------------|-------:|-------:|
| `cv::imread`   　　　　　　　　　　　　　　　　　　　　　　| 18.828 | 19.276 |
| `Image processing` 　　　　　　　　　　　　　　　　　　　　|　　--- | 39.476 |
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　| 79.114 | 55.070 |
| `　　tracking_module::feed_frame`  　　　　　　　　　　　　| 37.828 | 47.229 |

画像処理に着目して比較した結果を以下の表に示す。

| 項目                                                    | 変更前    | 変更後    |
|--------------------------------------------------------|-------:|-------:|
| `orb_extractor::extract`   　　　　　　　　　　　　　　| 35.451 | 35.203 |
| `　　GaussianBlur　(DRP time)` 　　　　　　　　　　　　| 4.715  | 4.711  |
| `　　orb_extractor::compute_fast_keypoints (DRP time)` | 5.863  | 5.910  |
| `　　compute_orb_descriptors (DRP time)`   　　　　　　| 4.648  | 4.683  |

以上から、画像処理がTrackingスレッドから分割され、その分の処理時間がTrackingスレッドから削減されたことがわかる。  
ただし、`tracking_module::feed_frame`の平均処理時間は約`10`\[ms/frame\]増加した。  
これは、TrackingスレッドがLocal mappingスレッドと比較して相対的に高速化されたことにより、Trackingスレッドからみた地図の更新頻度が低下し、`tracking_module::feed_frame`の処理負荷が増えたためだと考えられる。

Image processingスレッドのうち、処理時間の大きな処理に着目して整理した表を以下の示す。

| 関数                                                            |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------|--------:|------------------:|
| `Image processing`　　　　　　　　　　　　　　　　　　　　　　|   100   |            39.476 |
| `　　util::convert_to_grayscale`  　　　　　　　　　　　　　　|     3.6 |             1.422 |
| `　　Resize[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|     8.2 |             3.256 |
| `　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`　　　　|    20.3 |             8.024 |
| `　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]` |    14.6 |             5.779 |
| `　　orb_extractor::compute_orientation[LEFT][0-7]`   　　　　|    13.9 |             5.513 |
| `　　GaussianBlur[LEFT][0-7]` 　　　　　　　　　　　　　　　　|    15.1 |             5.978 |
| `　　compute_orb_descriptors[LEFT][0-7]`  　　　　　　　　　　|    14.5 |             5.733 |
| `　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|    9.8  |            (3.868) |

以上から、stella_vslamを`20`\[fps\]以上で動作させるためには、Image loadingスレッドとImage processingスレッドの平均処理時間を合計で約`8`\[ms/frame\]だけ削減する必要があると考えられる。  
したがって、以下のいずれかの対応が必要であると考えられる。

1. データセットをグレースケールに変更する
2. 4つのDRPプログラムをそれぞれ1.8倍以上高速化する
    - `DRP time`は、4アルゴリズム合計で`17.179`\[ms/frame\]
3. 木構造による間引きを含む`orb_extractor::distribute_keypoints_via_tree`と、`orb_extractor::compute_orientation`をDRPに移植する

2024年4月時点で`core-image-weston`上でUSBカメラが正常に動作しないため、ELPカメラを使用した場合の動作確認は行っていない。

## 8 stella_vslamのDRP-AI TVMのスレッド分割

stella_vslamのDRP-AI TVMのスレッド分割を行った。

まず、中間データのダンプ結果の確認を行った。  
以下の2項目の組み合わせである計12パターンについて、DRP-AIを有効にしたときの、画像処理のスレッド分割前のダンプ結果と、画像処理のスレッド分割後のダンプ結果が0番と1番のフレームについて厳密に一致することを確認できた。

1. 単眼、ステレオ、RGB-Dの3モード
2. OpenCVA、DRPドライバネイティブ（CVアセット用のFAST）、DRPドライバネイティブ（SLAM組み込み用のFAST）、DRP無しの4モード

次に、SLAM精度と処理時間の評価を行った。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2428
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：**有効**
- FASTのDRP実装：SLAM組みこみ用のFAST
- compute_orb_descriptorsのDRP実装：FP16
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

### 8.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.04_2.mono.slamfast.ai.3wh.yolo_detection.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.424291
      mean      0.069030
    median      0.041335
       min      0.004687
      rmse      0.104019
       sse      11.501624
       std      0.077813

```

最大誤差が`42`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.04_2.mono.slamfast.ai.3wh.yolo_detection.txt \
>   --correct_scale --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.04_2.mono.slamfast.ai.3wh.yolo_detection
infos:  1063 poses, 21.786m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/yolo_detection/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/yolo_detection/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/yolo_detection/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

### 8.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

#### 8.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |            23.968 |
| `　　cv::imread` |    99.8 |            23.941 |
| `　　その他`  　　|     0.2 |             ----- |

#### 8.2.2 Image processingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            48.481 |
| `　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　　　|     3.1 |             1.532 |
| `　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　　　|     1.4 |             0.688 |
| `　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　　　|     0.6 |             0.31  |
| `　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　　　|     1.6 |             0.81  |
| `　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　　　|    89.4 |            43.366 |
| `　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　　　|     8.3 |             4.039 |
| `　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　　　|     8.2 |             4.013 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.031 |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     1.1 |             0.554 |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.071 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.33  |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|     4.3 |             2.105 |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.376 |
| `　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　|     0.9 |             0.472 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　　　|    52.2 |            25.313 |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　　　|    20.2 |             9.833 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.003 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0.1 |             0.057 |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     1.8 |             0.879 |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.133 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.403 |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|    13   |             6.345 |
| `　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　　　　　|     0.2 |             0.112 |
| `　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　　　　　|     0.1 |             0.09  |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　　　　　|     3.4 |             1.651 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　　　|    16.8 |             8.159 |
| `　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　　　|    14.7 |             7.138 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|    13.7 |             6.673 |
| `　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     0   |             0.035 |
| `　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　　　|     1.4 |             0.717 |
| `　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.081 |
| `　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.346 |
| `　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　　　|    10   |             4.895 |
| `　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     1   |             0.491 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|    12.4 |             6.013 |
| `　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　　　|     0.1 |             0.051 |
| `　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     0   |             0.033 |
| `　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　　　|     1.3 |             0.653 |
| `　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|     0   |             0.033 |
| `　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.036 |
| `　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.322 |
| `　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　　　|     9.7 |             4.737 |
| `　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.078 |
| `　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2.8 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     3.9 |             ----- |

#### 8.2.3 Yolo detectionスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Yolo detection` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            39.022 |
| `　　yolo_detector::start[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|    92.2 |            36.009 |
| `　　　　convert to RGB or YUYV[LEFT]`   　　　　　　　　　　　　　　　　　　　　|     0   |             0.013 |
| `　　　　resize[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　bottom padding[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     2.1 |             0.822 |
| `　　　　copy input to physical memory[LEFT]`　　　　　　　　　　　　　　　　　　|     1.8 |             0.739 |
| `　　　　PreRuntime::Pre[LEFT]`  　　　　　　　　　　　　　　　　　　　　　　　　|    16.7 |             6.541 |
| `　　　　MeraDrpRuntimeWrapper::SetInput[LEFT]`  　　　　　　　　　　　　　　　　|    25.9 |            10.124 |
| `　　　　MeraDrpRuntimeWrapper::Run[LEFT]`   　　　　　　　　　　　　　　　　　　|    45.3 |            17.704 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　yolo_detector::finish[LEFT]`　　　　　　　　　　　　　　　　　　　　　　　　|     6.2 |             2.434 |
| `　　　　Receive result[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     6.1 |             2.419 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.6 |             ----- |

#### 8.2.4 Trackingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            67.446 |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |            67.44  |
| `　　　　Wait for tracking_module::wait_for_next_frame_ to false`　　　　　　　　|     9.7 |             6.598 |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|     1.2 |             0.852 |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|    88.6 |            59.798 |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|     0.3 |             0.238 |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|     2.6 |             1.801 |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|    84.5 |            57.051 |
| `　　　　　　　　std::lock_guard`　　　　　　　　　　　　　　　　　　　　　　　　|    13.5 |             9.144 |
| `　　　　　　　　tracking_module::update_last_frame` 　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　　　　　tracking_module::relocalize_by_pose`　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　data::frame::compute_bow`   　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|    18.9 |            12.8   |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|    18.9 |            12.757 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|     8.3 |             5.639 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    10.2 |             6.933 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|    51.9 |            35.038 |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|    19.9 |            13.488 |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|     0.1 |             0.11  |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|    19.8 |             ----- |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|    18.5 |            12.54  |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |     0.4 |             0.325 |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |     5.9 |             4.032 |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|    10.8 |             7.337 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     1.4 |             ----- |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|    13.3 |             9.001 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    12.7 |             8.575 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　data::map_database::update_frame_statistics`　　　　　　　　　　|     0   |             0.029 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.2 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

### 8.3 考察

`7.2 ボトルネック解析結果`と比較した。  
ただし、変更前はDRP-AI無し、変更後はDRP-AIありの評価結果である点に注意する。

| 項目                                                        | 変更前    | 変更後    |
|------------------------------------------------------------|-------:|-------:|
| `cv::imread`   　　　　　　　　　　　　　　　　　　　　　　| 19.276 | 23.941 |
| `Image processing` 　　　　　　　　　　　　　　　　　　　　| 39.476 | 48.481 |
| `　　yolo_detector::start[LEFT]`   　　　　　　　　　　　　|  0     |  ----- |
| `　　yolo_detector::finish[LEFT]`  　　　　　　　　　　　　|  0     |  ----- |
| `Yolo detection`   　　　　　　　　　　　　　　　　　　　　|  ----- | 39.022 |
| `　　yolo_detector::start[LEFT]`   　　　　　　　　　　　　|  ----- | 36.009 |
| `　　yolo_detector::finish[LEFT]`  　　　　　　　　　　　　|  ----- |  2.434 |
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　| 55.070 | 67.446 |
| `　　tracking_module::feed_frame`  　　　　　　　　　　　　| 47.229 | 59.798 |

仮にYolo detectionスレッドの処理がImage processingスレッドから分割されていなかった場合、Yolo detectionスレッドの`39.022`\[ms/frame\]分の処理時間はImage processingスレッドに計上される。  
したがって、`39.476 + 39.022 = 78.498`\[ms/frame\]になっていたと想定される。  
一方で、Yolo detectionスレッドの処理をImage processingスレッドから分割したことで、Image processingスレッドの平均処理時間の実際の増分は`48.481 - 39.476 = 9.005`\[ms/frame\]に収まっている。

以上から、DRP-AI TVMのスレッド分割によって、DRP-AIを使用する場合について、Image processingスレッド平均処理時間を約`30`\[ms/frame\]削減できたと考えられる。

また、仮にYolo detectionスレッドの処理がImage processingスレッドから分割されていなかった場合、Yolo detectionスレッドの`39.022`\[ms/frame\]分の処理時間はTrackingスレッドの平均処理時間の増加にもつながる。  
したがって、`55.070 + 39.022 = 94.092`\[ms/frame\]になっていたと想定される。  
一方で、Yolo detectionスレッドの処理をImage processingスレッドから分割したことで、Trackingスレッドの平均処理時間の実際の増分は`67.446 - 55.070 = 12.376`\[ms/frame\]に収まっている。

`cv::imread`や排他制御による待ち時間を含まない`tracking_module::feed_frame`の平均処理時間も増加していることがわかる。  
これは、DRP-AIを使用することによってメモリアクセスが増加し、そのために処理時間が増加している可能性が考えられる。

## 9 stella_vslamのマルチスレッド対応後の評価

DRP-AI TVMのスレッド分割の後の評価を行った。

stella_vslamのマルチスレッド対応後のSLAM精度と処理時間の評価を行った。

### 9.1 単眼 + OpenCVA

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2430
- OpenCVA：有効
- DRPドライバネイティブ：無効
- DRP-AI：有効
- compute_orb_descriptorsのDRP実装：FP16
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

#### 9.1.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.mono.opencva.ai.3wh.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.253575
      mean      0.028271
    median      0.022680
       min      0.001335
      rmse      0.037943
       sse      1.530345
       std      0.025306

```

最大誤差が`25`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.mono.opencva.ai.3wh.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024-0423.mono.opencva.ai.3wh
infos:  1063 poses, 18.296m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/multi_thread/mono/opencva/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/multi_thread/mono/opencva/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/multi_thread/mono/opencva/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 9.1.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
OpenCVAの処理時間は●で示す。

##### 9.1.2.1 Image loadingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            23.518 |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |            23.493 |

##### 9.1.2.2 Image processingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            86.576 |
| `　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　　　|     1.4 |             1.229 |
| `　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.633 |
| `　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　　　|     0.3 |             0.283 |
| `　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.708 |
| `　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　　　|    94.8 |            82.116 |
| `　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　　　|     4.3 |             3.724 |
| `　　　　　　Resize[LEFT][0-7]●` 　　　　　　　　　　　　　　　　　　　　　　　　|     4.2 |             3.704 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　　　|    49.9 |            43.226 |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　　　|    35   |            30.334 |
| `　　　　　　　　FAST[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　　　|    34.3 |            29.775 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             ----- |
| `　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　　　|     8.3 |             7.19  |
| `　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　　　|     6.3 |             5.525 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　　　GaussianBlur[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　　　|     3.2 |             2.818 |
| `　　　　compute_orb_descriptors[LEFT][0-7]●`　　　　　　　　　　　　　　　　　　|    36.6 |            31.7   |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2   |             ----- |

##### 9.1.2.3 Yolo detectionスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Yolo detection` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            37.842 |
| `　　yolo_detector::start[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|    92.2 |            34.898 |
| `　　　　convert to RGB or YUYV[LEFT]`   　　　　　　　　　　　　　　　　　　　　|     0   |             0.013 |
| `　　　　resize[LEFT]●`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　bottom padding[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     2   |             0.766 |
| `　　　　copy input to physical memory[LEFT]`　　　　　　　　　　　　　　　　　　|     1.8 |             0.716 |
| `　　　　PreRuntime::Pre[LEFT]`  　　　　　　　　　　　　　　　　　　　　　　　　|    16.8 |             6.377 |
| `　　　　MeraDrpRuntimeWrapper::SetInput[LEFT]`  　　　　　　　　　　　　　　　　|    24.8 |             9.419 |
| `　　　　MeraDrpRuntimeWrapper::Run[LEFT]`   　　　　　　　　　　　　　　　　　　|    46.3 |            17.554 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　yolo_detector::finish[LEFT]`　　　　　　　　　　　　　　　　　　　　　　　　|     6.1 |             2.337 |
| `　　　　Receive result[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     6.1 |             2.317 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.7 |             ----- |

##### 9.1.2.4 Trackingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            93.347 |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |            93.342 |
| `　　　　Wait for tracking_module::wait_for_next_frame_ to false`　　　　　　　　|    47.6 |            44.51  |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             0.841 |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|    51.1 |            47.773 |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.237 |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|     0.5 |             0.535 |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|    49.5 |            46.277 |
| `　　　　　　　　std::lock_guard`　　　　　　　　　　　　　　　　　　　　　　　　|     3   |             2.863 |
| `　　　　　　　　tracking_module::update_last_frame` 　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　tracking_module::relocalize_by_pose`　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　data::frame::compute_bow`   　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|    13.1 |            12.286 |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|    13.1 |            12.239 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|     5.5 |             5.213 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     7.3 |             6.829 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|    33.2 |            31.035 |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|    12.5 |            11.739 |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|     0.1 |             0.122 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|    12.4 |             ----- |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|    11.7 |            10.933 |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |     0.3 |             0.313 |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |     3.5 |             3.357 |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|     6.9 |             6.529 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     1   |             ----- |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|     8.9 |             8.353 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     8.4 |             7.917 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　data::map_database::update_frame_statistics`　　　　　　　　　　|     0   |             0.024 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

### 9.2 単眼 + SLAM組み込み用のFAST

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2428
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：有効
- FASTのDRP実装：SLAM組みこみ用のFAST
- compute_orb_descriptorsのDRP実装：FP16
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

#### 9.2.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.mono.slamfast.ai.3wh.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.522933
      mean      0.135059
    median      0.074457
       min      0.010584
      rmse      0.183249
       sse      35.695801
       std      0.123852

```

最大誤差が`52`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.mono.slamfast.ai.3wh.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024-0423.mono.slamfast.ai.3wh
infos:  1063 poses, 32.503m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/multi_thread/mono/slamfast/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/multi_thread/mono/slamfast/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/multi_thread/mono/slamfast/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 9.2.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

##### 9.2.2.1 Image loadingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            23.543 |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.8 |            23.519 |

##### 9.2.2.2 Image processingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            47.344 |
| `　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　　　|     2.8 |             1.368 |
| `　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　　　|     1.4 |             0.675 |
| `　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　　　|     0.6 |             0.3   |
| `　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　　　|     1.6 |             0.787 |
| `　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　　　|    89.5 |            42.408 |
| `　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　　　|     8.3 |             3.941 |
| `　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　　　|     8.2 |             3.923 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.028 |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     1.2 |             0.598 |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.064 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.331 |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|     4.2 |             2.028 |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.344 |
| `　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　|     0.9 |             0.461 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　　　|    51.9 |            24.601 |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　　　|    20.4 |             9.68  |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.003 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.045 |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     1.9 |             0.938 |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.127 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.421 |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|    13.2 |             6.292 |
| `　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　　　　　|     0.1 |             0.087 |
| `　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　　　　　|     0.1 |             0.084 |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　　　　　|     3.2 |             1.529 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             ----- |
| `　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　　　|    16.4 |             7.785 |
| `　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　　　|    14.6 |             6.942 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|    13.8 |             6.546 |
| `　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     0   |             0.033 |
| `　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　　　|     1.4 |             0.691 |
| `　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.072 |
| `　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.332 |
| `　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　　　|    10.2 |             4.848 |
| `　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     1   |             0.478 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|    12.6 |             5.995 |
| `　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　　　|     0.1 |             0.05  |
| `　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     0   |             0.031 |
| `　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　　　|     1.4 |             0.708 |
| `　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|     0   |             0.032 |
| `　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.034 |
| `　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.317 |
| `　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　　　|     9.9 |             4.689 |
| `　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.073 |
| `　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2.9 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     4.1 |             ----- |

##### 9.2.2.3 Yolo detectionスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Yolo detection` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            39.332 |
| `　　yolo_detector::start[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|    92.4 |            36.37  |
| `　　　　convert to RGB or YUYV[LEFT]`   　　　　　　　　　　　　　　　　　　　　|     0   |             0.013 |
| `　　　　resize[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　bottom padding[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     2.1 |             0.843 |
| `　　　　copy input to physical memory[LEFT]`　　　　　　　　　　　　　　　　　　|     1.8 |             0.746 |
| `　　　　PreRuntime::Pre[LEFT]`  　　　　　　　　　　　　　　　　　　　　　　　　|    17.5 |             6.897 |
| `　　　　MeraDrpRuntimeWrapper::SetInput[LEFT]`  　　　　　　　　　　　　　　　　|    24.7 |             9.726 |
| `　　　　MeraDrpRuntimeWrapper::Run[LEFT]`   　　　　　　　　　　　　　　　　　　|    45.9 |            18.082 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　yolo_detector::finish[LEFT]`　　　　　　　　　　　　　　　　　　　　　　　　|     5.9 |             2.342 |
| `　　　　Receive result[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     5.9 |             2.327 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.7 |             ----- |

##### 9.2.2.4 Trackingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.156 |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |            68.151 |
| `　　　　Wait for tracking_module::wait_for_next_frame_ to false`　　　　　　　　|     9.1 |             6.238 |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|     1.2 |             0.845 |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|    89.3 |            60.866 |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.15  |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|     2.1 |             1.449 |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|    85.9 |            58.601 |
| `　　　　　　　　std::lock_guard`　　　　　　　　　　　　　　　　　　　　　　　　|    14.3 |             9.774 |
| `　　　　　　　　tracking_module::update_last_frame` 　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　tracking_module::relocalize_by_pose`　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　data::frame::compute_bow`   　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|    18.2 |            12.456 |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|    18.2 |            12.409 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|     7.9 |             5.447 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     9.9 |             6.783 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|     0   |             0.004 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|    53.2 |            36.298 |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|    20.9 |            14.248 |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|     0.1 |             0.109 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|    20.8 |             ----- |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|    19.5 |            13.351 |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |     0.4 |             0.32  |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |     6.7 |             4.593 |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|    11.1 |             7.573 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     1.3 |             ----- |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|    12.7 |             8.69  |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    12.1 |             8.28  |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　data::map_database::update_frame_statistics`　　　　　　　　　　|     0   |             0.024 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

### 9.3 単眼 + DRP無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2430
- OpenCVA：無効
- DRPドライバネイティブ：無効
- DRP-AI：有効
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

#### 9.3.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.mono.cpu.ai.3wh.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.508045
      mean      0.038724
    median      0.025974
       min      0.000751
      rmse      0.055008
       sse      3.189331
       std      0.039069

```

最大誤差が`50`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.mono.cpu.ai.3wh.txt --correct_scale --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024-0423.mono.cpu.ai.3wh
infos:  1054 poses, 21.502m path length, 35.628s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/multi_thread/mono/cpu/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/multi_thread/mono/cpu/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/multi_thread/mono/cpu/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 9.3.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。

##### 9.3.2.1 Image loadingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            22.762 |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |            22.74  |

##### 9.3.2.2 Image processingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            86.62  |
| `　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　　　|     1.1 |             0.98  |
| `　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.631 |
| `　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　　　|     0.3 |             0.282 |
| `　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.707 |
| `　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　　　|    95.1 |            82.432 |
| `　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　　　|     5.9 |             5.137 |
| `　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　　　|     5.9 |             5.118 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　　　|    42.6 |            36.987 |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　　　|    27.5 |            23.865 |
| `　　　　　　　　FAST[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|    26.9 |            23.341 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　　　|     8   |             6.96  |
| `　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　　　|     6.9 |             5.999 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|     9.1 |             7.949 |
| `　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|    36.5 |            31.624 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1   |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2   |             ----- |

##### 9.3.2.3 Yolo detectionスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Yolo detection` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            38.152 |
| `　　yolo_detector::start[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|    91.2 |            34.816 |
| `　　　　convert to RGB or YUYV[LEFT]`   　　　　　　　　　　　　　　　　　　　　|     0   |             0.022 |
| `　　　　resize[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　bottom padding[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     2   |             0.768 |
| `　　　　copy input to physical memory[LEFT]`　　　　　　　　　　　　　　　　　　|     1.9 |             0.746 |
| `　　　　PreRuntime::Pre[LEFT]`  　　　　　　　　　　　　　　　　　　　　　　　　|    16.8 |             6.418 |
| `　　　　MeraDrpRuntimeWrapper::SetInput[LEFT]`  　　　　　　　　　　　　　　　　|    23.6 |             9.008 |
| `　　　　MeraDrpRuntimeWrapper::Run[LEFT]`   　　　　　　　　　　　　　　　　　　|    46.6 |            17.782 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　yolo_detector::finish[LEFT]`　　　　　　　　　　　　　　　　　　　　　　　　|     7.2 |             2.75  |
| `　　　　Receive result[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     7.1 |             2.728 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.6 |             ----- |

##### 9.3.2.4 Trackingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            92.119 |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |            92.114 |
| `　　　　Wait for tracking_module::wait_for_next_frame_ to false`　　　　　　　　|    51.3 |            47.288 |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             0.857 |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|    47.4 |            43.687 |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|     0.5 |             0.526 |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|     0.4 |             0.438 |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|    45.5 |            41.978 |
| `　　　　　　　　std::lock_guard`　　　　　　　　　　　　　　　　　　　　　　　　|     3   |             2.787 |
| `　　　　　　　　tracking_module::update_last_frame` 　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　tracking_module::relocalize_by_pose`　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　data::frame::compute_bow`   　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|    12   |            11.112 |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|    12   |            11.075 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|     5.2 |             4.829 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     6.6 |             6.084 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|     0   |             0.003 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|    30.4 |            28.007 |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|    10.7 |             9.936 |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|     0.1 |             0.106 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|    10.6 |             ----- |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|    10.9 |            10.042 |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |     0.3 |             0.294 |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |     3.2 |             3.028 |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|     6.5 |             6.015 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             ----- |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|     8.7 |             8.021 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     8.2 |             7.584 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　data::map_database::update_frame_statistics`　　　　　　　　　　|     0   |             0.025 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1   |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

### 9.4 RGB-D + OpenCVA

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：RGB-D
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2430
- OpenCVA：有効
- DRPドライバネイティブ：無効
- DRP-AI：有効
- compute_orb_descriptorsのDRP実装：FP16
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

#### 9.4.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.rgbd.opencva.ai.3wh.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.613761
      mean      0.074593
    median      0.043980
       min      0.004448
      rmse      0.122715
       sse      16.007741
       std      0.097442

```

最大誤差が`61`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.rgbd.opencva.ai.3wh.txt --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024-0423.rgbd.opencva.ai.3wh
infos:  1063 poses, 17.164m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/multi_thread/rgbd/opencva/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/multi_thread/rgbd/opencva/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/multi_thread/rgbd/opencva/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 9.4.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
OpenCVAの処理時間は●で示す。

##### 9.4.2.1 Image loadingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            37.08  |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |            37.052 |

##### 9.4.2.2 Image processingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            92.235 |
| `　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　　　|     1.8 |             1.75  |
| `　　util::convert_to_true_depth`　　　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             0.879 |
| `　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.651 |
| `　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　　　|     0.3 |             0.291 |
| `　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.738 |
| `　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　　　|    92.9 |            85.746 |
| `　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　　　|     5.1 |             4.768 |
| `　　　　　　Resize[LEFT][0-7]●` 　　　　　　　　　　　　　　　　　　　　　　　　|     5.1 |             4.747 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　　　|    48.9 |            45.13  |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　　　|    34.5 |            31.86  |
| `　　　　　　　　FAST[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　　　|    33.8 |            31.259 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             ----- |
| `　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　　　|     8.2 |             7.589 |
| `　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　　　|     5.9 |             5.53  |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　　　GaussianBlur[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　　　|     3.1 |             2.883 |
| `　　　　compute_orb_descriptors[LEFT][0-7]●`　　　　　　　　　　　　　　　　　　|    34.9 |            32.217 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2.6 |             ----- |

##### 9.4.2.3 Yolo detectionスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Yolo detection` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            37.502 |
| `　　yolo_detector::start[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|    92.1 |            34.557 |
| `　　　　convert to RGB or YUYV[LEFT]`   　　　　　　　　　　　　　　　　　　　　|     0   |             0.01  |
| `　　　　resize[LEFT]●`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　bottom padding[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     1.9 |             0.748 |
| `　　　　copy input to physical memory[LEFT]`　　　　　　　　　　　　　　　　　　|     1.8 |             0.683 |
| `　　　　PreRuntime::Pre[LEFT]`  　　　　　　　　　　　　　　　　　　　　　　　　|    16.9 |             6.351 |
| `　　　　MeraDrpRuntimeWrapper::SetInput[LEFT]`  　　　　　　　　　　　　　　　　|    23.2 |             8.723 |
| `　　　　MeraDrpRuntimeWrapper::Run[LEFT]`   　　　　　　　　　　　　　　　　　　|    47.9 |            17.989 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　yolo_detector::finish[LEFT]`　　　　　　　　　　　　　　　　　　　　　　　　|     6.2 |             2.361 |
| `　　　　Receive result[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     6.2 |             2.34  |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.7 |             ----- |

##### 9.4.2.4 Trackingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           210.481 |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |           210.477 |
| `　　　　Wait for tracking_module::wait_for_next_frame_ to false`　　　　　　　　|     1.6 |             3.42  |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|     1.4 |             2.951 |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|    96.9 |           203.959 |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|     0   |             0.062 |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|     1.3 |             2.926 |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|    94.7 |           199.51  |
| `　　　　　　　　std::lock_guard`　　　　　　　　　　　　　　　　　　　　　　　　|     7.3 |            15.458 |
| `　　　　　　　　tracking_module::update_last_frame` 　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　tracking_module::relocalize_by_pose`　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　data::frame::compute_bow`   　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|    19.8 |            41.802 |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|    19.8 |            41.7   |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|     7.5 |            15.896 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    12   |            25.426 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|     0   |             0.018 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|    67.5 |           142.182 |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|    15.3 |            32.318 |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|     0   |             0.174 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|    15.3 |             ----- |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|    34.7 |            73.116 |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |     0.2 |             0.501 |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |     9.1 |            19.24  |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|    20.7 |            43.753 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     4.7 |             ----- |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|    17.4 |            36.729 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    16.9 |            35.679 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　data::map_database::update_frame_statistics`　　　　　　　　　　|     0   |             0.026 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

### 9.5 RGB-D + SLAM組み込み用のFAST

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：RGB-D
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2428
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：有効
- FASTのDRP実装：SLAM組みこみ用のFAST
- compute_orb_descriptorsのDRP実装：FP16
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

#### 9.5.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.rgbd.slamfast.ai.3wh.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.429131
      mean      0.174910
    median      0.161543
       min      0.018619
      rmse      0.185320
       sse      36.507088
       std      0.061237

```

最大誤差が`42`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.rgbd.slamfast.ai.3wh.txt --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024-0423.rgbd.slamfast.ai.3wh
infos:  1063 poses, 17.131m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/multi_thread/rgbd/slamfast/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/multi_thread/rgbd/slamfast/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/multi_thread/rgbd/slamfast/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 9.5.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

##### 9.5.2.1 Image loadingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            36.021 |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |            35.997 |

##### 9.5.2.2 Image processingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            51.446 |
| `　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　　　|     3.4 |             1.753 |
| `　　util::convert_to_true_depth`　　　　　　　　　　　　　　　　　　　　　　　　|     1.8 |             0.961 |
| `　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　　　|     1.2 |             0.661 |
| `　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　　　|     0.5 |             0.296 |
| `　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　　　|     1.5 |             0.778 |
| `　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　　　|    86.7 |            44.655 |
| `　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　　　|     8.7 |             4.479 |
| `　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　　　|     8.6 |             4.462 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.03  |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     1.2 |             0.656 |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.083 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.414 |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|     4.3 |             2.223 |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.426 |
| `　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　|     1   |             0.52  |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　　　|    51.3 |            26.395 |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　　　|    20.5 |            10.559 |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     0   |             0.003 |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|     0   |             0.047 |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     2   |             1.048 |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.151 |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.455 |
| `　　　　　　　　DRP time[LEFT][0-7]★`　　　　　　　　　　　　　　　　　　　　　　|    12.8 |             6.623 |
| `　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　　　　　|     0.2 |             0.108 |
| `　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　　　　　|     0.1 |             0.081 |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　　　　　|     3.6 |             1.867 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             ----- |
| `　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　　　|    16.3 |             8.39  |
| `　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　　　|    14   |             7.224 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|    12.6 |             6.498 |
| `　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     0   |             0.032 |
| `　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　　　|     1.3 |             0.673 |
| `　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.072 |
| `　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.329 |
| `　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　　　|     9.3 |             4.83  |
| `　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             0.472 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|    11.5 |             5.935 |
| `　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　　　|     0   |             0.044 |
| `　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|     0   |             0.03  |
| `　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　　　|     1.2 |             0.659 |
| `　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|     0   |             0.031 |
| `　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.036 |
| `　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.311 |
| `　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　　　|     9.1 |             4.69  |
| `　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.074 |
| `　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2.6 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     4.9 |             ----- |

##### 9.5.2.3 Yolo detectionスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Yolo detection` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            38.647 |
| `　　yolo_detector::start[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|    92.4 |            35.722 |
| `　　　　convert to RGB or YUYV[LEFT]`   　　　　　　　　　　　　　　　　　　　　|     0   |             0.012 |
| `　　　　resize[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　bottom padding[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     1.9 |             0.76  |
| `　　　　copy input to physical memory[LEFT]`　　　　　　　　　　　　　　　　　　|     1.7 |             0.682 |
| `　　　　PreRuntime::Pre[LEFT]`  　　　　　　　　　　　　　　　　　　　　　　　　|    17   |             6.599 |
| `　　　　MeraDrpRuntimeWrapper::SetInput[LEFT]`  　　　　　　　　　　　　　　　　|    24.4 |             9.439 |
| `　　　　MeraDrpRuntimeWrapper::Run[LEFT]`   　　　　　　　　　　　　　　　　　　|    47   |            18.176 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　yolo_detector::finish[LEFT]`　　　　　　　　　　　　　　　　　　　　　　　　|     6   |             2.325 |
| `　　　　Receive result[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     5.9 |             2.309 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.6 |             ----- |

##### 9.5.2.4 Trackingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           229.753 |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |           229.748 |
| `　　　　Wait for tracking_module::wait_for_next_frame_ to false`　　　　　　　　|     1.3 |             3.215 |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|     1.4 |             3.26  |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|    97.1 |           223.121 |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|     0   |             0.062 |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|     1.6 |             3.801 |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|    94.7 |           217.667 |
| `　　　　　　　　std::lock_guard`　　　　　　　　　　　　　　　　　　　　　　　　|     8.3 |            19.244 |
| `　　　　　　　　tracking_module::update_last_frame` 　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　tracking_module::relocalize_by_pose`　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　data::frame::compute_bow`   　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|    19.6 |            45.184 |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|    19.6 |            45.083 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|     7.3 |            16.929 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    12   |            27.751 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|     0   |             0.023 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|    66.6 |           153.165 |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|    14.9 |            34.435 |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|     0   |             0.174 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|    14.9 |             ----- |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|    33.7 |            77.582 |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |     0.2 |             0.519 |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |     8.9 |            20.565 |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|    20   |            46.106 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     4.6 |             ----- |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|    17.9 |            41.128 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    17.3 |            39.971 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　　　　　data::map_database::update_frame_statistics`　　　　　　　　　　|     0   |             0.031 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

### 9.6 RGB-D + DRP無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：RGB-D
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
    - 間引き後の平均特徴点数：2430
- OpenCVA：無効
- DRPドライバネイティブ：無効
- DRP-AI：有効
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

#### 9.6.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.rgbd.cpu.ai.3wh.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.476953
      mean      0.173437
    median      0.129181
       min      0.023136
      rmse      0.203747
       sse      44.128263
       std      0.106924

```

最大誤差が`47`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt eval/frame_trajectory.v2x.2024-0423.rgbd.cpu.ai.3wh.txt --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024-0423.rgbd.cpu.ai.3wh
infos:  1063 poses, 17.530m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/multi_thread/rgbd/cpu/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/multi_thread/rgbd/cpu/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/multi_thread/rgbd/cpu/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

#### 9.6.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。

##### 9.6.2.1 Image loadingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            36.186 |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |            36.163 |

##### 9.6.2.2 Image processingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Image processing`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            94.798 |
| `　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　　　|     1.5 |             1.487 |
| `　　util::convert_to_true_depth`　　　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             0.8   |
| `　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.649 |
| `　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　　　|     0.3 |             0.29  |
| `　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.739 |
| `　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　　　|    93.4 |            88.623 |
| `　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　　　|     6   |             5.755 |
| `　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　　　|     6   |             5.734 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　　　|    40.8 |            38.752 |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　　　|    26.5 |            25.2   |
| `　　　　　　　　FAST[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|    25.9 |            24.64  |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　　　|     7.7 |             7.388 |
| `　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　　　|     6.3 |             6.022 |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　　　|    11.6 |            11.089 |
| `　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　|    33.8 |            32.13  |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.2 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2.7 |             ----- |

##### 9.6.2.3 Yolo detectionスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Yolo detection` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            38     |
| `　　yolo_detector::start[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|    91.5 |            34.781 |
| `　　　　convert to RGB or YUYV[LEFT]`   　　　　　　　　　　　　　　　　　　　　|     0   |             0.013 |
| `　　　　resize[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.002 |
| `　　　　bottom padding[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     2   |             0.766 |
| `　　　　copy input to physical memory[LEFT]`　　　　　　　　　　　　　　　　　　|     1.8 |             0.721 |
| `　　　　PreRuntime::Pre[LEFT]`  　　　　　　　　　　　　　　　　　　　　　　　　|    16.8 |             6.412 |
| `　　　　MeraDrpRuntimeWrapper::SetInput[LEFT]`  　　　　　　　　　　　　　　　　|    23.1 |             8.783 |
| `　　　　MeraDrpRuntimeWrapper::Run[LEFT]`   　　　　　　　　　　　　　　　　　　|    47.4 |            18.032 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　yolo_detector::finish[LEFT]`　　　　　　　　　　　　　　　　　　　　　　　　|     6.9 |             2.654 |
| `　　　　Receive result[LEFT]`   　　　　　　　　　　　　　　　　　　　　　　　　|     6.9 |             2.631 |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.6 |             ----- |

##### 9.6.2.4 Trackingスレッド

| 関数                                                                               |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           228.683 |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.9 |           228.679 |
| `　　　　Wait for tracking_module::wait_for_next_frame_ to false`　　　　　　　　|     1.4 |             3.347 |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|     1.3 |             3.02  |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|    97.1 |           222.166 |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|     0   |             0.066 |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|     1.5 |             3.603 |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|    94.8 |           216.909 |
| `　　　　　　　　std::lock_guard`　　　　　　　　　　　　　　　　　　　　　　　　|     7.6 |            17.413 |
| `　　　　　　　　tracking_module::update_last_frame` 　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　tracking_module::relocalize_by_pose`　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　data::frame::compute_bow`   　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|    19   |            43.543 |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|    18.9 |            43.439 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|     7.3 |            16.796 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    11.4 |            26.26  |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|     0   |             0.025 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|    68.1 |           155.887 |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|    14.6 |            33.517 |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|     0   |             0.169 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|    14.6 |             ----- |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|    35.9 |            82.255 |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |     0.2 |             0.521 |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |     9.7 |            22.245 |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|    20.9 |            48.022 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     5.1 |             ----- |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|    17.5 |            40.096 |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|    17   |            38.953 |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             ----- |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　data::map_database::update_frame_statistics`　　　　　　　　　　|     0   |             0.029 |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.8 |             ----- |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

### 9.7 考察

上記で確認した評価結果を評価条件ごとに比較する。  
以降の表では、DRPドライバネイティブの場合についても前処理・後処理のCPU処理時間を含む値を記載する。  
なお、簡単のためにOpenCVAが無効かつDRPドライバネイティブが有効の場合も、DRP-AI TVMの前処理の`cv::resize`とDRPドライバネイティブ動作の処理の間で排他制御を行っている点に注意する。

まず、`cv::imread`の平均処理時間について比較した。

| 実行モード                              | 平均処理時間（\[ms/frame\]） |
|---------------------------------------|-------:|
| 単眼 + OpenCVA                        | 23.493 |
| 単眼 + SLAM組み込み用のFAST            | 23.519 |
| 単眼 + DRP無し                        | 22.740 |
| RGB-D + OpenCVA                      | 37.052 |
| RGB-D + SLAM組み込み用のFAST           | 35.997 |
| RGB-D + DRP無し                       | 36.163 |

単眼モードの間で有意な差は無かった。  
同様に、RGB-Dモードの間で有意な差は無かった。

単眼モードよりもRGB-Dモードの方が平均処理時間が大きいが、これはDepth画像の読み込みも必要であるためだと考えられる。

次に、`Image processing`の平均処理時間について比較した。

| 実行モード                              | 平均処理時間（\[ms/frame\]） |
|---------------------------------------|-------:|
| 単眼 + OpenCVA                        | 86.576 |
| 単眼 + SLAM組み込み用のFAST            | 47.344 |
| 単眼 + DRP無し                        | 86.620 |
| RGB-D + OpenCVA                      | 92.235 |
| RGB-D + SLAM組み込み用のFAST           | 51.446 |
| RGB-D + DRP無し                       | 94.798 |

DRPドライバネイティブ動作の場合が、他の場合と比較して高速に動作していることがわかる。

次に、Image processingスレッドの`Resize`の平均処理時間について比較した。

| 実行モード                              | 平均処理時間（\[ms/frame\]） |
|---------------------------------------|-------:|
| 単眼 + OpenCVA                        | 3.704 |
| 単眼 + SLAM組み込み用のFAST            | 3.923 |
| 単眼 + DRP無し                        | 5.118 |
| RGB-D + OpenCVA                      | 4.747 |
| RGB-D + SLAM組み込み用のFAST           | 4.462 |
| RGB-D + DRP無し                       | 5.734 |

DRPを使用する場合が、DRP無しと比較して高速に動作していることがわかる。

次に、Image processingスレッドの`GaussianBlur`の平均処理時間について比較した。

| 実行モード                              | 平均処理時間（\[ms/frame\]） |
|---------------------------------------|-------:|
| 単眼 + OpenCVA                        | 2.818 |
| 単眼 + SLAM組み込み用のFAST            | 6.546 |
| 単眼 + DRP無し                        | 7.949 |
| RGB-D + OpenCVA                      | 2.883 |
| RGB-D + SLAM組み込み用のFAST           | 6.498 |
| RGB-D + DRP無し                       | 11.089 |

OpenCVA動作の場合が、他の場合と比較して高速に動作していることがわかる。

次に、Image processingスレッドの`orb_extractor::compute_fast_keypoints`の平均処理時間について比較した。

| 実行モード                              | 平均処理時間（\[ms/frame\]） |
|---------------------------------------|-------:|
| 単眼 + OpenCVA                        | 30.334 |
| 単眼 + SLAM組み込み用のFAST            | 9.680 |
| 単眼 + DRP無し                        | 23.865 |
| RGB-D + OpenCVA                      | 31.860 |
| RGB-D + SLAM組み込み用のFAST           | 10.559 |
| RGB-D + DRP無し                       | 25.200 |

DRPドライバネイティブ動作の場合が、他の場合と比較して高速に動作していることがわかる。

次に、Image processingスレッドの`compute_orb_descriptors`の平均処理時間について比較した。

| 実行モード                              | 平均処理時間（\[ms/frame\]） |
|---------------------------------------|-------:|
| 単眼 + OpenCVA                        | 31.700 |
| 単眼 + SLAM組み込み用のFAST            | 5.995 |
| 単眼 + DRP無し                        | 31.624 |
| RGB-D + OpenCVA                      | 32.217 |
| RGB-D + SLAM組み込み用のFAST           | 5.935 |
| RGB-D + DRP無し                       | 32.130 |

DRPドライバネイティブ動作の場合が、他の場合と比較して高速に動作していることがわかる。

次に、`Yolo detection`の平均処理時間について比較した。

| 実行モード                              | 平均処理時間（\[ms/frame\]） |
|---------------------------------------|-------:|
| 単眼 + OpenCVA                        | 37.842 |
| 単眼 + SLAM組み込み用のFAST            | 39.332 |
| 単眼 + DRP無し                        | 38.152 |
| RGB-D + OpenCVA                      | 37.502 |
| RGB-D + SLAM組み込み用のFAST           | 38.647 |
| RGB-D + DRP無し                       | 38.000 |

モード間でYOLOの処理内容に差異がないため、平均処理時間にも有意な差がないことがわかる。

最後に、`Main loop`の平均処理時間について比較した。

| 実行モード                              | 平均処理時間（\[ms/frame\]） |
|---------------------------------------|-------:|
| 単眼 + OpenCVA                        | 93.347 |
| 単眼 + SLAM組み込み用のFAST            | 68.156 |
| 単眼 + DRP無し                        | 92.119 |
| RGB-D + OpenCVA                      | 210.481 |
| RGB-D + SLAM組み込み用のFAST           | 229.753 |
| RGB-D + DRP無し                       | 228.683 |

単眼モードではDRPドライバネイティブ動作の場合が、他の場合と比較して高速に動作していることがわかる。  
RGB-DモードではOpenCVA動作の場合が、他の場合と比較して高速に動作していることがわかる。

## 10 Yolo-Planar-SLAMのDRP-AI TVMのYOLOX-Sの正式版への変更

正式版のDRP-AI TVMのYOLOX-Sを、Yolo-Planar-SLAMで使用できるようにするための変更を行った。

暫定版のDRP-AI TVMのYOLOX-Sのための実装`yolo-planar-slam/drp_ai_modules/tvm/yoloxs_provisional`をベースに、正式版のための実装を作成した。  
主な変更点はstella_vslamと同様である。

変更を行った上で、`yolox_cam`を暫定版から正式版に変更して動作確認を行った。  
また、Yolo-Planar-SLAMのビルド時と実行時にリンクされる`libtvm_runtime.so`は`app_yolox-S_bgr640x640`に含まれていたものに変更した。  
なお、`正式版のDRP-AI TVMのYOLOX-Sのサンプルプログラムの動作確認`に記載した不具合を回避するために`core-image-weston`上で確認した点に注意する。

![SocketViewerの描画結果](image/yolo-planar-slam/planar_socket_viewer_drpai-tvm_output_scale_0.png)

正常にバウンディングボックスを検出できていることがわかる。

次に、評価を行った。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1000
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- compute_orb_descriptorsのDRP実装：FP32
- DRP-AIオブジェクトファイル：BGR入力（`app_yolox-S_bgr640x640/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1
- CIP Linux：`core-image-weston`

### 10.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.2024.04.mono.opencva.ai.tvm.3wx.1000.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.198217
      mean      0.030693
    median      0.023090
       min      0.002180
      rmse      0.041571
       sse      1.439557
       std      0.028037

```

最大誤差が`19`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.2024.04.mono.opencva.ai.tvm.3wx.1000.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.2024.04.mono.opencva.ai.tvm.3wx.1000
infos:  833 poses, 10.754m path length, 27.990s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/yolo-planar-slam/yoloxs/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/yolo-planar-slam/yoloxs/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/yolo-planar-slam/yoloxs/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

### 10.2 ボトルネック解析結果

ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

#### 10.2.1 Image loadingスレッド

| 関数               |   割合(%) |   実測値(msec/frame) |
|:-----------------|--------:|------------------:|
| `Image loading`  |   100   |             8.481 |
| `　　cv::imread` |    99.9 |             8.474 |

#### 10.2.2 Image processingスレッド

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            91.331 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.5 |             0.491 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB or YUYV`　　　　　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　resize●`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             0.649 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     0.5 |             0.51  |
| `　　　　PreRuntime::Pre`   　　　　　　　　　　　　　　　　　　　　|     5.9 |             5.455 |
| `　　　　MeraDrpRuntimeWrapper::SetInput`   　　　　　　　　　　　　|     8.8 |             8.093 |
| `　　　　MeraDrpRuntimeWrapper::Run`　　　　　　　　　　　　　　　　|    18.2 |            16.623 |
| `　　　　Receive result`　　　　　　　　　　　　　　　　　　　　　　|     2.4 |             2.271 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     3.2 |             2.971 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     3.1 |             2.884 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.031 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     0.4 |             0.404 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     2.5 |             2.291 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.3 |             0.302 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    37.6 |            34.388 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     0.6 |             0.577 |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     2.9 |             2.673 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     3.4 |             3.189 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.005 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     3.2 |             2.935 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.021 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.025 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.5 |             0.501 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.023 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             0.309 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　computeOrbDescriptors DRP time[0][0-7]★`   　　　　　　　　|     4.5 |             4.129 |
| `　　　　computeOrbDescriptors DRP time[1][0-7]★`   　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.017 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            91.331 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    80.9 |            73.911 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    18.4 |            16.806 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     0.6 |             0.577 |

#### 10.2.3 Trackingスレッド

| 関数                                                                         |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            92.716 |
| `　　Sleep specified at execution` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`   　　　　　　　　　　　　　　|     0   |             0.016 |
| `　　System::Track*`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.7 |            92.493 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`  　　　　　　　　|    51.8 |            48.072 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true` 　　|     0   |             0.001 |
| `　　　　Tracking::GrabImage*` 　　　　　　　　　　　　　　　　　　　　　　|    47.8 |            44.39  |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction` |     0.7 |             0.687 |
| `　　　　　　Tracking::Track`  　　　　　　　　　　　　　　　　　　　　　　|    47.1 |            43.697 |
| `　　　　　　　　Map::mMutexMapUpdate` 　　　　　　　　　　　　　　　　　　|     2.1 |             1.951 |
| `　　　　　　　　Tracking::MonocularInitialization`　　　　　　　　　　　　|     3.4 |             3.189 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`  　　　　　　　　|     0.8 |             0.796 |
| `　　　　　　　　Tracking::TrackReferenceKeyFrame` 　　　　　　　　　　　　|     0   |             0.066 |
| `　　　　　　　　　　ORBmatcher::SearchByBoW`  　　　　　　　　　　　　　　|     0   |             0.003 |
| `　　　　　　　　Tracking::TrackWithMotionModel`   　　　　　　　　　　　　|    13.3 |            12.394 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     7.5 |             6.981 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection` 　　　　　　　　|     5.5 |             5.149 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection`　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`  　　　　　　　　　　　　　　　　|    26.2 |            24.344 |
| `　　　　　　　　　　Tracking::UpdateLocalMap` 　　　　　　　　　　　　　　|     2.6 |             2.477 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     7.9 |             7.343 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`  　　　　　　　　　　　　|    15.4 |            14.357 |
| `　　　　　　　　　　　　Project points in frame and check its visibility` |    12.5 |            11.645 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`   　　　　　　　　|     2.7 |             2.573 |

### 10.3 考察

[暫定版の評価結果](../step2/Stella%20VSLAM+AI連携アプリ実装・評価報告書.md#92-ボトルネック解析)と比較した。  
なお、DRPで動作する4アルゴリズムの平均処理時間には、有意な差は無かった。

| 項目                                   | 変更前    | 変更後    |
|---------------------------------------|-------:|-------:|
| `Image processing`　　　　　　　　　　| 402.13  | 91.331 |
| `　　convert to RGB or YUYV`  　　　　|  12.168 |  0.001 |
| `　　resize●` 　　　　　　　　　　　　|  17.623 |  0.000 |
| `　　bottom padding`  　　　　　　　　|  14.744 |  0.649 |
| `　　copy input to physical memory`   |   5.823 |  0.510 |
| `　　PreRuntime::Pre` 　　　　　　　　|  16.487 |  5.455 |
| `　　MeraDrpRuntimeWrapper::SetInput` |   3.431 |  8.093 |
| `　　MeraDrpRuntimeWrapper::Run`  　　| 249.092 | 16.623 |
| `　　Receive result`  　　　　　　　　|   4.049 |  2.271 |
| `Main loop`   　　　　　　　　　　　　| 415.416 | 92.716 |

以上から、正式版のDRP-AI TVMのYOLOX-Sを使用することによって、SLAMの平均処理時間が減少したことがわかる。

`5.2 ボトルネック解析結果`に記載した、正式版のDRP-AI TVMのYOLOX-Sを組み込んだstella_vslamの評価結果と比較する。

stella_vslamの評価結果は以下の通り。

| 関数                                          |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------|--------:|------------------:|
| `yolo_detector::start[LEFT]`　　　　　　　　|    21.9 |            31.163 |
| `　　convert to RGB or YUYV[LEFT]`  　　　　|     0   |             0.001 |
| `　　bottom padding[LEFT]`  　　　　　　　　|     0.5 |             0.748 |
| `　　copy input to physical memory[LEFT]`   |     0.3 |             0.476 |
| `　　PreRuntime::Pre[LEFT]` 　　　　　　　　|     3.6 |             5.218 |
| `　　MeraDrpRuntimeWrapper::SetInput[LEFT]` |     5.8 |             8.271 |
| `　　MeraDrpRuntimeWrapper::Run[LEFT]`  　　|    11.5 |            16.387 |
| `　　その他` 　　　　　　　　　　　　　　　　|     0.2 |             ----- |

| 関数                            |   割合(%) |   実測値(msec/frame) |
|:------------------------------|--------:|------------------:|
| `yolo_detector::finish[LEFT]` |     1.6 |             2.270 |
| `　　Receive result[LEFT]`　　|     1.5 |             2.262 |
| `　　その他`   　　　　　　　　|     0.1 |             ----- |

Yolo-Planar-SLAMの評価結果は以下の通り。

| 関数                                     |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------|--------:|------------------:|
| `YoloObjectDetect` 　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　convert to RGB or YUYV`   　　　　|     0   |             0.001 |
| `　　resize`   　　　　　　　　　　　　|     0   |             0.000 |
| `　　bottom padding`   　　　　　　　　|     0.7 |             0.649 |
| `　　copy input to physical memory`　　|     0.5 |             0.510  |
| `　　PreRuntime::Pre`  　　　　　　　　|     5.9 |             5.455 |
| `　　MeraDrpRuntimeWrapper::SetInput`  |     8.8 |             8.093 |
| `　　MeraDrpRuntimeWrapper::Run`   　　|    18.2 |            16.623 |
| `　　Receive result`   　　　　　　　　|     2.4 |             2.271 |

DRP-AIの処理時間に有意な差は無いことがわかる。

## 11 直列動作検証

[別冊_直列動作検証報告書](別冊_直列動作検証報告書.md)に別途記載する。

## 12 画像入力のワークアラウンド

[別冊_ワークアラウンド実装・評価報告書](別冊_ワークアラウンド実装・評価報告書.md)に別途記載する。

## 13 高速化の実現可能性

Yolo-Planar-SLAMおよびstella_vslamの高速化の実現可能性について記載する。

### 13.1 Yolo-Planar-SLAMのDRP-AI処理のスレッド分割

2024年5月時点で、Yolo-Planar-SLAMのDRP-AI処理はImage processingスレッドに含まれている。  
stella_vslamと同様に、Yolo detectionスレッドに分割した場合に、Yolo-Planar-SLAM全体としての処理時間を削減できる可能性がある。

### 13.2 stella_vslamのDRP-AI動作について

stella_vslamでDRP-AI TranslatorのYOLOモデルを使用できるようにし、DRP-AI TVMではなくDRP-AI TranslatorのYOLOを実行するように変更した方が、高速に動作する可能性がある。

### 13.3 CPU-DRP連携のポーリング周期について

[補足資料](../../README_Supplementary.md)の`DRP連携のポーリング周期`に記載した通り、CPU-DRP連携のポーリング周期はYolo-Planar-SLAMとstella_vslamで異なる。  
このポーリング周期を適切な値にチューニングすることで、Yolo-Planar-SLAMやstella_vslamの処理時間を削減できる可能性がある。

### 13.4 DRP実装の高速化について

以下の点でDRP実装の高速化の余地がある。  
なお、2024年5月時点の仕様・性能については[補足資料](../../README_Supplementary.md)の`DRP実装の仕様・性能`に記載してある。

- 入出力のマルチチャネル対応
- 入出力のマルチバイト対応
- 最新バージョンのMusketeerでコンフィギュレーションコードを生成する
- 最新バージョンのMusketeerで反復合成を行う
- 2パス合成を行う

### 13.5 OpenCVAのFASTのDRP制約条件の緩和

[補足資料](../../README_Supplementary.md)の`DRP連携`に記載した通り、OpenCVAのFASTでは入力画像の縦サイズ、横サイズのいずれも16以上の偶数の場合のみDRPが使用されるため、SLAMプログラムではDRPが使用されない可能性がある。  
OpenCVAのFASTでDRPを使用するための制約条件を緩和することで、DRPが使用されないケースを減らし、高速化できる可能性がある。

### 13.6 orb_descriptorsの実数処理について

orb_descriptorsの入力は浮動小数点ではなく、固定小数点で行うように実装されている。  
浮動小数点で入力するように変更することで、固定小数点との間の変換処理が省略でき、高速化できる可能性がある。

### 13.7 SRAMの使用

DRP実装の実行時に、V2xボードに搭載されているSRAMを使用するように変更することで、高速化できる可能性がある。

## 14 今後の懸念

今後の懸念について記載する。

### 14.1 ワークアラウンドによる性能の低下の懸念について

[別冊_ワークアラウンド実装・評価報告書](別冊_ワークアラウンド実装・評価報告書.md)に記載したワークアラウンドによって、SLAMプログラムの処理時間が増加する懸念がある。  
特に、画像読み込みに失敗した場合に処理時間が増加する懸念がある。

### 14.2 DRP実装のorb_descriptorsの演算精度について

`3 stella_vslamの高速化試行`に記載した通り、高速化のためにorb_descriptorsのDRP実装をFP32からFP16に変更した。  
このため、FP32の場合と比較して演算精度が低下し、本案件で評価していない実行条件によっては、SLAM精度への悪影響が発生する懸念がある。
