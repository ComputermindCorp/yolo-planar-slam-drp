# Stella VSLAM+AI連携アプリ 実装・評価報告書

株式会社Fixstars Autonomous Technologies  
v1.0, 2024-03-18

## 1 はじめに

本書は案件「DRP-AIアプリ（AI+SLAM連携）のアプリ品種拡張コーディング」におけるStella VSLAM+AI連携アプリ 実装・評価報告書である。  
本書ではYolo-Planar-SLAMとstella_vslamに関する作業について、下記の点を記載する。

- 評価環境
- バージョン1移行
- stella_vslamのデータセット検証
- stella_vslamのYocto適合
- MMNGRの調査
- DRP-AI TVMの環境構築
- stella_vslamのグレースケール入力の動作確認
- Yolo-Planar-SLAMへのDRP-AI TVMのYOLOX-Sの組み込み
- stella_vslamへのDRP-AI TVMのYOLOX-Sの組み込み
- stella_vslamのOpenCVA適合
- stella_vslamのログ出力の追加・仕様変更
- stella_vslamのtracking timeの描画対応
- stella_vslamのステレオモード適合
- stella_vslamのDRPドライバネイティブ適合
- Yolo-Planar-SLAMの直列動作検証の検討
- stella_vslamの高速化試行
- Yolo-Planar-SLAMのROS2対応検討
- 今後の懸念

## 2 評価環境

本章では、本案件で使用した評価環境（ハードウェア、ソフトウェア）の情報を記載する。

### 2.1 ハードウェア

#### 2.1.1 Intel CPU搭載PC

- CPU：Intel(R) Core(TM) i7-8700 CPU @ 3.20GHz
    - 物理コア数：6
    - コアあたりのスレッド数：2
- メモリ：48GB

#### 2.1.2 Raspberry Pi 4 Model B Rev 1.4

- CPU：Broadcom BCM2711, Quad core Cortex-A72 (ARM v8) 64-bit SoC @ 1.5GHz
    - 物理コア数：4
    - コアあたりのスレッド数：1
- メモリ：8GB

#### 2.1.3 V2xボード（α2、EVK-α、電力改善版）

- CPU：Cortex-A55 @ 1.7GHz
    - 物理コア数：4
    - コアあたりのスレッド数：1
- メモリ：16GB
- S/N number：33001049

### 2.2 ソフトウェア

#### 2.2.1 Intel CPU搭載PC

- OS：Ubuntu 18.04 64bit
- Musketeer：Ver.20230724
- CVC：7.00b(open_src_cvc_700c_tar.bz2)

#### 2.2.2 Raspberry Pi 4 Model B Rev 1.4

- OS：Ubuntu Server 18.04 64bit
- gcc：7.5.0
- OpenCV：4.1.0
- Eigen：3.3.4
- Boost：1.65.1
- socket.io-client-cpp：[ff6ef08](https://github.com/shinsumicco/socket.io-client-cpp/commit/ff6ef08e45c594e33aa6bc19ebdd07954914efe0)
- g2o：20230223
- Node.js：12.22.2
- socket.io：2.0.4
- express：4.16.2
- ejs：2.5.7
- yaml-cpp：0.5.2
- suitesparse-config：5.1.2
- suitesparse-cxsparse：5.1.2
- socket_publisher：0.0.1

#### 2.2.3 V2xボード（α2、EVK-α、電力改善版）

- OS：CIP Linux
- gcc：8.3.0
- OpenCV：4.1.0
- PCL：1.9.1
- Eigen：3.3.7
- flann：1.9.1
- Boost：1.72.0
- socket.io-client-cpp：1.6.0
- g2o：20230223
- Node.js：12.22.12
- socket.io：2.0.4
- express：4.16.2
- ejs：2.5.7
- yaml-cpp：0.8.0
- suitesparse-config：5.4.0
- suitesparse-cxsparse：5.4.0
- socket_publisher：0.0.1
- socket_viewer：[e1e14ee](https://github.com/stella-cv/socket_viewer/tree/e1e14eec215f5022c84185781ba8d81de22a6f40)

### 2.3 評価データ

Yolo-Planar-SLAMの評価については、RGB画像とDepth画像を含み、ORB-SLAM2およびYolo-Planar-SLAMが対応している形式である[TUM Dataset](https://vision.in.tum.de/data/datasets/rgbd-dataset/download)の`fr3/walking_xyz`を使用する。  
以降では`rgbd_dataset_freiburg3_walking_xyz`と記載する。  
また、このデータセットの画像をグレースケールに変換したデータセットである`GRAY_rgbd_dataset_freiburg3_walking_xyz`を受領した。  
合わせて使用する。

stella_vslamの単眼モードとRGB-Dモードの評価については、RGB画像とDepth画像を含み、stella_vslamが対応している形式である[TUM Dataset](https://vision.in.tum.de/data/datasets/rgbd-dataset/download)の`fr3/walking_halfsphere`を使用する。  
以降では`rgbd_dataset_freiburg3_walking_halfsphere`と記載する。

stella_vslamのステレオモードの評価については、左右のカメラ画像を含み、stella_vslamが対応している形式である[The EuRoC MAV Dataset](https://projects.asl.ethz.ch/datasets/doku.php?id=kmavvisualinertialdatasets)の`vicon_room1/V1_01_easy`を使用する。  
以降では`V1_01_easy`と記載する。

## 3 バージョン1移行

受領したバージョン1のBSPファイル一式を使用して、Yocto環境を構築した。  
また、Yolo-Planar-SLAMもバージョン1のYocto環境でビルドし、β版の時点から動作に変更がないのかを確認した。

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1000
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：RGB入力（`YOLOX_S_dense_640x640_RGB_10271351`）
- DRP/DRP-AIドライバ：**バージョン1**

なお、投機実行の後に`max_features`が更新され、再実行が発生した回数は、859フレーム中1回だった。

まず、OpenCVAとDRPドライバネイティブとDRP-AIの入出力データをダンプし、2023年11月末時点のダンプ結果と比較して最初の3フレーム分の結果が厳密に一致していることを確認した。

次に、ボトルネック解析を行った。  
ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

### 3.1 Image loadingスレッド

| 関数                                       |   割合(%) |   実測値(msec/frame) |
|:-----------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　|   100   |            14.552 |
| `　　cv::imread` 　　　　　　　　　　　　|    99.9 |            14.546 |

### 3.2 Image processingスレッド

`[0]`は投機実行時の値を、`[1]`は投機実行後に`max_features`の値が更新されて再実行された時の値を、`[0-7]`は全レベルの合算値であることをそれぞれ示す。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            66.836 |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.8 |             0.573 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB or YUYV`　　　　　　　　　　　　　　　　　　|     1   |             0.727 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     1.2 |             0.806 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     7.6 |             5.09  |
| `　　　　polling`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.02  |
| `　　　　Yolo*Model::get_object_detection`  　　　　　　　　　　　　|     0   |             0.017 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　 ----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     4.9 |             3.277 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     4.6 |             3.105 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　 ----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.032 |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     0.5 |             0.397 |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     0   |             0.037 |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.4 |             0.306 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    52   |            34.769 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.2 |             2.15  |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     3.7 |             2.492 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     4.7 |             3.206 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.006 |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     4.3 |             2.933 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.005 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　 ----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.02  |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.025 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.8 |             0.554 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.023 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.042 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             0.309 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     6.1 |             4.131 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.043 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.017 |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            66.836 |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    75.1 |            50.199 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|    21.6 |            14.456 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     3.2 |             2.15  |

### 3.3 Trackingスレッド

| 関数                                                                         |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |            68.277 |
| `　　Sleep specified at execution` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`   　　　　　　　　　　　　　　|     0   |             0.062 |
| `　　System::Track*`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.4 |            67.928 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`  　　　　　　　　|    36.2 |            24.769 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true` 　　|     0   |             0     |
| `　　　　Tracking::GrabImage*` 　　　　　　　　　　　　　　　　　　　　　　|    63.1 |            43.131 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction` |     0.9 |             0.634 |
| `　　　　　　Tracking::Track`  　　　　　　　　　　　　　　　　　　　　　　|    62.2 |            42.489 |
| `　　　　　　　　Map::mMutexMapUpdate` 　　　　　　　　　　　　　　　　　　|     3.9 |             2.665 |
| `　　　　　　　　Tracking::MonocularInitialization`　　　　　　　　　　　　|     4.8 |             3.297 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`  　　　　　　　　|     1.1 |             0.811 |
| `　　　　　　　　Tracking::TrackWithMotionModel`   　　　　　　　　　　　　|    19.2 |            13.164 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     9.9 |             6.783 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection` 　　　　　　　　|     8.9 |             6.132 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection`　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`  　　　　　　　　　　　　　　　　|    31.6 |            21.633 |
| `　　　　　　　　　　Tracking::UpdateLocalMap` 　　　　　　　　　　　　　　|     2.8 |             1.968 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     9.9 |             6.823 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`  　　　　　　　　　　　　|    18.5 |            12.688 |
| `　　　　　　　　　　　　Project points in frame and check its visibility` |    15.2 |            10.432 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`   　　　　　　　　|     3.1 |             2.154 |

### 3.4 Inferenceスレッド

| 関数                                |   割合(%) |   実測値(msec/frame) |
|:----------------------------------|--------:|------------------:|
| `RecognizeBase::inference_thread` |   100   |            20.813 |
| `　　polling` 　　　　　　　　　　|    90.9 |            18.919 |

### 3.5 考察

[2023年12月末時点のβ版での計測結果](../step1/AI+SLAM連携アプリ%20実装・評価報告書.md)と比較する。

`Image loading`は`10.272`\[ms/frame\]から`14.552`\[ms/frame\]となっている。

`Image processing`は`70.863`\[ms/frame\]から`66.836`\[ms/frame\]となっている。  
このうち、OpenCVA/DRPドライバネイティブ/DRP-AIで動作する処理は以下のようになった。

- `Resize[0-7]●`は`5.791`\[ms/frame\]から`3.277`\[ms/frame\]
- `GaussianBlur[0-7]●`は`4.289`\[ms/frame\]から`3.105`\[ms/frame\]
- `FAST[0-7]●`は`34.924`\[ms/frame\]から`34.769`\[ms/frame\]
- `computeDescriptors`の`DRP time[0][0-7]★`は`4.130`\[ms/frame\]から`4.131`\[ms/frame\]
- `computeDescriptors`の`DRP time[1][0-7]★`は`0.006`\[ms/frame\]から`0.006`\[ms/frame\]

`Main loop`は`72.35`\[ms/frame\]から`68.277`\[ms/frame\]となっている。

`RecognizeBase::inference_thread`は`22.861`\[ms/frame\]から`20.813`\[ms/frame\]となっている。  
このうち、`polling`は`20.898`\[ms/frame\]から`18.919`\[ms/frame\]となっている。

以上から、以下のことが言える。

- Resize、GaussianBlur、DRP-AIのYOLOX-Sについてはβ版の場合と比較してバージョン1では高速に動作するようになった
- FAST、computeOrbDescriptorsについては有意な性能の差は見られなかった

## 4 stella_vslamのデータセット検証

stella_vslamで使用するデータセットの選定・動作検証について記載する。

Yolo-Planar-SLAMと異なり、stella_vslamには人のバウンディングボックスを使用した特徴点間引きの処理が含まれていない。  
そのため、stella_vslamで人が映りこんでいるデータセットを使用する場合にはSLAM精度が破綻する可能性が高い。  
そこで、stella_vslamの単眼、ステレオ、RGB-Dモードのそれぞれで使用するデータセットの選定・動作検証を行った。

stella_vslamの各実行ファイルのソースコードを確認したところ、それぞれ以下のモードに対応していることがわかった。

- run_camera_slam.cc：単眼、ステレオ
- run_euroc_slam.cc：単眼、ステレオ
- run_image_slam.cc：単眼
- run_kitti_slam.cc：単眼、ステレオ
- run_tum_rgbd_slam.cc：単眼、RGB-D
- run_video_slam.cc：単眼

RGB-Dモードに対応しているのは`run_tum_rgbd_slam`のみであることがわかる。  
また、データセットを使用する場合にステレオモードに対応しているのは`run_euroc_slam`と`run_kitti_slam`のみであることがわかる。  
よって、単眼、ステレオ、RGB－Dの3つのモードで評価を行うためには、TUMデータセットから少なくとも1種類、EuRoCデータセットまたはKITTIデータセットから少なくとも1種類のデータセットを選定する必要がある。

### 4.1 単眼

まず、単眼モードについて確認を行った。  
以下の10種類のTUMデータセットについて、RasPi4上でSLAM精度の確認を行った。

- rgbd_dataset_freiburg1_desk：正常
- rgbd_dataset_freiburg1_xyz：正常
- rgbd_dataset_freiburg3_sitting_halfsphere：破綻
- rgbd_dataset_freiburg3_sitting_rpy：破綻
- rgbd_dataset_freiburg3_sitting_static：破綻
- rgbd_dataset_freiburg3_sitting_xyz：正常
- rgbd_dataset_freiburg3_walking_halfsphere：正常
- rgbd_dataset_freiburg3_walking_rpy：破綻
- rgbd_dataset_freiburg3_walking_static：破綻
- rgbd_dataset_freiburg3_walking_xyz：正常

RasPi4上でSLAM精度が破綻しなかった5種類のTUMデータセットについて、追加で5回ずつ実行し、SLAM精度の確認を行った。

- rgbd_dataset_freiburg1_desk：破綻するケースを含む
- rgbd_dataset_freiburg1_xyz：正常
- rgbd_dataset_freiburg3_sitting_xyz：正常
- rgbd_dataset_freiburg3_walking_halfsphere：正常
- rgbd_dataset_freiburg3_walking_xyz：破綻するケースを含む

RasPi4上でSLAM精度の破綻が確認されなかった3種類のデータセットについて、目視確認を行いカメラの移動範囲が最も広かった`rgbd_dataset_freiburg3_walking_halfsphere`を採用した。  
なお、`rgbd_dataset_freiburg3_walking_halfsphere`は人が映りこんでいるデータセットである。

また、V2xボード（α2、EVK-α、電力改善版）上で`rgbd_dataset_freiburg3_walking_halfsphere`について5回実行し、SLAM精度が破綻するケースが含まれていないことを確認した。

### 4.2 RGB-D

次に、RGB-Dモードについて確認を行った。

まず、単眼モードの時と同様に`rgbd_dataset_freiburg3_walking_halfsphere`を使用した場合について5回ずつ実行し、SLAM精度の確認を行った。  
5回ともSLAM精度の破綻は確認されなかった。  
以上から`rgbd_dataset_freiburg3_walking_halfsphere`を採用した。

また、V2xボード（α2、EVK-α、電力改善版）上で`rgbd_dataset_freiburg3_walking_halfsphere`について5回実行し、SLAM精度が破綻するケースが含まれていないことを確認した。

### 4.3 ステレオ

次に、ステレオモードについて確認を行った。

TUMデータセットには左右の画像は含まれていない。  
（RGB画像とDepth画像のみが含まれている）

`V1_01_easy`には左右の画像が含まれている。  
そこでステレオモードで`V1_01_easy`を使用した場合について5回ずつ実行し、SLAM精度の確認を行った。  
5回ともSLAM精度の破綻は確認されなかった。  
以上から`V1_01_easy`を採用した。

また、V2xボード（α2、EVK-α、電力改善版）上で`V1_01_easy`について5回実行し、SLAM精度が破綻するケースが含まれていないことを確認した。

## 5 stella_vslamのYocto適合

V2xボード（α2、EVK-α、電力改善版）上でstella_vslamを動作確認・評価した作業について記載する。

### 5.1 クロスコンパイル検証

また、stella_vslamをバージョン1のYocto環境でビルドできるように対応を行った。

#### 5.1.1 g2oのソースビルド

公式のstella_vslamでは、g2oをソースビルドする手順となっている。  
これを踏襲し、公式のstella_vslamと同様のバージョンのg2oをバージョン1のYocto環境でビルドできるように対応を行った。  
なお、`cmake`の実行時オプションは[公式のDockerfile.socket](https://github.com/stella-cv/stella_vslam/blob/0.4.0/Dockerfile.socket#L86-L98)と同等である。  
特に、`G2O_USE_OPENGL`には`OFF`を指定している点に注意する。

`g2oConfig.cmake`に以下の記述が含まれている。

```cmake
find_dependency(OpenGL)
```

`G2O_USE_OPENGL`には`OFF`を指定しているため、`OpenGL`は不要であると考えられる。  
また、上記の記述が有効であるとバージョン1のYocto環境で上記のg2oを参照してアプリをビルドするときにOpenGLの参照でエラーとなる。  
そこで、本案件では`find_dependency(OpenGL)`をコメントアウトする対応を行った。

#### 5.1.2 レシピの追加

ビルドする対象がYolo-Planar-SLAMではくstella_vslamとなったため、メタパッケージの名称を`meta-yolo-planar-slam`から`meta-stella-vslam`に変更した。  
なお、Yolo-Planar-SLAMは`meta-stella-vslam`を使用してもビルド可能である。

stella_vslamでは、新たにyaml-cppへの依存が発生するため、レシピを作成した。  
また、[`g2o::solver_csparse`と`g2o::csparse_extension`への依存](https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/CMakeLists.txt#L24-L25)が含まれており、suitesparse-cxsparseへの依存が発生するため、suitesparse-cxsparseと、その依存ライブラリであるsuitesparse-configのレシピを作成した。  
なお、suitesparse-cxsparseはLGPLであるため、`build/conf/local.conf`に`WHITELIST_GPL-3.0 = " suitesparse-cxsparse suitesparse-config "`を追加する必要がある。

### 5.2 処理時間計測機能の追加

stella_vslamへの処理時間計測機能の追加を行った。  
なお、画像処理に関する処理時間計測用コードについて、左画像と右画像の処理時間を別々に計測する必要がある。  
そのため、処理時間計測用コードを左右で分離し、左画像と右画像のそれぞれで処理時間を計測できるように対応した。  
ただし、オリジナルのstella_vslamの左画像と右画像の処理はそれぞれ別スレッドで動作するため、並列に実行されている点に注意する。

合わせて`match::stereo::compute`などのステレオモードでのみ実行される処理についても処理時間を計測できるように対応を行った。

### 5.3 動作確認・評価

V2xボード（α2、EVK-α、電力改善版）上でstella_vslamの動作確認と評価を行った。

#### 5.3.1 単眼

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- DRP：無し
- DRP-AI：無し
- OpenCVA：無し
- DRP-AIオブジェクトファイル：無し
- DRP/DRP-AIドライバ：バージョン1

##### 5.3.1.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   frame_trajectory.v2x.2024.mono.cpu.none.3wh.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.562096
      mean      0.041194
    median      0.028623
       min      0.003461
      rmse      0.068847
       sse      5.033743
       std      0.055163

```

最大誤差が`56`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   frame_trajectory.v2x.2024.mono.cpu.none.3wh.txt \
>   --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.mono.cpu.none.3wh
infos:  1062 poses, 21.540m path length, 35.728s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/original/mono/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/original/mono/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/original/mono/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 5.3.1.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
`[LEFT]`は左画像についての処理を示す。

| 関数                                                                            |   割合(%) |   実測値(msec/frame) |
|:------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           132.211 |
| `　　Sleep while waiting for the next frame`  　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　cv::imread`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    13.7 |            18.225 |
| `　　system::feed_*_frame`　　　　　　　　　　　　　　　　　　　　　　　　　　|    86.1 |           113.962 |
| `　　　　util::convert_to_grayscale`  　　　　　　　　　　　　　　　　　　　　|     0.6 |             0.914 |
| `　　　　camera::base::undistort_keypoints`   　　　　　　　　　　　　　　　　|     0.4 |             0.609 |
| `　　　　camera::base::convert_keypoints_to_bearings` 　　　　　　　　　　　　|     0.2 |             0.281 |
| `　　　　data::assign_keypoints_to_grid`  　　　　　　　　　　　　　　　　　　|     0.6 |             0.81  |
| `　　　　orb_extractor::extract`  　　　　　　　　　　　　　　　　　　　　　　|    57   |            75.46  |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]`  　　　　　　　　　　|     3.2 |             4.288 |
| `　　　　　　　　Resize[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     3.2 |             4.277 |
| `　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]` 　　　　　　　　　　|    25.5 |            33.74  |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`　　　　　　|    16.8 |            22.32  |
| `　　　　　　　　　　FAST[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|    16.6 |            21.979 |
| `　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]` 　　|     4.6 |             6.083 |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`   　　　　　　|     3.9 |             5.196 |
| `　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　GaussianBlur[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|     4.9 |             6.606 |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]`  　　　　　　　　　　　　　　|    22.8 |            30.265 |
| `　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             ----- |
| `　　　　frame_publisher::update` 　　　　　　　　　　　　　　　　　　　　　　|     0.5 |             0.679 |
| `　　　　tracking_module::feed_frame` 　　　　　　　　　　　　　　　　　　　　|    25   |            33.161 |
| `　　　　　　tracking_module::initialize` 　　　　　　　　　　　　　　　　　　|     0.1 |             0.23  |
| `　　　　　　keyframe_inserter::insert_new_keyframe`  　　　　　　　　　　　　|     0.2 |             0.333 |
| `　　　　　　tracking_module::track`  　　　　　　　　　　　　　　　　　　　　|    23.1 |            30.542 |
| `　　　　　　　　tracking_module::track_current_frame`　　　　　　　　　　　　|     7.5 |             9.995 |
| `　　　　　　　　　　frame_tracker::motion_based_track`   　　　　　　　　　　|     7.5 |             9.972 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`   　　　　|     3.6 |             4.851 |
| `　　　　　　　　　　　　pose_optimizer::optimize`　　　　　　　　　　　　　　|     3.7 |             5.022 |
| `　　　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`　　　　　　　　　　|     0   |             0.002 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`　　　　　　　　　　　　　　|    14.9 |            19.776 |
| `　　　　　　　　　　tracking_module::update_local_map`   　　　　　　　　　　|     4.6 |             6.202 |
| `　　　　　　　　　　tracking_module::search_local_landmarks` 　　　　　　　　|     4.9 |             6.576 |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map`  |     5.2 |             6.994 |
| `　　　　　　　　　　　　pose_optimizer::optimize`　　　　　　　　　　　　　　|     5   |             6.703 |
| `　　　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes` |     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`　　　　　　　　　　　　|     0   |             0.004 |
| `　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             ----- |
| `　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.6 |             ----- |
| `　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.8 |             ----- |
| `　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |

#### 5.3.2 RGB-D

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：RGB-D
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- DRP：無し
- DRP-AI：無し
- OpenCVA：無し
- DRP-AIオブジェクトファイル：無し
- DRP/DRP-AIドライバ：バージョン1

##### 5.3.2.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   frame_trajectory.v2x.2024.rgbd.cpu.none.3wh.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.433401
      mean      0.225722
    median      0.217132
       min      0.063955
      rmse      0.234057
       sse      58.234119
       std      0.061908

```

最大誤差が`43`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   frame_trajectory.v2x.2024.rgbd.cpu.none.3wh.txt \
>   --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.rgbd.cpu.none.3wh
infos:  1063 poses, 17.303m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/original/rgbd/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/original/rgbd/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/original/rgbd/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 5.3.2.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
`[LEFT]`は左画像についての処理を示す。

| 関数                                                                            |   割合(%) |   実測値(msec/frame) |
|:------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           314.16  |
| `　　Sleep while waiting for the next frame`  　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　cv::imread`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     9.2 |            29.165 |
| `　　system::feed_*_frame`　　　　　　　　　　　　　　　　　　　　　　　　　　|    90.7 |           284.974 |
| `　　　　util::convert_to_grayscale`  　　　　　　　　　　　　　　　　　　　　|     0.3 |             0.985 |
| `　　　　util::convert_to_true_depth` 　　　　　　　　　　　　　　　　　　　　|     0.2 |             0.726 |
| `　　　　camera::base::undistort_keypoints`   　　　　　　　　　　　　　　　　|     0.1 |             0.611 |
| `　　　　camera::base::convert_keypoints_to_bearings` 　　　　　　　　　　　　|     0   |             0.283 |
| `　　　　data::assign_keypoints_to_grid`  　　　　　　　　　　　　　　　　　　|     0.2 |             0.827 |
| `　　　　orb_extractor::extract`  　　　　　　　　　　　　　　　　　　　　　　|    25.2 |            79.466 |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]`  　　　　　　　　　　|     1.3 |             4.361 |
| `　　　　　　　　Resize[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     1.3 |             4.342 |
| `　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]` 　　　　　　　　　　|    11.6 |            36.459 |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`　　　　　　|     7.2 |            22.848 |
| `　　　　　　　　　　FAST[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|     7.1 |            22.496 |
| `　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]` 　　|     2.5 |             8.011 |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`   　　　　　　|     1.7 |             5.355 |
| `　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　GaussianBlur[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|     2.3 |             7.515 |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]`  　　　　　　　　　　　　　　|     9.6 |            30.471 |
| `　　　　frame_publisher::update` 　　　　　　　　　　　　　　　　　　　　　　|     0.6 |             2.156 |
| `　　　　tracking_module::feed_frame` 　　　　　　　　　　　　　　　　　　　　|    62.6 |           196.811 |
| `　　　　　　tracking_module::initialize` 　　　　　　　　　　　　　　　　　　|     0   |             0.045 |
| `　　　　　　keyframe_inserter::insert_new_keyframe`  　　　　　　　　　　　　|     0.9 |             2.848 |
| `　　　　　　tracking_module::track`  　　　　　　　　　　　　　　　　　　　　|    60.1 |           189.113 |
| `　　　　　　　　tracking_module::track_current_frame`　　　　　　　　　　　　|     9.9 |            31.37  |
| `　　　　　　　　　　frame_tracker::motion_based_track`   　　　　　　　　　　|     9.9 |            31.301 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`   　　　　|     4.1 |            13.191 |
| `　　　　　　　　　　　　pose_optimizer::optimize`　　　　　　　　　　　　　　|     5.6 |            17.78  |
| `　　　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`　　　　　　　　　　|     0   |             0.018 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`　　　　　　　　　　　　　　|    48.8 |           153.403 |
| `　　　　　　　　　　tracking_module::update_local_map`   　　　　　　　　　　|     9.4 |            29.673 |
| `　　　　　　　　　　tracking_module::search_local_landmarks` 　　　　　　　　|    26   |            81.857 |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map`  |    13.3 |            41.857 |
| `　　　　　　　　　　　　pose_optimizer::optimize`　　　　　　　　　　　　　　|    12.9 |            40.678 |
| `　　　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             ----- |
| `　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes` |     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`　　　　　　　　　　　　|     0   |             0.005 |
| `　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.4 |             ----- |
| `　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.6 |             ----- |
| `　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     1.5 |             ----- |
| `　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |

#### 5.3.3 ステレオ

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：V1_01_easy
- モード：Stereo
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- DRP：無し
- DRP-AI：無し
- OpenCVA：無し
- DRP-AIオブジェクトファイル：無し
- DRP/DRP-AIドライバ：バージョン1

##### 5.3.3.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum data.tum frame_trajectory.v2x.2024.stereo.cpu.none.euroc.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.166122
      mean      0.082270
    median      0.075975
       min      0.019698
      rmse      0.087577
       sse      22.027230
       std      0.030023

```

最大誤差が`16`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=data.tum frame_trajectory.v2x.2024.stereo.cpu.none.euroc.txt --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.stereo.cpu.none.euroc
infos:  2872 poses, 58.862m path length, 143.550s duration
--------------------------------------------------------------------------------
name:   data
infos:  28712 poses, 58.592m path length, 143.555s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/original/stereo/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/original/stereo/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/original/stereo/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 5.3.3.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
`[LEFT]`は左画像を、`[RIGHT]`は右画像についての処理を示す。

| 関数                                                                            |   割合(%) |   実測値(msec/frame) |
|:------------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           306.994 |
| `　　Sleep while waiting for the next frame`  　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　cv::imread`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     2.9 |             8.976 |
| `　　system::feed_*_frame`　　　　　　　　　　　　　　　　　　　　　　　　　　|    93.8 |           288.037 |
| `　　　　util::convert_to_grayscale`  　　　　　　　　　　　　　　　　　　　　|     0   |             0.002 |
| `　　　　camera::base::undistort_keypoints`   　　　　　　　　　　　　　　　　|     0.1 |             0.4   |
| `　　　　camera::base::convert_keypoints_to_bearings` 　　　　　　　　　　　　|     0.2 |             0.616 |
| `　　　　data::assign_keypoints_to_grid`  　　　　　　　　　　　　　　　　　　|     0.1 |             0.453 |
| `　　　　match::stereo::compute`  　　　　　　　　　　　　　　　　　　　　　　|    36.8 |           113.259 |
| `　　　　　　loop in match::stereo::compute`  　　　　　　　　　　　　　　　　|    36.6 |           112.426 |
| `　　　　　　std::sort`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.066 |
| `　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　orb_extractor::extract`  　　　　　　　　　　　　　　　　　　　　　　|    22.3 |            68.65  |
| `　　　　frame_publisher::update` 　　　　　　　　　　　　　　　　　　　　　　|     0.4 |             1.44  |
| `　　　　tracking_module::feed_frame` 　　　　　　　　　　　　　　　　　　　　|    33   |           101.591 |
| `　　　　　　tracking_module::initialize` 　　　　　　　　　　　　　　　　　　|     0   |             0.007 |
| `　　　　　　keyframe_inserter::insert_new_keyframe`  　　　　　　　　　　　　|     0.2 |             0.904 |
| `　　　　　　tracking_module::track`  　　　　　　　　　　　　　　　　　　　　|    31.9 |            98.138 |
| `　　　　　　　　tracking_module::track_current_frame`　　　　　　　　　　　　|     5.7 |            17.744 |
| `　　　　　　　　　　frame_tracker::motion_based_track`   　　　　　　　　　　|     5.7 |            17.725 |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`   　　　　|     1.8 |             5.599 |
| `　　　　　　　　　　　　pose_optimizer::optimize`　　　　　　　　　　　　　　|     3.9 |            11.983 |
| `　　　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`　　　　　　　　　　|     0   |             0.009 |
| `　　　　　　　　　　frame_tracker::robust_match_based_track` 　　　　　　　　|     0   |             0     |
| `　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　　　　　relocalizer::relocalize` 　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　　　　　tracking_module::track_local_map`　　　　　　　　　　　　　　|    25.9 |            79.79  |
| `　　　　　　　　　　tracking_module::update_local_map`   　　　　　　　　　　|    10.9 |            33.702 |
| `　　　　　　　　　　tracking_module::search_local_landmarks` 　　　　　　　　|     9   |            27.769 |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map`  |     5.9 |            18.313 |
| `　　　　　　　　　　　　pose_optimizer::optimize`　　　　　　　　　　　　　　|     5.7 |            17.741 |
| `　　　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　|     0.2 |             ----- |
| `　　　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes` |     0   |             0     |
| `　　　　　　　　tracking_module::update_motion_model`　　　　　　　　　　　　|     0   |             0.004 |
| `　　　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.3 |             ----- |
| `　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             ----- |
| `　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.9 |             ----- |
| `　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     3.3 |             ----- |

上記の`orb_extractor::extract`は、左画像と右画像それぞれについての`orb_extractor::extract`の処理を開始してから、完了するまでの処理時間を示している。  
ここで、左画像と右画像それぞれについての`orb_extractor::extract`は別スレッドで実行されるため、並列に動作する。  
左画像と右画像それぞれについての`orb_extractor::extract`の内訳は以下の通り。

| 関数                                                                    |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------|--------:|------------------:|
| `orb_extractor::extract[LEFT]`　　　　　　　　　　　　　　　　　　　　|　　---- |　　　　　　----- |
| `　　orb_extractor::compute_image_pyramid[LEFT]`  　　　　　　　　　　|     2.1 |             6.716 |
| `　　　　Resize[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     2.1 |             6.705 |
| `　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　orb_extractor::compute_fast_keypoints[LEFT]` 　　　　　　　　　　|     9.3 |            28.736 |
| `　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`　　　　　　|     6.9 |            21.3   |
| `　　　　　　FAST[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|     6.8 |            21.023 |
| `　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]` 　　|     1.1 |             3.545 |
| `　　　　orb_extractor::compute_orientation[LEFT][0-7]`   　　　　　　|     1.2 |             3.766 |
| `　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　GaussianBlur[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|     4.5 |            14.072 |
| `　　compute_orb_descriptors[LEFT][0-7]`  　　　　　　　　　　　　　　|     5.3 |            16.551 |

| 関数                                                                    |   割合(%) |   実測値(msec/frame) |
|:----------------------------------------------------------------------|--------:|------------------:|
| `orb_extractor::extract[RIGHT]`   　　　　　　　　　　　　　　　　　　|　　---- |　　　　　　----- |
| `　　orb_extractor::compute_image_pyramid[RIGHT]` 　　　　　　　　　　|     2.1 |             6.668 |
| `　　　　Resize[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　|     2.1 |             6.659 |
| `　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　orb_extractor::compute_fast_keypoints[RIGHT]`　　　　　　　　　　|     9.2 |            28.55  |
| `　　　　orb_extractor::compute_fast_keypoints[RIGHT][0-7]`   　　　　|     6.8 |            21.173 |
| `　　　　　　FAST[RIGHT][0-7]`　　　　　　　　　　　　　　　　　　　　|     6.8 |            20.899 |
| `　　　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             ----- |
| `　　　　orb_extractor::distribute_keypoints_via_tree[RIGHT][0-7]`　　|     1.1 |             3.461 |
| `　　　　orb_extractor::compute_orientation[RIGHT][0-7]`  　　　　　　|     1.2 |             3.788 |
| `　　　　その他`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             ----- |
| `　　GaussianBlur[RIGHT][0-7]`　　　　　　　　　　　　　　　　　　　　|     4.6 |            14.334 |
| `　　compute_orb_descriptors[RIGHT][0-7]` 　　　　　　　　　　　　　　|     5.3 |            16.557 |

#### 5.3.4 考察

Trackingスレッド全体の平均処理時間は以下の通り。  
ただし、単眼・RGB-Dモードとステレオモードでは使用しているデータセットが異なる点に注意する。

- 単眼：`132.211`\[ms/frame\]
- RGB-D：`314.160`\[ms/frame\]
- ステレオ：`306.994`\[ms/frame\]

このうち、画像処理である`orb_extractor::extract`の平均処理時間は以下の通り。  
なお、ステレオモードでは左画像と右画像の2スレッドが並列に動作している点に注意する。

- 単眼：`75.460`\[ms/frame\]
- RGB-D：`79.466`\[ms/frame\]
- ステレオ：`68.650`\[ms/frame\]

また、最適化処理である`tracking_module::feed_frame`の平均処理時間は以下の通り。

- 単眼：`33.161`\[ms/frame\]
- RGB-D：`196.811`\[ms/frame\]
- ステレオ：`101.591`\[ms/frame\]

`tracking_module::feed_frame`の処理時間の内訳のうち、`その他`の割合は十分に小さい。  
また、呼び出されている関数も表に記載した範囲ではモードごとに差異は無い。  
そのため、モードごとに`tracking_module::feed_frame`で処理される特徴点の個数が大きく異なるために処理時間に差がある可能性が考えられる。

##### 5.3.4.1 Yolo-Planar-SLAMとの比較

Yolo-Planar-SLAMの単眼モードでは`GRAY_rgbd_dataset_freiburg3_walking_xyz`を使用している。  
Yolo-Planar-SLAMのRGB-Dモードでは`rgbd_dataset_freiburg3_walking_xyz`を使用している。  
stella_vslamの単眼モードとRGB-Dモードでは`rgbd_dataset_freiburg3_walking_halfsphere`を使用している。  
Yolo-Planar-SLAMとstella_vslamでは使用しているデータセットが異なる点に注意する。

今回のstella_vslamのTrackingスレッド全体の平均処理時間は以下の通り。

- 単眼：`132.211`\[ms/frame\]
- RGB-D：`314.160`\[ms/frame\]

[2023年時点のYolo-Planar-SLAMでの単眼の評価結果](../step1/AI+SLAM連携アプリ%20実装・評価報告書.md)は以下の通り。

- `Image loading`が`9.252`\[ms/frame\]
- `Image processing`が`91.056`\[ms/frame\]
    - YOLO含む
    - 排他制御の待ち時間は十分に短い
- `Main loop`が`92.512`\[ms/frame\]
    - うち、排他制御の待ち時間は`43.534`\[ms/frame\]

マルチスレッド対応を無効化した場合を考えると`9.252 + 91.056 + 92.512 - 43.534 = 149.286`\[ms/frame\]となる。  
使用したTUMデータセットが異なるため単純な比較はできないが、stella_vslamの方が高速に動作しているように見える。

[2023年時点のYolo-Planar-SLAMでのRGB-Dの評価結果](../step1/AI+SLAM連携アプリ%20実装・評価報告書.md)は以下の通り。

- `Image loading`が`48.514`\[ms/frame\]
- `Image processing`が`120.981`\[ms/frame\]
    - YOLO含む
    - うち、排他制御の待ち時間は`16.057`\[ms/frame\]
- `Main loop`が`122.510`\[ms/frame\]
    - 排他制御の待ち時間は十分に短い

マルチスレッド対応を無効化した場合を考えると`48.514 + 120.981 - 16.057 + 122.510 = 275.948`\[ms/frame\]となる。  
使用したTUMデータセットが異なるため単純な比較はできないが、Yolo-Planar-SLAMの方が高速に動作しているように見える。

RGB-Dの場合でも画像処理についてはstella_vslamの方が高速に動作している。  
Yolo-Planar-SLAMの`Tracking::TrackLocalMap`が`50.633`\[ms/frame\]であるのに対して、stella_vslamの`tracking_module::track_local_map`が`153.403`\[ms/frame\]であるため、処理時間にかなりの差がある。

##### 5.3.4.2 最大特徴点数について

stella_vslamでは、Yolo-Planar-SLAMの最大特徴点数（`ORBextractor.nFeatures`）に相当する設定値は存在しない。  
この変更は<https://github.com/stella-cv/stella_vslam/pull/299>で行われている。  
また、以下の記載がある。

> This change removes the resolution-dependent parameters `Preprocessing::max_num_keypoints` and `Preprocessing::ini_max_num_keypoints`, and adds a resolution-independent `Preprocessing::min_size` parameter.

`Preprocessing::min_size`については[Parameters](https://stella-cv.readthedocs.io/en/0.4.0/parameters.html)に以下の記載がある。

> Size of node occupied by one feature point. The larger this value, the fewer feature points are extracted.

そこで、`Preprocessing::min_size`を変更した場合のstella_vslamの挙動の変化を確認した。

`min_size`をデフォルトの`800`から`100`に変更したところ、`orb_extractor::distribute_keypoints_via_tree`の後の特徴点数が0レベルでは約4倍になった。  
`min_size`をデフォルトの`800`から`2000`に変更したところ、`orb_extractor::distribute_keypoints_via_tree`の後の特徴点数が7レベルでは約半分になった。  
0～4レベルでは、確認した限りでは変化が無かった。

以上から、トラッキングで使用したい特徴点を増やしたい場合には`min_size`を小さくし、特徴点を減らしたい場合には`min_size`を大きくすることでチューニングが可能であると考えられる。

##### 5.3.4.3 各モードと、特徴点・ランドマークの個数について

モードごとの`tracking_module::update_local_map`の平均処理時間は以下の通り。  
ただし、単眼・RGB-Dモードとステレオモードで使用しているデータセットが異なる点に注意する。

- 単眼：`6.202`\[ms/frame\]
- RGB-D：`29.673`\[ms/frame\]
    - 単眼の約`4.7`倍
- ステレオ：`33.702`\[ms/frame\]
    - 単眼の約`5.4`倍

また、モードごとの`tracking_module::search_local_landmarks`の平均処理時間は以下の通り。

- 単眼：`6.576`\[ms/frame\]
- RGB-D：`81.857`\[ms/frame\]
    - 単眼の約`12.4`倍
- ステレオ：`27.769`\[ms/frame\]
    - 単眼の約`4.2`倍

モードごとに平均処理時間に大きな差があることがわかる。

そこで、単眼、ステレオ、RGB-Dモードのそれぞれで特徴点・ランドマークの個数の差を確認した。  
ただし、単眼・RGB-Dモードとステレオモードで使用しているデータセットが異なる点に注意する。

単眼モードでは以下の通り。

- `tracking_module::update_local_map`の中の`curr_frm_.frm_obs_.num_keypts_`：`2437`\[num/frame\]
- `tracking_module::search_local_landmarks`の中の`curr_frm_.get_landmarks()`のsize：`2437`\[num/frame\]
- `tracking_module::search_local_landmarks`の中の`local_landmarks_`のsize：`1377`\[num/frame\]

RGB-Dモードでは以下の通り。

- `tracking_module::update_local_map`の中の`curr_frm_.frm_obs_.num_keypts_`：`2440`\[num/frame\]
- `tracking_module::search_local_landmarks`の中の`curr_frm_.get_landmarks()`のsize：`2440`\[num/frame\]
- `tracking_module::search_local_landmarks`の中の`local_landmarks_`のsize：`6399`\[num/frame\]

ステレオモードでは以下の通り。

- `tracking_module::update_local_map`の中の`curr_frm_.frm_obs_.num_keypts_`：`1260`\[num/frame\]
- `tracking_module::search_local_landmarks`の中の`curr_frm_.get_landmarks()`のsize：`1260`\[num/frame\]
- `tracking_module::search_local_landmarks`の中の`local_landmarks_`のsize：`7934`\[num/frame\]

以上から、Depth情報の有無によって、`local_landmarks_`のsizeに、4～6倍の差が発生することが推測できる。  
なお、[keyframe_inserter::create_new_keyframe](https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/module/keyframe_inserter.cc#L132-L135)で、Depth情報の有無によって処理が分岐する。

また、RGB-Dモードとそれ以外のモードの間で[tracking_module::search_local_landmarks](https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/tracking_module.cc#L573-L580)の処理に分岐が発生する。

```cpp
// acquire more 2D-3D matches by projecting the local landmarks to the current frame
match::projection projection_matcher(0.8);
const float margin = (curr_frm_.id_ < last_reloc_frm_id_ + 2)
                         ? 20.0
                         : ((camera_->setup_type_ == camera::setup_type_t::RGBD)
                                ? 10.0
                                : 5.0);
projection_matcher.match_frame_and_landmarks(curr_frm_, local_landmarks_, lm_to_reproj, lm_to_x_right, lm_to_scale, margin);
```

`curr_frm_.id_ < last_reloc_frm_id_ + 2`が`false`の場合に、`margin`の値がRGB-Dとそれ以外の間で2倍異なることがわかる。  
`margin`は、`data::get_keypoints_in_cell`で使用される。  
`data::get_keypoints_in_cell`の返り値である`std::vector<unsigned int>`型の`indices`にインデックス値を格納するときに、`push_back`するかどうかの判定で使用される。  
つまり、`margin`が大きいほど`indices`の要素数は増える。  
`indices`の要素数が増えると`projection::match_frame_and_landmarks`の中のループの範囲も増える。  
そのため、`margin`の値の差が平均処理時間の差の原因になっていると推測できる。

## 6 MMNGRの調査

バージョン1のYocto環境に含まれているMMNGRについて調査を行った結果について記載する。

受領したDRP-AI TVMのYOLOX-Sのサンプルプログラム（`v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119`）は、MMNGRが必須となっていた。  
そのため、本案件で使用するCIP LinuxにMMNGRを含めるために調査と対応を行った。

まず、受領したバージョン1のBSPファイル一式を使用して、`core-image-bsp`をビルドした。  
また、`core-image-bsp`のSDKインストーラーもビルドし、SDKをインストールした。  
このSDKを使用して、サンプルプログラムをビルドすると以下のエラーとなる。

```shell
In file included from /yocto_rzv2x_ver1_workdir/v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/camera/camera.cpp:13:
/yocto_rzv2x_ver1_workdir/v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/camera/camera.h:19:10: fatal error: mmngr_user_public.h: No such file or directory
 #include "mmngr_user_public.h"
          ^~~~~~~~~~~~~~~~~~~~~
```

`mmngr_user_public.h`が含まれていないことがわかる。

次に、`core-image-bsp`の代わりに`core-image-weston`で同様の手順を確認した。  
サンプルプログラムのビルドで上記のエラーは発生しなかった。  
よって、`core-image-weston`にはMMNGRが含まれているが、`core-image-bsp`には含まれていないことがわかる。

本案件で使用するCIP LinuxにMMNGRを追加し、上記のエラーを解消するために、本案件のメタパッケージである`meta-stella-vslam`の`recipes-core/images/core-image-%.bbappend`に、以下の記述を追加した。

```plaintxt
IMAGE_INSTALL_append = " mmngr-user-module mmngrbuf-user-module"
```

上記の変更を加えた後に`core-image-bsp`をビルドした。  
また、`core-image-bsp`のSDKインストーラーもビルドし、SDKを再度インストールした。  
このSDKを使用することで、上記のビルドエラーは解消された。

本案件では以降も`core-image-bsp`に`mmngr-user-module`と`mmngrbuf-user-module`を含めることとする。

## 7 DRP-AI TVMの環境構築

DRP-AI TVMを使用したサンプルプログラムをビルドするために環境構築を行った内容について記載する。

### 7.1 環境構築

`v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119/setup/SetupV2H.md`の手順に従い、DRP-AI TVMの環境構築を行った。  
なお、`1. Preparation`に記載されている手順については行わず、本案件で受領したDRP-AI Translatorのインストーラーを使用した。  
受領したDRP-AI TranslatorのインストーラーのMD5ハッシュ値は以下の通り。

```shell
$ md5sum DRP-AI_Translator_i8-v1.00-Linux-x86_64-Install
58d4a4ea980fc2ffec28b6b045c92d0d  DRP-AI_Translator_i8-v1.00-Linux-x86_64-Install
```

`2.Install DRP-AI Translator`の手順に従ってDRP-AI Translatorのインストールを行った。  
ここで、`sudo`を使用せずに実行したところ、正常にインストールされなかった。  
なお、exit codeは`0`で正常を示しているが、必要なファイルがインストールされていない。  
`SetupV2H.md`には以下の記載がある。

> Please follow the steps below by root or sudo user(Renesas internal only).

本案件で`sudo`を付けるべきかは判断できなかった。  
手順書には`/opt`へインストールするように記載されているが、例えばホームディレクトリ以下にインストールするように変更すれば本不具合は回避できると考えられる。  
しかし、`/opt`以外へインストールした場合に不整合が発生しないのかは判断できなかった。

以上の理由から、本案件では`/opt`の権限を`chmod`で変更し、ユーザーにwrite権限を付与することで本不具合を回避した。

次に、`2. Install the minimal pre-requisites`の手順で`apt`を使用して依存パッケージをインストールした。  
ただし`ppa:ubuntu-toolchain-r/test`の追加は行わなかった。

`3. Clone the respository`の手順は行わなかった。  
本案件では受領した`v210_yolox_tmp_240119.zip`を使用する。

次に`4. Set environment variables`の手順でDRP-AI TVMの環境構築の設定を行った。

```shell
export YOCTO_DIR=/yocto_rzv2x_ver1_workdir
export TVM_ROOT=${YOCTO_DIR:?}/v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119
export TVM_HOME=${TVM_ROOT:?}/tvm
export PYTHONPATH=${TVM_HOME:?}/python:${PYTHONPATH:?}
export SDK=${YOCTO_DIR:?}/bsp_sdk
export TRANSLATOR=/opt/DRP-AI_Translator_i8/translator/
export QUANTIZER=/opt/DRP-AI_Translator_i8/drpAI_Quantizer/
export PRODUCT=V2H
```

次に`5. Setup DRP-AI TVM environment`の手順でDRP-AI TVMの環境構築を行った。

```shell
cd ${TVM_ROOT:?}
bash setup/make_drp_env.sh
```

### 7.2 DRP-AI TVMのYOLOX-Sのサンプルプログラムの確認

ELPカメラは`1920x1080`の画像サイズに対応していないため、`how-to/sample_app_v2h/src/camera/define.h`に以下の変更を行った。

```diff
 /* Output Camera Size */
-#define CAM_INPUT_FHD
+// #define CAM_INPUT_FHD
+#define CAM_INPUT_VGA
 #define IMAGE_OUTPUT_FHD
 #define MIPI_CAM_RES "1920x1080"
```

`how-to/sample_app_v2h/README.md`の手順でDRP-AI TVMのYOLOX-Sのサンプルプログラムをビルドした。

```shell
cd ${TVM_ROOT:?}/how-to/sample_app_v2h/src
rm -rf build
mkdir -p build
cd build
cmake \
  -DCMAKE_TOOLCHAIN_FILE=${TVM_ROOT:?}/apps/toolchain/runtime.cmake \
  ..
make -j1
```

`core-image-weston`のCIP Linux上で、サンプルプログラムを実行したところエラーとなった。

```shell
[04:18:51] /yocto_rzv2x_ver1_workdir/v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119/apps/MeraDrpRuntimeWrapper.cpp:112: Loading input...
[ 4172.065102] (mali-cmar-backe) NOTE: The GFX library has the time limitation by reason of an evaluation module.
Segmentation fault
```

次に、`how-to/sample_app_v2h/src/image.cpp`のパディング処理に関連する`copyMakeBorder`の実装に以下の変更を行った。

```diff
@@ -477,7 +477,13 @@ void Image::convert_size(int in_w, int resize_w, bool is_padding)
     if (is_padding)
     {
         cv::Mat dst_image;
-        copyMakeBorder(resize_image, dst_image, 0, 0, (out_w - resize_w) / 2, (out_w - resize_w) / 2, cv::BORDER_CONSTANT, cv::Scalar(0, 0, 0, 255));
+        copyMakeBorder(resize_image, dst_image,
+            0,
+            (out_h - resize_image.rows),
+            (out_w - resize_image.cols) / 2,
+            (out_w - resize_image.cols) / 2,
+            cv::BORDER_CONSTANT,
+            cv::Scalar(0, 0, 0, 255));
         memcpy(img_buffer[buf_id], dst_image.data, out_w * out_h * out_c);
     }
     else
```

再度DRP-AI TVMのYOLOX-Sのサンプルプログラムをビルドし、`core-image-weston`のCIP Linux上で実行したところエラーは解消された。  
ただし、正常なバウンディングボックスの検出結果は得られなかった。

次に、FHDに対応した別のUSBカメラを使用して、`CAM_INPUT_VGA`をdefineせずに動作確認した。  
正常にバウンディングボックスを検出できていることを確認できた。  
以上から、`CAM_INPUT_VGA`をdefineした場合の動作については、不整合が発生していると考えられる。

2023年12月に受領した`drp-tvm_v2x_samples.zip`に含まれていた`drp-tvm_v2x_samples/resnet50_v1_onnx`の`preprocess`の入力データのフォーマットは、以下の通り`640x480x3`だと考えられる。

```shell
$ grep data resnet50_v1_onnx/preprocess/addr_map.txt
data_in 0 e1000
data e1000 b7c00
data_out 198c00 93000
```

なお、`0xE_1000 == 921600 == 640 * 480 * 3`である。

一方で、前述のDRP-AI TVMのYOLOX-Sのサンプルプログラムの`preprocess`の入力データのフォーマットは、以下の通り`1920x1920x2`だと考えられる。

```shell
$ grep data yolox_cam/preprocess/
addr_map.txt
data_in 0 708000
data 708000 1068000
data_out 1770000 4b0000
```

なお、`0x70_8000 == 7372800 == 1920 * 1920 * 2`である。

よって、`drp-tvm_v2x_samples/resnet50_v1_onnx`の実装と異なり、DRP-AI TVMのYOLOX-Sのサンプルプログラムでは`CAM_INPUT_VGA`をdefineしたときの`640x480`の入力に対応していないと考えられる。

## 8 stella_vslamのグレースケール入力の動作確認

V2xボード（α2、EVK-α、電力改善版）上でstella_vslamの評価を行った。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：**GRAY_rgbd_dataset_freiburg3_walking_xyz**
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- DRP：無し
- DRP-AI：無し
- OpenCVA：無し
- DRP-AIオブジェクトファイル：無し
- DRP/DRP-AIドライバ：バージョン1

別の作業と並行して行った都合上、`core-image-weston`を使用した点に注意する。

### 8.1 SLAM精度評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt eval/frame_trajectory.v2x.2024.0130.mono.cpu.none.3wx.gray.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.110879
      mean      0.028988
    median      0.024101
       min      0.000949
      rmse      0.035026
       sse      1.040351
       std      0.019660

```

最大誤差が`11`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt eval/frame_trajectory.v2x.2024.0130.mono.cpu.none.3wx.gray.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0130.mono.cpu.none.3wx.gray
infos:  848 poses, 12.330m path length, 28.510s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/gray/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/gray/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/gray/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

### 8.2 ボトルネック解析結果

ボトルネック解析結果は以下の通り。  
`[LEFT]`は左画像についての処理を示す。

| 関数                                                                               |            割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|-----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100           |     124.41        |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      8.1         |      10.093       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     91.8         |     114.31        |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.5         |       0.68        |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0.2         |       0.314       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.6         |       0.871       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     65.5         |      81.522       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      3.4         |       4.263       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      3.4         |       4.249       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|     29.4         |      36.603       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|     19.3         |      24.055       |
| `　　　　　　　　　　FAST[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|     19           |      23.659       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      5.3         |       6.642       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      4.6         |       5.725       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      5           |       6.276       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     27.1         |      33.74        |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.6         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       0.485       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     22.7         |      28.333       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0.4         |       0.514       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.1         |       0.243       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     20.4         |      25.451       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      8.2         |      10.265       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      8.2         |      10.235       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      3.8         |       4.761       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      4.3         |       5.376       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0           |       0.003       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     11.7         |      14.62        |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|      3           |       3.738       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0           |       0.08        |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      3           |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|      3.3         |       4.207       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1         |       0.203       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      0.9         |       1.179       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|      2           |       2.586       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|      5.3         |       6.671       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      5.1         |       6.41        |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0           |       0.004       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.5         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.8         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      2           |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |

### 8.3 考察

`5 stella_vslamのYocto適合`に記載したTrackingスレッド全体の平均処理時間は以下の通り。  
ただし、単眼・RGB-Dモードとステレオモードでは使用しているデータセットが異なる点に注意する。

- 単眼（RGB）：`132.211`\[ms/frame\]
- RGB-D：`314.160`\[ms/frame\]
- ステレオ：`306.994`\[ms/frame\]

今回のグレースケールのTUMデータセットを使用した場合のTrackingスレッド全体の平均処理時間は以下の通り。

- 単眼（グレー）：`124.41`\[ms/frame\]

このうち、`cv::imread`の平均処理時間は以下の通り。

- 単眼（RGB）：`18.225`\[ms/frame\]
- 単眼（グレー）：`10.093`\[ms/frame\]

同じく、`util::convert_to_grayscale`の平均処理時間は以下の通り。

- 単眼（RGB）：`0.914`\[ms/frame\]
- 単眼（グレー）：`0.001`\[ms/frame\]

以上から、入力画像をRGBからグレースケールに変更することで、約`9`\[ms/frame\]の処理時間を削減できると考えられる。

## 9 Yolo-Planar-SLAMへのDRP-AI TVMのYOLOX-Sの組み込み

Yolo-Planar-SLAMに対してDRP-AI TVMのYOLOX-Sの組み込みを行った作業について記載する。

組み込み作業は受領したサンプルプログラム（`drp-tvm_dev-v210_add_yolox_240119`）の実装をベースに行った。

サンプルプログラムとの主な実装の差異は以下の通り。

1. `libtvm_runtime.so`を`/usr/lib64/libtvm_runtime.so`に配置すること
2. USBカメラだけではなく、データセットも使用すること
    - MMNGRを使用せずに、`ioctl(DRPAI_ASSIGN)`で入力画像を書き込むこと
    - 入力画像を`0x5870_0000`ではなく`0x2_5E00_0000`に配置したこと
3. DRPとDRP-AIの最大動作周波数の設定値を`how-to/sample_app_v2h/README.md`の手順の通りに固定したこと
    - サンプルプログラムを引数無しで実行する手順の設定値であり、DRPは`2（420MHz）`、DRP-AIは`2（1GHz）`
4. Yolo-Planar-SLAMの入力画像を`640x480`から`1920x1440`に拡大する処理を追加したこと
    - 取得したバウンディングボックスの値を、拡大率に応じて縮小して（`640x480`の画像上のスケールに戻して）からSLAM側に戻すこと
5. `ioctl(DRPAI_SET_ADRCONV)`で`0xD000_0000 ~ 0xEFFF_FFFF`を`0x0_5800_0000 ~ 0x0_77FF_FFFF`にアドレス変換する処理を無効化したこと

また、動作確認と評価を行った。  
実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：GRAY_rgbd_dataset_freiburg3_walking_xyz
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- 最大特徴点数：1000
- DRP：有効
- DRP-AI：有効
- OpenCVA：有効
- DRP-AIオブジェクトファイル：**YUYV入力**（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

なお、投機実行の後に`max_features`が更新され、再実行が発生した回数は、859フレーム中1回だった。

以降の評価は`core-image-weston`上で行った点に注意する。

まず、本変更の前後で中間データのダンプ結果を比較した。  
比較は最初の3フレームについて行った。

画像の入力から、FASTの出力までの中間データは厳密に一致した。  
バウンディングボックスについては使用するYOLOX-Sのモデル自体がDRP-AI Translatorから変更されているため、想定通り一致しなかった。

変更前の、DRP-AI TranslatorのYOLOX-Sを使用した時のバウンディングボックスの値は以下の通り。

```shell
#yolo_bounding_box_list_0000.csv
tl.x,tl.y,br.x,br.y
438.000000000000000,7.000000000000000,637.000000000000000,473.000000000000000
51.000000000000000,123.000000000000000,245.000000000000000,483.000000000000000

# yolo_bounding_box_list_0001.csv
tl.x,tl.y,br.x,br.y
466.000000000000000,14.000000000000000,646.000000000000000,468.000000000000000
50.000000000000000,116.000000000000000,244.000000000000000,485.000000000000000

# yolo_bounding_box_list_0002.csv
tl.x,tl.y,br.x,br.y
414.000000000000000,-1.000000000000000,635.000000000000000,477.000000000000000
48.000000000000000,114.000000000000000,247.000000000000000,483.000000000000000
```

変更後の、DRP-AI TVMのYOLOX-Sを使用した時のバウンディングボックスの値は以下の通り。

```shell
# yolo_bounding_box_list_0000.csv
tl.x,tl.y,br.x,br.y
421.000000000000000,0.000000000000000,640.000000000000000,476.000000000000000
48.000000000000000,127.000000000000000,242.000000000000000,477.000000000000000

# yolo_bounding_box_list_0001.csv
tl.x,tl.y,br.x,br.y
463.000000000000000,3.000000000000000,639.000000000000000,480.000000000000000
46.000000000000000,122.000000000000000,240.000000000000000,472.000000000000000

# yolo_bounding_box_list_0002.csv
tl.x,tl.y,br.x,br.y
470.000000000000000,4.000000000000000,638.000000000000000,480.000000000000000
48.000000000000000,117.000000000000000,242.000000000000000,476.000000000000000
```

目視で比較した限りでは不整合は無い。

また、バウンディングボックスの差異が影響する、特徴点の間引き処理以降の中間データは、変更の前後で想定通り一致しなかった。

Socket Viewerを使用した場合についても目視確認を行い、正常に動作していることを確認できた。

Yolo-Planar-SLAMの実行時のコンソール出力の一部を以下に示す。

```shell
mapped = 25e000000, pre_in_addr = 25e000000
proc[DRPAI_INDEX_INPUT].address = 25e000000
[TIME] PreRuntime DRP-AI processing time : 12.13 msec
[TIME] GetResult() Processing Time : 2.20 msec
[05:29:46] /yocto_rzv2x_ver1_workdir/yolo-planar-slam/drp_ai_modules/tvm/MeraDrpRuntimeWrapper.cpp:106: Loading input...
 Bounding Box Number : 9
 Bounding Box        : (X, Y, W, H) = (216, 270, 95, 95)
 Detected Class      : tvmonitor (Class 19)
 Probability         : 87.599998 %
 Bounding Box Number : 12
 Bounding Box        : (X, Y, W, H) = (106, 322, 213, 311)
 Detected Class      : person (Class 14)
 Probability         : 92.000000 %
 Bounding Box Number : 23
 Bounding Box        : (X, Y, W, H) = (490, 323, 245, 311)
 Detected Class      : person (Class 14)
 Probability         : 92.000000 %
 Bounding Box Count  : 3
Measurement result of  857 frame
    System::TrackMonocular                 :  412.868[ms]
    Sleep specified at execution           :    0.001[ms]
    Sleep while waiting for the next frame :    0.000[ms]
    Tracking state                         : OK
mapped = 25e000000, pre_in_addr = 25e000000
proc[DRPAI_INDEX_INPUT].address = 25e000000
[TIME] PreRuntime DRP-AI processing time : 12.14 msec
[TIME] GetResult() Processing Time : 2.24 msec
[05:29:46] /yocto_rzv2x_ver1_workdir/yolo-planar-slam/drp_ai_modules/tvm/MeraDrpRuntimeWrapper.cpp:106: Loading input...
 Bounding Box Number : 2
 Bounding Box        : (X, Y, W, H) = (218, 270, 95, 92)
 Detected Class      : tvmonitor (Class 19)
 Probability         : 90.699997 %
 Bounding Box Number : 19
 Bounding Box        : (X, Y, W, H) = (108, 323, 218, 318)
 Detected Class      : person (Class 14)
 Probability         : 92.000000 %
 Bounding Box Number : 21
 Bounding Box        : (X, Y, W, H) = (494, 323, 234, 311)
 Detected Class      : person (Class 14)
 Probability         : 92.000000 %
 Bounding Box Count  : 3
Measurement result of  858 frame
    System::TrackMonocular                 :  381.944[ms]
    Sleep specified at execution           :    0.000[ms]
    Sleep while waiting for the next frame :    0.000[ms]
    Tracking state                         : OK
```

2023年12月時点で実装されていたYolo-Planar-SLAMのコンソール出力に加えて、組み込んだサンプルプログラム由来のコンソール出力が追加されていることがわかる。

### 9.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum groundtruth.txt frameTrajectory.v2x.tvm.mono.opencva.ai.3wx.1000.gray.txt --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.303390
      mean      0.026416
    median      0.018983
       min      0.000867
      rmse      0.043298
       sse      1.563490
       std      0.034305

```

最大誤差が`30`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=groundtruth.txt frameTrajectory.v2x.tvm.mono.opencva.ai.3wx.1000.gray.txt --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frameTrajectory.v2x.tvm.mono.opencva.ai.3wx.1000.gray
infos:  834 poses, 11.095m path length, 28.020s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  2884 poses, 6.618m path length, 28.832s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/yolo-planar-slam/yoloxs/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/yolo-planar-slam/yoloxs/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/yolo-planar-slam/yoloxs/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

### 9.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。  
OpenCVAの処理時間は●で示す。

#### 9.2.1 Image loadingスレッド

| 関数                                       |   割合(%) |   実測値(msec/frame) |
|:-----------------------------------------|--------:|------------------:|
| `Image loading`  　　　　　　　　　　　　|   100   |             9.149 |
| `　　cv::imread` 　　　　　　　　　　　　|    99.9 |             9.144 |

#### 9.2.2 Image processingスレッド

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           402.13  |
| `　　cv::cvtColor to yolo input image`  　　　　　　　　　　　　　　|     0.7 |             3.007 |
| `　　YoloObjectDetect`  　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　convert to RGB or YUYV`　　　　　　　　　　　　　　　　　　|     3   |            12.168 |
| `　　　　expansion●`　　　　　　　　　　　　　　　　　　　　　　　　|     4.3 |            17.623 |
| `　　　　bottom padding`　　　　　　　　　　　　　　　　　　　　　　|     3.6 |            14.744 |
| `　　　　copy input to physical memory` 　　　　　　　　　　　　　　|     1.4 |             5.823 |
| `　　　　PreRuntime::Pre`   　　　　　　　　　　　　　　　　　　　　|     4.1 |            16.487 |
| `　　　　MeraDrpRuntimeWrapper::SetInput`   　　　　　　　　　　　　|     0.8 |             3.431 |
| `　　　　MeraDrpRuntimeWrapper::Run`　　　　　　　　　　　　　　　　|    61.9 |           249.092 |
| `　　　　Receive result`　　　　　　　　　　　　　　　　　　　　　　|     1   |             4.049 |
| `　　ComputePyramid`　　　　　　　　　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　Resize[0-7]●`  　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             2.825 |
| `　　GaussianBlur[0-7]●`　　　　　　　　　　　　　　　　　　　　　　|     0.7 |             2.957 |
| `　　ComputeKeyPointsOctTree[0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　push cell_indice[0-7]` 　　　　　　　　　　　　　　　　　　|     0   |             0.03  |
| `　　　　clone cell_image[0-7]` 　　　　　　　　　　　　　　　　　　|     0.1 |             0.51  |
| `　　　　receive output of DRP-AI`  　　　　　　　　　　　　　　　　|     1   |             4.07  |
| `　　　　pop cell_image[0-7]`   　　　　　　　　　　　　　　　　　　|     0.1 |             0.438 |
| `　　　　FAST[0-7]●`　　　　　　　　　　　　　　　　　　　　　　　　|    11.2 |            45.175 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     0   |             0     |
| `　　Frame::RemoveMovingKeyPoints`  　　　　　　　　　　　　　　　　|     0.7 |             3.167 |
| `　　ORBextractor::DistributeOctTree[0][0-7]`   　　　　　　　　　　|     1.1 |             4.558 |
| `　　ORBextractor::DistributeOctTree[1][0-7]`   　　　　　　　　　　|     0   |             0.02  |
| `　　computeOrientation[0][0-7]`　　　　　　　　　　　　　　　　　　|     1   |             4.062 |
| `　　computeOrientation[1][0-7]`　　　　　　　　　　　　　　　　　　|     0   |             0.009 |
| `　　computeDescriptors[0-1][0-7]`  　　　　　　　　　　　　　　　　| 　　--- | 　　　　　　----- |
| `　　　　calculate parameter[0][0-7]`   　　　　　　　　　　　　　　|     0   |             0.001 |
| `　　　　calculate parameter[1][0-7]`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[0][0-7]` 　　　　　　　　|     0   |             0.043 |
| `　　　　cv::KeyPoint to drp::KeyPoint_ORB[1][0-7]` 　　　　　　　　|     0   |             0     |
| `　　　　copy parameter using MemcpyU2P[0][0-7]`　　　　　　　　　　|     0   |             0.038 |
| `　　　　copy parameter using MemcpyU2P[1][0-7]`　　　　　　　　　　|     0   |             0     |
| `　　　　copy input image using MemcpyU2P[0][0-7]`  　　　　　　　　|     0.1 |             0.653 |
| `　　　　copy input image using MemcpyU2P[1][0-7]`  　　　　　　　　|     0   |             0.001 |
| `　　　　copy input keypoints using MemcpyU2P[0][0-7]`  　　　　　　|     0   |             0.033 |
| `　　　　copy input keypoints using MemcpyU2P[1][0-7]`  　　　　　　|     0   |             0     |
| `　　　　Activate`  　　　　　　　　　　　　　　　　　　　　　　　　|     0   |             0.054 |
| `　　　　Start[0][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0.1 |             0.469 |
| `　　　　Start[1][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　DRP time[0][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     1.3 |             5.249 |
| `　　　　DRP time[1][0-7]★` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.006 |
| `　　　　MemcpyP2U[0][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0.058 |
| `　　　　MemcpyP2U[1][0-7]` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　　　postprocess[0][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0.03  |
| `　　　　postprocess[1][0-7]`   　　　　　　　　　　　　　　　　　　|     0   |             0     |

`max_features`の値に依存しない前半の処理と、`max_features`の値に依存する投機実行を含む後半の処理の処理時間はそれぞれ以下の通り。

| 関数                                                                  |   割合(%) |   実測値(msec/frame) |
|:--------------------------------------------------------------------|--------:|------------------:|
| `Image processing`  　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           402.13  |
| `　　Image processing(first)`   　　　　　　　　　　　　　　　　　　|    93.5 |           376.056 |
| `　　Image processing(second)[0-7]` 　　　　　　　　　　　　　　　　|     6.4 |            26.037 |
| `　　Wait for ImageProcessing::wait_for_next_max_features to false` |     0   |             0     |

#### 9.2.3 Trackingスレッド

| 関数                                                                         |   割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------|--------:|------------------:|
| `Main loop`　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   100   |           415.416 |
| `　　Sleep specified at execution` 　　　　　　　　　　　　　　　　　　　　|     0   |             0     |
| `　　Sleep while waiting for the next frame`   　　　　　　　　　　　　　　|     0   |             0     |
| `　　System::Track*`   　　　　　　　　　　　　　　　　　　　　　　　　　　|    99.4 |           412.941 |
| `　　　　Wait for Tracking::wait_for_next_frame to false`  　　　　　　　　|    80.6 |           334.836 |
| `　　　　Wait for ImageProcessing::wait_for_next_max_features to true` 　　|     0   |             0     |
| `　　　　Tracking::GrabImage*` 　　　　　　　　　　　　　　　　　　　　　　|    18.7 |            78.031 |
| `　　　　　　Frame::MyCalculateAfterRemoveDynamicPointsAndPlaneExtraction` |     0.1 |             0.531 |
| `　　　　　　Tracking::Track`  　　　　　　　　　　　　　　　　　　　　　　|    18.6 |            77.48  |
| `　　　　　　　　Map::mMutexMapUpdate` 　　　　　　　　　　　　　　　　　　|     0.5 |             2.315 |
| `　　　　　　　　Tracking::MonocularInitialization`　　　　　　　　　　　　|     1.4 |             5.841 |
| `　　　　　　　　　　ORBmatcher::SearchForInitialization`  　　　　　　　　|     0.3 |             1.472 |
| `　　　　　　　　Tracking::TrackWithMotionModel`   　　　　　　　　　　　　|     3.9 |            16.449 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     2.5 |            10.639 |
| `　　　　　　　　　　first ORBmatcher::SearchByProjection` 　　　　　　　　|     1.3 |             5.534 |
| `　　　　　　　　　　second ORBmatcher::SearchByProjection`　　　　　　　　|     0   |             0     |
| `　　　　　　　　Tracking::TrackLocalMap`  　　　　　　　　　　　　　　　　|    11.5 |            48.079 |
| `　　　　　　　　　　Tracking::UpdateLocalMap` 　　　　　　　　　　　　　　|     0.9 |             4.028 |
| `　　　　　　　　　　Optimizer::PoseOptimization`  　　　　　　　　　　　　|     3.2 |            13.378 |
| `　　　　　　　　　　Tracking::SearchLocalPoints`  　　　　　　　　　　　　|     7.2 |            30.176 |
| `　　　　　　　　　　　　Project points in frame and check its visibility` |     5.9 |            24.709 |
| `　　　　　　　　　　　　ORBmatcher::SearchByProjection`   　　　　　　　　|     1.2 |             5.319 |

#### 9.2.4 考察

`3 バージョン1移行`に記載した、DRP-AI TranslatorのYOLOX-Sモデルを使用した時の評価結果と比較する。

`Image loading`の平均処理時間は以下の通り。

- DRP-AI Translator：`14.552`\[ms/frame\]
- DRP-AI TVM：`9.149`\[ms/frame\]

`Image processing`の平均処理時間は以下の通り。

- DRP-AI Translator：`66.836`\[ms/frame\]
- DRP-AI TVM：`402.130`\[ms/frame\]

`Main loop`の平均処理時間は以下の通り。

- DRP-AI Translator：`68.277`\[ms/frame\]
- DRP-AI TVM：`415.416`\[ms/frame\]

`Image processing`のうち、DRP-AIの入力画像をコピーする処理の平均処理時間は以下の通り。

- DRP-AI Translator
    - `convert to RGB or YUYV`：`0.727`\[ms/frame\]
    - `bottom padding`：`0.806`\[ms/frame\]
    - `copy input to physical memory`：`5.090`\[ms/frame\]
- DRP-AI TVM
    - `convert to RGB or YUYV`：`12.168`\[ms/frame\]
    - `expansion`：`17.623`\[ms/frame\]
    - `bottom padding`：`14.744`\[ms/frame\]
    - `copy input to physical memory`：`5.823`\[ms/frame\]
    - `MeraDrpRuntimeWrapper::SetInput`：`3.431`\[ms/frame\]

`Image processing`のうち、DRP-AIの平均処理時間は以下の通り。  
ただし、DRP-AI Translatorの場合はスレッド並列化されているため、下記の処理時間は隠蔽されている点に注意する。

- DRP-AI Translator
    - `polling`：`18.919`\[ms/frame\]
- DRP-AI TVM
    - `PreRuntime::Pre`：`16.487`\[ms/frame\]
        - `PreRuntime::GetResult`を含む
    - `MeraDrpRuntimeWrapper::Run`：`249.092`\[ms/frame\]

`MeraDrpRuntimeWrapper::Run`の処理時間が非常に大きいことがわかる。  
また、`PreRuntime::Pre`のみの処理時間だけでも、DRP-AI Translatorの場合のDRP-AIと同程度の処理時間がかかっていることがわかる。

以上から、DRP-AI TVMのYOLOX-Sを使用する場合には、DRP-AI TranslatorのYOLOX-Sを使用する場合と比較して処理時間の観点で不利であることがわかる。  
特に、DRP-AI TVMの場合の前処理（`PreRuntime::Pre`）のみと比較しても、DRP-AI Translatorと同程度の処理時間であるため、`MeraDrpRuntimeWrapper::Run`の処理時間が10倍以上高速化されたとしてもDRP-AI Translatorの場合と比較して、処理時間の観点で不利である可能性が高い。

## 10 stella_vslamへのDRP-AI TVMのYOLOX-Sの組み込み

stella_vslamに対してDRP-AI TVMのYOLOX-Sの組み込みを行った作業について記載する。

組み込み作業は受領したサンプルプログラム（`drp-tvm_dev-v210_add_yolox_240119`）の実装をベースに行った。  
また、バウンディングボックスをSocket Viewerのフレーム画像に描画する対応も行った。

サンプルプログラムとの主な実装の差異は、`9 Yolo-Planar-SLAMへのDRP-AI TVMのYOLOX-Sの組み込み`と同様である。

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- DRP：無し
- DRP-AI：有効
- OpenCVA：無し
- DRP-AIオブジェクトファイル：**YUYV入力**（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

なお、評価は`core-image-weston`上で行った点に注意する。

まず、Socket Viewerを使用して目視確認を行い、正常に動作していることを確認した。  
ただし、Yolo-Planar-SLAMのSocket Viewerと同等の変更を加えていないため、フレーム画像のアスペクト比が横長になっている。

### 10.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.0213_3.mono.cpu.ai.3wh.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.086921
      mean      0.018421
    median      0.016010
       min      0.000514
      rmse      0.021686
       sse      0.493810
       std      0.011444

```

最大誤差が`8`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.0213_3.mono.cpu.ai.3wh.txt \
>   --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0213_3.mono.cpu.ai.3wh
infos:  1050 poses, 15.052m path length, 35.628s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/yoloxs/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/yoloxs/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/yoloxs/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

### 10.2 ボトルネック解析

ボトルネック解析結果は以下の通り。

| 関数                                                                               |    割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|---------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100   |     396.418       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0   |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      5   |      20.153       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     94.9 |     376.24        |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0.3 |       1.521       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.1 |       0.613       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0   |       0.291       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.2 |       0.8         |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     85   |     337.083       |
| `　　　　　　yolo_detector::start[LEFT]` 　　　　　　　　　　　　　　　　　　　　|     63   |     249.943       |
| `　　　　　　　　convert to RGB or YUYV` 　　　　　　　　　　　　　　　　　　　　|      1.8 |       7.333       |
| `　　　　　　　　expansion`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      4.6 |      18.617       |
| `　　　　　　　　bottom padding` 　　　　　　　　　　　　　　　　　　　　　　　　|      1.2 |       4.938       |
| `　　　　　　　　copy input to physical memory`  　　　　　　　　　　　　　　　　|      0.7 |       2.893       |
| `　　　　　　　　PreRuntime::Pre`　　　　　　　　　　　　　　　　　　　　　　　　|      3.4 |      13.763       |
| `　　　　　　　　MeraDrpRuntimeWrapper::SetInput`　　　　　　　　　　　　　　　　|      0.7 |       3.006       |
| `　　　　　　　　MeraDrpRuntimeWrapper::Run` 　　　　　　　　　　　　　　　　　　|     50.2 |     199.333       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     0.4 |       -----       |
| `　　　　　　orb_extractor::create_rectangle_mask[LEFT]` 　　　　　　　　　　　　|      0   |       0           |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      1.1 |       4.471       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      1.1 |       4.367       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0   |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|      9.1 |      36.191       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|      5.7 |      22.831       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      1.5 |       6.108       |
| `　　　　　　　　yolo_detector::finish[LEFT]`　　　　　　　　　　　　　　　　　　|      0.5 |       2.369       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      1.4 |       5.561       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0  |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      3.7 |      14.749       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      7.7 |      30.836       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.4 |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.1 |       0.744       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|      8.2 |      32.713       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0.1 |       0.608       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0   |       0.342       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|      7.4 |      29.539       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      2.4 |       9.811       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      2.4 |       9.764       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      1.1 |       4.69        |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      1.2 |       4.978       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.1 |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0   |       0.001       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0   |       0.02        |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0   |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0   |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|      4.9 |      19.467       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|      1.5 |       6.218       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0   |       0.065       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      1.5 |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|      1.5 |       6.341       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0   |       0.211       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      0.4 |       1.953       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|      0.9 |       3.866       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2 |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|      1.7 |       6.904       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      1.6 |       6.626       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.1 |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2 |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0   |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0   |       0.004       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1 |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.7 |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1   |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1 |       -----       |

### 10.3 考察

`5 stella_vslamのYocto適合`に記載した、DRP-AI適合前の評価結果と比較する。

`Main loop`の平均処理時間は以下の通り。

- 適合前：`314.160`\[ms/frame\]
- 適合後：`396.418`\[ms/frame\]

このうち、適合後のDRP-AIの入力画像をコピーする処理の平均処理時間は以下の通り。

- `convert to RGB or YUYV`：`7.333`\[ms/frame\]
- `expansion`：`18.617`\[ms/frame\]
- `bottom padding`：`4.938`\[ms/frame\]
- `copy input to physical memory`：`2.893`\[ms/frame\]
- `MeraDrpRuntimeWrapper::SetInput`：`3.006`\[ms/frame\]

また、DRP-AIの平均処理時間は以下の通り。

- `PreRuntime::Pre`：`13.763`\[ms/frame\]
    - `PreRuntime::GetResult`を含む
- `MeraDrpRuntimeWrapper::Run`：`199.333`\[ms/frame\]

`MeraDrpRuntimeWrapper::Run`の処理時間が非常に大きいことがわかる。

以上から、DRP-AI TVMのYOLOX-Sを使用する場合には処理時間の観点で不利であることがわかる。

## 11 stella_vslamのOpenCVA適合

stella_vslamのOpenCVA適合について記載する。  
合わせて、OpenMPとカラーフォーマットの実装についても調査・変更を行った内容についても記載する。  
また、評価環境を`core-image-weston`から`core-image-bsp`に変更した点についても記載する。

### 11.1 USE_OPENMPの確認

stella_vslamのOpenMPの`#pragma omp parallel for`が有効となるように`USE_OPENMP`を`ON`に変更して評価を行った。  
オリジナル実装の時点での該当の箇所は以下の通り。

```shell
$ grep -rn -A 1 '#ifdef USE_OPENMP' src/
src/stella_vslam/mapping_module.cc:336:#ifdef USE_OPENMP
src/stella_vslam/mapping_module.cc-337-#pragma omp parallel for
--
src/stella_vslam/mapping_module.cc:362:#ifdef USE_OPENMP
src/stella_vslam/mapping_module.cc-363-#pragma omp critical
--
src/stella_vslam/feature/orb_extractor.cc:139:#ifdef USE_OPENMP
src/stella_vslam/feature/orb_extractor.cc-140-#pragma omp parallel for
--
src/stella_vslam/feature/orb_extractor.cc:158:#ifdef USE_OPENMP
src/stella_vslam/feature/orb_extractor.cc-159-#pragma omp parallel for
--
src/stella_vslam/feature/orb_extractor.cc:171:#ifdef USE_OPENMP
src/stella_vslam/feature/orb_extractor.cc-172-#pragma omp parallel for
--
src/stella_vslam/feature/orb_extractor.cc:207:#ifdef USE_OPENMP
src/stella_vslam/feature/orb_extractor.cc-208-#pragma omp critical
--
src/stella_vslam/match/stereo.cc:30:#ifdef USE_OPENMP
src/stella_vslam/match/stereo.cc-31-#pragma omp parallel for
--
src/stella_vslam/match/stereo.cc:88:#ifdef USE_OPENMP
src/stella_vslam/match/stereo.cc-89-#pragma omp critical
```

評価結果は以下の通り。

- `USE_OPENMP=OFF`：`132.211`\[ms/frame\]
    - `5 stella_vslamのYocto適合`の評価結果
- `USE_OPENMP=ON`：`125.330`\[ms/frame\]
- `USE_OPENMP=OFF` + DRP-AI：`396.418`\[ms/frame\]
    - `10 stella_vslamへのDRP-AI TVMのYOLOX-Sの組み込み`の評価結果
- `USE_OPENMP=ON` + DRP-AI：`402.641`\[ms/frame\]

YOLOを使用しない場合では、`USE_OPENMP`を`OFF`から`ON`に変更することで約`7`\[ms/frame\]の処理時間を削減できている。  
YOLOを使用する場合では平均処理時間が増加している。  
ただし、平均処理時間が非常に大きいため、有意な性能差なのかは判断できていない。

### 11.2 core-image-bspへの移行

V2xボード上で使用するLinuxイメージを`core-image-weston`から`core-image-bsp`に戻した。  
また、変更による影響を確認するために評価を行った。  
評価結果は以下の通り。

- `core-image-weston`：`125.330`\[ms/frame\]
- `core-image-bsp`：`126.172`\[ms/frame\]
- `core-image-weston` + DRP-AI：`402.641`\[ms/frame\]
- `core-image-bsp` + DRP-AI：`400.444`\[ms/frame\]

YOLOの有無に依らず、有意な平均処理時間の差は見られなかった。

### 11.3 カラーフォーマットの設定の変更

以下の2つの画像が厳密に一致していなかったため、調査を行った。

1. stella_vslamの内部でグレースケール変換された画像
2. Musketeerのテストベンチファイル作成用の単体プログラムでグレースケール変換した画像

TUMデータセットの実行時の設定ファイルは`stella_vslam/example/tum_rgbd/TUM_RGBD_mono_3.yaml`にある。  
[公開されている公式のstella_vslamで設定されている`color_order`](https://github.com/stella-cv/stella_vslam/blob/0.4.0/example/tum_rgbd/TUM_RGBD_mono_3.yaml#L27)の値は以下の通り。

```yaml
  color_order: "RGB"
```

この設定値は、[system::create_monocular_frame](https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.cc#L281-L287)で参照される。  
ここで、`img`は`cv::imread`で`cv::IMREAD_UNCHANGED`を指定して画像ファイルを読み込んだ時の返り値であることに注意する。

```cpp
data::frame system::create_monocular_frame(const cv::Mat& img, const double timestamp, const cv::Mat& mask) {
    // color conversion
    if (!camera_->is_valid_shape(img)) {
        spdlog::warn("preprocess: Input image size is invalid");
    }
    cv::Mat img_gray = img;
    util::convert_to_grayscale(img_gray, camera_->color_order_);
```

[util::convert_to_grayscale](https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/util/image_converter.cc#L8-L23)の中で、`camera_->color_order_`の値によって条件分岐が行われる。

```cpp
void convert_to_grayscale(cv::Mat& img, const camera::color_order_t in_color_order) {
    if (img.channels() == 3) {
        switch (in_color_order) {
            case camera::color_order_t::Gray: {
                break;
            }
            case camera::color_order_t::RGB: {
                cv::cvtColor(img, img, cv::COLOR_RGB2GRAY);
                break;
            }
            case camera::color_order_t::BGR: {
                cv::cvtColor(img, img, cv::COLOR_BGR2GRAY);
                break;
            }
        }
    }
```

`cv::imread`で読み込んだ画像のカラーフォーマットは`RGB`ではなく、`BGR`が正しい。  
そのため、`util::convert_to_grayscale`の`cv::cvtColor`では`cv::COLOR_BGR2GRAY`が使用されることが適切だと考えられる。  
しかし、前述の通り`color_order`には`RGB`が指定されているため`cv::COLOR_RGB2GRAY`が使用される。

以下の記事も確認したが、`cv::imread`で読み込んだカラー画像のグレースケール変換には`cv::COLOR_BGR2GRAY`が使用されていることがわかる。

- <https://note.nkmk.me/python-opencv-numpy-color-to-gray/>
- <https://qiita.com/yoya/items/dba7c40b31f832e9bc2a>
- <https://www.argocorp.com/UVC_camera/Sample_OpenCV_cvtColor.html>

以上から、`stella_vslam/example/tum_rgbd/TUM_RGBD_mono_3.yaml`の`color_order`の設定値を`RGB`から`BGR`に変更した。

### 11.4 OpenMPによるループ並列の無効化

`orb_extractor::compute_fast_keypoint`の[cv::FASTを含むfor文](https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/feature/orb_extractor.cc#L139-L243)は`#pragma omp parallel for`によって並列動作する。  
しかし、OpenCVAのFASTは並列に実行しようとするとリソースの競合によってエラーとなる。  
そのため、該当するOpenMPのループ並列の無効化を行った。

### 11.5 OpenCVA適合

stella_vslamについてOpenCVA適合の作業を行った。  
また、動作確認と評価を行った。

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- DRP：無し
- DRP-AI：**無効**
- DRP-AIオブジェクトファイル：**YUYV入力**（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

まず、中間データのダンプ結果の確認を行った。  
OpenCVA適合前のダンプ結果と、OpenCVA適合後にOpenCVAを無効としたときのダンプ結果が厳密に一致することを確認できた。  
次に、OpenCVA適合後のOpenCVAが有効のときのダンプ結果を、0番と1番のフレームについて目視確認して、不自然な点が無いことを確認した。

#### 11.5.1 OpenCVAあり

##### 11.5.1.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.0215.mono.opencva.none.3wh.bsp.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.207153
      mean      0.032490
    median      0.026133
       min      0.002225
      rmse      0.040993
       sse      1.786322
       std      0.024997

```

最大誤差が`20`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.0215.mono.opencva.none.3wh.bsp.txt \
>   --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0215.mono.opencva.none.3wh.bsp
infos:  1063 poses, 17.245m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/opencva/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/opencva/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/opencva/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 11.5.1.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
OpenCVAの処理時間は●で示す。

| 関数                                                                               |            割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|-----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100           |     133.167       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     13.7         |      18.256       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     86.2         |     114.883       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0.8         |       1.073       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.4         |       0.61        |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0.2         |       0.281       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.5         |       0.794       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     56.1         |      74.815       |
| `　　　　　　orb_extractor::create_rectangle_mask[LEFT]` 　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      2.2         |       2.944       |
| `　　　　　　　　Resize[LEFT][0-7]●` 　　　　　　　　　　　　　　　　　　　　　　|      2.2         |       2.932       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|     28.4         |      37.949       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|     19.6         |      26.107       |
| `　　　　　　　　　　FAST[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　|     19.3         |      25.741       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      4.7         |       6.356       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      3.9         |       5.293       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　|      2.1         |       2.871       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     22.8         |      30.423       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.6         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.6         |       0.817       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     25.8         |      34.442       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.199       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.2         |       0.384       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     23.8         |      31.766       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      7.4         |       9.942       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      7.4         |       9.913       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      3.6         |       4.802       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      3.7         |       5.01        |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0           |       0.004       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     15.4         |      20.636       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|      4.9         |       6.647       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0           |       0.074       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      4.9         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|      5.3         |       7.06        |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1         |       0.21        |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      1.6         |       2.175       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|      3.2         |       4.316       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|      5.1         |       6.923       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      4.9         |       6.618       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0           |       0.004       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1           |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.7         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.8         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |

#### 11.5.2 OpenCVA無し

##### 11.5.2.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.0215_2.mono.cpu.none.3wh.bsp.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.317424
      mean      0.062073
    median      0.045531
       min      0.010167
      rmse      0.075139
       sse      5.995884
       std      0.042341

```

最大誤差が`31`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   eval/frame_trajectory.v2x.2024.0215_2.mono.cpu.none.3wh.bsp.txt \
>   --correct_scale --align -p
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0215_2.mono.cpu.none.3wh.bsp
infos:  1062 poses, 18.153m path length, 35.728s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/no_opencva/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/no_opencva/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/no_opencva/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

##### 11.5.2.2 ボトルネック解析

ボトルネック解析結果は以下の通り。

| 関数                                                                               |         割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　| 100           |     137.441       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|  13.2         |      18.236       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|  86.7         |     119.172       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|   0.7         |       1.06        |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|   0.4         |       0.61        |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|   0.2         |       0.279       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|   0.5         |       0.79        |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|  54.8         |      75.452       |
| `　　　　　　orb_extractor::create_rectangle_mask[LEFT]` 　　　　　　　　　　　　|   0           |       0           |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|   3.1         |       4.269       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|   3           |       4.258       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|  24.4         |      33.658       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|  16.1         |      22.255       |
| `　　　　　　　　　　FAST[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|  15.9         |      21.909       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|   4.3         |       6.03        |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|   3.7         |       5.195       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|   5           |       6.889       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|  21.8         |      29.982       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.5         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|   0.5         |       0.797       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|  27.7         |      38.166       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|   0.1         |       0.23        |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|   0.3         |       0.439       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|  25.7         |      35.381       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|   7.4         |      10.255       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|   7.4         |      10.231       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|   3.6         |       5.008       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|   3.7         |       5.12        |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|   0           |       0.002       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|  17.1         |      23.503       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|   5.4         |       7.517       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|   0           |       0.073       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   5.4         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|   6           |       8.347       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |   0.1         |       0.215       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |   1.8         |       2.56        |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|   3.7         |       5.144       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.4         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|   5.5         |       7.633       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|   5.3         |       7.299       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|   0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|   0           |       0.004       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   1.2         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   1.6         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   1.9         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |

#### 11.5.3 考察

まず、OpenMPによるループ並列の無効化による影響について考察する。  
OpenMPによるループ並列の無効化と、OpenCVA適合の前後のTrackingスレッドの平均処理時間は以下の通り。

- 適用前：`126.172`\[ms/frame\]
- 適用後：`137.441`\[ms/frame\]

よって、約`11`\[ms/frame\]だけ平均処理時間が増加していることがわかる。

次に、OpenCVAの有効/無効による影響について考察する。  
OpenMPによるループ並列の無効化と、OpenCVA適合の後のTrackingスレッドの平均処理時間は以下の通り。

- OpenCVAあり：`133.167`\[ms/frame\]
- OpenCVA無し：`137.441`\[ms/frame\]

このうち、OpenCVAが有効の場合にDRPで実行されるアルゴリズムの平均処理時間は以下の通り。

- resize
    - OpenCVAあり：`2.932`\[ms/frame\]
    - OpenCVA無し：`4.258`\[ms/frame\]
- GaussianBlur
    - OpenCVAあり：`2.871`\[ms/frame\]
    - OpenCVA無し：`6.889`\[ms/frame\]
- FAST
    - OpenCVAあり：`25.741`\[ms/frame\]
    - OpenCVA無し：`21.909`\[ms/frame\]

resizeとGaussianBlurについてはOpenCVAを有効にすることで高速化されていることがわかる。  
一方で、FASTについてはOpenCVAを有効にすることで処理時間が増加していることがわかる。  

## 12 stella_vslamのログ出力の追加・仕様変更

stella_vslamのログ出力の実装の変更内容について記載する。

オリジナルのstella_vslamのログ出力はspdlogを使用して行われている。  
作業の効率化のため、本案件のstella_vslamのログ出力をspdlogに統一した。

また、以下の情報をログ出力するように変更した。

- 有効なビルドスイッチ
- バージョン情報
- Tracking state
- Tracking time

spdlogのログレベルは、実行時に`--log-level`オプションで指定できる。  
デフォルトでは`info`が設定される。  
ログレベルごとのログ出力の例は以下の通り。

`info`レベルの場合は以下の通り。

```shell
[2024-02-27 02:22:32.601] [I]
Version information
  The version of stella_vslam : 2.9.0
  This software is derived from version 0.4.0 of the original stella_vslam


[2024-02-27 02:22:32.601] [I]
Build switch information
  defined ENABLE_MEASURE_TIME
  defined ENABLE_DRP_DRIVER_NATIVE
  defined ENABLE_DRP_AI_TVM


[2024-02-27 02:22:32.625] [I] loading ORB vocabulary: /home/root/stella_vslam_examples/orb_vocab.fbow
[2024-02-27 02:22:32.672] [I] load orb_params "default ORB feature extraction setting"
[2024-02-27 02:22:32.674] [I] startup SLAM system
[2024-02-27 02:22:32.674] [I] start mapping module
[2024-02-27 02:22:32.674] [I] start global optimization module
[2024-02-27 02:22:32.832] [I] tracking time : 91.0[msec]
[2024-02-27 02:22:32.974] [I] tracking time : 121.0[msec]
[2024-02-27 02:22:33.114] [I] tracking time : 120.0[msec]
[2024-02-27 02:22:33.257] [I] tracking time : 123.0[msec]
[2024-02-27 02:22:33.395] [I] initialization succeeded with F
[2024-02-27 02:22:33.462] [I] new map created with 120 points: frame 0 - frame 4
[2024-02-27 02:22:33.483] [I] tracking time : 207.0[msec]
[2024-02-27 02:22:33.628] [I] tracking time : 125.0[msec]
[2024-02-27 02:22:33.740] [I] tracking time : 93.0[msec]
[2024-02-27 02:22:33.845] [I] tracking time : 86.0[msec]
[2024-02-27 02:22:33.962] [I] tracking time : 98.0[msec]
[2024-02-27 02:22:34.085] [I] tracking time : 103.0[msec]
```

`debug`レベルの場合は以下の通り。

```shell
[2024-02-27 02:23:07.092] [I]
Version information
  The version of stella_vslam : 2.9.0
  This software is derived from version 0.4.0 of the original stella_vslam


[2024-02-27 02:23:07.092] [I]
Build switch information
  defined ENABLE_MEASURE_TIME
  defined ENABLE_DRP_DRIVER_NATIVE
  defined ENABLE_DRP_AI_TVM


[2024-02-27 02:23:07.116] [I] loading ORB vocabulary: /home/root/stella_vslam_examples/orb_vocab.fbow
[2024-02-27 02:23:07.161] [D] CONSTRUCT: camera::base
[2024-02-27 02:23:07.161] [D] CONSTRUCT: camera::perspective
[2024-02-27 02:23:07.161] [D] compute image bounds
[2024-02-27 02:23:07.161] [I] load orb_params "default ORB feature extraction setting"
[2024-02-27 02:23:07.161] [D] CONSTRUCT: data::camera_database
[2024-02-27 02:23:07.161] [D] CONSTRUCT: data::map_database
[2024-02-27 02:23:07.161] [D] CONSTRUCT: data::bow_database
[2024-02-27 02:23:07.161] [D] CONSTRUCT: data::orb_params_database
[2024-02-27 02:23:07.162] [D] CONSTRUCT: publish::frame_publisher
[2024-02-27 02:23:07.162] [D] CONSTRUCT: publish::map_publisher
[2024-02-27 02:23:07.163] [D] CONSTRUCT: module::initializer
[2024-02-27 02:23:07.163] [D] CONSTRUCT: module::relocalizer
[2024-02-27 02:23:07.163] [D] CONSTRUCT: tracking_module
[2024-02-27 02:23:07.163] [D] CONSTRUCT: mapping_module
[2024-02-27 02:23:07.163] [D] load mapping parameters
[2024-02-27 02:23:07.163] [D] load monocular mappping parameters
[2024-02-27 02:23:07.163] [D] Use baseline_dist_thr_ratio: 0.02
[2024-02-27 02:23:07.163] [D] CONSTRUCT: loop_detector
[2024-02-27 02:23:07.163] [D] CONSTRUCT: global_optimization_module
[2024-02-27 02:23:07.163] [I] startup SLAM system
[2024-02-27 02:23:07.163] [I] start mapping module
[2024-02-27 02:23:07.163] [I] start global optimization module
[2024-02-27 02:23:07.316] [D] CONSTRUCT: initialize::perspective
[2024-02-27 02:23:07.318] [D] Tracking state : Initializing
[2024-02-27 02:23:07.318] [I] tracking time : 89.0[msec]
[2024-02-27 02:23:07.442] [D] try to initialize with the initial frame and the current frame: frame 0 - frame 1
[2024-02-27 02:23:07.457] [D] reconstruct_with_F
[2024-02-27 02:23:07.459] [D] Tracking state : Initializing
[2024-02-27 02:23:07.459] [I] tracking time : 120.0[msec]
[2024-02-27 02:23:07.582] [D] try to initialize with the initial frame and the current frame: frame 0 - frame 2
[2024-02-27 02:23:07.596] [D] reconstruct_with_F
[2024-02-27 02:23:07.598] [D] Tracking state : Initializing
[2024-02-27 02:23:07.598] [I] tracking time : 120.0[msec]
[2024-02-27 02:23:07.727] [D] try to initialize with the initial frame and the current frame: frame 0 - frame 3
[2024-02-27 02:23:07.742] [D] reconstruct_with_F
[2024-02-27 02:23:07.744] [D] Tracking state : Initializing
[2024-02-27 02:23:07.744] [I] tracking time : 126.0[msec]
[2024-02-27 02:23:07.867] [D] try to initialize with the initial frame and the current frame: frame 0 - frame 4
[2024-02-27 02:23:07.881] [D] reconstruct_with_F
[2024-02-27 02:23:07.882] [I] initialization succeeded with F
[2024-02-27 02:23:07.882] [D] DESTRUCT: initialize::perspective
[2024-02-27 02:23:07.941] [I] new map created with 65 points: frame 0 - frame 4
[2024-02-27 02:23:07.961] [D] Tracking state : Tracking
[2024-02-27 02:23:07.961] [I] tracking time : 197.0[msec]
[2024-02-27 02:23:08.103] [D] Tracking state : Tracking
[2024-02-27 02:23:08.103] [I] tracking time : 123.0[msec]
[2024-02-27 02:23:08.216] [D] Tracking state : Tracking
[2024-02-27 02:23:08.216] [I] tracking time : 93.0[msec]
```

`trace`レベルの場合は以下の通り。

```shell
[2024-02-27 02:23:35.011] [I]
Version information
  The version of stella_vslam : 2.9.0
  This software is derived from version 0.4.0 of the original stella_vslam


[2024-02-27 02:23:35.011] [I]
Build switch information
  defined ENABLE_MEASURE_TIME
  defined ENABLE_DRP_DRIVER_NATIVE
  defined ENABLE_DRP_AI_TVM


[2024-02-27 02:23:35.012] [T] Start opencva::initialize
[2024-02-27 02:23:35.035] [T] Succeeded in opencva::initialize
[2024-02-27 02:23:35.035] [I] loading ORB vocabulary: /home/root/stella_vslam_examples/orb_vocab.fbow
[2024-02-27 02:23:35.082] [D] CONSTRUCT: camera::base
[2024-02-27 02:23:35.082] [D] CONSTRUCT: camera::perspective
[2024-02-27 02:23:35.082] [D] compute image bounds
[2024-02-27 02:23:35.082] [I] load orb_params "default ORB feature extraction setting"
[2024-02-27 02:23:35.082] [D] CONSTRUCT: data::camera_database
[2024-02-27 02:23:35.082] [D] CONSTRUCT: data::map_database
[2024-02-27 02:23:35.082] [D] CONSTRUCT: data::bow_database
[2024-02-27 02:23:35.082] [D] CONSTRUCT: data::orb_params_database
[2024-02-27 02:23:35.083] [D] CONSTRUCT: publish::frame_publisher
[2024-02-27 02:23:35.083] [D] CONSTRUCT: publish::map_publisher
[2024-02-27 02:23:35.083] [D] CONSTRUCT: module::initializer
[2024-02-27 02:23:35.083] [D] CONSTRUCT: module::relocalizer
[2024-02-27 02:23:35.083] [D] CONSTRUCT: tracking_module
[2024-02-27 02:23:35.084] [D] CONSTRUCT: mapping_module
[2024-02-27 02:23:35.084] [D] load mapping parameters
[2024-02-27 02:23:35.084] [D] load monocular mappping parameters
[2024-02-27 02:23:35.084] [D] Use baseline_dist_thr_ratio: 0.02
[2024-02-27 02:23:35.084] [D] CONSTRUCT: loop_detector
[2024-02-27 02:23:35.084] [D] CONSTRUCT: global_optimization_module
[2024-02-27 02:23:35.084] [I] startup SLAM system
[2024-02-27 02:23:35.084] [I] start mapping module
[2024-02-27 02:23:35.084] [I] start global optimization module
[2024-02-27 02:23:35.151] [T] Start 0 frame orb_extractor::compute_image_pyramid
[2024-02-27 02:23:35.155] [T] Finish 0 frame orb_extractor::compute_image_pyramid
[2024-02-27 02:23:35.155] [T] Start 0 frame orb_extractor::compute_fast_keypoints
[2024-02-27 02:23:35.155] [T] values at 0 level of 0 frame orb_extractor::compute_fast_keypoints
[2024-02-27 02:23:35.155] [T]     width    : 602
[2024-02-27 02:23:35.155] [T]     height   : 442
[2024-02-27 02:23:35.155] [T]     num_cols : 10
[2024-02-27 02:23:35.155] [T]     num_rows : 7
[2024-02-27 02:23:35.165] [T] values at 1 level of 0 frame orb_extractor::compute_fast_keypoints
[2024-02-27 02:23:35.165] [T]     width    : 495
[2024-02-27 02:23:35.165] [T]     height   : 362
[2024-02-27 02:23:35.165] [T]     num_cols : 8
[2024-02-27 02:23:35.165] [T]     num_rows : 6
[2024-02-27 02:23:35.172] [T] values at 2 level of 0 frame orb_extractor::compute_fast_keypoints
# 略
[2024-02-27 02:23:35.185] [T] values at 7 level of 0 frame orb_extractor::compute_fast_keypoints
[2024-02-27 02:23:35.185] [T]     width    : 141
[2024-02-27 02:23:35.185] [T]     height   : 96
[2024-02-27 02:23:35.185] [T]     num_cols : 3
[2024-02-27 02:23:35.185] [T]     num_rows : 2
[2024-02-27 02:23:35.192] [T] Finish 0 frame orb_extractor::compute_fast_keypoints
[2024-02-27 02:23:35.196] [T] Start 0 frame orb_extractor::compute_orb_descriptors
[2024-02-27 02:23:35.202] [T] Finish 0 frame orb_extractor::compute_orb_descriptors
[2024-02-27 02:23:35.202] [T] Start 0 frame orb_extractor::compute_orb_descriptors
[2024-02-27 02:23:35.209] [T] Finish 0 frame orb_extractor::compute_orb_descriptors
[2024-02-27 02:23:35.209] [T] Start 0 frame orb_extractor::compute_orb_descriptors
# 略
[2024-02-27 02:23:35.232] [T] Finish 0 frame orb_extractor::compute_orb_descriptors
[2024-02-27 02:23:35.236] [D] CONSTRUCT: initialize::perspective
[2024-02-27 02:23:35.239] [D] Tracking state : Initializing
[2024-02-27 02:23:35.239] [I] tracking time : 89.0[msec]
[2024-02-27 02:23:35.260] [T] Start 1 frame orb_extractor::compute_image_pyramid
```

## 13 stella_vslamのtracking timeの描画対応

Socket Viewerのフレーム画像の下部にtracking timeを描画するように変更した。  
なお、tracking timeを描画するのかは実行時オプションの`Viewer::draw_tracking_time`で切り替え可能となっている。

Socket Viewerの描画結果は以下の通り。

![SocketViewer](image/stella_vslam/socket_viewer.png)

なお、Yolo-Planar-SLAMのSocket Viewerと同等の変更を加えていないため、フレーム画像のアスペクト比が横長になっている。

## 14 stella_vslamのステレオモード適合

DRPを使用する各処理について、ステレオモードの場合に、左右の画像処理のそれぞれで競合が発生しないように対応を行った。  
同様に、DRP-AIについても対応を行った。  
具体的には、左画像と右画像の画像処理をそれぞれ行うスレッドを、並列に動作しないように変更を行った。

## 15 stella_vslamのDRPドライバネイティブ適合

stella_vslamのDRPドライバネイティブ適合について記載する。

### 15.1 SLAM組み込み用のFASTの実装変更

ORB-SLAM2と、その派生ソフトウェアであるYolo-Planar-SLAMの[ORBextractor::ComputeKeyPointsOctTree](https://github.com/raulmur/ORB_SLAM2/blob/f2e6f51cdc8d067655d90a78c06261378e07e8f3/src/ORBextractor.cc#L765-L853)のセル分割実装と、stella_vslamの[orb_extractor::compute_fast_keypoints](https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/feature/orb_extractor.cc#L128-L249)のセル分割実装には原理的な差異がある。  
よって、SLAM組み込み用のFASTをstella_vslamで使用するためには、SLAM組み込み用のFASTの実装も合わせて変更する必要がある。  
そのためSLAM組み込み用のFASTの実装の変更と評価を行った。

#### 15.1.1 ceil処理の確認

[orb_extractor::compute_fast_keypoints](https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/feature/orb_extractor.cc#L153-L154)のコードの一部を以下に示す。

```cpp
const unsigned int num_cols = std::ceil(width / cell_size) + 1;
const unsigned int num_rows = std::ceil(height / cell_size) + 1;
```

stella_vslamの上記の`std::ceil`は、実数値に対する切り上げ処理を行っていない。

例えば、入力画像のサイズが`640x480`のとき、1レベルの画像のサイズは`533x400`となる。  
`orb_extractor::orb_patch_radius_`は`19`であるため、上記の`width`は`533 - 2*19 = 495`となる。  
また、`495 / cell_size = 495 / 64 = 7.734375`となり、`std::ceil(7.734375)`は`8`となる。  
ただし、`width`も`height`も`cell_size`も整数型であるため、除算の時点で端数は切捨てられている。  
そのため、実際には`std::ceil(width / cell_size)`は`8`ではなく`7`となる。  
よって`num_cols`も`8 + 1 = 9`ではなく`7 + 1 = 8`となる。

上記の推測の裏付けを取るため、stella_vslamにデバッグ出力を追加し、確認を行った。

```shell
[2024-02-27 02:23:35.165] [T] values at 1 level of 0 frame orb_extractor::compute_fast_keypoints
[2024-02-27 02:23:35.165] [T]     width    : 495
[2024-02-27 02:23:35.165] [T]     height   : 362
[2024-02-27 02:23:35.165] [T]     num_cols : 8
[2024-02-27 02:23:35.165] [T]     num_rows : 6
```

前述の通り、1レベルにおける`num_cols`が`9`ではなく`8`となっていることがわかる。

以上から、stella_vslam向けのSLAM組み込み用のFASTの実装では、`std::ceil`相当の処理は不要であることがわかる。

#### 15.1.2 テストベンチファイルの作成

Musketeer上で動作確認・評価を行うためのテストベンチファイルを作成した。  
テストベンチファイル用の入出力データには`rgbd_dataset_freiburg3_walking_halfsphere`を使用した。  
`rgbd_dataset_freiburg3_walking_halfsphere`には、1067フレーム分のデータが含まれている。  
RasPi4上で、`rgbd_dataset_freiburg3_walking_halfsphere`を使用して単眼モードで中間データのダンプを行った。  
ダンプファイルのうち、0レベルにおけるセル分割処理とFAST処理の出力特徴点の個数を確認した。

```shell
$ wc -l mono.cpu.main/keypts_to_distribute/keypts_to_distribute_*_0.csv | sort | head -n 3
     586 mono.cpu.main/keypts_to_distribute/keypts_to_distribute_0416_0.csv
     587 mono.cpu.main/keypts_to_distribute/keypts_to_distribute_0423_0.csv
     591 mono.cpu.main/keypts_to_distribute/keypts_to_distribute_0422_0.csv
$ wc -l mono.cpu.main/keypts_to_distribute/keypts_to_distribute_*_0.csv | sort | tail -n 3
    3576 mono.cpu.main/keypts_to_distribute/keypts_to_distribute_0717_0.csv
    3670 mono.cpu.main/keypts_to_distribute/keypts_to_distribute_0718_0.csv
 1903407 total
```

`rgbd_dataset_freiburg3_walking_halfsphere`のうち、0レベルにおいては718番フレームの出力特徴点の個数がもっとも多く、ヘッダーの1行の除いて3669個であることがわかる。  
そのため、Musketeer上でのstella_vslam向けのSLAM組み込み用のFASTの評価では、`rgbd_dataset_freiburg3_walking_halfsphere`の718番フレームの0レベルの中間データをもとに作成したテストベンチファイルを使用する。

#### 15.1.3 変更・動作確認

`15.1.1 ceil処理の確認`の内容を踏まえたうえで、SLAM組み込み用のFASTの実装をstella_vslam相当のセル分割処理に変更した。  
MusketeerはVer.20230724を使用した。

なお、`hazard_avoid_sche = YES`アトリビュートを指定しない場合に意図しない出力が得られる既知の不具合についても確認した。  
`hazard_avoid_sche = YES`アトリビュートを使用しない場合は、意図しない出力が得られる不具合が再現できた。  
そのため、stella_vslam向けのSLAM組み込み用のFASTでも`hazard_avoid_sche = YES`アトリビュートを使用する。

`15.1.2 テストベンチファイルの作成`で作成したテストベンチファイルを使用して、CレベルシミュレーションとRTレベルシミュレーションでVerifiedとなることを確認した。  
RTレベルシミュレーションにおける性能評価の結果は以下の通り。

```shell
[DRP    ] all=759586, exec=755229, hold= 4357 (din=3086, dout=0, rollb=1164, cfgcw=134, end=0)
[BUSDin ] all=967207, dma =26769, stop=19686, data=636712[Byte]
[BUSDout] all=967207, dma = 3670, stop= 3670, data=18347[Byte]
exec time =2418.017500 [us]
```

### 15.2 CVアセット用のFASTの実装変更

CVアセット用のFASTのDRP実装は、入力セル画像の最大サイズを`60x60`として実装していた。  
これは、ORB-SLAM2およびYolo-Planar-SLAMの実装上、想定しなければならない最大サイズである。

一方で、stella_vslamでは最大で`70x70`のセル画像が入力されうる。  
そのため、CVアセット用のFASTの実装に以下の変更を加えた。

```diff
 #define MAX_KEYPOINTS (WORDS_PER_VMEM * 8)  // size of vMEM16x8_RAM

-#define MAX_IMG_SIZE 60
+#define MAX_IMG_SIZE 70

 #define patternSize 16
```

### 15.3 DRPドライバネイティブ適合

以下のアルゴリズムについて、DRPドライバネイティブ適合を行った。

- resize
- GaussianBlur
- FAST
- compute_orb_descriptors

なお、FASTについてはSLAM組み込み用のFASTとCVアセット用のFASTのいずれかを実行時オプションで指定し、使用することができる。

単眼モードで、SLAM組み込み用のFASTが有効のときのダンプ結果を、0番と1番のフレームについて目視確認して、不自然な点が無いことを確認した。  
同様にCVアセット用のFASTについても目視確認を行い、不自然な点が無いことを確認した。

### 15.4 動作確認・評価

OpenCVA、DRPドライバネイティブ、DRP-AIのすべての適合作業が完了した時点での、stella_vslamの動作確認と評価を行った。  
なお、後述する`17 stella_vslamの高速化試行`の変更は以下の動作確認と評価の内容に反映されていないため、注意する必要がある。

#### 15.4.1 単眼

##### 15.4.1.1 OpenCVAあり

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：有効
- DRPドライバネイティブ：無効
- DRP-AI：無効
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.1.1.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.mono.opencva.none.3wh.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.142212
      mean      0.025855
    median      0.021214
       min      0.002020
      rmse      0.030842
       sse      0.971205
       std      0.016814

```

最大誤差が`14`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.mono.opencva.none.3wh.txt \
>   --correct_scale --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_3.mono.opencva.none.3wh
infos:  1021 poses, 15.429m path length, 34.520s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/mono/opencva/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/mono/opencva/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/mono/opencva/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.1.1.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
OpenCVAの処理時間は●で示す。

| 関数                                                                               |            割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|-----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100           |     127.275       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     14.3         |      18.215       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     85.6         |     109.015       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0.7         |       1.016       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.4         |       0.617       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0.2         |       0.28        |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.5         |       0.746       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     58.7         |      74.721       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      2.3         |       2.93        |
| `　　　　　　　　Resize[LEFT][0-7]●` 　　　　　　　　　　　　　　　　　　　　　　|      2.2         |       2.912       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|     29.2         |      37.195       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|     20.3         |      25.888       |
| `　　　　　　　　　　FAST[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　|     20           |      25.519       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      4.6         |       5.981       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      4           |       5.178       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　|      2.1         |       2.749       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     24.6         |      31.313       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.5         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       0.62        |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     22.9         |      29.221       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0.3         |       0.425       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.2         |       0.36        |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     20.8         |      26.553       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      6.6         |       8.414       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      6.5         |       8.386       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      3.1         |       4.041       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      3.3         |       4.257       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0           |       0.002       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     13.4         |      17.173       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|      4.3         |       5.57        |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0           |       0.061       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      4.3         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|      4.5         |       5.73        |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1         |       0.18        |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      1.4         |       1.83        |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|      2.7         |       3.437       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|      4.6         |       5.868       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      4.4         |       5.624       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0           |       0.004       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.8         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.6         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.8         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |

##### 15.4.1.2 DRPドライバネイティブあり（SLAM組み込み用のFAST）

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：無効
- FASTのDRP実装：SLAM組みこみ用のFAST
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.1.2.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.mono.slamfast.none.3wh.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.295603
      mean      0.040999
    median      0.029024
       min      0.004379
      rmse      0.053537
       sse      3.046735
       std      0.034428

```

最大誤差が`29`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.mono.slamfast.none.3wh.txt \
>   --correct_scale --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_3.mono.slamfast.none.3wh
infos:  1063 poses, 19.206m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/mono/slamfast/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/mono/slamfast/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/mono/slamfast/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.1.2.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

| 関数                                                                               |         割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　| 100           |     104.577       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|  17.4         |      18.214       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|  82.5         |      86.325       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|   0.9         |       1.008       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|   0.5         |       0.627       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|   0.2         |       0.284       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|   0.7         |       0.76        |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|  41.2         |      43.188       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|   3           |       3.151       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|   2.9         |       3.137       |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|   0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|   0           |       0.024       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0.3         |       0.415       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.041       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0.2         |       0.275       |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|   1.7         |       1.837       |
| `　　　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|   0.2         |       0.244       |
| `　　　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　|   0.2         |       0.254       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|  19.8         |      20.757       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|   9.1         |       9.58        |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|   0           |       0.002       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|   0           |       0.029       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0.5         |       0.535       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.057       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0.3         |       0.317       |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|   7.1         |       7.453       |
| `　　　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　　　|   0           |       0.038       |
| `　　　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　　　|   0           |       0.051       |
| `　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　　　|   0.9         |       1.017       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|   5.5         |       5.775       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|   5           |       5.251       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|   5.6         |       5.945       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|   0           |       0.001       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0           |       0.027       |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|   0.4         |       0.459       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.049       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       0.312       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|   4.5         |       4.708       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0.3         |       0.345       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       -----       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|  12.1         |      12.718       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|   0           |       0.001       |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　|   0           |       0.038       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0           |       0.027       |
| `　　　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|   0.4         |       0.473       |
| `　　　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　|   0           |       0.03        |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.031       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       0.306       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|  11.1         |      11.705       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0           |       0.066       |
| `　　　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.4         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.7         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|   0.6         |       0.727       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|  36           |      37.742       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|   0.1         |       0.197       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|   0.4         |       0.49        |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|  33.4         |      34.951       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|  10.1         |      10.566       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|  10           |      10.535       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|   4.9         |       5.166       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|   5           |       5.261       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|   0           |       0.004       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|  21.8         |      22.883       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|   6.9         |       7.315       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|   0           |       0.074       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   6.9         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|   7.5         |       7.856       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |   0.2         |       0.22        |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |   2.3         |       2.486       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|   4.5         |       4.731       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.5         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|   7.3         |       7.707       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|   7           |       7.373       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|   0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|   0           |       0.004       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   1.5         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   2.1         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   2.4         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |

##### 15.4.1.3 DRPドライバネイティブあり（CVアセット用のFAST）

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：無効
- FASTのDRP実装：CVアセット用のFAST
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.1.3.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_4.mono.cvfast.none.3wh.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.249032
      mean      0.029113
    median      0.022154
       min      0.001102
      rmse      0.037113
       sse      1.464187
       std      0.023018

```

最大誤差が`24`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_4.mono.cvfast.none.3wh.txt \
>   --correct_scale --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_4.mono.cvfast.none.3wh
infos:  1063 poses, 17.259m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/mono/cvfast/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/mono/cvfast/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/mono/cvfast/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.1.3.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

| 関数                                                                               |         割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|--------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　| 100           |     119.669       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|  15.2         |      18.222       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|  84.7         |     101.408       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|   0.8         |       0.972       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|   0.5         |       0.627       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|   0.2         |       0.285       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|   0.6         |       0.813       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|  49.4         |      59.117       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|   2.6         |       3.13        |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|   2.6         |       3.116       |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|   0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|   0           |       0.023       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0.3         |       0.406       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.041       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0.2         |       0.274       |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|   1.5         |       1.834       |
| `　　　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|   0.1         |       0.236       |
| `　　　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　|   0.2         |       0.256       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|  30.7         |      36.828       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|  20.8         |      24.992       |
| `　　　　　　　　　　FAST[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|  20.5         |      24.636       |
| `　　　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　|   0           |       0.021       |
| `　　　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　|   0.5         |       0.7         |
| `　　　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|   0.7         |       0.884       |
| `　　　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　|   0.6         |       0.784       |
| `　　　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|   6.7         |       8.101       |
| `　　　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　|   6.8         |       8.248       |
| `　　　　　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　|   0.5         |       0.639       |
| `　　　　　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　|   0.5         |       0.604       |
| `　　　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　|   0.4         |       0.553       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   3.8         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|   5.3         |       6.437       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|   4.3         |       5.237       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|   4.9         |       5.926       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|   0           |       0.001       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0           |       0.027       |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|   0.3         |       0.437       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.048       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       0.313       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|   3.9         |       4.709       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0.2         |       0.342       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|  10.5         |      12.666       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|   0           |       0.001       |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　|   0           |       0.038       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|   0           |       0.028       |
| `　　　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|   0.3         |       0.425       |
| `　　　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　|   0           |       0.029       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|   0           |       0.03        |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       0.305       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|   9.7         |      11.7         |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|   0           |       0.063       |
| `　　　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.3         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.7         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|   0.5         |       0.687       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|  30.7         |      36.809       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|   0.1         |       0.196       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|   0.3         |       0.392       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|  28.4         |      34.065       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|   8.8         |      10.55        |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|   8.7         |      10.52        |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|   4.3         |       5.15        |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|   4.3         |       5.264       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|   0           |       0.004       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|   0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|  18.1         |      21.662       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|   5.7         |       6.881       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|   0           |       0.076       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   5.7         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|   6           |       7.242       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |   0.1         |       0.216       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |   1.9         |       2.303       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|   3.6         |       4.34        |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.4         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|   6.2         |       7.533       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|   6           |       7.211       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.2         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|   0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|   0           |       0.004       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   1.5         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   1.9         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   2           |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|   0.1         |       -----       |

##### 15.4.1.4 DRP無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：Monocular
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：無効
- DRPドライバネイティブ：無効
- DRP-AI：無効
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.1.4.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.mono.cpu.none.3wh.txt \
>   --correct_scale --align
APE w.r.t. translation part (m)
(with Sim(3) Umeyama alignment)

       max      0.124992
      mean      0.027284
    median      0.022223
       min      0.001775
      rmse      0.032477
       sse      1.121185
       std      0.017615

```

最大誤差が`12`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.mono.cpu.none.3wh.txt \
>   --correct_scale --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_3.mono.cpu.none.3wh
infos:  1063 poses, 16.194m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/mono/cpu/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/mono/cpu/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/mono/cpu/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.1.4.2 ボトルネック解析

ボトルネック解析結果は以下の通り。

| 関数                                                                               |            割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|-----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100           |     135.25        |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     13.4         |      18.17        |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     86.5         |     117.057       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0.6         |       0.944       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.4         |       0.623       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0.2         |       0.282       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.5         |       0.755       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     56.2         |      76.052       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      3.1         |       4.265       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      3.1         |       4.251       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|     24.6         |      33.337       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|     16.3         |      22.178       |
| `　　　　　　　　　　FAST[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|     16.1         |      21.834       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      4.3         |       5.853       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      3.7         |       5.137       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      4.8         |       6.571       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     23.1         |      31.326       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.6         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       0.657       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     26.4         |      35.826       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0           |       0.133       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.2         |       0.389       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     24.6         |      33.279       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      7.6         |      10.316       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      7.6         |      10.286       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      3.6         |       4.978       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      3.8         |       5.205       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0           |       0.002       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     15.8         |      21.477       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|      4.9         |       6.734       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0           |       0.071       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      4.9         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|      5.4         |       7.355       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1         |       0.216       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      1.7         |       2.36        |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|      3.2         |       4.4         |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|      5.4         |       7.383       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      5.2         |       7.065       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0           |       0.004       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.2         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.6         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.8         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |

#### 15.4.2 ステレオ

##### 15.4.2.1 OpenCVAあり

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：V1_01_easy
- モード：Stereo
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：有効
- DRPドライバネイティブ：無効
- DRP-AI：無効
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.2.1.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum data.tum ./eval/frame_trajectory.v2x.2024.0226_3.stereo.opencva.none.euroc.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.169481
      mean      0.082243
    median      0.075966
       min      0.024051
      rmse      0.087400
       sse      21.938426
       std      0.029577

```

最大誤差が`16`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=data.tum ./eval/frame_trajectory.v2x.2024.0226_3.stereo.opencva.none.euroc.txt --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_3.stereo.opencva.none.euroc
infos:  2872 poses, 58.734m path length, 143.550s duration
--------------------------------------------------------------------------------
name:   data
infos:  28712 poses, 58.592m path length, 143.555s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/stereo/opencva/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/stereo/opencva/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/stereo/opencva/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.2.1.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
OpenCVAの処理時間は●で示す。

| 関数                                                                               |           割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100          |     283.29        |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0          |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      3.1        |       8.996       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     93.3        |     264.542       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0          |       0.002       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.1        |       0.401       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0.3        |       0.942       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.1        |       0.427       |
| `　　　　match::stereo::compute` 　　　　　　　　　　　　　　　　　　　　　　　　|     12.3        |      34.887       |
| `　　　　　　loop in match::stereo::compute` 　　　　　　　　　　　　　　　　　　|     12          |      34.078       |
| `　　　　　　std::sort`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0          |       0.066       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3        |       -----       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     45.5        |     128.941       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      1.1        |       3.294       |
| `　　　　　　　　Resize[LEFT][0-7]●` 　　　　　　　　　　　　　　　　　　　　　　|      1.1        |       3.28        |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0          |       -----       |
| `　　　　　　orb_extractor::compute_image_pyramid[RIGHT]`　　　　　　　　　　　　|      1.1        |       3.238       |
| `　　　　　　　　Resize[RIGHT][0-7]●`　　　　　　　　　　　　　　　　　　　　　　|      1.1        |       3.227       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0          |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|     14.2        |      40.277       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|     12          |      34.073       |
| `　　　　　　　　　　FAST[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　|     11.9        |      33.768       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1        |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      0.9        |       2.79        |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      1.1        |       3.348       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2        |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[RIGHT]`   　　　　　　　　　　|     14.1        |      40.206       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[RIGHT][0-7]`  　　　　　　|     12          |      34.076       |
| `　　　　　　　　　　FAST[RIGHT][0-7]●`  　　　　　　　　　　　　　　　　　　　　|     11.9        |      33.774       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1        |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[RIGHT][0-7]`   　　|      0.9        |       2.758       |
| `　　　　　　　　orb_extractor::compute_orientation[RIGHT][0-7]` 　　　　　　　　|      1.1        |       3.306       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1        |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　|      1          |       2.897       |
| `　　　　　　GaussianBlur[RIGHT][0-7]●`  　　　　　　　　　　　　　　　　　　　　|      1          |       2.893       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      6          |      17.244       |
| `　　　　　　compute_orb_descriptors[RIGHT][0-7]`　　　　　　　　　　　　　　　　|      6          |      17.106       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1          |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.4        |       1.272       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     33.9        |      96.14        |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0          |       0.008       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.3        |       0.905       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     32.7        |      92.871       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      6          |      17.083       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      6          |      17.065       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      1.8        |       5.36        |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      4          |      11.576       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2        |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0          |       0.008       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0          |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0          |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0          |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     26.5        |      75.246       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|     10.9        |      30.982       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0          |       0.107       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     10.9        |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|      9.5        |      27.038       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1        |       0.463       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      4.2        |      12.074       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|      4.3        |      12.245       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.9        |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|      6          |      17.219       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      5.8        |      16.69        |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2        |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1        |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0          |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0          |       0.005       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2        |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.9        |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.7        |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      3.6        |       -----       |

##### 15.4.2.2 DRPドライバネイティブあり（SLAM組み込み用のFAST）

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：V1_01_easy
- モード：Stereo
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：無効
- FASTのDRP実装：SLAM組みこみ用のFAST
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.2.2.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum data.tum ./eval/frame_trajectory.v2x.2024.0226_3.stereo.slamfast.none.euroc.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.182964
      mean      0.085213
    median      0.078963
       min      0.016972
      rmse      0.090809
       sse      23.683059
       std      0.031384

```

最大誤差が`18`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=data.tum ./eval/frame_trajectory.v2x.2024.0226_3.stereo.slamfast.none.euroc.txt --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_3.stereo.slamfast.none.euroc
infos:  2872 poses, 58.994m path length, 143.550s duration
--------------------------------------------------------------------------------
name:   data
infos:  28712 poses, 58.592m path length, 143.555s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/stereo/slamfast/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/stereo/slamfast/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/stereo/slamfast/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.2.2.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

| 関数                                                                               |            割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|-----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100           |     230.661       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      3.8         |       8.987       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     91.8         |     211.846       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.002       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.1         |       0.401       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0.3         |       0.846       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.443       |
| `　　　　match::stereo::compute` 　　　　　　　　　　　　　　　　　　　　　　　　|     15.8         |      36.49        |
| `　　　　　　loop in match::stereo::compute` 　　　　　　　　　　　　　　　　　　|     15.4         |      35.666       |
| `　　　　　　std::sort`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.068       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       -----       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     30.4         |      70.342       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      1.5         |       3.659       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      1.5         |       3.648       |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|      0           |       0.024       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0.2         |       0.472       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.041       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.274       |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|      0.9         |       2.08        |
| `　　　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|      0.1         |       0.361       |
| `　　　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　|      0.1         |       0.324       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_image_pyramid[RIGHT]`　　　　　　　　　　　　|      1.5         |       3.587       |
| `　　　　　　　　Resize[RIGHT][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|      1.5         |       3.577       |
| `　　　　　　　　　　calculate parameter[RIGHT][0-7]`　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　|      0           |       0.022       |
| `　　　　　　　　　　copy input using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　　　|      0.1         |       0.459       |
| `　　　　　　　　　　Activate[RIGHT]`　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.03        |
| `　　　　　　　　　　Start[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.268       |
| `　　　　　　　　　　DRP time[RIGHT][0-7]★`  　　　　　　　　　　　　　　　　　　|      0.8         |       2.072       |
| `　　　　　　　　　　MemcpyP2U[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　|      0.1         |       0.348       |
| `　　　　　　　　　　cv::Mat::clone[RIGHT][0-7]` 　　　　　　　　　　　　　　　　|      0.1         |       0.315       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|      7           |      16.333       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|      4.4         |      10.161       |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|      0           |       0.026       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0.2         |       0.546       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.038       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.307       |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|      3.7         |       8.712       |
| `　　　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　　　|      0           |       0.033       |
| `　　　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　　　|      0           |       0.047       |
| `　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　　　|      0.1         |       0.365       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3           |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      1.1         |       2.667       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      1.4         |       3.458       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[RIGHT]`   　　　　　　　　　　|      7           |      16.265       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[RIGHT][0-7]`  　　　　　　|      4.3         |      10.145       |
| `　　　　　　　　　　calculate parameter[RIGHT][0-7]`　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　|      0           |       0.026       |
| `　　　　　　　　　　copy input using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　　　|      0.2         |       0.541       |
| `　　　　　　　　　　Activate[RIGHT]`　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.037       |
| `　　　　　　　　　　Start[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.307       |
| `　　　　　　　　　　DRP time[RIGHT][0-7]★`  　　　　　　　　　　　　　　　　　　|      3.7         |       8.709       |
| `　　　　　　　　　　copy keypoints size using MemcpyP2U[RIGHT][0-7]`　　　　　　|      0           |       0.032       |
| `　　　　　　　　　　copy keypoints using MemcpyP2U[RIGHT][0-7]` 　　　　　　　　|      0           |       0.047       |
| `　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[RIGHT][0-7]` 　　　　　　|      0.1         |       0.36        |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[RIGHT][0-7]`   　　|      1.1         |       2.643       |
| `　　　　　　　　orb_extractor::compute_orientation[RIGHT][0-7]` 　　　　　　　　|      1.4         |       3.431       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      2.5         |       5.964       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0           |       0.026       |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|      0.2         |       0.507       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.046       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.312       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|      2           |       4.642       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.387       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　GaussianBlur[RIGHT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      2.5         |       5.959       |
| `　　　　　　　　calculate parameter[RIGHT][0-7]`　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　copy parameter using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　　　|      0           |       0.026       |
| `　　　　　　　　copy input using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　　　　　|      0.2         |       0.505       |
| `　　　　　　　　Activate[RIGHT]`　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.045       |
| `　　　　　　　　Start[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.312       |
| `　　　　　　　　DRP time[RIGHT][0-7]★`  　　　　　　　　　　　　　　　　　　　　|      2           |       4.64        |
| `　　　　　　　　MemcpyP2U[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.388       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      3.5         |       8.243       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　|      0           |       0.022       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0           |       0.026       |
| `　　　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|      0.2         |       0.523       |
| `　　　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　|      0           |       0.025       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.028       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.304       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|      3.1         |       7.227       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0           |       0.05        |
| `　　　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　compute_orb_descriptors[RIGHT][0-7]`　　　　　　　　　　　　　　　　|      3.5         |       8.217       |
| `　　　　　　　　calculate parameter[RIGHT][0-7]`　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[RIGHT][0-7]`  　　　　　　　　|      0           |       0.022       |
| `　　　　　　　　copy parameter using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　　　|      0           |       0.026       |
| `　　　　　　　　copy input image using MemcpyU2P[RIGHT][0-7]`   　　　　　　　　|      0.2         |       0.522       |
| `　　　　　　　　copy input keypoints using MemcpyU2P[RIGHT][0-7]`   　　　　　　|      0           |       0.024       |
| `　　　　　　　　Activate[RIGHT]`　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.028       |
| `　　　　　　　　Start[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.304       |
| `　　　　　　　　DRP time[RIGHT][0-7]★`  　　　　　　　　　　　　　　　　　　　　|      3.1         |       7.2         |
| `　　　　　　　　MemcpyP2U[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　|      0           |       0.049       |
| `　　　　　　　　postprocess[RIGHT][0-7]`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.4         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.5         |       1.312       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     43.5         |     100.419       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0           |       0.008       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.3         |       0.902       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     42           |      97.048       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      7.6         |      17.614       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      7.6         |      17.596       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      2.3         |       5.476       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      5.1         |      11.983       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0           |       0.008       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     34           |      78.535       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|     14.1         |      32.647       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0           |       0.11        |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     14.1         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|     11.9         |      27.655       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.2         |       0.471       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      5.2         |      12.193       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|      5.4         |      12.535       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      1.1         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|      7.9         |      18.227       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      7.6         |      17.672       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0           |       0.005       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.2         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.1         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      4.4         |       -----       |

##### 15.4.2.3 DRPドライバネイティブあり（CVアセット用のFAST）

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：V1_01_easy
- モード：Stereo
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：無効
- FASTのDRP実装：CVアセット用のFAST
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.2.3.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum data.tum ./eval/frame_trajectory.v2x.2024.0226_4.stereo.cvfast.none.euroc.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.184919
      mean      0.084846
    median      0.078663
       min      0.015296
      rmse      0.090419
       sse      23.480087
       std      0.031251

```

最大誤差が`18`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=data.tum ./eval/frame_trajectory.v2x.2024.0226_4.stereo.cvfast.none.euroc.txt --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_4.stereo.cvfast.none.euroc
infos:  2872 poses, 58.895m path length, 143.550s duration
--------------------------------------------------------------------------------
name:   data
infos:  28712 poses, 58.592m path length, 143.555s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/stereo/cvfast/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/stereo/cvfast/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/stereo/cvfast/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.2.3.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

| 関数                                                                               |            割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|-----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100           |     266.271       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      3.3         |       8.962       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     92.9         |     247.572       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.002       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.1         |       0.405       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0.2         |       0.793       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.444       |
| `　　　　match::stereo::compute` 　　　　　　　　　　　　　　　　　　　　　　　　|     13.2         |      35.341       |
| `　　　　　　loop in match::stereo::compute` 　　　　　　　　　　　　　　　　　　|     12.9         |      34.526       |
| `　　　　　　std::sort`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.067       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     40.2         |     107.183       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      1.3         |       3.667       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      1.3         |       3.655       |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|      0           |       0.025       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0.1         |       0.468       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.041       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.275       |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|      0.7         |       2.08        |
| `　　　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|      0.1         |       0.362       |
| `　　　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　|      0.1         |       0.331       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_image_pyramid[RIGHT]`　　　　　　　　　　　　|      1.3         |       3.604       |
| `　　　　　　　　Resize[RIGHT][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|      1.3         |       3.594       |
| `　　　　　　　　　　calculate parameter[RIGHT][0-7]`　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　|      0           |       0.023       |
| `　　　　　　　　　　copy input using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　　　|      0.1         |       0.459       |
| `　　　　　　　　　　Activate[RIGHT]`　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.031       |
| `　　　　　　　　　　Start[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.269       |
| `　　　　　　　　　　DRP time[RIGHT][0-7]★`  　　　　　　　　　　　　　　　　　　|      0.7         |       2.072       |
| `　　　　　　　　　　MemcpyP2U[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　|      0.1         |       0.351       |
| `　　　　　　　　　　cv::Mat::clone[RIGHT][0-7]` 　　　　　　　　　　　　　　　　|      0.1         |       0.325       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|     13           |      34.82        |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|     10.7         |      28.641       |
| `　　　　　　　　　　FAST[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|     10.6         |      28.36        |
| `　　　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　|      0           |       0.025       |
| `　　　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　|      0.3         |       0.848       |
| `　　　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|      0.4         |       1.079       |
| `　　　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　|      0.3         |       0.915       |
| `　　　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|      3.5         |       9.584       |
| `　　　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　|      3.6         |       9.615       |
| `　　　　　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　|      0.2         |       0.777       |
| `　　　　　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　|      0.2         |       0.618       |
| `　　　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　|      0.1         |       0.429       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      2           |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      1           |       2.801       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      1.2         |       3.331       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[RIGHT]`   　　　　　　　　　　|     13           |      34.704       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[RIGHT][0-7]`  　　　　　　|     10.7         |      28.575       |
| `　　　　　　　　　　FAST[RIGHT][0-7]`   　　　　　　　　　　　　　　　　　　　　|     10.6         |      28.296       |
| `　　　　　　　　　　　　calculate parameter[RIGHT][0-7]`　　　　　　　　　　　　|      0           |       0.025       |
| `　　　　　　　　　　　　copy parameter using MemcpyU2P[RIGHT][0-7]` 　　　　　　|      0.3         |       0.846       |
| `　　　　　　　　　　　　copy input using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　|      0.4         |       1.08        |
| `　　　　　　　　　　　　Activate[RIGHT]`　　　　　　　　　　　　　　　　　　　　|      0.3         |       0.914       |
| `　　　　　　　　　　　　Start[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　|      3.5         |       9.58        |
| `　　　　　　　　　　　　DRP time[RIGHT][0-7]★`  　　　　　　　　　　　　　　　　|      3.5         |       9.58        |
| `　　　　　　　　　　　　copy keypoints size using MemcpyP2U[RIGHT][0-7]`　　　　|      0.2         |       0.774       |
| `　　　　　　　　　　　　copy keypoints using MemcpyP2U[RIGHT][0-7]` 　　　　　　|      0.2         |       0.615       |
| `　　　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[RIGHT][0-7]` 　　　　|      0.1         |       0.423       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      2.1         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[RIGHT][0-7]`   　　|      1           |       2.774       |
| `　　　　　　　　orb_extractor::compute_orientation[RIGHT][0-7]` 　　　　　　　　|      1.2         |       3.306       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      2.2         |       5.941       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0           |       0.027       |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|      0.1         |       0.481       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.044       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.314       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|      1.7         |       4.637       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.389       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　GaussianBlur[RIGHT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      2.2         |       5.932       |
| `　　　　　　　　calculate parameter[RIGHT][0-7]`　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　copy parameter using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　　　|      0           |       0.027       |
| `　　　　　　　　copy input using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　　　　　|      0.1         |       0.478       |
| `　　　　　　　　Activate[RIGHT]`　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.043       |
| `　　　　　　　　Start[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.313       |
| `　　　　　　　　DRP time[RIGHT][0-7]★`  　　　　　　　　　　　　　　　　　　　　|      1.7         |       4.635       |
| `　　　　　　　　MemcpyP2U[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.387       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      3           |       8.213       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　|      0           |       0.022       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0           |       0.026       |
| `　　　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|      0.1         |       0.483       |
| `　　　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　|      0           |       0.025       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.028       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.305       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|      2.7         |       7.227       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0           |       0.051       |
| `　　　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　compute_orb_descriptors[RIGHT][0-7]`　　　　　　　　　　　　　　　　|      3           |       8.187       |
| `　　　　　　　　calculate parameter[RIGHT][0-7]`　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[RIGHT][0-7]`  　　　　　　　　|      0           |       0.022       |
| `　　　　　　　　copy parameter using MemcpyU2P[RIGHT][0-7]` 　　　　　　　　　　|      0           |       0.026       |
| `　　　　　　　　copy input image using MemcpyU2P[RIGHT][0-7]`   　　　　　　　　|      0.1         |       0.484       |
| `　　　　　　　　copy input keypoints using MemcpyU2P[RIGHT][0-7]`   　　　　　　|      0           |       0.025       |
| `　　　　　　　　Activate[RIGHT]`　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.028       |
| `　　　　　　　　Start[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.305       |
| `　　　　　　　　DRP time[RIGHT][0-7]★`  　　　　　　　　　　　　　　　　　　　　|      2.7         |       7.2         |
| `　　　　　　　　MemcpyP2U[RIGHT][0-7]`  　　　　　　　　　　　　　　　　　　　　|      0           |       0.051       |
| `　　　　　　　　postprocess[RIGHT][0-7]`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.2         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.5         |       1.359       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     37.7         |     100.479       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0           |       0.007       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.3         |       0.886       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     36.4         |      97.149       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      6.6         |      17.633       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      6.6         |      17.615       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      2           |       5.49        |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      4.5         |      11.991       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0           |       0.008       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     29.5         |      78.721       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|     12.3         |      33.008       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0           |       0.11        |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     12.3         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|     10.3         |      27.435       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1         |       0.47        |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      4.5         |      12.203       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|      4.6         |      12.46        |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      1.1         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|      6.8         |      18.272       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      6.6         |      17.721       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0           |       0.004       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1           |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.9         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      3.8         |       -----       |

##### 15.4.2.4 DRP無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：V1_01_easy
- モード：Stereo
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：無効
- DRPドライバネイティブ：無効
- DRP-AI：無効
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.2.4.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum data.tum ./eval/frame_trajectory.v2x.2024.0226_3.stereo.cpu.none.euroc.txt --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.171875
      mean      0.082202
    median      0.075875
       min      0.017303
      rmse      0.087545
       sse      22.011502
       std      0.030116

```

最大誤差が`17`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum --ref=data.tum ./eval/frame_trajectory.v2x.2024.0226_3.stereo.cpu.none.euroc.txt --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_3.stereo.cpu.none.euroc
infos:  2872 poses, 58.813m path length, 143.550s duration
--------------------------------------------------------------------------------
name:   data
infos:  28712 poses, 58.592m path length, 143.555s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/stereo/cvfast/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/stereo/cvfast/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/stereo/cvfast/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.2.4.2 ボトルネック解析

ボトルネック解析結果は以下の通り。

| 関数                                                                               |            割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|-----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100           |     282.168       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      3.1         |       8.993       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     93.2         |     263.222       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.002       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.1         |       0.411       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0.3         |       0.926       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.432       |
| `　　　　match::stereo::compute` 　　　　　　　　　　　　　　　　　　　　　　　　|     12.9         |      36.489       |
| `　　　　　　loop in match::stereo::compute` 　　　　　　　　　　　　　　　　　　|     12.6         |      35.655       |
| `　　　　　　std::sort`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.067       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     42.4         |     119.723       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      2.1         |       6.147       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      2.1         |       6.134       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_image_pyramid[RIGHT]`　　　　　　　　　　　　|      2.1         |       6.05        |
| `　　　　　　　　Resize[RIGHT][0-7]` 　　　　　　　　　　　　　　　　　　　　　　|      2.1         |       6.04        |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|      9.8         |      27.718       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|      7.4         |      21.041       |
| `　　　　　　　　　　FAST[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      7.3         |      20.771       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      1.1         |       3.187       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      1.2         |       3.388       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[RIGHT]`   　　　　　　　　　　|      9.7         |      27.504       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[RIGHT][0-7]`  　　　　　　|      7.4         |      20.902       |
| `　　　　　　　　　　FAST[RIGHT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      7.3         |      20.637       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[RIGHT][0-7]`   　　|      1.1         |       3.126       |
| `　　　　　　　　orb_extractor::compute_orientation[RIGHT][0-7]` 　　　　　　　　|      1.1         |       3.368       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      2.7         |       7.87        |
| `　　　　　　GaussianBlur[RIGHT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      2.7         |       7.821       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      6.1         |      17.266       |
| `　　　　　　compute_orb_descriptors[RIGHT][0-7]`　　　　　　　　　　　　　　　　|      6           |      17.137       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.2         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       1.387       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     36.2         |     102.249       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0           |       0.007       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.3         |       0.895       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     35           |      98.87        |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      6.3         |      17.834       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      6.3         |      17.815       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      1.9         |       5.515       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      4.3         |      12.158       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0           |       0.009       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     28.4         |      80.323       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|     11.9         |      33.62        |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0           |       0.114       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     11.9         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|      9.8         |      27.838       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1         |       0.48        |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      4.3         |      12.247       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|      4.4         |      12.619       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      1           |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|      6.6         |      18.859       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      6.4         |      18.295       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0           |       0.005       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.9         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.8         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      3.7         |       -----       |

#### 15.4.3 RGB-D

##### 15.4.3.1 OpenCVAあり

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：RGB-D
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：有効
- DRPドライバネイティブ：無効
- DRP-AI：無効
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.3.1.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.rgbd.opencva.none.3wh.txt \
>   --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.441112
      mean      0.135529
    median      0.111062
       min      0.012100
      rmse      0.155733
       sse      25.780754
       std      0.076712

```

最大誤差が`44`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.rgbd.opencva.none.3wh.txt \
>   --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_3.rgbd.opencva.none.3wh
infos:  1063 poses, 16.887m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/rgbd/opencva/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/rgbd/opencva/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/rgbd/opencva/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.3.1.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
OpenCVAの処理時間は●で示す。

| 関数                                                                               |            割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|-----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100           |     282.358       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     11.1         |      31.514       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     88.8         |     250.823       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       1.077       |
| `　　　　util::convert_to_true_depth`　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       0.728       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.2         |       0.621       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0.1         |       0.283       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.2         |       0.744       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     27.3         |      77.334       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      1           |       2.975       |
| `　　　　　　　　Resize[LEFT][0-7]●` 　　　　　　　　　　　　　　　　　　　　　　|      1           |       2.952       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|     14           |      39.641       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|      9.3         |      26.433       |
| `　　　　　　　　　　FAST[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　|      9.2         |      26.052       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      2.7         |       7.658       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      1.8         |       5.292       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]●`   　　　　　　　　　　　　　　　　　　　　|      0.9         |       2.739       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|     11.1         |      31.407       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.7         |       2.01        |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     58.4         |     165.172       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0           |       0.046       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.7         |       2.146       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     56.2         |     158.709       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      9.8         |      27.815       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      9.8         |      27.747       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      4.2         |      12.126       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      5.4         |      15.349       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0           |       0.016       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     45.2         |     127.699       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|      8.2         |      23.191       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0           |       0.136       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      8.2         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|     24.4         |      68.927       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1         |       0.471       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      6.3         |      17.989       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|     14.9         |      42.109       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      3.1         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|     12.5         |      35.563       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     12.2         |      34.555       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0           |       0.005       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.2         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.5         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.4         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |

##### 15.4.3.2 DRPドライバネイティブあり（SLAM組み込み用のFAST）

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：RGB-D
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：無効
- FASTのDRP実装：SLAM組みこみ用のFAST
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.3.2.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.rgbd.slamfast.none.3wh.txt \
>   --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.431383
      mean      0.100333
    median      0.095713
       min      0.005709
      rmse      0.122682
       sse      15.999140
       std      0.070599

```

最大誤差が`43`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.rgbd.slamfast.none.3wh.txt \
>   --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_3.rgbd.slamfast.none.3wh
infos:  1063 poses, 16.569m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/rgbd/slanfast/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/rgbd/slanfast/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/rgbd/slanfast/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.3.2.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

| 関数                                                                               |            割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|-----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100           |     276.605       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|     10.5         |      29.053       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     89.4         |     247.534       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       0.984       |
| `　　　　util::convert_to_true_depth`　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       0.723       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.2         |       0.628       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0.1         |       0.285       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.2         |       0.766       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     16.4         |      45.459       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      1.1         |       3.198       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      1.1         |       3.175       |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|      0           |       0.026       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0.1         |       0.419       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.045       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0           |       0.277       |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|      0.6         |       1.837       |
| `　　　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|      0           |       0.24        |
| `　　　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　|      0.1         |       0.279       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|      8.3         |      23.05        |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|      3.6         |      10.018       |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|      0           |       0.002       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|      0           |       0.031       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0.1         |       0.494       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.064       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.32        |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|      2.6         |       7.453       |
| `　　　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　　　|      0           |       0.04        |
| `　　　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　　　|      0           |       0.048       |
| `　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　　　|      0.5         |       1.48        |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      2.6         |       7.454       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      1.9         |       5.331       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      2.1         |       5.878       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0           |       0.027       |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|      0.1         |       0.437       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.048       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.313       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|      1.6         |       4.666       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.338       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      4.5         |      12.68        |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　|      0           |       0.038       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0           |       0.027       |
| `　　　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|      0.1         |       0.443       |
| `　　　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　|      0           |       0.029       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.03        |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.306       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|      4.2         |      11.692       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0           |       0.066       |
| `　　　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.8         |       2.232       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     69.9         |     193.487       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0           |       0.045       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.7         |       2.191       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     67.5         |     186.774       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|     10.2         |      28.489       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|     10.2         |      28.42        |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      4.5         |      12.507       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      5.6         |      15.627       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0           |       0.017       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     55.3         |     153.018       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|     11.1         |      30.807       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0           |       0.141       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|     11.1         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|     29.8         |      82.644       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1         |       0.51        |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      8.1         |      22.628       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|     17.6         |      48.947       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      4           |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|     14.2         |      39.551       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     13.8         |      38.435       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0           |       0.005       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      2           |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.7         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.3         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |

##### 15.4.3.3 DRPドライバネイティブあり（CVアセット用のFAST）

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：RGB-D
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：無効
- DRPドライバネイティブ：有効
- DRP-AI：無効
- FASTのDRP実装：CVアセット用のFAST
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.3.3.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_4.rgbd.cvfast.none.3wh.txt \
>   --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.496909
      mean      0.149475
    median      0.113275
       min      0.024210
      rmse      0.183531
       sse      35.805846
       std      0.106495

```

最大誤差が`49`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_4.rgbd.cvfast.none.3wh.txt \
>   --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_4.rgbd.cvfast.none.3wh
infos:  1063 poses, 16.864m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/rgbd/cvfast/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/rgbd/cvfast/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/rgbd/cvfast/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.3.3.2 ボトルネック解析

ボトルネック解析結果は以下の通り。  
DRPの処理時間は★で示す。

| 関数                                                                               |            割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|-----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100           |     294.459       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      9.8         |      29.089       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     90.1         |     265.348       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       1.012       |
| `　　　　util::convert_to_true_depth`　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       0.74        |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.2         |       0.633       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0           |       0.289       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.2         |       0.819       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     21           |      61.967       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      1           |       3.196       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      1           |       3.173       |
| `　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|      0           |       0.026       |
| `　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0.1         |       0.415       |
| `　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.045       |
| `　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0           |       0.277       |
| `　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　|      0.6         |       1.836       |
| `　　　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|      0           |       0.237       |
| `　　　　　　　　　　cv::Mat::clone[LEFT][0-7]`  　　　　　　　　　　　　　　　　|      0           |       0.286       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3         |       -----       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|     13.4         |      39.594       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|      8.7         |      25.723       |
| `　　　　　　　　　　FAST[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      8.6         |      25.353       |
| `　　　　　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　|      0           |       0.022       |
| `　　　　　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　|      0.2         |       0.741       |
| `　　　　　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　|      0.3         |       0.921       |
| `　　　　　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　|      0.2         |       0.794       |
| `　　　　　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　|      2.7         |       8.096       |
| `　　　　　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　|      2.8         |       8.252       |
| `　　　　　　　　　　　　copy keypoints size using MemcpyP2U[LEFT][0-7]` 　　　　|      0.2         |       0.645       |
| `　　　　　　　　　　　　copy keypoints using MemcpyP2U[LEFT][0-7]`  　　　　　　|      0.2         |       0.618       |
| `　　　　　　　　　　　　cv::KeyPoint to drp::KeyPoint_FAST[LEFT][0-7]`  　　　　|      0.1         |       0.578       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      1.9         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      2.8         |       8.25        |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      1.8         |       5.357       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      1.9         |       5.862       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0           |       0.028       |
| `　　　　　　　　copy input using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　　　|      0.1         |       0.431       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.049       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.315       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|      1.5         |       4.648       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.34        |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      4.3         |      12.681       |
| `　　　　　　　　calculate parameter[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      0           |       0.001       |
| `　　　　　　　　cv::KeyPoint to drp::KeyPoint_ORB[LEFT][0-7]`   　　　　　　　　|      0           |       0.038       |
| `　　　　　　　　copy parameter using MemcpyU2P[LEFT][0-7]`  　　　　　　　　　　|      0           |       0.028       |
| `　　　　　　　　copy input image using MemcpyU2P[LEFT][0-7]`　　　　　　　　　　|      0.1         |       0.432       |
| `　　　　　　　　copy input keypoints using MemcpyU2P[LEFT][0-7]`　　　　　　　　|      0           |       0.029       |
| `　　　　　　　　Activate[LEFT]` 　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       0.031       |
| `　　　　　　　　Start[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       0.307       |
| `　　　　　　　　DRP time[LEFT][0-7]★`   　　　　　　　　　　　　　　　　　　　　|      3.9         |      11.701       |
| `　　　　　　　　MemcpyP2U[LEFT][0-7]`   　　　　　　　　　　　　　　　　　　　　|      0           |       0.067       |
| `　　　　　　　　postprocess[LEFT][0-7]` 　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.7         |       2.283       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     66           |     194.419       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0           |       0.045       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      1.1         |       3.372       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     63.2         |     186.129       |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|     10.6         |      31.467       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|     10.6         |      31.398       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      4.5         |      13.535       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      5.9         |      17.543       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2         |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0           |       0.017       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0           |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     50.1         |     147.807       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|      9.4         |      27.843       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0           |       0.147       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      9.4         |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|     26.7         |      78.705       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1         |       0.502       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      6.9         |      20.55        |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|     16.2         |      47.769       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      3.5         |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|     14           |      41.239       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     13.6         |      40.091       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.4         |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0           |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0           |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0           |       0.005       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      2.5         |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.7         |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.5         |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1         |       -----       |

##### 15.4.3.4 DRP無し

実行条件は以下の通り。

- 使用したマシン：V2xボード（α2、EVK-α、電力改善版）
- CPUの最大動作周波数設定：1.7GHz
- データセット：rgbd_dataset_freiburg3_walking_halfsphere
- モード：RGB-D
- オプション：デフォルト設定からヴィジュアライザに関するフラグを無効化
- `Preprocessing:min_size`：800
- OpenCVA：無効
- DRPドライバネイティブ：無効
- DRP-AI：無効
- DRP-AIオブジェクトファイル：YUYV入力（`v210_yolox_tmp_240119/yolox_cam`）
- DRP/DRP-AIドライバ：バージョン1

###### 15.4.3.4.1 SLAM軌跡評価

軌跡の評価結果は以下の通り。

```shell
$ evo_ape tum \
>   /opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.rgbd.cpu.none.3wh.txt \
>   --align
APE w.r.t. translation part (m)
(with SE(3) Umeyama alignment)

       max      0.575127
      mean      0.169002
    median      0.116447
       min      0.019570
      rmse      0.204338
       sse      44.384506
       std      0.114857

```

最大誤差が`57`\[cm\]であることがわかる。

軌跡のプロットも行った。

```shell
$ evo_traj tum \
>   --ref=/opt/dataset/tum/rgbd_dataset_freiburg3_walking_halfsphere/groundtruth.txt \
>   ./eval/frame_trajectory.v2x.2024.0226_3.rgbd.cpu.none.3wh.txt \
>   --align
--------------------------------------------------------------------------------
name:   frame_trajectory.v2x.2024.0226_3.rgbd.cpu.none.3wh
infos:  1063 poses, 17.071m path length, 35.760s duration
--------------------------------------------------------------------------------
name:   groundtruth
infos:  3582 poses, 8.536m path length, 35.810s duration
```

軌跡の比較図は以下の通り。

![軌跡の比較図](image/stella_vslam/drp_driver/rgbd/cpu/evo_traj_trajectories.png)

フレームごとの位置の誤差は以下の通り。

![フレームごとの位置の誤差](image/stella_vslam/drp_driver/rgbd/cpu/evo_traj_xyz_view.png)

フレームごとの姿勢の誤差は以下の通り。

![フレームごとの姿勢の誤差](image/stella_vslam/drp_driver/rgbd/cpu/evo_traj_rpy_view.png)

目視した限りではSLAM精度の破綻は見られない。

###### 15.4.3.4.2 ボトルネック解析

ボトルネック解析結果は以下の通り。

| 関数                                                                               |           割合(%) |   実測値(msec/frame) |
|:---------------------------------------------------------------------------------|----------------:|------------------:|
| `Main loop`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|    100          |     316.678       |
| `　　Sleep while waiting for the next frame` 　　　　　　　　　　　　　　　　　　|      0          |       0           |
| `　　cv::imread` 　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      9.1        |      29.083       |
| `　　system::feed_*_frame`   　　　　　　　　　　　　　　　　　　　　　　　　　　|     90.8        |     287.574       |
| `　　　　util::convert_to_grayscale` 　　　　　　　　　　　　　　　　　　　　　　|      0.3        |       0.984       |
| `　　　　util::convert_to_true_depth`　　　　　　　　　　　　　　　　　　　　　　|      0.2        |       0.723       |
| `　　　　camera::base::undistort_keypoints`  　　　　　　　　　　　　　　　　　　|      0.1        |       0.632       |
| `　　　　camera::base::convert_keypoints_to_bearings`　　　　　　　　　　　　　　|      0          |       0.286       |
| `　　　　data::assign_keypoints_to_grid` 　　　　　　　　　　　　　　　　　　　　|      0.2        |       0.809       |
| `　　　　orb_extractor::extract` 　　　　　　　　　　　　　　　　　　　　　　　　|     25.2        |      80.092       |
| `　　　　　　orb_extractor::compute_image_pyramid[LEFT]` 　　　　　　　　　　　　|      1.3        |       4.368       |
| `　　　　　　　　Resize[LEFT][0-7]`  　　　　　　　　　　　　　　　　　　　　　　|      1.3        |       4.344       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0          |       -----       |
| `　　　　　　orb_extractor::compute_fast_keypoints[LEFT]`　　　　　　　　　　　　|     11.4        |      36.276       |
| `　　　　　　　　orb_extractor::compute_fast_keypoints[LEFT][0-7]`   　　　　　　|      7.2        |      22.858       |
| `　　　　　　　　　　FAST[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      7.1        |      22.496       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1        |       -----       |
| `　　　　　　　　orb_extractor::distribute_keypoints_via_tree[LEFT][0-7]`　　　　|      2.4        |       7.878       |
| `　　　　　　　　orb_extractor::compute_orientation[LEFT][0-7]`  　　　　　　　　|      1.6        |       5.293       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.2        |       -----       |
| `　　　　　　GaussianBlur[LEFT][0-7]`　　　　　　　　　　　　　　　　　　　　　　|      2.3        |       7.318       |
| `　　　　　　compute_orb_descriptors[LEFT][0-7]` 　　　　　　　　　　　　　　　　|      9.9        |      31.521       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.3        |       -----       |
| `　　　　frame_publisher::update`　　　　　　　　　　　　　　　　　　　　　　　　|      0.6        |       2.154       |
| `　　　　tracking_module::feed_frame`　　　　　　　　　　　　　　　　　　　　　　|     62.7        |     198.745       |
| `　　　　　　tracking_module::initialize`　　　　　　　　　　　　　　　　　　　　|      0          |       0.046       |
| `　　　　　　keyframe_inserter::insert_new_keyframe` 　　　　　　　　　　　　　　|      0.9        |       2.905       |
| `　　　　　　tracking_module::track` 　　　　　　　　　　　　　　　　　　　　　　|     60.3        |     191.02        |
| `　　　　　　　　tracking_module::track_current_frame`   　　　　　　　　　　　　|      9.8        |      31.278       |
| `　　　　　　　　　　frame_tracker::motion_based_track`  　　　　　　　　　　　　|      9.8        |      31.207       |
| `　　　　　　　　　　　　projection::match_current_and_last_frames`  　　　　　　|      4.1        |      13.286       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|      5.5        |      17.605       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.2        |       -----       |
| `　　　　　　　　　　frame_tracker::bow_match_based_track`   　　　　　　　　　　|      0          |       0.018       |
| `　　　　　　　　　　frame_tracker::robust_match_based_track`　　　　　　　　　　|      0          |       0           |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0          |       -----       |
| `　　　　　　　　relocalizer::relocalize`　　　　　　　　　　　　　　　　　　　　|      0          |       0           |
| `　　　　　　　　tracking_module::track_local_map`   　　　　　　　　　　　　　　|     49.1        |     155.621       |
| `　　　　　　　　　　tracking_module::update_local_map`  　　　　　　　　　　　　|      9.8        |      31.083       |
| `　　　　　　　　　　　　loop of num_keypts_`　　　　　　　　　　　　　　　　　　|      0          |       0.148       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      9.8        |       -----       |
| `　　　　　　　　　　tracking_module::search_local_landmarks`　　　　　　　　　　|     25.9        |      82.284       |
| `　　　　　　　　　　　　first loop in tracking_module::search_local_landmarks`  |      0.1        |       0.499       |
| `　　　　　　　　　　　　second loop in tracking_module::search_local_landmarks` |      6.9        |      22.114       |
| `　　　　　　　　　　　　match::projection::match_frame_and_landmarks`   　　　　|     15.4        |      48.911       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      3.5        |       -----       |
| `　　　　　　　　　　tracking_module::optimize_current_frame_with_local_map` 　　|     13.3        |      42.234       |
| `　　　　　　　　　　　　pose_optimizer::optimize`   　　　　　　　　　　　　　　|     12.9        |      41.093       |
| `　　　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　|      0.4        |       -----       |
| `　　　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1        |       -----       |
| `　　　　　　　　tracking_module::track_local_map_without_temporal_keyframes`　　|      0          |       0           |
| `　　　　　　　　tracking_module::update_motion_model`   　　　　　　　　　　　　|      0          |       0.005       |
| `　　　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.4        |       -----       |
| `　　　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.5        |       -----       |
| `　　　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      1.5        |       -----       |
| `　　その他`  　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　|      0.1        |       -----       |

#### 15.4.4 考察

Trackingスレッドの平均処理時間は以下の通り。

| モード   | 実行時オプション       | 全体 \[ms/frame\] |
|-------|----------------|--------------:|
| 単眼    | OpenCVA        | 127.275       |
| 単眼    | SLAM組み込み用のFAST | 104.577       |
| 単眼    | CVアセット用のFAST   | 119.669       |
| 単眼    | CPU            | 135.250       |
| ステレオ  | OpenCVA        | 283.290       |
| ステレオ  | SLAM組み込み用のFAST | 230.661       |
| ステレオ  | CVアセット用のFAST   | 266.271       |
| ステレオ  | CPU            | 282.168       |
| RGB-D | OpenCVA        | 282.358       |
| RGB-D | SLAM組み込み用のFAST | 276.605       |
| RGB-D | CVアセット用のFAST   | 294.459       |
| RGB-D | CPU            | 316.678       |

単眼 + SLAM組み込み用のFASTの場合がもっとも高速に動作していることがわかる。  
また、いずれのモードでもSLAM組み込み用のFASTを使用する場合がもっとも高速に動作していることがわかる。

Resizeの平均処理時間は以下の通り。

| モード   | 実行時オプション       | 左 \[ms/frame\] | 右 \[ms/frame\] |
|-------|----------------|-------------:|-------------:|
| 単眼    | OpenCVA        | 2.912        |        ----- |
| 単眼    | SLAM組み込み用のFAST | 3.137        |        ----- |
| 単眼    | CVアセット用のFAST   | 3.116        |        ----- |
| 単眼    | CPU            | 4.251        |        ----- |
| ステレオ  | OpenCVA        | 3.280        | 3.227        |
| ステレオ  | SLAM組み込み用のFAST | 3.648        | 3.577        |
| ステレオ  | CVアセット用のFAST   | 3.655        | 3.594        |
| ステレオ  | CPU            | 6.134        | 6.040        |
| RGB-D | OpenCVA        | 2.952        |        ----- |
| RGB-D | SLAM組み込み用のFAST | 3.175        |        ----- |
| RGB-D | CVアセット用のFAST   | 3.173        |        ----- |
| RGB-D | CPU            | 4.344        |        ----- |

単眼 + OpenCVAの場合がもっとも高速に動作していることがわかる。  
また、いずれのモードでもOpenCVAを使用する場合がもっとも高速に動作していることがわかる。

GaussianBlurの平均処理時間は以下の通り。  
なお、OpenCVAのGaussianBlurでは入力画像の縦サイズ、横サイズのいずれも偶数の場合のみDRPが使用される点に注意する。

| モード   | 実行時オプション       | 左 \[ms/frame\] | 右 \[ms/frame\] |
|-------|----------------|-------------:|-------------:|
| 単眼    | OpenCVA        | 2.749        |        ----- |
| 単眼    | SLAM組み込み用のFAST | 5.945        |        ----- |
| 単眼    | CVアセット用のFAST   | 5.926        |        ----- |
| 単眼    | CPU            | 6.571        |        ----- |
| ステレオ  | OpenCVA        | 2.897        | 2.893        |
| ステレオ  | SLAM組み込み用のFAST | 5.964        | 5.959        |
| ステレオ  | CVアセット用のFAST   | 5.941        | 5.932        |
| ステレオ  | CPU            | 7.870        | 7.821        |
| RGB-D | OpenCVA        | 2.739        |        ----- |
| RGB-D | SLAM組み込み用のFAST | 5.878        |        ----- |
| RGB-D | CVアセット用のFAST   | 5.862        |        ----- |
| RGB-D | CPU            | 7.318        |        ----- |

RGB-D + OpenCVAの場合がもっとも高速に動作していることがわかる。  
また、いずれのモードでもOpenCVAを使用する場合がもっとも高速に動作していることがわかる。

`orb_extractor::compute_fast_keypoints[LEFT|RIGHT][0-7]`の平均処理時間は以下の通り。  
なお、OpenCVAのFASTでは入力画像の縦サイズ、横サイズのいずれも16以上の偶数の場合のみDRPが使用される点に注意する。

| モード   | 実行時オプション       | 左 \[ms/frame\] | 右 \[ms/frame\] |
|-------|----------------|-------------:|-------------:|
| 単眼    | OpenCVA        | 25.888       |        ----- |
| 単眼    | SLAM組み込み用のFAST | 9.580        |        ----- |
| 単眼    | CVアセット用のFAST   | 24.992       |        ----- |
| 単眼    | CPU            | 22.178       |        ----- |
| ステレオ  | OpenCVA        | 34.073       | 34.076       |
| ステレオ  | SLAM組み込み用のFAST | 10.161       | 10.145       |
| ステレオ  | CVアセット用のFAST   | 28.641       | 28.575       |
| ステレオ  | CPU            | 21.041       | 20.902       |
| RGB-D | OpenCVA        | 26.433       |        ----- |
| RGB-D | SLAM組み込み用のFAST | 10.018       |        ----- |
| RGB-D | CVアセット用のFAST   | 25.723       |        ----- |
| RGB-D | CPU            | 22.858       |        ----- |

単眼 + SLAM組み込み用のFASTの場合がもっとも高速に動作していることがわかる。  
また、いずれのモードでもSLAM組み込み用のFASTを使用する場合がもっとも高速に動作していることがわかる。

compute_orb_descriptorsの平均処理時間は以下の通り。  
なお、OpenCVAのcompute_orb_descriptorsは存在しないため、通常のCPU実装が使用されている点に注意する。

| モード   | 実行時オプション       | 左 \[ms/frame\] | 右 \[ms/frame\] |
|-------|----------------|-------------:|-------------:|
| 単眼    | OpenCVA        | 31.313       |        ----- |
| 単眼    | SLAM組み込み用のFAST | 12.718       |        ----- |
| 単眼    | CVアセット用のFAST   | 12.666       |        ----- |
| 単眼    | CPU            | 31.326       |        ----- |
| ステレオ  | OpenCVA        | 17.244       | 17.106       |
| ステレオ  | SLAM組み込み用のFAST | 8.243        | 8.217        |
| ステレオ  | CVアセット用のFAST   | 8.213        | 8.187        |
| ステレオ  | CPU            | 17.266       | 17.137       |
| RGB-D | OpenCVA        | 31.407       |        ----- |
| RGB-D | SLAM組み込み用のFAST | 12.680       |        ----- |
| RGB-D | CVアセット用のFAST   | 12.681       |        ----- |
| RGB-D | CPU            | 31.521       |        ----- |

単眼 + DRPドライバネイティブ動作の場合がもっとも高速に動作していることがわかる。  
なお、SLAM組み込み用のFASTと、CVアセット用のFASTでは、両方で同じDRPドライバネイティブ実装が使用されており、両者の間で有意な性能差は無い。  
また、いずれのモードでもDRPドライバネイティブを使用する場合がもっとも高速に動作していることがわかる。

## 16 Yolo-Planar-SLAMの直列動作検証の検討

DRPとDRP-AIの処理を並列に実行できない場合について、検討した内容を記載する。

### 16.1 画像処理と処理時間の概要

Yolo-Planar-SLAMのDRP-AI Translator動作について以下の図に示す。  
Image loadingスレッドなどの直列動作検証に関連しないスレッドについては省略した。

![Yolo-Planar-SLAMのDRP-AI Translator動作](image/yolo-planar-slam/serial/translator.png)

Yolo-Planar-SLAMのDRP-AI TVM動作について以下の図に示す。

![Yolo-Planar-SLAMのDRP-AI TVM動作](image/yolo-planar-slam/serial/tvm.png)

DRP-AI TVMを使用する場合には、InferenceスレッドにYOLOの処理が分離されていないことがわかる。

Yolo-Planar-SLAMの画像処理の主な内訳ついて以下の図に示す。

![Yolo-Planar-SLAMの画像処理の主な内訳](image/yolo-planar-slam/serial/image_processing.png)

オレンジの点線で囲った部分は、ORB-SLAM2に対して追加された、Yolo-Planar-SLAMの拡張実装の範囲である。

Yolo-Planar-SLAMの単眼 + OpenCVAの実測値について以下の図に示す。

![Yolo-Planar-SLAMの単眼 + OpenCVAの実測値](image/yolo-planar-slam/serial/opencva_0.png)

`3 バージョン1移行`の実測値を記載している。  
なお、単位はすべて\[ms/frame\]である。

上記のうち、YOLOの出力に依存しない処理部分について以下の図に示す。

![Yolo-Planar-SLAMの単眼 + OpenCVAの実測値（YOLOの出力に依存しない処理部分）](image/yolo-planar-slam/serial/opencva_1.png)

DRP-AIのYOLOと、並列に実行できるCPU処理が無いことがわかる。  
厳密にはグレースケール変換などは並列に実行できるが、処理時間が十分に小さいため高速化の効果は得られないと考えられる。

Yolo-Planar-SLAMの単眼 + SLAM組み込み用のFASTの実測値について以下の図に示す。

![Yolo-Planar-SLAMの単眼 + SLAM組み込み用のFASTの実測値](image/yolo-planar-slam/serial/slamfast_0.png)

2023年9月時点の評価結果の実測値を記載している。  
なお、単位はすべて\[ms/frame\]である。  
ここで、前処理とは、`drp::Activate`より前の処理を指す。  
また、後処理とは、終了割り込みを確認した後の処理を指す。

上記のうち、YOLOの出力に依存しない処理部分について以下の図に示す。

![Yolo-Planar-SLAMの単眼 + SLAM組み込み用のFASTの実測値（YOLOの出力に依存しない処理部分）](image/yolo-planar-slam/serial/slamfast_1.png)

Resizeを7回実行しておき、DRP-AIのYOLOの処理を開始してから、Resizeの後処理をまとめて並列実行することは原理的には可能である。  
しかし、P2Uの処理に含まれる`ioctl(DRP_ASSIGN)`はDRPドライバに対する操作であるため、「直列動作」の制約を満たさないと考えられる。  
よって並列実行できるのはResiezの後処理のcloneの部分のみであるが、処理時間が十分に小さいため高速化の効果は得られないと考えられる。

Yolo-Planar-SLAMの単眼 + CVアセット用のFASTの実測値について以下の図に示す。

![Yolo-Planar-SLAMの単眼 + CVアセット用のFASTの実測値](image/yolo-planar-slam/serial/cvfast_0.png)

2023年9月時点の評価結果の実測値を記載している。  
なお、単位はすべて\[ms/frame\]である。  
ここで、前処理とは、`drp::Activate`より前の処理を指す。  
また、後処理とは、終了割り込みを確認した後の処理を指す。

上記のうち、YOLOの出力に依存しない処理部分について以下の図に示す。

![Yolo-Planar-SLAMの単眼 + CVアセット用のFASTの実測値のうち、YOLOの出力に依存しない処理部分）](image/yolo-planar-slam/serial/cvfast_1.png)

CVアセット用のFASTの前処理・後処理とDRP-AIのYOLOを並列実行することが可能であれば、高速化できると考えられる。  
しかし、CVアセット用のFASTの実行回数は、例えば入力画像のサイズが`640x480`の場合では`815`回と多いため、1回あたりの実行時間は前処理で`0.01`\[ms/frame\]、後処理で`0.005`\[ms/frame\]程度であると考えられる。  
1回あたりの実行時間が十分に短く、かつ各実行の間にDRPを使用する処理を実行する必要があるため、高速化の効果は得られないと考えられる。

### 16.2 排他制御対象のAPI

排他制御を考慮すべき`ioctl`の処理は以下の通り。

- DRP_SET_SEQ
- DRP_ASSIGN
- DRP_START
- DRP_GET_STATUS
- DRPAI_SET_DRP_MAX_FREQ
- DRPAI_SET_DRPAI_FREQ
- DRPAI_GET_DRPAI_AREA
- DRPAI_SET_ADRCONV
- DRPAI_ASSIGN
- DRPAI_ASSIGN_PARAM
- DRPAI_START
- DRPAI_GET_STATUS
- DRPAI_REG_DUMP

Yolo-Planar-SLAMにおいて、排他制御を考慮すべき処理である`ioctl`およびOpenCVAのAPIが直接呼び出されているソースコードは以下の通り。

- drp_modules/drp.cc
- opencva_modules/opencva.cc
- drp_ai_modules/translator/recognize/recognize_base.cpp
- drp_ai_modules/translator/drp/drp_proc.cpp
- drp_ai_modules/tvm/yoloxs_provisional/YoloDetector_tvm.cpp
- drp_ai_modules/tvm/yoloxs_provisional/PreRuntimeV2H.cpp

上記のソースコード中の`ioctl`およびOpenCVAのAPIに対して`std::mutex`による排他制御を実装することで、直列動作を実現できる見込みである。  

### 16.3 stella_vslamの直列動作検証について

stella_vslamについては、今後にバウンディングボックスによる特徴点の間引き処理を追加する想定で検討するべきかによって、方針が変わる。  
間引き処理を追加する想定の場合、原理的にはYolo-Planar-SLAMと同等となり、直列動作検証の結論も同様となる。  
間引き処理を追加しない想定の場合、画像処理の後のCPU処理もDRP-AIのYOLOと並列に実行することができるため、処理時間の観点で有利になる可能性がある。

## 17 stella_vslamの高速化試行

stella_vslamの高速化試行について記載する。

`5 stella_vslamのYocto適合`に記載した、単眼 + SLAM組み込み用のFASTの場合の処理時間の割合は以下の通り。

- `Resize`の`DRP time`：`1.7`%
- `GaussianBlur`の`DRP time`：`4.5`%
- `orb_extractor::compute_fast_keypoints`の`DRP time`：`7.1`%
- `compute_orb_descriptors`の`DRP time`：`11.1`%

ここでは、特に処理時間の割合が大きい`Resize`以外の3アルゴリズムについての最適化・高速化を検討した。

### 17.1 STP4向け最適化

DRP開発ツール担当の方よりいただいた、STP4向けの最適化に関するコメントを参考に最適化を行う。

高速化試行の開始時点でのRTレベルシミュレーションの評価結果は以下の通り。

| DRP実装                                 | 処理時間（us） |
|-----------------------------------------|---------:|
| 7x7のGaussianBlur                       | 399.3    |
| SLAM組み込み用のFAST（stella_vslam）     | 2418.0   |
| compute_orb_descriptors                 | 1288.9   |

まず、以下の点について変更を行った。

> 面内多状態は有効、組み合わせは自動でがデフォルトとしております。

同じく以下の点についても変更を行った。

> 状態組み合わせ方法のオプションは「ループ内の状態を優先的にまとめる」を強く推奨いたします。

最適化方針は「遅延・面積両立」に設定した。  
このときのRTレベルシミュレーションの評価結果は以下の通り。

| DRP実装                                 | 処理時間（us） |
|-----------------------------------------|---------:|
| 7x7のGaussianBlur                       | 414.7    |
| SLAM組み込み用のFAST（stella_vslam）     | 1852.2   |
| compute_orb_descriptors                 | 12423.3  |

次に、最適化方針は「面数最小」に設定した場合について評価を行った。  
このときのRTレベルシミュレーションの評価結果は以下の通り。

| DRP実装                                 | 処理時間（us） |
|-----------------------------------------|---------:|
| 7x7のGaussianBlur                       | 401.0    |
| SLAM組み込み用のFAST（stella_vslam）     | 1881.3   |
| compute_orb_descriptors                 | 1267.6   |

次に、過去のバージョンのMusketeerで反復合成を行って決定した、配置配線のオプションを削除した。  
このときのRTレベルシミュレーションの評価結果は以下の通り。

| DRP実装                                 | 処理時間（us） | 備考                   |
|-----------------------------------------|---------:|----------------------|
| 7x7のGaussianBlur                       | 400.7    | 面数最小    |
| SLAM組み込み用のFAST（stella_vslam）     | 2175.5   | 遅延・面積両立 |
| compute_orb_descriptors                 | 1289.2   | 面数最小    |

次に、上記とは最適化方針を逆に設定した場合について評価した。  
このときのRTレベルシミュレーションの評価結果は以下の通り。

| DRP実装                                 | 処理時間（us） | 備考                   |
|-----------------------------------------|---------:|----------------------|
| 7x7のGaussianBlur                       | 501.0    | 遅延・面積両立 |
| SLAM組み込み用のFAST（stella_vslam）     | 2175.5   | 面数最小    |
| compute_orb_descriptors                 | 13128.6  | 遅延・面積両立 |

反復合成オプションを削除した場合では、いずれのアルゴリズムでも「面数最小」の場合が高速に動作していることがわかる。

ここまでの各アルゴリズムのRTレベルシミュレーションの評価結果をまとめると、以下のようになる。

- 7x7のGaussianBlurでは、反復合成オプションを削除し、かつ「面数最小」の場合がもっとも高速に動作する
    - ただし、STP4向け最適化の前の方が高速に動作している
- SLAM組み込み用のFAST（stella_vslam）では、反復合成オプションを削除せず、かつ「遅延・面積両立」の場合がもっとも高速に動作する
- compute_orb_descriptorsでは、反復合成オプションを削除せず、かつ「面数最小」の場合がもっとも高速に動作する

### 17.2 実装の変更

compute_orb_descriptorsの実装の変更について、以下の2点について検討を行った。

1. メモリの使用量を増やすことで、1サイクルあたりに可能なアクセス数を増やし、動作周波数を改善する
2. ORB特徴量の計算の型を`float`を`short_float`に変更した場合に、処理時間をどの程度減らせるのかの調査

compute_orb_descriptorsは、入力特徴点のそれぞれについて、その特徴点の座標の周囲の画像を使用してORB特徴量を計算する。  
特徴点の周辺画像のサイズは最大で`37x37`となる。  
画素数は`37 * 37 = 1369`となる。  
Vmuに格納する場合は`vMEM16x8_RAM`が使用されるため、Vmuは`8`個必要となる。  
Hmuに格納する場合は`hMEM16x1_RAM`が使用されるため、Hmuは`1`個必要となる。

特徴点の周辺画像の読み込みは、特徴点1つあたり最大で`1369`\[B\]分必要となる。  
現実装では2チャネル並列で読み込みを行っている。  
`8`\[B\]読み込みの場合、1サイクルあたり`8 * 2 = 16`回の書き込みが発生する。  
そのため、配列を8分割しないとポート数が足りなくなる。

ORB特徴量計算の係数は、xとyのそれぞれで`512`個の値を保持する必要がある。  
Vmuに格納する場合は`vMEM16x2_ROM`が使用されるため、Vmuは`2`個必要となる。（ただしORB特徴量の計算の型が`float`から`short_float`に変更した場合）  
Hmuに格納する場合は`hMEM32x1_ROM`が使用されるため、Hmuは`1`個必要となる。

`get_value`は、特徴点1つあたり`32 * 8 * 2 = 512`回実行される。  
ORB特徴量`1`\[B\]あたりでは、`8 * 2 = 16`回実行される。  
ORB特徴量`1`\[B\]あたりでは、ORB特徴量計算の係数は、xとyのそれぞれで`16 * 2 = 32`回ずつ参照される。  
同じく、特徴点の周辺画像は`16`回参照される。

ORB特徴量`1`\[B\]あたりの計算を`N`サイクルで実現するためには、ORB特徴量計算の係数は、xとyのそれぞれで`16/N`分割する必要がある。  
同じく、特徴点の周辺画像は`8/N`分割する必要がある。

ORB特徴量計算の係数をxとyのそれぞれで`16/N`分割した場合、Vmuに格納する場合はVmuが`32/N`個必要となる。  
Hmuに格納する場合はHmuが`16/N`個必要となる。

特徴点の周辺画像を`8/N`分割した場合、Vmuに格納する場合はVmuが`64/N`個必要となる。  
Hmuに格納する場合はHmuが`8/N`個必要となる。

- ORB特徴量計算のxの係数：Vmuが`32/N`個 or Hmuが`16/N`個
    - 1本あたりVmuが`2`個 or Hmuが`1`個
- ORB特徴量計算のyの係数：Vmuが`32/N`個 or Hmuが`16/N`個
    - 1本あたりVmuが`2`個 or Hmuが`1`個
- 特徴点の周辺画像：Vmuが`64/N`個 or Hmuが`8/N`個
    - 1本あたりVmuが`8`個 or Hmuが`1`個

STP4Cには、Vmuが`24`個、Hmuが`10`個だけ搭載されている。

まず、ORB特徴量計算の係数のxとyのそれぞれを`16/4 = 4`分割して、性能を確認した。  
RTレベルシミュレーションの評価結果では、処理時間は`1289.225000`\[us\]から`1133.707500`\[us\]に改善した。

次に、特徴点の周辺画像も分割する場合を評価した。

`N=1`の場合は、明らかにSTP4Cではリソースが不足する。  
`N=2`の場合も、明らかにSTP4Cではリソースが不足する。  
`N=4`の場合は、ORB特徴量計算の係数でHmuを`8`個、特徴点の周辺画像でHmuを`2`個使用すれば足りる。  
ただしORB特徴量の計算の型が`float`のままでは`DII=6`でも配置配線で`F_RAP10054`のエラーになった。  
もしくは、ORB特徴量計算の係数でHmuを`8`個、特徴点の周辺画像でVmuを`16`個使用すれば足りる。  
ただしORB特徴量の計算の型が`float`のままでは`DII=6`でも配置配線で`F_RAP10054`のエラーになった。  
もしくは、ORB特徴量計算の係数でVmuを`16`個、特徴点の周辺画像でHmuを`2`個使用すれば足りる。  
ただしORB特徴量の計算の型が`float`のままでは`DII=6`でも配置配線で`F_RAP10054`のエラーになった。  
もしくは、ORB特徴量計算の係数でVmuを`8`個とHmuを`4`個、特徴点の周辺画像でHmuを`2`個使用すれば足りる。  
ただしORB特徴量の計算の型が`float`のままでは`DII=6`でも配置配線で`F_RAP10054`のエラーになった。

`N=4`かつORB特徴量の計算の型を`float`から`short_float`に変更した場合についても調査した。  
RTレベルシミュレーションの評価結果では、処理時間は`1052.477500`\[us\]に改善した。

さらに、ORB特徴量の計算の処理を`DII = 4`でフォールディングすることで、処理時間は`508.705000`\[us\]に改善した。

さらに、特徴点の周辺画像を8バイトごとに読み込むように変更することで、処理時間は`213.045000`\[us\]に改善した。

ORB特徴量の計算の型を`float`から`short_float`に変更しない場合についても、`DII = 4`でのフォールディングと、特徴点の周辺画像を8バイトごとに読み込むように変更した時の評価を行おうとしたが、ビルドできなかった。  
前述の2つの変更をそれぞれ片方だけ適用した場合でも、同様にビルドできなかった。

以上から、以下のことがいえる。

- ORB特徴量の計算の型を`float`のまま変更しない場合の処理時間は、`1133.707500`\[us\]となる
- ORB特徴量の計算の型を`float`から`short_float`に変更する場合の処理時間は、`213.045000`\[us\]となる
    - 実数計算の精度が低下するため、現時点のテストベンチファイルの期待値と結果が一致しなくなる
    - 実数計算の精度が低下するため、SLAM精度が低下する懸念がある
- ORB特徴量の計算の型が`short_float`の場合は、`float`の場合と比較して約`5.3`倍高速に動作する

なお、ORB特徴量計算の最近接偶数丸めの処理は、STP3を想定した実装のままとなっている。  
そのため、現時点の実装でもRTレベルシミュレーションの出力は、OpenCVのリファレンス出力とは厳密に一致していない。  
本案件においてcompute_orb_descriptorsのDRP実装と、OpenCV実装の出力の誤差がどこまで許容されうるのかについては、調査・検討の必要がある。

### 17.3 反復合成

反復合成を行った。

#### 17.3.1 7x7のGaussianBlur

受領した`opt.top`に記述されている80通りのオプションについて、「遅延・面積両立」と「面数最小」のそれぞれで反復合成を行った。  
最も高速であったオプションは「面数最小」かつ`rap -yplace_opt --disperse_level=17`であり、処理時間は`400.220000`\[us\]であった。

#### 17.3.2 SLAM組み込み用のFAST（stella_vslam）

受領した`opt.top`に記述されている80通りのオプションについて、「遅延・面積両立」と「面数最小」のそれぞれで反復合成を行った。  
最も高速であったオプションは「遅延・面積両立」かつ`rap -yplace_opt --disperse_level=18 -netweight on`であり、処理時間は`1851.015000`\[us\]であった。

#### 17.3.3 compute_orb_descriptors

前述の`実装の変更`を優先したため、着手していない。

## 18 Yolo-Planar-SLAMのROS2対応検討

Yolo-Planar-SLAMのROS2対応の検討結果について記載する。

まず、Systemクラスのコンストラクタ引数が増えているため、必要に応じて変更する。  
検討段階であるため、ここでは設定はハードコーディングすることを想定する。

ROS2ラッパーの[rgbd.cpp#L25](https://github.com/alsora/ros2-ORB_SLAM2/blob/17df90f9b8e8ed51e59312c8187dc165a8a8f0c8/src/rgbd/rgbd.cpp#L25)の内容を以下に示す。  
ROS2ラッパーの以下の実装に対して、Systemクラスのコンストラクタ引数に応じて変更が必要となる。

```cpp
ORB_SLAM2::System SLAM(argv[1], argv[2], ORB_SLAM2::System::RGBD, visualization);
```

次に、`System::TrackRGBD`ではなく、ROS2ラッパーのためのImageLoadingクラスの派生クラスのインスタンスに画像データを渡す必要がある。

ROS2ラッパーの[rgbd-slam-node.cpp#L52](https://github.com/alsora/ros2-ORB_SLAM2/blob/17df90f9b8e8ed51e59312c8187dc165a8a8f0c8/src/rgbd/rgbd-slam-node.cpp#L52)の内容を以下に示す。

```cpp
cv::Mat Tcw = m_SLAM->TrackRGBD(cv_ptrRGB->image, cv_ptrD->image, msgRGB->header.stamp.sec);
```

変更後の実装イメージは以下の通り。

```cpp
m_SLAM->mpImageLoader->PushInput(cv_ptrRGB->image, cv_ptrD->image, msgRGB->header.stamp.sec);
```

なお、`mpImageLoader`メンバは`private`になっているため、`public`に変更する必要がある。  
本案件のYolo-Planar-SLAMの`include/System.h`の内容を以下に示す。

```cpp
ImageLoading* mpImageLoader;
```

前述の「ROS2ラッパーのためのImageLoadingクラスの派生クラスのインスタンス」を作るために、設定値で分岐する変更も必要となる。  
本案件のYolo-Planar-SLAMの`src/System.cc`の内容を以下に示す。

```cpp
    if (input_type == InputType::DATASET) {
        mpImageLoader = new DatasetImageLoading(mSensor, image_dir_, image_filenames_, depth_filenames_, timestamp_);
        mptImageLoading = new thread(&ORB_SLAM2::ImageLoading::Run, mpImageLoader);
    }
    else if (input_type == InputType::MONO_CAMERA) {
        mpImageLoader = new MonocularCameraImageLoading(mSensor, strSettingsFile);
        mptImageLoading = new thread(&ORB_SLAM2::ImageLoading::Run, mpImageLoader);
    }
    // ここにROS2ラッパーのための条件文を増やす
#if defined(ENABLE_REALSENSE2)
    else if (input_type == InputType::D435i_CAMERA) {
        fprintf(stderr, "WARNING : The operation has not been verified when D435i is used.\n");
        mpImageLoader = new D435iCameraImageLoading(mSensor, strSettingsFile);
        mptImageLoading = new thread(&ORB_SLAM2::ImageLoading::Run, mpImageLoader);
    }
#endif
    else {
        fprintf(stderr, "Invalid InputType : %d in System::System\n", input_type);
    }
```

コメントで示した箇所に、ROS2ラッパーのための条件分岐を追加する必要がある。

また、「ROS2ラッパーのためのImageLoadingクラスの派生クラス」は新規に実装する必要がある。  
USBカメラ用の派生クラスである、MonocularCameraImageLoadingクラスをもとに実装する。  
合わせて、「ROS2ラッパーのためのImageLoadingクラスの派生クラス」に対して`PushInput`関数も新規に実装する必要がある。

ROS2ラッパー側との排他制御も必要になる。  
排他制御のフローは以下のようになると考えられる。

- `PushInput`関数経由でROS2から画像を渡されたときに、ROS2ラッパーのための受け渡しフラグを`true`にする
- MonocularCameraImageLoadingクラスの場合に`cap.read`が実行されている箇所で、ROS2ラッパーのための受け渡しフラグが`true`になるまで待機する処理を入れる
- Image processingスレッドに画像を受け渡す処理を実行する
    - データセットやUSBカメラの場合と同じ
- ROS2ラッパーのための受け渡しフラグを`false`にする

## 19 今後の懸念

今後の懸念について記載する。

### 19.1 DRP-AI TVM動作時の入力画像のメモリ空間について

`9 Yolo-Planar-SLAMへのDRP-AI TVMのYOLOX-Sの組み込み`に記載した、Yolo-Planar-SLAMのDRP-AI TVM連携実装と、受領したサンプルプログラム（`drp-tvm_dev-v210_add_yolox_240119`）との差異の一部を以下に示す。

> ```markdown
> 2. USBカメラだけではなく、データセットも使用すること
>     - MMNGRを使用せずに、`ioctl(DRPAI_ASSIGN)`で入力画像を書き込むこと
>     - 入力画像を`0x5870_0000`ではなく`0x2_5E00_0000`に配置したこと
> 5. `ioctl(DRPAI_SET_ADRCONV)`で`0xD000_0000 ~ 0xEFFF_FFFF`を`0x0_5800_0000 ~ 0x0_77FF_FFFF`にアドレス変換する処理を無効化したこと
> ```

受領したサンプルプログラムでは、入力画像は`0x5870_0000`に配置される。  
上記の1を無効化し、入力画像を`0x5870_0000`に配置した場合の挙動を確認した。

まず、以下の変更を加えた。

`drp_ai_modules/tvm/yoloxs_provisional/YoloDetector_tvm.h`の差分は以下の通り。

```diff
     double expansion_scale; // expected to be 3.0 (== 1920 / 640)

-    const uint64_t preruntime_input_address = 0x25E000000;
+    const uint64_t preruntime_input_address = 0x58700000;
     uint64_t capture_address;
```

ビルドし実行したところ、エラーになった。

```shell
Start processing sequence ...
Images in the sequence: 859

mapped = 0, pre_in_addr = 58700000
proc[DRPAI_INDEX_INPUT].address = 58700000
[ERROR] Failed to run DRPAI_START : errno=12
[ERROR] Failed to run Pre-processing Runtime Pre()
YoloObjectDetectStart error
```

加えて、前述の4の変更を元に戻し、`0xD000_0000 ~ 0xEFFF_FFFF`から`0x0_5800_0000 ~ 0x0_77FF_FFFF`へのアドレス変換も再有効化して挙動を確認した。  
`drp_ai_modules/tvm/yoloxs_provisional/PreRuntimeV2H.cpp`の`PreRuntime::Pre`の差分は以下の通り。

```diff
             this->mapped_in_addr_v2h = param->pre_in_addr;
-            /*
             drpai_adrconv.conv_address = param->pre_in_addr & 0xffffff000000;
             drpai_adrconv.org_address = 0xD0000000;
-            drpai_adrconv.size = 0x20000000; /*(drpai_obj_info.drpai_address.data_in_size + 0xffffff) & 0xff000000;* /
+            drpai_adrconv.size = 0x20000000; /*(drpai_obj_info.drpai_address.data_in_size + 0xffffff) & 0xff000000;*/
             drpai_adrconv.mode = DRPAI_ADRCONV_MODE_ADD;
```

```diff
                 std::cerr << "[ERROR] Failed to run SET_ADRCONV(2) for DRP-AI input image : errno=" << errno << std::endl;
                 return PRE_ERROR;
             }
-            */
```

エラーとはならなかったが、正常なバウンディングボックスの結果を得られなかった。

```shell
Start processing sequence ...
Images in the sequence: 859

mapped = 0, pre_in_addr = 58700000
proc[DRPAI_INDEX_INPUT].address = 58700000
[TIME] PreRuntime DRP-AI processing time : 11.14 msec
[TIME] GetResult() Processing Time : 4.58 msec
[05:45:31] /yocto_rzv2x_ver1_workdir/yolo-planar-slam/drp_ai_modules/tvm/yoloxs_provisional/MeraDrpRuntimeWrapper.cpp:106: Loading input...
 Bounding Box Count  : 0
Measurement result of    0 frame
    System::TrackMonocular                 :  348.996[ms]
    Sleep specified at execution           :    0.000[ms]
    Sleep while waiting for the next frame :    0.000[ms]
    Tracking state                         : NOT_INITIALIZED
mapped = 58700000, pre_in_addr = 58700000
proc[DRPAI_INDEX_INPUT].address = 58700000
[TIME] PreRuntime DRP-AI processing time : 11.09 msec
[TIME] GetResult() Processing Time : 2.46 msec
[05:45:32] /yocto_rzv2x_ver1_workdir/yolo-planar-slam/drp_ai_modules/tvm/yoloxs_provisional/MeraDrpRuntimeWrapper.cpp:106: Loading input...
 Bounding Box Count  : 0
mapped = 58700000, pre_in_addr = 58700000
proc[DRPAI_INDEX_INPUT].address = 58700000
[TIME] PreRuntime DRP-AI processing time : 11.20 msec
[TIME] GetResult() Processing Time : 1.97 msec
[05:45:32] /yocto_rzv2x_ver1_workdir/yolo-planar-slam/drp_ai_modules/tvm/yoloxs_provisional/MeraDrpRuntimeWrapper.cpp:106: Loading input...
Measurement result of    1 frame
    System::TrackMonocular                 :  588.173[ms]
    Sleep specified at execution           :    0.000[ms]
    Sleep while waiting for the next frame :    0.000[ms]
    Tracking state                         : NOT_INITIALIZED
 Bounding Box Count  : 0
```

MMNGRを使用せずに、`ioctl(DRPAI_ASSIGN)`で入力画像を`0x5870_0000`に書き込む場合にはDRP-AIから正常な結果を得られないことがわかる。  
DRP-AIの開発者から、`0x2_5E00_0000`ではなく`0x5870_0000`を使用した方が処理時間が短くなる可能性がある、と回答をいただいている。  
そのため、DRP-AIの処理時間を削減する必要が発生した場合に、上記の不具合に起因して一部の高速化手法を適用できない懸念がある。

### 19.2 compute_orb_descriptorsの出力の誤差について

compute_orb_descriptorsのDRP実装における、ORB特徴量計算の最近接偶数丸めの処理は、STP3を想定した実装のままとなっている。  
そのため、現時点の実装ではRTレベルシミュレーションの出力は、OpenCVのリファレンス出力とは厳密に一致していない。  
compute_orb_descriptorsのDRP実装とOpenCV実装の出力の誤差を十分に減らす必要がある場合には、STP4の仕様に準拠した実装に変更する必要がある。
