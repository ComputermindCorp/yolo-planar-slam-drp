# AI+SLAM 導入・カスタマイズガイド

## 前提条件

- [SDカード作成マニュアル](../yocto_dev/README_SD_Image.md)を読み終わっていること
- [SDカード作成マニュアル](../yocto_dev/README_SD_Image.md)の前提条件を満たしていること
- [SDカード作成マニュアル](../yocto_dev/README_SD_Image.md)の作業が完了していること
- [Boot loader更新マニュアル](../yocto_dev/README_Boot_Loader.md)を読み終わっていること
- [Boot loader更新マニュアル](../yocto_dev/README_Boot_Loader.md)の前提条件を満たしていること
- [Boot loader更新マニュアル](../yocto_dev/README_Boot_Loader.md)の作業が完了していること

## 1 Yolo-Planar-SLAM + AI導入・カスタマイズガイド

[Yolo-Planar-SLAM + AI導入・カスタマイズガイド](yolo-planar-slam/README.md)に記載されている。

## 2 Stella VSLAM + AI導入・カスタマイズガイド

[Stella VSLAM + AI導入・カスタマイズガイド](stella_vslam/README.md)に記載されている。
