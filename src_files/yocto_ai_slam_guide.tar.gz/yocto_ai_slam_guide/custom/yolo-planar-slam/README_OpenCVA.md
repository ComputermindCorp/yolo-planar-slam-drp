# Yolo-Planar-SLAMのOpenCVA導入マニュアル

## 前提条件

- [動作マニュアル](README.md)を読み終わっていること
- [動作マニュアル](README.md)の前提条件を満たしていること

## リポジトリのclone

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、GitHubからYolo-Planar-SLAMリポジトリをcloneする。

```shell
cd ${HOME}
git clone https://github.com/BZDOLiVE/YoloPlanarSLAM.git
cd YoloPlanarSLAM
git checkout 45510b59d41eb6bcd28e2657c39cb6ab664b5c1f
```

## パッチの適用

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、パッチファイルをYolo-Planar-SLAMリポジトリの中へコピーする。

```shell
cd ${HOME}/YoloPlanarSLAM
cp -r ${HOME}/yocto_ai_slam_guide/patch .
```

### OpenCV 3.2.0から4.1.0への変更

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、OpenCVのC APIをC++ APIへ変更するパッチを適用する。

```shell
git apply patch/0001-change-c-api-in-opencv-to-cpp-api.patch
```

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、OpenCV 3.2.0から4.1.0へ変更するパッチを適用する。

```shell
git apply patch/0002-change-opencv-from-3.2.0-to-4.1.0.patch
```

### C++17適合

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、C++17でビルドするための変更を行うパッチを適用する。

```shell
git apply patch/0003-fix-increment.patch
```

### 外部ライブラリへの依存の削除

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、ncnnへの依存を削除するパッチを適用する。

```shell
git apply patch/0004-remove-ncnn.patch
```

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、Pangolinへの依存を削除するパッチを適用する。

```shell
git apply patch/0005-remove-pangolin.patch
```

Pangolinへの依存を削除するため、Pangolin Viewerは使用できなくなる。  
Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、Pangolin Viewerを使用しないように設定を変更するパッチを適用する。

```shell
git apply patch/0006-disable-pangolin-viewer.patch
```

### 実行時オプションの追加

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、Yolo-Planar-SLAMの実行時オプションを追加するパッチを適用する。

```shell
git apply patch/0007-expand-option.patch
```

パッチを適用することで、以下のオプションが追加される。

- UseOpenCVA
- UseDrpAI

### DRP-AI連携のデモプログラムの取り込み

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、DRP-AI連携処理のためのコードを取り込むパッチを適用する。

```shell
  git apply patch/0008-import-drp-ai-demo-code.patch
```

なお、パッチの適用時に以下の警告が出力されるが、無視してよい。

```shell
patch/0008-import-drp-ai-demo-code.patch:57: trailing whitespace.
            CEREAL_NVP(X),
patch/0008-import-drp-ai-demo-code.patch:241: trailing whitespace.
                i_archive(cereal::make_nvp(COMMAND_ID_KEY, ret->command_name));
patch/0008-import-drp-ai-demo-code.patch:242: trailing whitespace.
                i_archive(cereal::make_nvp(VALUE_KEY, *ret));
patch/0008-import-drp-ai-demo-code.patch:548: trailing whitespace.
 * @return int8_t
patch/0008-import-drp-ai-demo-code.patch:570: trailing whitespace.
 * @return int8_t
warning: squelched 397 whitespace errors
warning: 402 lines add whitespace errors.
```

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、取り込んだソースコードから不要な処理を削除するパッチを適用する。

```shell
git apply patch/0009-shrink-drp-ai-demo-code.patch
```

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、取り込んだソースコードが`0003-modify-memory-map-for-drpai.patch`を適用したV2xボード上で動作するように変更するパッチを適用する。

```shell
git apply patch/0010-adapt-alpha2-drp-ai-demo-code.patch
```

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、取り込んだソースコードをYolo-Planar-SLAMと連携できるように変更するパッチを適用する。

```shell
git apply patch/0011-custom-drp-ai-demo-code.patch
```

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、使用するDRP-AIオブジェクトファイルを`yolov2_sp90`から`YoloV2_sp90_VGA_RGB_0726`に変更するパッチを適用する。

```shell
git apply patch/0012-change-drp-ai-object-files.patch
```

### DRP-AI連携処理の追加

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、DRP-AI連携処理のためのクラス`YoloDetector_drp`の仮実装を追加するパッチを適用する。

```shell
git apply patch/0013-temporarily-implement-drp-ai.patch
```

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、DRP-AI連携処理を追加するパッチを適用する。

```shell
git apply patch/0014-use-drp-ai.patch
```

### OpenCVAの組み込み

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、OpenCVAを組み込むパッチを適用する。

```shell
git apply patch/0015-use-opencva.patch
```

### DRPドライバネイティブ連携処理の追加

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、Yolo-Planar-SLAMの実行時オプションを追加するパッチを適用する。

```shell
git apply patch/0016-expand-option-drp-driver-native.patch
```

パッチを適用することで、以下のオプションが追加される。

- UseDrpDriverNative

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、DRPドライバネイティブ連携処理を追加するパッチを適用する。

```shell
git apply patch/0017-use-drp-driver-native.patch
```

パッチを適用することで、以下のオプションが追加される。

- UseDrpDriverNative

### DRP-AIのチャネル分割

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、DRP-AI処理の入力画像を`/dev/udmabuf0`を使用してコピーする処理を追加するパッチを適用する。

```shell
git apply patch/0018-write-drp-ai-input-using-udmabuf.patch
```

## ビルド設定の変更

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、Yolo-Planar-SLAMのビルド設定をC++11からC++17へ変更する。

```shell
cd ${HOME}/YoloPlanarSLAM
sed -i 's/set(CMAKE_CXX_STANDARD 11)/set(CMAKE_CXX_STANDARD 17)/g' CMakeLists.txt
```

2023年10月時点で、Yocto環境でC++プログラムをビルドする時に`-march=native`を指定するとエラーとなることがわかっている。  
エラーを回避するために、Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、Yolo-Planar-SLAMのビルド設定から`-march=native`を削除する。

```shell
cd ${HOME}/YoloPlanarSLAM
sed -i 's/ \+-march=native *//g' CMakeLists.txt
sed -i 's/ \+-march=native *//g' Thirdparty/DBoW2/CMakeLists.txt
sed -i 's/ \+-march=native *//g' Thirdparty/g2o/CMakeLists.txt
```

## ビルド

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、`/yocto_rzv2x_beta_workdir/yolo-planar-slam.opencva`に本案件の`YoloPlanarSLAM`ディレクトリを配置する。

```shell
cd /yocto_rzv2x_beta_workdir
mkdir yolo-planar-slam.opencva
cp -r ${HOME}/YoloPlanarSLAM/* yolo-planar-slam.opencva/
```

Yocto環境を構築したコンピュータ上で以下のコマンドを実行し、Yolo-Planar-SLAMをビルドする。

```shell
source /yocto_rzv2x_beta_workdir/bsp_sdk/environment-setup-aarch64-poky-linux

cd /yocto_rzv2x_beta_workdir/yolo-planar-slam.opencva/
cd Thirdparty/DBoW2
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j

cd /yocto_rzv2x_beta_workdir/yolo-planar-slam.opencva/
cd Thirdparty/g2o
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j

cd /yocto_rzv2x_beta_workdir/yolo-planar-slam.opencva/
mkdir -p build
cd build
cmake -DCMAKE_BUILD_TYPE=Release \
  -DOpenMP_C_FLAGS='-fopenmp' \
  -DOpenMP_CXX_FLAGS='-fopenmp' \
  -DOpenMP_C_LIB_NAMES='gomp;pthread' \
  -DOpenMP_CXX_LIB_NAMES='gomp;pthread' \
  -DOpenMP_gomp_LIBRARY=${SDKTARGETSYSROOT}/usr/lib64/libgomp.so \
  -DOpenMP_pthread_LIBRARY=${SDKTARGETSYSROOT}/usr/lib64/libpthread.so \
  ..
make -j
```

## パッチの概要

各パッチの変更内容の概要は以下の通り。

![パッチの概要](image/patch_category.png)

赤文字で示した部分は、汎用の連携対応の変更を行うパッチである。

### OpenCV 3.2.0から4.1.0への変更

`0001-change-c-api-in-opencv-to-cpp-api.patch`を適用することで、主に以下の変更が適用される。

- `cvMat`を`cv::Mat`に置き換える
- `CV_LOAD_IMAGE_UNCHANGED`を`cv::IMREAD_UNCHANGED`に置き換える
- `cvSVD`を`cv::SVD::compute`と`cv::transpose`に置き換える
- C APIとC++ APIの間で1対1対応が取れない場合は、等価な処理となるように変更する

`0002-change-opencv-from-3.2.0-to-4.1.0.patch`を適用することで以下の変更が適用される。

- CMakeで指定するバージョンの変更
- C API用のヘッダーファイルをincludeしないように変更
- `cv::FileStorage`によるファイル読み出し処理のOpenCV 4系対応

### C+17適合

`0003-fix-increment.patch`を適用することで以下の変更が適用される。

- `src/LoopClosing.cc`に実装されている、bool型変数のインクリメントを修正する

変更の差分は以下の通り。

```diff
-        mnFullBAIdx++;
+        mnFullBAIdx = true;
```

### 外部ライブラリへの依存の削除

`0004-remove-ncnn.patch`を適用することで以下の変更が適用される。

- ncnnへの依存の削除
    - オリジナルのYolo-Planar-SLAMではYOLOの実行にncnnが使用されている
    - 2023年10月時点でV2xボード向けのncnnのレシピは作成されていないため、依存を解決できない

`0005-remove-pangolin.patch`を適用することで以下の変更が適用される。

- Pangolinへの依存の削除
    - オリジナルのYolo-Planar-SLAMではヴィジュアライザの実行にPangolinが使用されている
    - 2023年10月時点でV2xボード向けのPangolinのレシピは作成されていないため、依存を解決できない

`0006-disable-pangolin-viewer.patch`を適用することで以下の変更が適用される。

- `System`クラスのコンストラクタ引数を、ヴィジュアライザを使用しないように変更

### DRP-AI/OpenCVA対応

`0007-expand-option.patch`を適用することで以下の変更が適用される。

- `UseOpenCVA`オプションの追加
- `UseDrpAI`オプションの追加

`0008-import-drp-ai-demo-code.patch`を適用することで以下の変更が適用される。

- `rzv2h_yolov2_demo_src_20230508`のソースコードの一部の取り込み

`0009-shrink-drp-ai-demo-code.patch`を適用することで以下の変更が適用される。

- 取り込んだ`rzv2h_yolov2_demo_src_20230508`のソースコードから不要な処理を削除する

`0010-adapt-alpha2-drp-ai-demo-code.patch`を適用することで以下の変更が適用される。

- 取り込んだ`rzv2h_yolov2_demo_src_20230508`のソースコードのうち、α2への移行に伴って64bitにする必要がある型を変更する
    - DRP-AIのメモリ空間が`0x8000_0000`から`0x2_4000_0000`へ変更されたため
- `DRPProc::read_addrmap_txt`と`DRPProc::drp_adrconv`を追加する
    - `ioctl(DRPAI_SET_ADRCONV)`を使用できるようにする

`0011-custom-drp-ai-demo-code.patch`を適用することで、取り込んだ`rzv2h_yolov2_demo_src_20230508`のソースコードに対して、Yolo-Planar-SLAMとの連携のために必要な以下の変更が適用される。

- グローバル変数をメンバ変数に変更
- メンバ変数のスコープの変更
- `YoloV2Sp90Model::get_object_detection`の追加
- `RecognizeBase::get_data_in_addr`の追加
- `RecognizeBase::get_data_in_size`の追加
- スレッド間の排他制御の追加

`0012-change-drp-ai-object-files.patch`を適用することで以下の変更が適用される。

- DRP-AIオブジェクトファイルのメモリアドレスマップの読み込み形式を10進数から16進数に変更する
- 使用するDRP-AIオブジェクトファイルを`YoloV2_sp90_VGA_RGB_0726`に変更する

変更の差分は以下の通り。

```diff
@@ -102,7 +102,7 @@ int8_t DRPProc::read_addrmap_txt(std::string addr_file, st_addr_t* drpai_address
     {
         std::istringstream iss(str);
         iss >> element >> a >> s;
-#if 1
+#if 0
         l_addr = strtol(a.c_str(), NULL, 10);
         l_size = strtol(s.c_str(), NULL, 10);
```

```diff
-    constexpr static string_view MODEL_DIR = "yolov2_sp90";
+    constexpr static string_view MODEL_DIR = "YoloV2_sp90_VGA_RGB_0726";
```

`0013-temporarily-implement-drp-ai.patch`を適用することで以下の変更が適用される。

- `YoloDetector_drp.h`と`YoloDetector_drp.cc`の仮実装を追加する
    - `YoloDetector`クラスの派生クラス
- `YoloDetector_drp`クラスのインスタンスを扱えるように変更
    - `Tracking`クラスの変更
    - `YoloDetector`クラスの変更
    - `UseDrpAI`の設定値によって、DRP-AIを使用するのかを切り替えられるようにする
- `YoloDetector::YoloObjectDetect`から不要な引数を削除

`0014-use-drp-ai.patch`を適用することで以下の変更が適用される。

- `YoloDetector_drp.h`と`YoloDetector_drp.cc`へのDRP-AI連携処理の追加
- DRP-AI連携処理の追加
    - `Tracking`クラスの変更
    - `YoloDetector`クラスの変更
    - `UseDrpAI`の設定値によって、DRP-AIを使用するのかを切り替えられるようにする

`0015-use-opencva.patch`を適用することで以下の変更が適用される。

- `OpenCVA.h`と`OpenCVA.cc`の追加
- OpenCVA連携処理の追加
    - `System`クラスの変更
    - `ORBextractor`クラスの変更
    - `UseOpenCVA`の設定値によって、OpenCVAでDRPを使用するのかを切り替えられるようにする
- FASTの入力画像を`cv::Mat::clone`でディープコピーする
    - OpenCVAのFASTの入力画像は`cv::Mat::isContinuous`が`true`でないと正常に動作しないため

### DRPドライバネイティブ対応

`0016-expand-option-drp-driver-native.patch`を適用することで以下の変更が適用される。

- `UseDrpDriverNative`オプションの追加

`0017-use-drp-driver-native.patch`を適用することで以下の変更が適用される。

- `DrpDriverNative.h`と`DrpDriverNative.cc`の追加
- DRPドライバネイティブ連携処理の追加
    - `System`クラスの変更
    - `Tracking`クラスの変更
    - `ORBextractor`クラスの変更
    - `UseDrpDriverNative`の設定値によって、`computeDescriptors`でDRPを使用するのかを切り替えられるようにする

### DRP-AIドライバの2チャネル対応

`0018-write-drp-ai-input-using-udmabuf.patch`を適用することで、`0003-modify-memory-map-for-drpai.patch`を適用したCIP Linux上でDRP-AIプログラムを実行するために以下の変更が適用される。

- `YoloDetector_drp`クラスに`/dev/udmabuf0`をopen/closeする処理を追加する
- `YoloDetector_drp`クラスに`mmap`と`memcpy`を使用して、DRP-AIの入力画像を書き込む処理を追加する
    - 書き込み先のメモリ空間の先頭アドレス値は`/sys/class/u-dma-buf/udmabuf0/phys_addr`から取得する

### 各パッチの変更量

各パッチの変更量は以下の通り。

![各パッチの変更量](image/patch_size.png)

青文字で示した、`0008-import-drp-ai-demo-code.patch`の変更量が大きい点に注意する必要がある。
