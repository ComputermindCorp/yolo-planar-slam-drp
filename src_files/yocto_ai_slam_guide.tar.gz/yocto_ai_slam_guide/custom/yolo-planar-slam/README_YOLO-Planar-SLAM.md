# OpenCVA差し替え版のYolo-Planar-SLAM動作マニュアル

## 前提条件

- [OpenCVA導入マニュアル](README_OpenCVA.md)を読み終わっていること
- [OpenCVA導入マニュアル](README_OpenCVA.md)の前提条件を満たしていること
- [OpenCVA導入マニュアル](README_OpenCVA.md)の作業が完了していること
- V2xボードの`$HOME/yolo-planar-slam.opencva/Vocabulary/ORBvoc.txt`にOpenCVA組み込み版のYolo-Planar-SLAMの`Vocabulary/ORBvoc.txt`と同じファイルが配置されていること
- V2xボードの`$HOME/yolo-planar-slam.opencva/configuration_code/orb_descriptors_drp_out.bin`にcomputeOrbDescriptorsのコンフィギュレーションコードが配置されていること
- V2xボードの`$HOME/yolo-planar-slam.opencva/YoloV2_sp90_VGA_RGB_0726`にYOLOv2のDRP-AIオブジェクトファイル一式（`YoloV2_sp90_VGA_RGB_0726`）が配置されていること

## ビルド済みのYolo-Planar-SLAMの配置

[OpenCVA導入マニュアル](README_OpenCVA.md)の`ビルド`のビルド生成物のうち、以下のディレクトリをV2xボード上の`$HOME/yolo-planar-slam.opencva/`以下にコピーする。

- /yocto_rzv2x_beta_workdir/yolo-planar-slam.opencva/Examples
- /yocto_rzv2x_beta_workdir/yolo-planar-slam.opencva/lib
- /yocto_rzv2x_beta_workdir/yolo-planar-slam.opencva/Thirdparty

## LD_LIBRARY_PATHの設定

以下のコマンドを実行し、ホームディレクトリ以下のYolo-Planar-SLAMのライブラリがリンクされるようにする。

```shell
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam.opencva/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam.opencva/Thirdparty/g2o/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$HOME/yolo-planar-slam.opencva/Thirdparty/DBoW2/lib:$LD_LIBRARY_PATH
```

以下のコマンドを実行し、意図した通りにリンクされているのかを確認する。

```shell
/lib64/ld-linux-aarch64.so.1 --list $HOME/yolo-planar-slam.opencva/Examples/RGB-D/rgbd_tum | \
  grep -E 'modules|SLAM|g2o|DBoW2'
```

以下のように、Yolo-Planar-SLAMのライブラリのリンク先が`/home/root`以下のファイルとなっていれば問題ない。

```shell
        libORB_SLAM2.so => /home/root/yolo-planar-slam.opencva/lib/libORB_SLAM2.so (0x0000ffff95a1e000)
        libDBoW2.so => /home/root/yolo-planar-slam.opencva/Thirdparty/DBoW2/lib/libDBoW2.so (0x0000ffff952fe000)
        libg2o.so => /home/root/yolo-planar-slam.opencva/Thirdparty/g2o/lib/libg2o.so (0x0000ffff95272000)
        libdrp_ai_modules.so => /home/root/yolo-planar-slam.opencva/lib/libdrp_ai_modules.so (0x0000ffff94732000)
```

以下のようにerrorが出た場合には、意図したライブラリにリンクされていない。  
手順を再確認する必要がある。

```shell
/home/root/yolo-planar-slam.opencva/Examples/RGB-D/rgbd_tum: error while loading shared libraries: libORB_SLAM2.so: cannot open shared object file: No such file or directory
```

## 実行

`rgbd_dataset_freiburg3_walking_xyz`を使用する場合は設定ファイルは`$HOME/yolo-planar-slam.opencva/Examples/RGB-D/TUM3.yaml`にある。

OpenCVAを使用する場合には`UseOpenCVA`に`true`を設定する。  
OpenCVAを使用しない場合には`UseOpenCVA`に`false`を設定する。

2023年10月時点でDRP-AIを使用しない場合は実行できないため、`UseDrpAI`に`true`を設定する。

`UseOpenCVA`を`true`に設定した上で、DRPドライバネイティブ実装を使用する場合には`UseDrpDriverNative`に`true`を設定する。  
`true`に設定した場合はcomputeOrbDescriptorsがDRPドライバネイティブで実行される。

DRPドライバネイティブ実装を使用しない場合には`UseDrpDriverNative`に`false`を設定する。

RGB-DモードでYolo-Planar-SLAMを使用する場合は、以下を実行する。

```shell
cd $HOME/yolo-planar-slam.opencva/
./Examples/RGB-D/rgbd_tum \
  Vocabulary/ORBvoc.txt \
  Examples/RGB-D/TUM3.yaml \
  /opt/dataset/tum/rgbd_dataset_freiburg3_walking_xyz \
  /opt/dataset/tum/rgbd_dataset_freiburg3_walking_xyz/associate.txt
```
