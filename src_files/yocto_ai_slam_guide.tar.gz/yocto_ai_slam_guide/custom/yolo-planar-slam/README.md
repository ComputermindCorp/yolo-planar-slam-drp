# Yolo-Planar-SLAM + AI導入・カスタマイズガイド

## 前提条件

- [AI+SLAM 導入・カスタマイズガイド](../README.md)を読み終わっていること
- [AI+SLAM 導入・カスタマイズガイド](../README.md)の前提条件を満たしていること
- [AI+SLAM 導入・カスタマイズガイド](../README.md)の作業が完了していること

## 1 OpenCVA差し替え版のYolo-Planar-SLAM動作マニュアル一覧

### 1.1 Yolo-Planar-SLAMのOpenCVA導入マニュアル

[Yolo-Planar-SLAMのOpenCVA導入マニュアル](README_OpenCVA.md)に記載されている。

### 1.2 OpenCVA差し替え版のYolo-Planar-SLAM動作マニュアル

[OpenCVA差し替え版のYolo-Planar-SLAM動作マニュアル](README_YOLO-Planar-SLAM.md)に記載されている。  
`1.1 OpenCVA導入マニュアル`の作業が完了している必要がある。

## 2 OpenCVA組み込み版のYolo-Planar-SLAM動作マニュアル一覧

DRP-AI TranslatorとDRP-AI TVMの切り替え方法については[Yolo-Planar-SLAMビルドマニュアル](../../yocto_dev/README_Build_YOLO-Planar-SLAM.md)を参照すること。

### 2.1 DRP-AI TranslatorのYOLOモデル変更マニュアル

[DRP-AI TranslatorのYOLOモデル変更マニュアル](../README_DRP-AI_Translator.md)に記載されている。

### 2.2 DRP-AI TVMのYOLOモデル変更マニュアル

[DRP-AI TVMのYOLOモデル変更マニュアル](../README_DRP-AI_TVM.md)に記載されている。
