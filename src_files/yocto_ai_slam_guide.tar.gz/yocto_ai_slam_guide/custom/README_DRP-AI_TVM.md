# DRP-AI TVMのYOLOモデル変更マニュアル

本マニュアルでは`v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119`の実装を取り込む場合の例を記載する。

## 前提条件

- [動作マニュアル](README.md)を読み終わっていること
- [動作マニュアル](README.md)の前提条件を満たしていること
- [Yocto導入ガイド](../yocto_dev/README.md)を読み終わっていること
- [Yocto導入ガイド](../yocto_dev/README.md)の前提条件を満たしていること
- 作業対象がYolo-Planar-SLAMの場合は、[Yolo-Planar-SLAMビルドマニュアル](../yocto_dev/README_Build_YOLO-Planar-SLAM.md)を読み終わっていること
- 作業対象がYolo-Planar-SLAMの場合は、[Yolo-Planar-SLAMビルドマニュアル](../yocto_dev/README_Build_YOLO-Planar-SLAM.md)の前提条件を満たしていること
- 作業対象がstella_vslamの場合は、[stella_vslamビルドマニュアル](../yocto_dev/README_Build_Stella_VSLAM.md)を読み終わっていること
- 作業対象がstella_vslamの場合は、[stella_vslamビルドマニュアル](../yocto_dev/README_Build_Stella_VSLAM.md)の前提条件を満たしていること

## 注意事項

本マニュアルは、2024年3月時点の実装について記載されている。  
**2024年4月以降の実装には準拠していない。**

## 作業ディレクトリの指定

作業対象がYolo-Planar-SLAMの場合は、以下のコマンドを実行し、設定を行う。

```shell
DRP_AI_TVM_MODULE_DIR=~/yolo-planar-slam/drp_ai_modules/tvm
DRP_AI_TVM_MODEL_CLASS_NAME=YoloDetector_tvm # 物体検出クラス名
```

作業対象がstella_vslamの場合は、以下のコマンドを実行し、設定を行う。

```shell
DRP_AI_TVM_MODULE_DIR=~/stella_vslam/src/stella_vslam/drp_ai
DRP_AI_TVM_MODEL_CLASS_NAME=yolo_detector # 物体検出クラス名
```

## サンプルプログラムの取り込み

DRP-AI TVMのサンプルプログラムのソースコードを取り込む。  
なお、2024年3月時点のDRP-AI TVM連携の実装は、`v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119`の実装を取り込み作成されている。

まず、`${DRP_AI_TVM_MODULE_DIR:?}`以下に、今回取り込むDRP-AI TVM実装に対応するディレクトリを作成する。  
ここでは`yoloxs_provisional_new`とする。

```shell
mkdir -p ${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional_new
```

次に、`v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119/apps`に含まれる以下のソースコードファイルを`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional_new`にコピーする。

- PreRuntime.h
- PreRuntimeV2H.cpp
- MeraDrpRuntimeWrapper.h
- MeraDrpRuntimeWrapper.cpp

同様に、`v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src`に含まれる以下のソースコードファイルとディレクトリを`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional_new`にコピーする。

- camera/define.h
- box.h
- box.cpp

## 取り込んだソースコードの変更

### 重複インクルードの防止

上記で取り込んだヘッダーファイルに重複インクルードのための記述が無い場合には、重複インクルードを防止するために、ヘッダーファイルの先頭に`#pragma once`を追記する。

### メモリアドレス変換の無効化

`PreRuntime::Load`と`PreRuntime::Pre`で実行される`ioctl(DRPAI_SET_ADRCONV)`によるメモリアドレス変換について、無効化が必要な場合がある。

`v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119`の`PreRuntime::Load`では、以下のメモリアドレス空間が実行されていた。

- `0x0_0000_0000 ~ 0x0_01FF_FFFF` → `0x2_5E00_0000 ~ 0x2_5FFF_FFFF`

`v210_yolox_tmp_240119/drp-tvm_dev-v210_add_yolox_240119`の`PreRuntime::Pre`では、以下のメモリアドレス空間が実行されていた。

- `0x0_0000_0000 ~ 0x0_01FF_FFFF` → `0x2_5E00_0000 ~ 0x2_5FFF_FFFF`
- `0x0_D000_0000 ~ 0x0_EFFF_FFFF` → `0x0_5800_0000 ~ 0x0_77FF_FFFF`

特に`0x0_D000_0000`から`0x0_5800_0000`のメモリアドレス変換については、MMNGRを使用してUSBカメラから取得した画像データが書き込まれる。  
しかし2024年2月時点で、`ioctl(DRPAI_ASSIGN)`を使用してこのメモリ空間に入力画像のデータを書き込んでも正常に動作しないことがわかっている。  
そのため、DRP-AIの入力画像は`0x0_5800_0000`ではなく`0x2_5E00_0000`に書き込み、DRP-AIから読み込むように変更する必要がある。  
なお、使用するDRP-AIモデルによって入力画像のメモリ空間の先頭アドレス値は`0x2_5E00_0000`から変更が必要な場合がある。

`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional_new/PreRuntimeV2H.cpp`に以下の変更を加え、前述のメモリアドレス変換をコメントアウトする。

```diff
@@ -620,9 +620,10 @@ uint8_t PreRuntime::Pre(s_preproc_param_t* param, void** out_ptr, uint32_t* out_
             }

             this->mapped_in_addr_v2h = param->pre_in_addr;
+            /*
             drpai_adrconv.conv_address = param->pre_in_addr & 0xffffff000000;
             drpai_adrconv.org_address = 0xD0000000;
-            drpai_adrconv.size = 0x20000000; /*(drpai_obj_info.drpai_address.data_in_size + 0xffffff) & 0xff000000;*/
+            drpai_adrconv.size = 0x20000000; /*(drpai_obj_info.drpai_address.data_in_size + 0xffffff) & 0xff000000;* /
             drpai_adrconv.mode = DRPAI_ADRCONV_MODE_ADD;
             ret = ioctl(drpai_obj_info.drpai_fd, DRPAI_SET_ADRCONV, &drpai_adrconv);

@@ -630,6 +631,7 @@ uint8_t PreRuntime::Pre(s_preproc_param_t* param, void** out_ptr, uint32_t* out_
                 std::cerr << "[ERROR] Failed to run SET_ADRCONV(2) for DRP-AI input image : errno=" << errno << std::endl;
                 return PRE_ERROR;
             }
+            */
         }

 #ifndef WITH_V2H_DEV
```

## 物体検出クラスの実装

### ベース実装のコピー

既存の物体検出クラスのソースコードをベースに実装を行う。  
ここでは`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional`をベースに実装する。

```shell
cd ${DRP_AI_TVM_MODULE_DIR:?}/
cp \
  yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.h \
  yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp \
  yoloxs_provisional_new/
cd -
```

### 参照先の変更

ビルドする実装を`yoloxs_provisional`から`yoloxs_provisional_new`に変更する。

Yolo-Planar-SLAMの場合は`${DRP_AI_TVM_MODULE_DIR:?}/CMakeLists.txt`に以下の変更を加える。

```diff
 include_directories(${CMAKE_CURRENT_SOURCE_DIR})
 include_directories(${CMAKE_CURRENT_SOURCE_DIR}/include)
-include_directories(${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional)
+include_directories(${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new)

 add_library(${PROJECT_NAME} SHARED
-  ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/box.cpp
-  ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/MeraDrpRuntimeWrapper.cpp
-  ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/PreRuntimeV2H.cpp
-  ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/YoloDetector_tvm.cpp
+  ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/box.cpp
+  ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/MeraDrpRuntimeWrapper.cpp
+  ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/PreRuntimeV2H.cpp
+  ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/YoloDetector_tvm.cpp
 )
```

stella_vslamの場合は`${DRP_AI_TVM_MODULE_DIR:?}/CMakeLists.txt`に以下の変更を加える。

```diff
 # Add sources
 target_sources(${PROJECT_NAME}
                PRIVATE
-               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/camera/define.h
-               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/box.h
-               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/PreRuntime.h
-               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/MeraDrpRuntimeWrapper.h
-               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/yolo_detector.h
-               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/box.cpp
-               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/MeraDrpRuntimeWrapper.cpp
-               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/PreRuntimeV2H.cpp
-               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/yolo_detector.cpp
+               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/camera/define.h
+               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/box.h
+               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/PreRuntime.h
+               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/MeraDrpRuntimeWrapper.h
+               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/yolo_detector.h
+               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/box.cpp
+               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/MeraDrpRuntimeWrapper.cpp
+               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/PreRuntimeV2H.cpp
+               ${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/yolo_detector.cpp
                )

 # Please refer to drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/CMakeLists.txt
 target_link_libraries(${PROJECT_NAME} PUBLIC tvm_runtime)

 # Install headers
-file(GLOB HEADERS "${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/*.h")
+file(GLOB HEADERS "${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/*.h")
 install(FILES ${HEADERS}
-        DESTINATION ${STELLA_VSLAM_INCLUDE_INSTALL_DIR}/drp_ai/yoloxs_provisional)
-file(GLOB HEADERS "${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional/camera/*.h")
+        DESTINATION ${STELLA_VSLAM_INCLUDE_INSTALL_DIR}/drp_ai/yoloxs_provisional_new)
+file(GLOB HEADERS "${CMAKE_CURRENT_SOURCE_DIR}/yoloxs_provisional_new/camera/*.h")
 install(FILES ${HEADERS}
-        DESTINATION ${STELLA_VSLAM_INCLUDE_INSTALL_DIR}/drp_ai/yoloxs_provisional/camera)
+        DESTINATION ${STELLA_VSLAM_INCLUDE_INSTALL_DIR}/drp_ai/yoloxs_provisional_new/camera)
```

参照するヘッダーファイルのpathを`yoloxs_provisional`から`yoloxs_provisional_new`に変更する。

Yolo-Planar-SLAMの場合は`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional_new/YoloDetector_tvm.h`に以下の変更を加える。

```diff
 #include <opencv2/core.hpp>

-#include "yoloxs_provisional/MeraDrpRuntimeWrapper.h"
-#include "yoloxs_provisional/PreRuntime.h"
-#include "yoloxs_provisional/camera/define.h"
-#include "yoloxs_provisional/box.h"
+#include "yoloxs_provisional_new/MeraDrpRuntimeWrapper.h"
+#include "yoloxs_provisional_new/PreRuntime.h"
+#include "yoloxs_provisional_new/camera/define.h"
+#include "yoloxs_provisional_new/box.h"

 namespace ORB_SLAM2 {
```

同様に`src/Tracking.cc`に以下の変更を加え、参照するヘッダーファイルのpathを`yoloxs_provisional`から`yoloxs_provisional_new`に変更する。

```diff
 #if defined(ENABLE_DRP_AI_TVM)
-#include "tvm/yoloxs_provisional/YoloDetector_tvm.h"
+#include "tvm/yoloxs_provisional_new/YoloDetector_tvm.h"
 #endif
```

stella_vslamの場合は以下の3つのヘッダーファイルに以下の変更を加える。

- `src/stella_vslam/publish/frame_publisher.h`
- `src/stella_vslam/feature/orb_extractor.h`
- `src/stella_vslam/system.h`

```diff
 #if defined(ENABLE_DRP_AI_TVM)
-#include "stella_vslam/drp_ai/yoloxs_provisional/yolo_detector.h"
+#include "stella_vslam/drp_ai/yoloxs_provisional_new/yolo_detector.h"
 #endif
```

### コンパイルオプションの設定

`${DRP_AI_TVM_MODULE_DIR:?}/CMakeLists.txt`で設定されるコンパイラオプションを、取り込んだサンプルプログラムを踏襲した設定に変更する。  
例えば、`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional`の場合では`drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/CMakeLists.txt`の設定を踏襲し、以下のように設定されている。

```cmake
# Please refer to drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/CMakeLists.txt
target_compile_options(${PROJECT_NAME} PUBLIC ${CXX} ${LDFLAGS} ${OpenMP_CXX_FLAGS} -lm -lrt -O3 -DNDEBUG)
target_compile_options(${PROJECT_NAME} PRIVATE -Wall )
target_compile_definitions(${PROJECT_NAME} PRIVATE IMAGE_MODE)
target_compile_definitions(${PROJECT_NAME} PRIVATE V2H)
target_compile_definitions(${PROJECT_NAME} PRIVATE DEBUG_LOG)
target_compile_features(${PROJECT_NAME} PUBLIC  cxx_std_17)
```

### 物体検出クラスのメンバ変数の定義

`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional_new/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.h`で定義されている物体検出クラスのメンバ変数を順に確認する。

まず、YOLOの検出対象のラベルリスト`label_file_map`の設定値を確認する。  
例えば、`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.h`では`drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/define_color.h`の定義を踏襲している。  
YOLOの検出対象のラベルリストに変更の必要があれば、変更する。

次に、`PreRuntime::Pre`の入力画像の横サイズ`expansion_output_width`の設定値を確認する。  
例えば、`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.h`では`v210_yolox_tmp_240119/yolox_cam/preprocess/drp_param_info.txt`の設定値を踏襲している。  
`PreRuntime::Pre`の入力画像の横サイズに変更の必要があれば、変更する。

最後に、`PreRuntime::Pre`の入力画像を配置する、メモリ空間の先頭アドレス値`preruntime_input_address`の設定値を確認する。  
例えば、`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.h`では`0x2_5E00_0000`に設定している。  
`PreRuntime::Pre`の入力画像を配置する、メモリ空間の先頭アドレス値に変更の必要があれば、変更する。  
特に、使用するDRP-AIモデルによって入力画像のメモリ空間の先頭アドレス値は`0x2_5E00_0000`から変更が必要な場合がある。

### 物体検出クラスのコンストラクタの定義

`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional_new/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`で定義されている、コンストラクタで設定されている以下のメンバ変数の値を確認する。

- `labels`
- `model_dir`
- `pre_dir`

例えば、`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`では、`drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/main.cpp`の設定を踏襲し、以下のように設定している。  
以下はYolo-Planar-SLAMの場合の例である。

```cpp
// Please refer to drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/main.cpp
YoloDetector_tvm::YoloDetector_tvm()
    : model_dir("yolox_cam"),
      pre_dir("yolox_cam/preprocess") {
```

上記で指定したラベルファイルとモデルディレクトリは、V2xボード上のYolo-Planar-SLAMリポジトリの中に事前に配置しておく必要がある。  
例えばYolo-Planar-SLAMの場合は、`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional`で使用するモデルディレクトリ`yolox_cam`はV2xボード上の`~/yolo-planar-slam/yolox_cam`に配置される。  
同じくstella_vslamの場合は、V2xボード上の`~/stella_vslam_examples/yolox_cam`に配置される。

### サンプルプログラムの関数の取り込み

DRP-AI TVMのサンプルプログラムから、以下の関数を`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional_new/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`に取り込む。  
例えば`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`に含まれている下記の関数は`drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/main.cpp`から取り込んでいる。

- float16_to_float32
- index
- offset
- get_drpai_start_addr
- set_drpai_freq
- init_drpai

同様に、以下の関数も取り込み、物体検出クラスのメンバ関数にする。

- get_result
- R_Post_Proc

なお、上記の関数の実装に`std::`や`cv::`などの名前空間が指定されていないクラス・変数が含まれている場合にはビルド時にエラーとなる可能性がある。  
そのため、特に`vector`や`string`に対しては必要に応じて名前空間を追記する。

### 動作周波数設定の確認

`set_drpai_freq`で設定する動作周波数を記述する。  
`ioctl(DRPAI_SET_DRP_MAX_FREQ)`と`ioctl(DRPAI_SET_DRPAI_FREQ)`の仕様については`rzv2h_drpai-driver_ver1.00/README.md`に記載されている。  
例えば、DRPの動作周波数を`420`\[MHz\]（設定値`2`）、DRP-AIの動作周波数を`1`\[GHz\]（設定値`2`）に設定する場合には、以下のように実装する。

```cpp
int set_drpai_freq(int drpai_fd) {
    int ret = 0;
    uint32_t data;
    int32_t drp_max_freq = 2;
    int32_t drpai_freq = 2;
```

### DRP-AI TVMの前処理の変更

物体検出クラスのメンバ関数`YoloObjectDetectStart`のDRP-AI TVMの前処理を確認する。

DRP-AI TVMの前処理では、以下の処理が必要な場合がある。

- 入力画像のYUYV変換、またはRGB変換
- 入力画像の拡大処理
- 入力画像の下端のパディング

また、DRP-AI TVMの前処理では、以下の処理が必要となる。

- DRP-AI TVMの実行開始処理

なお`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`の実装では、SLAM側から入力された画像のサイズは`640x480`、チャネル数は`3`のBGR画像でなければならない。

#### 入力画像のYUYV変換、またはRGB変換

SLAM側から入力された画像を、`PreRuntime::Pre`の入力画像のフォーマットに合わせて変換する処理が必要な場合がある。

`PreRuntime::Pre`の入力画像のフォーマットがYUYVの場合は、物体検出クラスのメンバ関数`YoloObjectDetectStart`の`convert_to_yuyv`を`true`に設定する。  
`PreRuntime::Pre`の入力画像のフォーマットがRGBの場合は、物体検出クラスのメンバ関数`YoloObjectDetectStart`の`convert_to_yuyv`を`false`に設定する。

例えば`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`ではYUYV変換が必要なため、以下のように実装されている。

```cpp
const bool convert_to_yuyv = true;
const bool convert_to_rgb = !convert_to_yuyv;
```

#### 入力画像の拡大処理

SLAM側から入力された画像を、`PreRuntime::Pre`の入力画像のサイズに合わせて拡大する処理が必要な場合がある。  
拡大処理を有効にすると、SLAM側から入力された画像の横サイズが物体検出クラスのメンバ変数`expansion_output_width`となるように、アスペクト比を維持したまま拡大される。

`PreRuntime::Pre`の入力画像の拡大処理が必要な場合は、物体検出クラスのメンバ関数`YoloObjectDetectStart`の`expansion_input`を`true`に設定する。

例えば`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`では拡大処理が必要なため、以下のように実装されている。

```cpp
const bool expansion_input = true;
```

#### 入力画像の下端のパディング

SLAM側から入力された画像の下端をパディングする処理が必要な場合がある。

`PreRuntime::Pre`の入力画像の下端をパディングする処理が必要な場合は、物体検出クラスのメンバ関数`YoloObjectDetectStart`の`bottom_padding`を`true`に設定する。

例えば`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`では下端のパディング処理を行うため、以下のように実装されている。

```cpp
const bool bottom_padding = true;
```

#### DRP-AI TVMの実行開始処理

物体検出クラスのメンバ関数`YoloObjectDetectStart`に含まれるDRP-AI TVMの実行開始処理に変更が必要な場合がある。

DRP-AI TVMの実行開始処理は`drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/main.cpp`の`R_Inf_Thread`の実装を踏襲している。  
例えば`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`では以下のように実装されている。  
なお、`MT_`で始まるマクロは処理時間を計測するために本案件で追加した処理である点に注意する。

```cpp
// Please refer to R_Inf_Thread on drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/main.cpp
{
    /*Get input data */
    auto input_data_type = runtime.GetInputDataType(0);

    /*Load input data */
    /*Input data type can be either FLOAT32 or FLOAT16, which depends on the model */
    if (InOutDataType::FLOAT32 == input_data_type) {
        /*Do nothing*/
    }
    else if (InOutDataType::FLOAT16 == input_data_type) {
        std::cerr << "[ERROR] Input data type : FP16." << std::endl;
        /*If your model input data type is FP16, use std::vector<uint16_t> for reading input data. */
        return false;
    }
    else {
        std::cerr << "[ERROR] Input data type : neither FP32 nor FP16." << std::endl;
        return false;
    }

    /*Variable for getting Inference output data*/
    void* output_ptr;
    uint32_t out_size;
    /*Variable for Pre-processing parameter configuration*/
    s_preproc_param_t in_param;

    in_param.pre_in_addr = /*(uintptr_t)*/ capture_address;

    MT_START(mt_drp_ai_yolo_pre);
    uint8_t ret = preruntime.Pre(&in_param, &output_ptr, &out_size);
    MT_FINISH(mt_drp_ai_yolo_pre);

    if (ret != 0) {
        fprintf(stderr, "[ERROR] Failed to run Pre-processing Runtime Pre()\n");
        return false;
    }

    /*Set Pre-processing output to be inference input. */
    MT_START(mt_drp_ai_yolo_set_input);
    runtime.SetInput(0, (float*)output_ptr);
    MT_FINISH(mt_drp_ai_yolo_set_input);

    MT_START(mt_drp_ai_yolo_run);
    runtime.Run();
    MT_FINISH(mt_drp_ai_yolo_run);
}
```

本作業で取り込むサンプルプログラムの実装と差異がある場合には、変更を行う。

### DRP-AI TVMの後処理の変更

物体検出クラスのメンバ関数`YoloObjectDetectFinish`のDRP-AI TVMの後処理を確認する。

DRP-AI TVMの後処理では、以下の処理が必要となる。

- DRP-AI TVMの出力バウンディングボックスを受け取る処理
- DRP-AI TVMの出力バウンディングボックスにNMSを適用する処理
- DRP-AI TVMの出力バウンディングボックスを、Yolo-Planar-SLAMのバウンディングボックス型に変換する処理

#### DRP-AI TVMの出力を受け取る処理

DRP-AI TVMの出力を受け取る処理は`drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/main.cpp`の`R_Inf_Thread`の実装を踏襲している。  
例えば`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`では以下のように実装されている。  
なお、`MT_`で始まるマクロは処理時間を計測するために本案件で追加した処理である点に注意する。

```cpp
MT_START(mt_drp_ai_yolo_receive_result);

/*Process to read the DRPAI output data.*/
int8_t ret = get_result();
if (0 != ret) {
    fprintf(stderr, "[ERROR] Failed to get result from memory.\n");
    MT_FINISH(mt_drp_ai_yolo_receive_result);
    return false;
}

/*Preparation for Post-Processing*/
/*CPU Post-Processing For YOLOX*/
R_Post_Proc(drpai_output_buf);
```

本作業で取り込むサンプルプログラムの実装と差異がある場合には、変更を行う。

#### DRP-AI TVMの出力バウンディングボックスにNMSを適用する処理

DRP-AI TVMの出力バウンディングボックスにNMSを適用し、NMSの適用後のバウンディングボックスのみをSLAMで使用する。  
そのため、物体検出クラスのメンバ関数`R_Post_Proc`の最後に以下の処理が必要となる。  
この処理は`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`でも実装されている。

```cpp
mtx.lock();
/* Clear the detected result list */
det.clear();
for (i = 0; i < (int32_t)det_buff.size(); i++) {
    /* Skip the overlapped bounding boxes */
    if (det_buff[i].prob == 0)
        continue;
    det.push_back(det_buff[i]);
}
mtx.unlock();
```

`det_buff`には、NMSで除外されなかったバウンディングボックスと、NMSで除外されたバウンディングボックスが`prob`の値を`0`に設定された状態で格納されている。  
`det`には、NMSで除外されなかったバウンディングボックスを格納する。

#### DRP-AI TVMの出力を、Yolo-Planar-SLAMのバウンディングボックス型に変換する処理

Yolo-Planar-SLAMの場合のみ、サンプルプログラムの`Box`型で定義されたバウンディングボックスを、Yolo-Planar-SLAMの`YoloBoundingBox`型で定義されたバウンディングボックスに変換する必要がある。  
例えば`${DRP_AI_TVM_MODULE_DIR:?}/yoloxs_provisional/${DRP_AI_TVM_MODEL_CLASS_NAME:?}.cpp`では以下のように実装されている。  
なお、`Box::y`と`Box::x`にはそれぞれバウンディングボックスの中心の座標値が格納される。  
一方で`YoloBoundingBox`型のコンストラクタの第一引数および第二引数にはバウンディングボックスの左上の端の座標値を与える必要がある点に注意する。  
同様に`YoloBoundingBox`型のコンストラクタの第三引数および第四引数にはバウンディングボックスの右下の端の座標値を与える必要がある点に注意する。

```cpp
yoloBoundingBoxList_.clear();
for (const detection d : det) {
    std::string label = label_file_map[d.c];
    yoloBoundingBoxList_.push_back(YoloBoundingBox(d.bbox.x - (d.bbox.w / 2),
                                                    d.bbox.y - (d.bbox.h / 2),
                                                    d.bbox.x + (d.bbox.w / 2),
                                                    d.bbox.y + (d.bbox.h / 2),
                                                    label,
                                                    d.prob));
}
```
