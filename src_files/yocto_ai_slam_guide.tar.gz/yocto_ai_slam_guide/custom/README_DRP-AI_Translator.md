# DRP-AI TranslatorのYOLOモデル変更マニュアル

## 前提条件

- [動作マニュアル](README.md)を読み終わっていること
- [動作マニュアル](README.md)の前提条件を満たしていること
- [Yocto導入ガイド](../yocto_dev/README.md)を読み終わっていること
- [Yocto導入ガイド](../yocto_dev/README.md)の前提条件を満たしていること
- [Yolo-Planar-SLAMビルドマニュアル](../yocto_dev/README_Build_YOLO-Planar-SLAM.md)を読み終わっていること
- [Yolo-Planar-SLAMビルドマニュアル](../yocto_dev/README_Build_YOLO-Planar-SLAM.md)の前提条件を満たしていること

## 注意事項

本マニュアルは、2024年3月時点の実装について記載されている。  
**2024年4月以降の実装には準拠していない。**

**2024年3月時点で、stella_vslamではDRP-AI Translator適合は行われていない。**

## Modelクラスの実装

新たに追加するModelクラスのソースコードを格納するディレクトリを作成する。  
ここでは例としてDRP-AIオブジェクトファイル`YOLOX_S_sp70_640x640_RGB_10271351`を使用するModelクラスを`drp_ai_modules/translator/recognize/yoloxs_sp70`に実装する。

```shell
mkdir -p drp_ai_modules/translator/recognize/yoloxs_sp70
```

既存のModelクラスのソースコードをベースに実装を行う。  
ここでは`drp_ai_modules/translator/recognize/yolov2_sp90`をベースに実装する。

```shell
cd drp_ai_modules/translator/recognize/
cp yolov2_sp90/yolov2_sp90_model.h   yoloxs_sp70/yoloxs_sp70_model.h
cp yolov2_sp90/yolov2_sp90_model.cpp yoloxs_sp70/yoloxs_sp70_model.cpp
cd -
```

Modelクラス名を変更する。  
ベースとした`yolov2_sp90`では`YoloV2Sp90Model`となっている。  
ここでは`YoloXSSp70Model`へ変更する。

```shell
cd drp_ai_modules/translator/recognize/
sed -i 's/YoloV2Sp90Model/YoloXSSp70Model/g' yoloxs_sp70/*
cd -
```

同様に定数名のprefixも変更する。  
ベースとした`yolov2_sp90`では`YOLOV2_SP90_`となっている。  
ここでは`YOLOXS_SP70_`へ変更する。

```shell
cd drp_ai_modules/translator/recognize/
sed -i 's/YOLOV2_SP90_/YOLOXS_SP70_/g' yoloxs_sp70/*
cd -
```

同様にソースコード中のファイル名も変更する。  
ベースとした`yolov2_sp90`では`yolov2_sp90_model.h`および`yolov2_sp90_model.cpp`となっている。  
ここでは`yoloxs_sp70_model.h`および`yoloxs_sp70_model.cpp`へ変更する。

```shell
cd drp_ai_modules/translator/recognize/
sed -i 's/yolov2_sp90_model/yoloxs_sp70_model/g' yoloxs_sp70/*
cd -
```

`yoloxs_sp70_model.h`で指定するDRP-AIオブジェクトファイル名を`YOLOX_S_sp70_640x640_RGB_10271351`に変更する。

```diff
-    constexpr static string_view MODEL_NAME = "yolov2_sp90";
+    constexpr static string_view MODEL_NAME = "YOLOX_S_sp70_640x640_RGB_10271351";
```

```diff
 #if (MODEL_RESOLUTION == 0)
-    constexpr static string_view MODEL_DIR = "yolov2_sp90";
+    constexpr static string_view MODEL_DIR = "YOLOX_S_sp70_640x640_RGB_10271351";
```

`yoloxs_sp70_model.h`で指定するパラメータを`YOLOX_S_sp70_640x640_RGB_10271351`向けに変更する。  
ここでは2023年10月時点の`app_yolox_cam/src/define.h`の設定値を踏襲する。

```diff
 class YoloXSSp70Model : public IRecognizeModel {
 private:
     constexpr static string_view MODEL_NAME = "YOLOX_S_sp70_640x640_RGB_10271351";
-    constexpr static int32_t YOLOXS_SP70_NUM_BB = 5;
+    constexpr static int32_t YOLOXS_SP70_NUM_BB = 1;
     /* Number of output layers. This value MUST match with the length of num_grids[] below */
-    constexpr static int32_t YOLOXS_SP70_NUM_INF_OUT_LAYER = 1;
+    constexpr static int32_t YOLOXS_SP70_NUM_INF_OUT_LAYER = 3;
     /* Thresholds */
-    constexpr static float YOLOXS_SP70_TH_PROB = 0.4f;
+    constexpr static float YOLOXS_SP70_TH_PROB = 0.5f;
     constexpr static float YOLOXS_SP70_TH_NMS = 0.5f;
     /* Size of input image to the model */
-    constexpr static int32_t YOLOXS_SP70_MODEL_IN_W = 416;
-    constexpr static int32_t YOLOXS_SP70_MODEL_IN_H = 416;
+    constexpr static int32_t YOLOXS_SP70_MODEL_IN_W = 640;
+    constexpr static int32_t YOLOXS_SP70_MODEL_IN_H = 640;

 #if (MODEL_RESOLUTION == 0)
     constexpr static string_view MODEL_DIR = "YOLOX_S_sp70_640x640_RGB_10271351";
     constexpr static int32_t YOLOXS_SP70_DRPAI_IN_WIDTH = 640;
-    constexpr static int32_t YOLOXS_SP70_DRPAI_IN_HEIGHT = 480;
+    constexpr static int32_t YOLOXS_SP70_DRPAI_IN_HEIGHT = 640;
```

`MODEL_RESOLUTION`による入力画像サイズの切り替えは行わないため、`MODEL_RESOLUTION == 0`以外のブロックは`yoloxs_sp70_model.h`から削除する。

```diff
-#if (MODEL_RESOLUTION == 0)
     constexpr static string_view MODEL_DIR = "YOLOX_S_sp70_640x640_RGB_10271351";
     constexpr static int32_t YOLOXS_SP70_DRPAI_IN_WIDTH = 640;
     constexpr static int32_t YOLOXS_SP70_DRPAI_IN_HEIGHT = 640;
-#elif (MODEL_RESOLUTION == 1)
-    constexpr static string_view MODEL_DIR = "yolov2_sp90_hd";
-    constexpr static int32_t YOLOXS_SP70_DRPAI_IN_WIDTH = 1280;
-    constexpr static int32_t YOLOXS_SP70_DRPAI_IN_HEIGHT = 720;
-#elif (MODEL_RESOLUTION == 2)
-    constexpr static string_view MODEL_DIR = "yolov2_sp90_fhd";
-    constexpr static int32_t YOLOXS_SP70_DRPAI_IN_WIDTH = 1920;
-    constexpr static int32_t YOLOXS_SP70_DRPAI_IN_HEIGHT = 1080;
-#endif
```

入力画像のカラーフォーマットがYUYVからRGBへ変更される。  
そのため、`yoloxs_sp70_model.cpp`の中で`YoloXSSp70Model`のコンストラクタで指定するチャネル数を、`2`から`3`に変更する。

```diff
 YoloXSSp70Model::YoloXSSp70Model()
-    : IRecognizeModel(MODEL_DIR.data(), MODEL_NAME.data(), YOLOXS_SP70_DRPAI_IN_WIDTH, YOLOXS_SP70_DRPAI_IN_HEIGHT, 2) {
+    : IRecognizeModel(MODEL_DIR.data(), MODEL_NAME.data(), YOLOXS_SP70_DRPAI_IN_WIDTH, YOLOXS_SP70_DRPAI_IN_HEIGHT, 3) {
```

`yoloxs_sp70_model.cpp`で指定するパラメータを`YOLOX_S_sp70_640x640_RGB_10271351`向けに変更する。  
ここでは2023年10月時点の`app_yolox_cam/src/define.h`の設定値を踏襲する。  
なお、YOLOv2とYOLOX-Sの間でラベル情報に差異は無かったため、`label_file_map`の変更は行っていない。

```diff
-    num_grids = {13};
+    num_grids = {80, 40, 20};
     anchors = {
-        1.3221, 1.73145,
-        3.19275, 4.00944,
-        5.05587, 8.09892,
-        9.47112, 4.84053,
-        11.2364, 10.0071};
+        1.08, 1.19,
+        3.42, 4.41,
+        6.63, 11.38,
+        9.42, 5.11,
+        16.62, 10.52};
     label_file_map = {"aeroplane", "bicycle", "bird", "boat", "bottle", "bus", "car", "cat", "chair", "cow", "diningtable", "dog", "horse", "motorbike", "person", "pottedplant", "sheep", "sofa", "train", "tvmonitor"};
-    num_inf_out = (label_file_map.size() + 5) * YOLOXS_SP70_NUM_BB * num_grids[0] * num_grids[0];
+    num_inf_out = (label_file_map.size() + 5) * YOLOXS_SP70_NUM_BB * num_grids[0] * num_grids[0]
+                  + (label_file_map.size() + 5) * YOLOXS_SP70_NUM_BB * num_grids[1] * num_grids[1]
+                  + (label_file_map.size() + 5) * YOLOXS_SP70_NUM_BB * num_grids[2] * num_grids[2];
```

`yoloxs_sp70_model.cpp`の`YoloXSSp70Model::post_proc`で実装されている後処理を、`YOLOX_S_sp70_640x640_RGB_10271351`向けに変更する。  
ここでは2023年10月時点の`app_yolox_cam/src/main.cpp`の`R_Post_Proc`の実装を踏襲する。

```diff
     uint32_t label_num = label_file_map.size();
 
+    // YOLOX-S
+    int stride = 0;
+    std::vector<int> strides = {8, 16, 32};
+
     /*Post Processing Start*/
     for (uint32_t n = 0; n < YOLOXS_SP70_NUM_INF_OUT_LAYER; n++) {
         uint8_t num_grid = num_grids[n];
-        uint8_t anchor_offset = 2 * YOLOXS_SP70_NUM_BB * (YOLOXS_SP70_NUM_INF_OUT_LAYER - (n + 1));
 
         for (uint32_t b = 0; b < YOLOXS_SP70_NUM_BB; b++) {
+            stride = strides[n];
             for (uint32_t y = 0; y < num_grid; y++) {
                 for (uint32_t x = 0; x < num_grid; x++) {
                     uint32_t offs = YoloCommon::yolo_offset(n, b, y, x, num_grids.data(), YOLOXS_SP70_NUM_BB, label_file_map.size());
                     double tc = floatarr[YoloCommon::yolo_index(num_grid, offs, 4)];
 
-                    double objectness = CommonFunc::sigmoid(tc);
+                    double objectness = tc;
 
-                    /* Get the class prediction */
-                    float classes[label_num];
-                    for (uint32_t i = 0; i < label_num; i++) {
-                        classes[i] = floatarr[YoloCommon::yolo_index(num_grid, offs, 5 + i)];
-                    }
-                    CommonFunc::softmax(classes, label_num);
                     float max_pred = 0;
                     int8_t pred_class = -1;
-                    for (uint32_t i = 0; i < label_num; i++) {
-                        if (classes[i] > max_pred) {
-                            pred_class = i;
-                            max_pred = classes[i];
+                    if (objectness > YOLOXS_SP70_TH_PROB) {
+                        /* Get the class prediction */
+                        float classes[label_num];
+                        for (uint32_t i = 0; i < label_num; i++) {
+                            classes[i] = floatarr[YoloCommon::yolo_index(num_grid, offs, 5 + i)];
+                        }
+
+                        for (uint32_t i = 0; i < label_num; i++) {
+                            if (classes[i] > max_pred) {
+                                pred_class = i;
+                                max_pred = classes[i];
+                            }
                         }
                     }
```

```diff
                         /* Compute the bounding box */
-                        /*get_region_box*/
-                        float center_x = ((float)x + CommonFunc::sigmoid(tx)) / (float)num_grid;
-                        float center_y = ((float)y + CommonFunc::sigmoid(ty)) / (float)num_grid;
-                        float box_w = (float)exp(tw) * anchors[anchor_offset + 2 * b + 0] / (float)num_grid;
-                        float box_h = (float)exp(th) * anchors[anchor_offset + 2 * b + 1] / (float)num_grid;
-
-                        /* Size Adjustment*/
-                        /* correct_region_boxes */
+                        /*get_yolo_box/get_region_box in paper implementation*/
+                        float center_x = (tx + float(x)) * stride;
+                        float center_y = (ty + float(y)) * stride;
+                        center_x = center_x / (float)YOLOXS_SP70_MODEL_IN_W;
+                        center_y = center_y / (float)YOLOXS_SP70_MODEL_IN_H;
+                        float box_w = exp(tw) * stride;
+                        float box_h = exp(th) * stride;
+                        box_w = box_w / (float)YOLOXS_SP70_MODEL_IN_W;
+                        box_h = box_h / (float)YOLOXS_SP70_MODEL_IN_H;
+
+                        /* Adjustment for size */
+                        /* correct_yolo/region_boxes */
                         center_x = (center_x - (YOLOXS_SP70_MODEL_IN_W - new_w) / 2. / YOLOXS_SP70_MODEL_IN_W) / ((float)new_w / YOLOXS_SP70_MODEL_IN_W);
                         center_y = (center_y - (YOLOXS_SP70_MODEL_IN_H - new_h) / 2. / YOLOXS_SP70_MODEL_IN_H) / ((float)new_h / YOLOXS_SP70_MODEL_IN_H);
                         box_w *= (float)(YOLOXS_SP70_MODEL_IN_W / new_w);
```

## メモリアドレスマップの読み込み方法の指定

`drp_ai_modules/translator/drp/drp_proc.cpp`の`DRPProc::read_addrmap_txt`で、DRP-AIオブジェクトファイルの`addr_map.txt`を10進数と16進数のどちらで読み込むのかを指定する。  
10進数で読み込む場合には`#if`ディレクティブの値を`1`を設定する。  
16進数で読み込む場合には`#if`ディレクティブの値を`0`を設定する。  
`YOLOX_S_sp70_640x640_RGB_10271351`は16進数で記述されているため、`#if`ディレクティブの値は以下のように`0`に設定する。

```cpp
#if 0
        l_addr = strtol(a.c_str(), NULL, 10);
        l_size = strtol(s.c_str(), NULL, 10);
#else
        l_addr = strtol(a.c_str(), NULL, 16);
        l_size = strtol(s.c_str(), NULL, 16);
#endif
```

## YoloDetector_drpの変更

### 使用するクラスの変更

まず、`drp_ai_modules/translator/YoloDetector_drp.h`で`include`するヘッダーを、使用したいModelクラスのヘッダーに変更する。

```diff
 #pragma once

 #include "recognize/recognize_base.h"
-#include "recognize/yolov2_sp90/yolov2_sp90_model.h"
+#include "recognize/yoloxs_sp70/yoloxs_sp70_model.h"
```

次に`drp_ai_modules/translator/YoloDetector_drp.cc`の`YoloDetector_drp::YoloDetector_drp`で指定するModelクラスを変更する。

```diff
     p_recog_base = std::shared_ptr<RecognizeBase>(new RecognizeBase(drp_max_freq, drpai_freq));

-    ret = p_recog_base->initialize(new YoloV2Sp90Model());
+    ret = p_recog_base->initialize(new YoloXSSp70Model());
     if (ret != 0) {
         fprintf(stderr, "Failed to RecognizeBase::initialize, Return code is %d\n", ret);
         exit(EXIT_FAILURE);
```

次に`drp_ai_modules/translator/YoloDetector_drp.cc`の`YoloDetector_drp::YoloObjectDetectFinish`で指定するModelクラスを変更する。

```diff
     MT_START(mt_drp_ai_yolo_get_object_detection);
-    auto model = std::static_pointer_cast<YoloV2Sp90Model>(p_recog_base->_model);
+    auto model = std::static_pointer_cast<YoloXSSp70Model>(p_recog_base->_model);
     result_object_detection = model->get_object_detection();
     MT_FINISH(mt_drp_ai_yolo_get_object_detection);
```

### 入力画像の前処理の変更

次に`YoloDetector_drp::YoloObjectDetectStart`の中のフラグを変更し、DRP-AIの入力画像のカラーフォーマットと下端のパディングの有無を指定する。  
入力画像のカラーフォーマットがYUYVの場合は`convert_to_yuyv`を`true`に設定する。  
入力画像のカラーフォーマットがRGBの場合は`convert_to_yuyv`を`false`に設定する。  
入力画像の下端のパディングを有効にする場合は`bottom_padding`を`true`に設定する。  
入力画像の下端のパディングを無効にする場合は`bottom_padding`を`false`に設定する。

```diff
 bool YoloDetector_drp::YoloObjectDetectStart() {
-    const bool convert_to_yuyv = true;
+    const bool convert_to_yuyv = false;
     const bool convert_to_rgb = !convert_to_yuyv;
-    const bool bottom_padding = false;
+    const bool bottom_padding = true;
```

## ビルド

[Yolo-Planar-SLAMビルドマニュアル](../yocto_dev/README_Build_YOLO-Planar-SLAM.md)に記載した手順でYolo-Planar-SLAMを再ビルドする。

## デプロイ

[SDカード作成マニュアル](../yocto_dev/README_SD_Image.md)に記載した手順でビルド生成物と必要なファイルをV2xボード用のmicroSDへ書き込む。  
なおDRP-AIオブジェクトファイルを書き込む手順で、使用したいDRP-AIオブジェクトファイルも書き込む必要がある。  
例えば、`YOLOX_S_sp70_640x640_RGB_10271351`の場合は`sync`よりも前に以下のコマンドを実行する必要がある。

```shell
sudo cp -r $HOME/YOLOX_S_sp70_640x640_RGB_10271351 \
  /media/sd/rootfs/home/root/yolo-planar-slam/
```

## 実行

[YOLO-Planar-SLAM動作マニュアル](../yocto_dev/README_YOLO-Planar-SLAM.md)に記載した手順でYolo-Planar-SLAMを実行する。
