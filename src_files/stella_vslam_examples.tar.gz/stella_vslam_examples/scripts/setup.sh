#!/bin/bash -u

cpu_num=`nproc --all`
if [ $cpu_num -le 2 ]; then
  export NUM_BUILD_THREADS=1
elif  [ $cpu_num -le 4 ]; then
  export NUM_BUILD_THREADS=2
else
  export NUM_BUILD_THREADS=$cpu_num
fi
echo NUM_BUILD_THREADS=$NUM_BUILD_THREADS

export STELLA_VSLAM_VERSION=2.12.0

echo STELLA_VSLAM_VERSION=$STELLA_VSLAM_VERSION
