#!/bin/bash

(
  set -ex

  export YOCTO_DIR=(/yocto_rzv2x_*_workdir)
  source ${YOCTO_DIR:?}/bsp_sdk/environment-setup-aarch64-poky-linux
  export CMAKE_INSTALL_PREFIX=${YOCTO_DIR:?}/local

  mkdir -p build
  cd build
  cmake -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX=${CMAKE_INSTALL_PREFIX:?} \
    -DENABLE_MEASURE_TIME=${MEASURE_TIME:-OFF} \
    -DENABLE_DUMP=${DUMP:-OFF} \
    -DENABLE_DEBUG_OUTPUT=${DEBUG_OUTPUT:-OFF} \
    -DENABLE_DRP_DRIVER_NATIVE=${DRP_DRIVER_NATIVE:-ON} \
    -DENABLE_DRP_AI_TVM=${DRP_AI_TVM:-ON} \
    -DDISABLE_YOCTO=${DISABLE_YOCTO:-OFF} \
    -DUSE_OPENMP=ON \
    -Dg2o_DIR=${CMAKE_INSTALL_PREFIX:?}/lib/cmake/g2o \
    -DOpenMP_C_FLAGS="-fopenmp" \
    -DOpenMP_CXX_FLAGS="-fopenmp" \
    -DOpenMP_C_LIB_NAMES="gomp;pthread" \
    -DOpenMP_CXX_LIB_NAMES="gomp;pthread" \
    -DOpenMP_gomp_LIBRARY=${SDKTARGETSYSROOT:?}/usr/lib64/libgomp.so \
    -DOpenMP_pthread_LIBRARY=${SDKTARGETSYSROOT:?}/usr/lib64/libpthread.so \
    -DSTELLA_VSLAM_VERSION=${STELLA_VSLAM_VERSION:?} \
    ..
  make -j${NUM_BUILD_THREADS:-}
)
