#pragma once

#include <mutex>

namespace drp_device_lock {

extern std::mutex mutex_drp_device;

}
