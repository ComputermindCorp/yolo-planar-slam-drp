#pragma once

#include <thread>
#include <mutex>

#include "stella_vslam/tracking_module.h"
#include "stella_vslam/camera/base.h"
#include "stella_vslam/config.h"
#include "stella_vslam/feature/orb_extractor.h"
#include "stella_vslam/marker_detector/base.h"

#include "stella_vslam/opencva/opencva.h"

#if defined(ENABLE_DRP_DRIVER_NATIVE)
#include "stella_vslam/drp/drp.h"
#endif

#if defined(ENABLE_DRP_AI_TVM)
#include "stella_vslam/yolo_detection_module.h"
#include "stella_vslam/drp_ai/yoloxs/yolo_detector.h"
#endif

#define MAX_DEVICE_PATH 128

namespace stella_vslam {

class image_processing_module {
public:
    image_processing_module(const std::shared_ptr<config>& cfg);
    ~image_processing_module();

    void run();

    void push_result();

    void set_tracking_module(tracking_module* tracker);
#if defined(ENABLE_DRP_AI_TVM)
    void set_yolo_detection_module(yolo_detection_module* yolo_detector);
#endif

    void set_mask(const cv::Mat& mask);

#if defined(ENABLE_DRP_DRIVER_NATIVE)
    bool drpfd_initialize();
    bool drpfd_finalize();
#endif

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.h#L74-L93
    //! Request to pause the image processing module
    std::shared_future<void> async_pause();

    //! Resume the image processing module
    void resume();

    //! Request to terminate the image processing module
    std::shared_future<void> async_terminate();

    //! Check if the image processing module is terminated or not
    bool is_terminated() const;

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.h#L239-L248
    // ORB extractors
    //! ORB extractor for left/monocular image
    feature::orb_extractor* extractor_left_ = nullptr;
    //! ORB extractor for right image
    feature::orb_extractor* extractor_right_ = nullptr;

    //! marker detector
    marker_detector::base* marker_detector_ = nullptr;

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.h#L277-L278
    //! Temporary variables for visualization
    std::vector<cv::KeyPoint> keypts_;

    std::unique_ptr<cv::Mat> input_image_ptr_;
    std::unique_ptr<cv::Mat> input_right_image_ptr_;
    std::unique_ptr<cv::Mat> input_depth_image_ptr_;
    double timestamp_;
    std::unique_ptr<data::frame> frame_ptr_;

    std::atomic<bool> wait_for_next_frame_;
    std::atomic<bool> finish_processing_;

private:
    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.h#L132-L145
    void create_monocular_frame();
    void create_stereo_frame();
    void create_RGBD_frame();

    tracking_module* tracker_ = nullptr;
#if defined(ENABLE_DRP_AI_TVM)
    yolo_detection_module* yolo_detector_ = nullptr;
#endif

    camera::base* camera_;

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.h#L211-L212
    //! parameters for orb feature extraction
    feature::orb_params* orb_params_ = nullptr;

    cv::Mat mask_;

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.h#L190-L191
    //! depthmap factor (pixel_value / depthmap_factor = true_depth)
    double depthmap_factor_ = 1.0;

    //! opencva flag
    std::shared_ptr<opencva::Options> opencva_options_ptr_;

#if defined(ENABLE_DRP_DRIVER_NATIVE)
    //! drp driver native flag
    std::shared_ptr<drp_driver_native::Options> drp_driver_native_options_ptr_;

    const uint8_t drp_dev_num_ = 1;
    int8_t drp_fd_;
#endif

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.h#L150-L188
    //! mutex for access to pause procedure
    mutable std::mutex mtx_pause_;

    //! promise for pause
    std::promise<void> promise_pause_;

    //! future for pause
    std::shared_future<void> future_pause_;

    //! flag which indicates termination is requested or not
    bool pause_is_requested_ = false;
    //! flag which indicates whether the main loop is paused or not
    bool is_paused_ = false;

    //! mutex for access to terminate procedure
    mutable std::mutex mtx_terminate_;

    //! promise for terminate
    std::promise<void> promise_terminate_;

    //! future for terminate
    std::shared_future<void> future_terminate_;

    //! Check if termination is requested or not
    bool terminate_is_requested() const;

    //! Raise the flag which indicates the main loop has been already terminated
    void terminate();

    //! flag which indicates termination is requested or not
    bool terminate_is_requested_ = false;
    //! flag which indicates whether the main loop is terminated or not
    bool is_terminated_ = true;
};

} // namespace stella_vslam
