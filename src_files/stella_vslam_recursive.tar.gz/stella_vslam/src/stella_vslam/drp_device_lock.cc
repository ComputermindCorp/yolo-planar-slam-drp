#include "drp_device_lock.h"

namespace drp_device_lock {

std::mutex mutex_drp_device;

}
