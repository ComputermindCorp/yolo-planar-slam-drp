#include "stella_vslam/image_processing_module.h"

#include "stella_vslam/util/image_converter.h"
#include "stella_vslam/util/yaml.h"
#include "stella_vslam/camera/camera_factory.h"
#include "stella_vslam/data/common.h"
#include "stella_vslam/match/stereo.h"
#include "stella_vslam/marker_detector/aruco.h"

#include "stella_vslam/image_position.h"

#include "stella_vslam/measure_time.h"

#include <spdlog/spdlog.h>

#include <cassert>

#if defined(NDEBUG)

#undef NDEBUG
#include <cassert>
#define NDEBUG

#endif

namespace stella_vslam {

image_processing_module::image_processing_module(const std::shared_ptr<config>& cfg)
    : tracker_(nullptr),
      camera_(camera::camera_factory::create(util::yaml_optional_ref(cfg->yaml_node_, "Camera"))),
      orb_params_(new feature::orb_params(util::yaml_optional_ref(cfg->yaml_node_, "Feature")))
#if defined(ENABLE_DRP_DRIVER_NATIVE)
      ,
      drp_fd_(drp_driver_native::FILE_DESCRIPTOR_CLOSE)
#endif
{
    spdlog::debug("CONSTRUCT: image_processing_module");

    // opencva
    const bool use_opencva_for_resize = util::yaml_optional_ref(cfg->yaml_node_, "OpenCVA")["resize"].as<bool>(false);
    const bool use_opencva_for_gaussian_blur = util::yaml_optional_ref(cfg->yaml_node_, "OpenCVA")["gaussian_blur"].as<bool>(false);
    const bool use_opencva_for_cvfast = util::yaml_optional_ref(cfg->yaml_node_, "OpenCVA")["cvfast"].as<bool>(false);

    opencva_options_ptr_.reset(new opencva::Options(use_opencva_for_resize,
                                                    use_opencva_for_gaussian_blur,
                                                    use_opencva_for_cvfast));

#if defined(ENABLE_DRP_DRIVER_NATIVE)
    const bool use_drp_driver_for_resize = util::yaml_optional_ref(cfg->yaml_node_, "DRP-Driver-Native")["resize"].as<bool>(false);
    const bool use_drp_driver_for_gaussian_blur = util::yaml_optional_ref(cfg->yaml_node_, "DRP-Driver-Native")["gaussian_blur"].as<bool>(false);
    const bool use_drp_driver_for_cvfast = util::yaml_optional_ref(cfg->yaml_node_, "DRP-Driver-Native")["cvfast"].as<bool>(false);
    const bool use_drp_driver_for_slamfast = util::yaml_optional_ref(cfg->yaml_node_, "DRP-Driver-Native")["slamfast"].as<bool>(false);
    const bool use_drp_driver_for_orb_descriptors = util::yaml_optional_ref(cfg->yaml_node_, "DRP-Driver-Native")["orb_descriptors"].as<bool>(false);

    drp_driver_native_options_ptr_.reset(new drp_driver_native::Options(use_drp_driver_for_resize,
                                                                        use_drp_driver_for_gaussian_blur,
                                                                        use_drp_driver_for_cvfast,
                                                                        use_drp_driver_for_slamfast,
                                                                        use_drp_driver_for_orb_descriptors));
#endif

#if !defined(DISABLE_YOCTO)
    if (opencva_options_ptr_->use_opencva()) {
        if (!opencva::initialize()) {
            spdlog::error("Failed to opencva::initialize.");
            exit(EXIT_FAILURE);
        }
    }
    else {
        if (!opencva::disable()) {
            spdlog::error("Failed to opencva::disable.");
            exit(EXIT_FAILURE);
        }
    }
#endif

#if defined(ENABLE_DRP_DRIVER_NATIVE)
    if (drp_driver_native_options_ptr_->use_drp_driver()) {
        if (!drpfd_initialize()) {
            spdlog::error("Failed to image_processing_module::drpfd_initialize.");
            exit(EXIT_FAILURE);
        }
        bool succeed_load = drp_driver_native::load_bin_configurations(drp_fd_, drp_driver_native_options_ptr_);
        if (!succeed_load) {
            spdlog::error("Failed to drp_driver_native::load_bin_configurations.");
            exit(EXIT_FAILURE);
        }
    }
#endif

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.cc#L70-L77
    // preprocessing modules
    const auto preprocessing_params = util::yaml_optional_ref(cfg->yaml_node_, "Preprocessing");
    if (camera_->setup_type_ == camera::setup_type_t::RGBD) {
        depthmap_factor_ = preprocessing_params["depthmap_factor"].as<double>(depthmap_factor_);
        if (depthmap_factor_ < 0.) {
            throw std::runtime_error("depthmap_factor must be greater than 0");
        }
    }

    const bool use_dump = util::yaml_optional_ref(cfg->yaml_node_, "Debug")["use_dump"].as<bool>(false);

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.cc#L78-L94
    auto mask_rectangles = util::get_rectangles(preprocessing_params["mask_rectangles"]);

    const auto min_size = preprocessing_params["min_size"].as<unsigned int>(800);
    extractor_left_ = new feature::orb_extractor(orb_params_, min_size, image_position_t::Left, mask_rectangles,
                                                 opencva_options_ptr_,

#if defined(ENABLE_DRP_DRIVER_NATIVE)
                                                 drp_fd_,
                                                 drp_driver_native_options_ptr_,
#endif
                                                 use_dump);

    if (camera_->setup_type_ == camera::setup_type_t::Stereo) {
        extractor_right_ = new feature::orb_extractor(orb_params_, min_size, image_position_t::Right, mask_rectangles,
                                                      opencva_options_ptr_,
#if defined(ENABLE_DRP_DRIVER_NATIVE)
                                                      drp_fd_,
                                                      drp_driver_native_options_ptr_,
#endif
                                                      use_dump);
    }

    if (cfg->marker_model_) {
        if (marker_detector::aruco::is_valid()) {
            spdlog::debug("marker detection: enabled");
            marker_detector_ = new marker_detector::aruco(camera_, cfg->marker_model_);
        }
        else {
            spdlog::warn("Valid marker_detector is not installed");
        }
    }

    wait_for_next_frame_.store(true);
    finish_processing_.store(false);
    spdlog::debug("change image_processing_module::wait_for_next_frame_ to true in image_processing_module.");
    spdlog::debug("change image_processing_module::finish_processing_ to false in image_processing_module.");
}

image_processing_module ::~image_processing_module() {
#if !defined(DISABLE_YOCTO)
    if (opencva_options_ptr_->use_opencva()) {
        if (!opencva::finalize()) {
            spdlog::error("Failed to opencva::finalize.");
            exit(EXIT_FAILURE);
        }
    }
#endif

#if defined(ENABLE_DRP_DRIVER_NATIVE)
    if (drp_driver_native_options_ptr_->use_drp_driver()) {
        if (!drpfd_finalize()) {
            spdlog::error("Failed to system::drpfd_finalize.");
            exit(EXIT_FAILURE);
        }
    }
#endif

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.cc#L126-L132
    delete extractor_left_;
    extractor_left_ = nullptr;
    delete extractor_right_;
    extractor_right_ = nullptr;

    delete marker_detector_;
    marker_detector_ = nullptr;

    spdlog::debug("DESTRUCT: image_processing_module");
}

// Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.cc#L62-L118
void image_processing_module::run() {
    spdlog::info("start image processing module");

    is_terminated_ = false;

    while (true) {
        std::this_thread::sleep_for(std::chrono::milliseconds(5));

        // check if termination is requested
        if (terminate_is_requested()) {
            // terminate and break
            terminate();
            break;
        }

        if (tracker_ && !wait_for_next_frame_.load() && !finish_processing_.load()) {
            MT_START(mt_image_processing);

            if (camera_->setup_type_ == camera::setup_type_t::Monocular) {
                create_monocular_frame();
            }
            else if (camera_->setup_type_ == camera::setup_type_t::Stereo) {
                create_stereo_frame();
            }
            else if (camera_->setup_type_ == camera::setup_type_t::RGBD) {
                create_RGBD_frame();
            }
            else {
                spdlog::critical("Unknown setup type detected in image_processing_module::run.");
                exit(EXIT_FAILURE);
            }

            finish_processing_.store(true);
            spdlog::debug("change image_processing_module::finish_processing_ to true in image_processing_module.");

            MT_FINISH(mt_image_processing);
        }

        if (tracker_
            && tracker_->wait_for_next_frame_.load()
            && finish_processing_.load()) {
            MT_START(mt_image_processing_push_result);

            push_result();

            MT_FINISH(mt_image_processing_push_result);
        }
    }

    spdlog::info("terminate image processing module");
}

// Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.cc#L281-L315
void image_processing_module::create_monocular_frame() {
    // color conversion
    if (!camera_->is_valid_shape(*input_image_ptr_)) {
        spdlog::warn("preprocess: Input image size is invalid");
    }

#if defined(ENABLE_DRP_AI_TVM)
    if (yolo_detector_) {
        while (yolo_detector_->loaded_images()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }

        yolo_detector_->set_input(input_image_ptr_);
    }
#endif

    MT_START(mt_convert_to_grayscale);
    util::convert_to_grayscale(*input_image_ptr_, camera_->color_order_);
    MT_FINISH(mt_convert_to_grayscale);

    data::frame_observation frm_obs;

    // Extract ORB feature
    keypts_.clear();

    MT_START(mt_extract);
    extractor_left_->extract(*input_image_ptr_, mask_, keypts_, frm_obs.descriptors_);
    MT_FINISH(mt_extract);

    frm_obs.num_keypts_ = keypts_.size();
    if (keypts_.empty()) {
        spdlog::warn("preprocess: cannot extract any keypoints");
    }

    // Undistort keypoints
    MT_START(mt_undistort_keypoints);
    camera_->undistort_keypoints(keypts_, frm_obs.undist_keypts_);
    MT_FINISH(mt_undistort_keypoints);

    // Convert to bearing vector
    MT_START(mt_convert_keypoints_to_bearings);
    camera_->convert_keypoints_to_bearings(frm_obs.undist_keypts_, frm_obs.bearings_);
    MT_FINISH(mt_convert_keypoints_to_bearings);

    // Assign all the keypoints into grid
    MT_START(mt_assign_keypoints_to_grid);
    data::assign_keypoints_to_grid(camera_, frm_obs.undist_keypts_, frm_obs.keypt_indices_in_cells_);
    MT_FINISH(mt_assign_keypoints_to_grid);

    // Detect marker
    std::unordered_map<unsigned int, data::marker2d> markers_2d;
    if (marker_detector_) {
        marker_detector_->detect(*input_image_ptr_, markers_2d);
    }

    frame_ptr_.reset(new data::frame(timestamp_, camera_, orb_params_, frm_obs, std::move(markers_2d)));
}

// Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.cc#L317-L374
void image_processing_module::create_stereo_frame() {
    // color conversion
    if (!camera_->is_valid_shape(*input_image_ptr_)) {
        spdlog::warn("preprocess: Input image size is invalid");
    }
    if (!camera_->is_valid_shape(*input_right_image_ptr_)) {
        spdlog::warn("preprocess: Input image size is invalid");
    }

#if defined(ENABLE_DRP_AI_TVM)
    if (yolo_detector_) {
        while (yolo_detector_->loaded_images()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }

        yolo_detector_->set_input(input_image_ptr_, input_right_image_ptr_);
    }
#endif

    MT_START(mt_convert_to_grayscale);
    util::convert_to_grayscale(*input_image_ptr_, camera_->color_order_);
    util::convert_to_grayscale(*input_right_image_ptr_, camera_->color_order_);
    MT_FINISH(mt_convert_to_grayscale);

    data::frame_observation frm_obs;
    //! keypoints of stereo right image
    std::vector<cv::KeyPoint> keypts_right;
    //! ORB descriptors of stereo right image
    cv::Mat descriptors_right;

    // Extract ORB feature
    keypts_.clear();

    MT_START(mt_extract);

    std::thread thread_left([this, &frm_obs]() {
        extractor_left_->extract(*input_image_ptr_, mask_, keypts_, frm_obs.descriptors_);
    });
    thread_left.join();

    std::thread thread_right([this, &frm_obs, &keypts_right, &descriptors_right]() {
        extractor_right_->extract(*input_right_image_ptr_, mask_, keypts_right, descriptors_right);
    });
    thread_right.join();

    MT_FINISH(mt_extract);

    frm_obs.num_keypts_ = keypts_.size();
    if (keypts_.empty()) {
        spdlog::warn("preprocess: cannot extract any keypoints");
    }

    // Undistort keypoints
    MT_START(mt_undistort_keypoints);
    camera_->undistort_keypoints(keypts_, frm_obs.undist_keypts_);
    MT_FINISH(mt_undistort_keypoints);

    // Estimate depth with stereo match
    match::stereo stereo_matcher(extractor_left_->image_pyramid_, extractor_right_->image_pyramid_,
                                 keypts_, keypts_right, frm_obs.descriptors_, descriptors_right,
                                 orb_params_->scale_factors_, orb_params_->inv_scale_factors_,
                                 camera_->focal_x_baseline_, camera_->true_baseline_);

    MT_START(mt_match_stereo_compute);
    stereo_matcher.compute(frm_obs.stereo_x_right_, frm_obs.depths_);
    MT_FINISH(mt_match_stereo_compute);

    // Convert to bearing vector
    MT_START(mt_convert_keypoints_to_bearings);
    camera_->convert_keypoints_to_bearings(frm_obs.undist_keypts_, frm_obs.bearings_);
    MT_FINISH(mt_convert_keypoints_to_bearings);

    // Assign all the keypoints into grid
    MT_START(mt_assign_keypoints_to_grid);
    data::assign_keypoints_to_grid(camera_, frm_obs.undist_keypts_, frm_obs.keypt_indices_in_cells_);
    MT_FINISH(mt_assign_keypoints_to_grid);

    // Detect marker
    std::unordered_map<unsigned int, data::marker2d> markers_2d;
    if (marker_detector_) {
        marker_detector_->detect(*input_image_ptr_, markers_2d);
    }

    frame_ptr_.reset(new data::frame(timestamp_, camera_, orb_params_, frm_obs, std::move(markers_2d)));
}

// Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/system.cc#L376-L437
void image_processing_module::create_RGBD_frame() {
    // color conversion
    if (!camera_->is_valid_shape(*input_image_ptr_)) {
        spdlog::warn("preprocess: Input image size is invalid");
    }
    if (!camera_->is_valid_shape(*input_depth_image_ptr_)) {
        spdlog::warn("preprocess: Input image size is invalid");
    }

#if defined(ENABLE_DRP_AI_TVM)
    if (yolo_detector_) {
        while (yolo_detector_->loaded_images()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }

        yolo_detector_->set_input(input_image_ptr_);
    }
#endif

    MT_START(mt_convert_to_grayscale);
    util::convert_to_grayscale(*input_image_ptr_, camera_->color_order_);
    MT_FINISH(mt_convert_to_grayscale);

    MT_START(mt_convert_to_true_depth);
    util::convert_to_true_depth(*input_depth_image_ptr_, depthmap_factor_);
    MT_FINISH(mt_convert_to_true_depth);

    data::frame_observation frm_obs;

    // Extract ORB feature
    keypts_.clear();

    MT_START(mt_extract);
    extractor_left_->extract(*input_image_ptr_, mask_, keypts_, frm_obs.descriptors_);
    MT_FINISH(mt_extract);

    frm_obs.num_keypts_ = keypts_.size();
    if (keypts_.empty()) {
        spdlog::warn("preprocess: cannot extract any keypoints");
    }

    // Undistort keypoints
    MT_START(mt_undistort_keypoints);
    camera_->undistort_keypoints(keypts_, frm_obs.undist_keypts_);
    MT_FINISH(mt_undistort_keypoints);

    // Calculate disparity from depth
    // Initialize with invalid value
    frm_obs.stereo_x_right_ = std::vector<float>(frm_obs.num_keypts_, -1);
    frm_obs.depths_ = std::vector<float>(frm_obs.num_keypts_, -1);

    for (unsigned int idx = 0; idx < frm_obs.num_keypts_; idx++) {
        const auto& keypt = keypts_.at(idx);
        const auto& undist_keypt = frm_obs.undist_keypts_.at(idx);

        const float x = keypt.pt.x;
        const float y = keypt.pt.y;

        const float depth = input_depth_image_ptr_->at<float>(y, x);

        if (depth <= 0) {
            continue;
        }

        frm_obs.depths_.at(idx) = depth;
        frm_obs.stereo_x_right_.at(idx) = undist_keypt.pt.x - camera_->focal_x_baseline_ / depth;
    }

    // Convert to bearing vector
    MT_START(mt_convert_keypoints_to_bearings);
    camera_->convert_keypoints_to_bearings(frm_obs.undist_keypts_, frm_obs.bearings_);
    MT_FINISH(mt_convert_keypoints_to_bearings);

    // Assign all the keypoints into grid
    MT_START(mt_assign_keypoints_to_grid);
    data::assign_keypoints_to_grid(camera_, frm_obs.undist_keypts_, frm_obs.keypt_indices_in_cells_);
    MT_FINISH(mt_assign_keypoints_to_grid);

    // Detect marker
    std::unordered_map<unsigned int, data::marker2d> markers_2d;
    if (marker_detector_) {
        marker_detector_->detect(*input_image_ptr_, markers_2d);
    }

    frame_ptr_.reset(new data::frame(timestamp_, camera_, orb_params_, frm_obs, std::move(markers_2d)));
}

void image_processing_module::push_result() {
    tracker_->curr_frm_ptr_ = std::move(frame_ptr_);
    tracker_->input_image_ptr_ = std::move(input_image_ptr_);
    tracker_->keypts_ = keypts_;
#if defined(ENABLE_DRP_AI_TVM)
    if (yolo_detector_) {
        while (!yolo_detector_->finish_detections()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }

        tracker_->bounding_box_list_ = yolo_detector_->get_output(image_position_t::Left);
    }
#endif

    wait_for_next_frame_.store(true);
    finish_processing_.store(false);
    tracker_->wait_for_next_frame_.store(false);
    spdlog::debug("change image_processing_module::wait_for_next_frame_ to true in image_processing_module.");
    spdlog::debug("change image_processing_module::finish_processing_ to false in image_processing_module.");
    spdlog::debug("change tracking_module::wait_for_next_frame_ to false in image_processing_module.");
}

void image_processing_module::set_tracking_module(tracking_module* tracker) {
    tracker_ = tracker;
}

#if defined(ENABLE_DRP_AI_TVM)
void image_processing_module::set_yolo_detection_module(yolo_detection_module* yolo_detector) {
    yolo_detector_ = yolo_detector;
}
#endif

void image_processing_module::set_mask(const cv::Mat& mask) {
    mask_ = mask.clone();
}

#if defined(ENABLE_DRP_DRIVER_NATIVE)

bool image_processing_module::drpfd_initialize() {
    assert(drp_dev_num_ == 1 && "drp_dev_num_ must be 1.");

    char device_path[MAX_DEVICE_PATH];
    sprintf(device_path, "/dev/drp%u", drp_dev_num_);

    if (drp_fd_ != drp_driver_native::FILE_DESCRIPTOR_CLOSE) {
        spdlog::warn("{} is already open.", device_path);
        return true;
    }

    errno = 0;
    drp_fd_ = open(device_path, O_RDWR);
    bool open_succeed = (0 < drp_fd_);
    if (!open_succeed) {
        spdlog::error("Failed to open({}). Return code is {}, errno is {}", device_path, drp_fd_, errno);
        return false;
    }

    return true;
}

bool image_processing_module::drpfd_finalize() {
    assert(drp_dev_num_ == 1 && "drp_dev_num_ must be 1.");

    char device_path[MAX_DEVICE_PATH];
    sprintf(device_path, "/dev/drp%u", drp_dev_num_);

    if (drp_fd_ == drp_driver_native::FILE_DESCRIPTOR_CLOSE) {
        spdlog::warn("{} is already closed.", device_path);
        return true;
    }

    errno = 0;
    int drpai_ret = close(drp_fd_);
    bool close_succeed = (drpai_ret == 0);

    if (!close_succeed) {
        spdlog::error("Failed to close({}). Return code is {}, errno is {}", device_path, drpai_ret, errno);
        return false;
    }

    drp_fd_ = drp_driver_native::FILE_DESCRIPTOR_CLOSE;

    drp_driver_native::memory_free();
  
    return true;
}

#endif

// Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.cc#L559-L649

std::shared_future<void> image_processing_module::async_pause() {
    std::lock_guard<std::mutex> lock1(mtx_pause_);
    pause_is_requested_ = true;
    if (!future_pause_.valid()) {
        future_pause_ = promise_pause_.get_future().share();
    }
    return future_pause_;
}

void image_processing_module::resume() {
    std::lock_guard<std::mutex> lock1(mtx_pause_);
    std::lock_guard<std::mutex> lock2(mtx_terminate_);

    // if it has been already terminated, cannot resume
    if (is_terminated_) {
        return;
    }

    is_paused_ = false;
    pause_is_requested_ = false;

    spdlog::info("resume image processing module");
}

std::shared_future<void> image_processing_module::async_terminate() {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    terminate_is_requested_ = true;
    if (!future_terminate_.valid()) {
        future_terminate_ = promise_terminate_.get_future().share();
    }
    return future_terminate_;
}

bool image_processing_module::is_terminated() const {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    return is_terminated_;
}

bool image_processing_module::terminate_is_requested() const {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    return terminate_is_requested_;
}

void image_processing_module::terminate() {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    is_terminated_ = true;
    promise_terminate_.set_value();
    promise_terminate_ = std::promise<void>();
    future_terminate_ = std::shared_future<void>();
}

} // namespace stella_vslam
