#ifndef STELLA_VSLAM_SYSTEM_H
#define STELLA_VSLAM_SYSTEM_H

#include "stella_vslam/type.h"
#include "stella_vslam/data/bow_vocabulary_fwd.h"

#include "stella_vslam/image_loading_module.h"
#include "stella_vslam/image_processing_module.h"

#if defined(ENABLE_DRP_DRIVER_NATIVE)
#include "stella_vslam/drp/drp.h"
#endif

#if defined(ENABLE_DRP_AI_TVM)
#include "stella_vslam/yolo_detection_module.h"
#include "stella_vslam/drp_ai/yoloxs/yolo_detector.h"
#endif

#include <string>
#include <thread>
#include <memory>
#include <mutex>
#include <atomic>
#include <memory>

#include <opencv2/core/mat.hpp>

#define MAX_DEVICE_PATH 128

namespace stella_vslam {

class config;
class tracking_module;
class mapping_module;
class global_optimization_module;

namespace camera {
class base;
} // namespace camera

namespace data {
class frame;
class camera_database;
class orb_params_database;
class map_database;
class bow_database;
} // namespace data

namespace feature {
class orb_extractor;
struct orb_params;
} // namespace feature

namespace marker_detector {
class base;
} // namespace marker_detector

namespace publish {
class map_publisher;
class frame_publisher;
} // namespace publish

namespace io {
class map_database_io_base;
}

class system {
public:
    //! Constructor
    system(const std::shared_ptr<config>& cfg,
           const std::string& vocab_file_path,
           const image_loading_option image_loading_option,
           const std::vector<stella_vslam::sequence::frame>& frames);

    system(const std::shared_ptr<config>& cfg,
           const std::string& vocab_file_path,
           const image_loading_option image_loading_option);

    //! Destructor
    ~system();

    //-----------------------------------------
    // system startup and shutdown

    //! Print system information
    void print_info();

    //! Startup the SLAM system
    void startup(const bool need_initialize = true);

    //! Shutdown the SLAM system
    void shutdown();

    //-----------------------------------------
    // data I/O

    //! Save the frame trajectory in the specified format
    void save_frame_trajectory(const std::string& path, const std::string& format) const;

    //! Save the keyframe trajectory in the specified format
    void save_keyframe_trajectory(const std::string& path, const std::string& format) const;

    //! Load the map database from file
    bool load_map_database(const std::string& path) const;

    //! Save the map database to file
    bool save_map_database(const std::string& path) const;

    //! Get the map publisher
    const std::shared_ptr<publish::map_publisher> get_map_publisher() const;

    //! Get the frame publisher
    const std::shared_ptr<publish::frame_publisher> get_frame_publisher() const;

    //-----------------------------------------
    // module management

    //! Enable the mapping module
    void enable_mapping_module();

    //! Disable the mapping module
    void disable_mapping_module();

    //! The mapping module is enabled or not
    bool mapping_module_is_enabled() const;

    //! Enable the loop detector
    void enable_loop_detector();

    //! Disable the loop detector
    void disable_loop_detector();

    //! The loop detector is enabled or not
    bool loop_detector_is_enabled() const;

    //! Request loop closure
    bool request_loop_closure(int keyfrm1_id, int keyfrm2_id);

    //! Loop BA is running or not
    bool loop_BA_is_running() const;

    //! Abort the loop BA externally
    void abort_loop_BA();

    //! Enable temporal mapping
    void enable_temporal_mapping();

    //-----------------------------------------
    // data feeding methods

    std::shared_ptr<Mat44_t> feed_frame();

    //! Feed a monocular frame to SLAM system
    //! (NOTE: distorted images are acceptable if calibrated)
    std::shared_ptr<Mat44_t> feed_monocular_frame();

    //! Feed a stereo frame to SLAM system
    //! (Note: Left and Right images must be stereo-rectified)
    std::shared_ptr<Mat44_t> feed_stereo_frame();

    //! Feed an RGBD frame to SLAM system
    //! (Note: RGB and Depth images must be aligned)
    std::shared_ptr<Mat44_t> feed_RGBD_frame();

    //-----------------------------------------
    // pose initializing/updating

    //! Request to update the pose to a given one.
    //! Return failure in case if previous request was not finished.
    bool relocalize_by_pose(const Mat44_t& cam_pose_wc);
    bool relocalize_by_pose_2d(const Mat44_t& cam_pose_wc, const Vec3_t& normal_vector);

    //-----------------------------------------
    // management for pause

    //! Pause the tracking module
    void pause_tracker();

    //! The tracking module is paused or not
    bool tracker_is_paused() const;

    //! Resume the tracking module
    void resume_tracker();

    //-----------------------------------------
    // management for reset

    //! Request to reset the system
    void request_reset();

    //! Reset of the system is requested or not
    bool reset_is_requested() const;

    //-----------------------------------------
    // management for terminate

    //! Request to terminate the system
    void request_terminate();

    //!! Termination of the system is requested or not
    bool terminate_is_requested() const;

    //-----------------------------------------
    // config

    camera::base* get_camera() const;

    void set_mask(const cv::Mat& mask);

    //! depthmap factor (pixel_value / depthmap_factor = true_depth)
    double depthmap_factor_ = 1.0;

private:
    //! Check reset request of the system
    void check_reset_request();

    //! Pause the mapping module and the global optimization module
    void pause_other_threads() const;

    //! Resume the mapping module and the global optimization module
    void resume_other_threads() const;

    void print_version() const;
    void print_build_switch() const;

    //! config
    const std::shared_ptr<config> cfg_;
    //! camera model
    camera::base* camera_ = nullptr;

    //! camera database
    data::camera_database* cam_db_ = nullptr;

    //! parameters for orb feature extraction
    feature::orb_params* orb_params_ = nullptr;

    //! orb_params database
    data::orb_params_database* orb_params_db_ = nullptr;

    //! map database
    data::map_database* map_db_ = nullptr;

    //! BoW vocabulary
    data::bow_vocabulary* bow_vocab_ = nullptr;

    //! BoW database
    data::bow_database* bow_db_ = nullptr;

    //! image loader
    image_loading_module* image_loader_ = nullptr;
    //! image loading thread
    std::unique_ptr<std::thread> image_loading_thread_ = nullptr;

    //! image processor
    image_processing_module* image_processor_ = nullptr;
    //! image processing thread
    std::unique_ptr<std::thread> image_processing_thread_ = nullptr;

#if defined(ENABLE_DRP_AI_TVM)
    //! yolo detection
    yolo_detection_module* yolo_detector_ = nullptr;
    //! yolo detection thread
    std::unique_ptr<std::thread> yolo_detection_thread_ = nullptr;
#endif

    const bool use_yolo_ = false;

    //! tracker
    tracking_module* tracker_ = nullptr;

    //! mapping module
    mapping_module* mapper_ = nullptr;
    //! mapping thread
    std::unique_ptr<std::thread> mapping_thread_ = nullptr;

    //! global optimization module
    global_optimization_module* global_optimizer_ = nullptr;
    //! global optimization thread
    std::unique_ptr<std::thread> global_optimization_thread_ = nullptr;

    //! frame publisher
    std::shared_ptr<publish::frame_publisher> frame_publisher_ = nullptr;
    //! map publisher
    std::shared_ptr<publish::map_publisher> map_publisher_ = nullptr;

    //! map I/O
    std::shared_ptr<io::map_database_io_base> map_database_io_ = nullptr;

    //! system running status flag
    std::atomic<bool> system_is_running_{false};

    //! mutex for reset flag
    mutable std::mutex mtx_reset_;
    //! reset flag
    bool reset_is_requested_ = false;

    //! mutex for terminate flag
    mutable std::mutex mtx_terminate_;
    //! terminate flag
    bool terminate_is_requested_ = false;

    //! mutex for flags of enable/disable mapping module
    mutable std::mutex mtx_mapping_;

    //! mutex for flags of enable/disable loop detector
    mutable std::mutex mtx_loop_detector_;
};

} // namespace stella_vslam

#endif // STELLA_VSLAM_SYSTEM_H
