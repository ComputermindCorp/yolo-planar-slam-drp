#include "stella_vslam/image_loading_module.h"

#include "stella_vslam/image_load/dataset_image_loading.h"
#include "stella_vslam/image_load/monocular_camera_image_loading.h"
#include "stella_vslam/image_load/monocular_video_loading.h"
#include "stella_vslam/util/yaml.h"

#include "stella_vslam/measure_time.h"

#include <spdlog/spdlog.h>

#include <cassert>

#if defined(NDEBUG)

#undef NDEBUG
#include <cassert>
#define NDEBUG

#endif

namespace stella_vslam {

image_loading_module::image_loading_module(const std::shared_ptr<config>& cfg,
                                           const image_loading_option option,
                                           const std::vector<sequence::frame>& frames)
    : image_processor_(nullptr),
      sensor_(option.sensor_type_) {
    spdlog::debug("CONSTRUCT: image_loading_module");

    if (option.input_type_ == input_type_t::DATASET) {
        image_loading_ptr_ = new dataset_image_loading(cfg, option, frames);
    }
    else if (option.input_type_ == input_type_t::MONO_CAMERA) {
        image_loading_ptr_ = new monocular_camera_image_loading(cfg, option);
    }
    else if (option.input_type_ == input_type_t::VIDEO) {
        image_loading_ptr_ = new monocular_video_loading(cfg, option);
    }
    else {
        spdlog::critical("Invalid option.input_type_ : {} in image_loading_module::image_loading_module", (int)option.input_type_);
        exit(EXIT_FAILURE);
    }
}

image_loading_module ::~image_loading_module() {
    delete image_loading_ptr_;
    image_loading_ptr_ = nullptr;

    spdlog::debug("DESTRUCT: image_loading_module");
}

// Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.cc#L62-L118
void image_loading_module::run() {
    spdlog::info("start image loading module");

    is_terminated_ = false;

    while (true) {
        std::this_thread::sleep_for(std::chrono::milliseconds(5));

        // check if termination is requested
        if (terminate_is_requested()) {
            // terminate and break
            terminate();
            break;
        }

        // check if frame remains
        if (image_loading_ptr_ && !image_loading_ptr_->remain_read_next_frame()) {
            // terminate and break
            terminate();
            break;
        }

        if (image_loading_ptr_ && image_loading_ptr_->need_skip_frame()) {
            image_loading_ptr_->frame_id_++;
            continue;
        }

        if (image_loading_ptr_ && image_loading_ptr_->can_read_next_frame()) {
            MT_START(mt_image_loading);

            bool read_succeed = false;
            if (sensor_ == camera::setup_type_t::Monocular) {
                read_succeed = image_loading_ptr_->read_monocular_frame();
            }
            else if (sensor_ == camera::setup_type_t::Stereo) {
                read_succeed = image_loading_ptr_->read_stereo_frame();
            }
            else if (sensor_ == camera::setup_type_t::RGBD) {
                read_succeed = image_loading_ptr_->read_RGBD_frame();
            }
            else {
                spdlog::critical("Unknown mode detected in image_loading_module::run.");
                exit(EXIT_FAILURE);
            }

            MT_FINISH(mt_image_loading);

            if (!read_succeed) {
                spdlog::error("Failed to read input image in image_loading.");
                spdlog::error("Skip images(frame_id == {}).", image_loading_ptr_->frame_id_);

                image_loading_ptr_->frame_id_++;
            }
        }

        if (image_loading_ptr_ && image_processor_->wait_for_next_frame_.load() && loaded_images()) {
            MT_START(mt_image_loading_push_result);
            push_result();
            MT_FINISH(mt_image_loading_push_result);
        }
    }

    spdlog::info("terminate image loading module");
}

bool image_loading_module::loaded_images() {
    return image_loading_ptr_->loaded_images_.load();
}

bool image_loading_module::missing_image() {
    return image_loading_ptr_->missing_image_.load();
}

void image_loading_module::push_result() {
    if (sensor_ == camera::setup_type_t::Monocular) {
        push_monocular_frame(image_processor_->input_image_ptr_,
                             image_processor_->timestamp_);
    }
    else if (sensor_ == camera::setup_type_t::Stereo) {
        push_stereo_frame(image_processor_->input_image_ptr_,
                          image_processor_->input_right_image_ptr_,
                          image_processor_->timestamp_);
    }
    else if (sensor_ == camera::setup_type_t::RGBD) {
        push_RGBD_frame(image_processor_->input_image_ptr_,
                        image_processor_->input_depth_image_ptr_,
                        image_processor_->timestamp_);
    }
    else {
        spdlog::critical("Unknown mode detected in image_loading_module::push_result.");
        exit(EXIT_FAILURE);
    }

    image_loading_ptr_->loaded_images_.store(false);
    image_processor_->wait_for_next_frame_.store(false);
    spdlog::debug("change image_loading_module::loaded_images_ to false in image_loading_module.");
    spdlog::debug("change image_processing_module::wait_for_next_frame_ to false in image_loading_module.");
}

void image_loading_module::set_image_processing_module(image_processing_module* image_processor) {
    image_processor_ = image_processor;
}

void image_loading_module::push_monocular_frame(std::unique_ptr<cv::Mat>& img_ptr,
                                                double& timestamp) {
    std::unique_lock<std::mutex> lock(image_loading_ptr_->mutex_frame_);

    img_ptr = std::move(image_loading_ptr_->img_ptr_);
    timestamp = image_loading_ptr_->timestamp_;

    image_loading_ptr_->frame_id_++;
}

void image_loading_module::push_stereo_frame(std::unique_ptr<cv::Mat>& img_ptr,
                                             std::unique_ptr<cv::Mat>& right_img_ptr,
                                             double& timestamp) {
    std::unique_lock<std::mutex> lock(image_loading_ptr_->mutex_frame_);

    img_ptr = std::move(image_loading_ptr_->img_ptr_);
    right_img_ptr = std::move(image_loading_ptr_->right_img_ptr_);
    timestamp = image_loading_ptr_->timestamp_;

    image_loading_ptr_->frame_id_++;
}

void image_loading_module::push_RGBD_frame(std::unique_ptr<cv::Mat>& img_ptr,
                                           std::unique_ptr<cv::Mat>& depth_img_ptr,
                                           double& timestamp) {
    std::unique_lock<std::mutex> lock(image_loading_ptr_->mutex_frame_);

    img_ptr = std::move(image_loading_ptr_->img_ptr_);
    depth_img_ptr = std::move(image_loading_ptr_->depth_img_ptr_);
    timestamp = image_loading_ptr_->timestamp_;

    image_loading_ptr_->frame_id_++;
}

// Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.cc#L559-L649

std::shared_future<void> image_loading_module::async_pause() {
    std::lock_guard<std::mutex> lock1(mtx_pause_);
    pause_is_requested_ = true;
    if (!future_pause_.valid()) {
        future_pause_ = promise_pause_.get_future().share();
    }
    return future_pause_;
}

void image_loading_module::resume() {
    std::lock_guard<std::mutex> lock1(mtx_pause_);
    std::lock_guard<std::mutex> lock2(mtx_terminate_);

    // if it has been already terminated, cannot resume
    if (is_terminated_) {
        return;
    }

    is_paused_ = false;
    pause_is_requested_ = false;

    spdlog::info("resume image loading module");
}

std::shared_future<void> image_loading_module::async_terminate() {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    terminate_is_requested_ = true;
    if (!future_terminate_.valid()) {
        future_terminate_ = promise_terminate_.get_future().share();
    }
    return future_terminate_;
}

bool image_loading_module::is_terminated() const {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    return is_terminated_;
}

bool image_loading_module::terminate_is_requested() const {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    return terminate_is_requested_;
}

void image_loading_module::terminate() {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    is_terminated_ = true;
    promise_terminate_.set_value();
    promise_terminate_ = std::promise<void>();
    future_terminate_ = std::shared_future<void>();
}

} // namespace stella_vslam
