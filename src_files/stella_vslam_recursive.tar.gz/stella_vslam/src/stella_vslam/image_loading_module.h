#pragma once

#include <thread>
#include <mutex>

#include "stella_vslam/tracking_module.h"
#include "stella_vslam/camera/base.h"
#include "stella_vslam/config.h"
#include "stella_vslam/image_load/image_loading.h"
#include "stella_vslam/image_load/image_loading_option.h"
#include "stella_vslam/image_processing_module.h"
#include "stella_vslam/image_load/input_type.h"
#include "stella_vslam/image_load/frame.h"

namespace stella_vslam {

class image_loading_module {
public:
    image_loading_module(const std::shared_ptr<config>& cfg,
                         const image_loading_option option,
                         const std::vector<stella_vslam::sequence::frame>& frames);
    ~image_loading_module();

    void run();

    bool loaded_images();
    bool missing_image();

    void push_result();

    void set_image_processing_module(image_processing_module* image_processor);

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.h#L74-L93
    //! Request to pause the image loading module
    std::shared_future<void> async_pause();

    //! Resume the image loading module
    void resume();

    //! Request to terminate the image loading module
    std::shared_future<void> async_terminate();

    //! Check if the image loading module is terminated or not
    bool is_terminated() const;

private:
    void push_monocular_frame(std::unique_ptr<cv::Mat>& img_ptr,
                              double& timestamp);
    void push_stereo_frame(std::unique_ptr<cv::Mat>& img_ptr,
                           std::unique_ptr<cv::Mat>& right_img_ptr,
                           double& timestamp);
    void push_RGBD_frame(std::unique_ptr<cv::Mat>& img_ptr,
                         std::unique_ptr<cv::Mat>& depth_img_ptr,
                         double& timestamp);

    image_processing_module* image_processor_ = nullptr;
    image_loading* image_loading_ptr_ = nullptr;

    camera::setup_type_t sensor_;

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.h#L150-L188
    //! mutex for access to pause procedure
    mutable std::mutex mtx_pause_;

    //! promise for pause
    std::promise<void> promise_pause_;

    //! future for pause
    std::shared_future<void> future_pause_;

    //! flag which indicates termination is requested or not
    bool pause_is_requested_ = false;
    //! flag which indicates whether the main loop is paused or not
    bool is_paused_ = false;

    //! mutex for access to terminate procedure
    mutable std::mutex mtx_terminate_;

    //! promise for terminate
    std::promise<void> promise_terminate_;

    //! future for terminate
    std::shared_future<void> future_terminate_;

    //! Check if termination is requested or not
    bool terminate_is_requested() const;

    //! Raise the flag which indicates the main loop has been already terminated
    void terminate();

    //! flag which indicates termination is requested or not
    bool terminate_is_requested_ = false;
    //! flag which indicates whether the main loop is terminated or not
    bool is_terminated_ = true;
};

} // namespace stella_vslam
