#pragma once

#include <future>
#include <thread>
#include <mutex>

#include "stella_vslam/camera/base.h"
#include "stella_vslam/config.h"
#include "stella_vslam/image_position.h"
#include "stella_vslam/drp_ai/yoloxs/yolo_detector.h"

namespace stella_vslam {

class yolo_detection_module {
public:
    yolo_detection_module(const std::shared_ptr<config>& cfg);
    ~yolo_detection_module();

    void run();

    bool loaded_images() const;
    bool finish_detections() const;

    void set_input(const std::unique_ptr<cv::Mat>& input_image_ptr);
    void set_input(const std::unique_ptr<cv::Mat>& input_image_ptr,
                   const std::unique_ptr<cv::Mat>& input_right_image_ptr);
    std::vector<drp_ai::bounding_box> get_output(const image_position_t image_position);

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.h#L74-L93
    //! Request to pause the image loading module
    std::shared_future<void> async_pause();

    //! Resume the image loading module
    void resume();

    //! Request to terminate the image loading module
    std::shared_future<void> async_terminate();

    //! Check if the image loading module is terminated or not
    bool is_terminated() const;

private:
    void detect(const image_position_t image_position) const;

    void dump_yolo_input(const image_position_t image_position) const;
    void dump_yolo_output(const image_position_t image_position) const;

    camera::base* camera_;

    bool use_dump_;

    //! YOLO detector for left/monocular image
    drp_ai::yolo_detector* yolo_detector_left_ = nullptr;
    //! YOLO detector for right image
    drp_ai::yolo_detector* yolo_detector_right_ = nullptr;

    cv::Mat input_image_ = cv::Mat();
    cv::Mat input_right_image_ = cv::Mat();

    std::atomic<bool> loaded_image_[2];
    std::atomic<bool> finish_detection_[2];

    constexpr static uint16_t LEFT = (uint16_t)image_position_t::Left;
    constexpr static uint16_t RIGHT = (uint16_t)image_position_t::Right;

    //! frame number
    uint32_t frame_idx_ = 0;

    // Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.h#L150-L188
    //! mutex for access to pause procedure
    mutable std::mutex mtx_pause_;

    //! promise for pause
    std::promise<void> promise_pause_;

    //! future for pause
    std::shared_future<void> future_pause_;

    //! flag which indicates termination is requested or not
    bool pause_is_requested_ = false;
    //! flag which indicates whether the main loop is paused or not
    bool is_paused_ = false;

    //! mutex for access to terminate procedure
    mutable std::mutex mtx_terminate_;

    //! promise for terminate
    std::promise<void> promise_terminate_;

    //! future for terminate
    std::shared_future<void> future_terminate_;

    //! Check if termination is requested or not
    bool terminate_is_requested() const;

    //! Raise the flag which indicates the main loop has been already terminated
    void terminate();

    //! flag which indicates termination is requested or not
    bool terminate_is_requested_ = false;
    //! flag which indicates whether the main loop is terminated or not
    bool is_terminated_ = true;
};

} // namespace stella_vslam
