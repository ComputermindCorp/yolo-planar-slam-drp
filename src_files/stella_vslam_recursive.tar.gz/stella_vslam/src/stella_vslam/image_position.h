#pragma once

// image position
enum class image_position_t {
    Left,
    Right
};
