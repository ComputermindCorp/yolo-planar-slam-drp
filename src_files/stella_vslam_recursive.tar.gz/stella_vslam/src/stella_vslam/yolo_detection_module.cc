#include "stella_vslam/yolo_detection_module.h"

#include <opencv2/imgcodecs.hpp>

#include "stella_vslam/camera/camera_factory.h"
#include "stella_vslam/util/yaml.h"

#include "stella_vslam/measure_time.h"

#include <spdlog/spdlog.h>

#include <cassert>

#if defined(NDEBUG)

#undef NDEBUG
#include <cassert>
#define NDEBUG

#endif

namespace stella_vslam {

yolo_detection_module::yolo_detection_module(const std::shared_ptr<config>& cfg)
    : camera_(camera::camera_factory::create(util::yaml_optional_ref(cfg->yaml_node_, "Camera"))),
      use_dump_(util::yaml_optional_ref(cfg->yaml_node_, "Debug")["use_dump"].as<bool>(false)),
      frame_idx_(0) {
    spdlog::debug("CONSTRUCT: yolo_detection_module");

    // yolo module
    const bool use_yolo = util::yaml_optional_ref(cfg->yaml_node_, "DRP-AI")["use_yolo"].as<bool>(false);
    if (use_yolo) {
        yolo_detector_left_ = new drp_ai::yolo_detector(image_position_t::Left);
        if (camera_->setup_type_ == camera::setup_type_t::Stereo) {
            yolo_detector_right_ = new drp_ai::yolo_detector(image_position_t::Right);
        }
    }

    loaded_image_[LEFT].store(false);
    loaded_image_[RIGHT].store(false);
    finish_detection_[LEFT].store(false);
    finish_detection_[RIGHT].store(false);
}

yolo_detection_module ::~yolo_detection_module() {
    spdlog::debug("DESTRUCT: yolo_detection_module");
}

// Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.cc#L62-L118
void yolo_detection_module::run() {
    spdlog::info("start yolo detection module");

    is_terminated_ = false;

    while (true) {
        std::this_thread::sleep_for(std::chrono::milliseconds(5));

        // check if termination is requested
        if (terminate_is_requested()) {
            // terminate and break
            terminate();
            break;
        }

        if (loaded_images()) {
            spdlog::trace("kick yolo detection module at {}", frame_idx_);

            MT_START(mt_yolo_detection);

            if (use_dump_) {
                dump_yolo_input(image_position_t::Left);
                if (camera_->setup_type_ == camera::setup_type_t::Stereo) {
                    dump_yolo_input(image_position_t::Right);
                }
            }

            assert(yolo_detector_left_ != nullptr);
            yolo_detector_left_->set_input(input_image_);
            if (camera_->setup_type_ == camera::setup_type_t::Stereo) {
                assert(yolo_detector_right_ != nullptr);
                yolo_detector_right_->set_input(input_right_image_);
            }

            detect(image_position_t::Left);
            if (camera_->setup_type_ == camera::setup_type_t::Stereo) {
                detect(image_position_t::Right);
            }

            if (use_dump_) {
                dump_yolo_output(image_position_t::Left);
                if (camera_->setup_type_ == camera::setup_type_t::Stereo) {
                    dump_yolo_output(image_position_t::Right);
                }
            }
            frame_idx_++;

            MT_FINISH(mt_yolo_detection);

            loaded_image_[LEFT].store(false);
            loaded_image_[RIGHT].store(false);
            finish_detection_[LEFT].store(true);
            finish_detection_[RIGHT].store(true);

            spdlog::trace("done yolo detection module at {}", frame_idx_);
        }
    }

    spdlog::info("terminate yolo detection module");
}

bool yolo_detection_module::loaded_images() const {
    if (camera_->setup_type_ == camera::setup_type_t::Stereo) {
        return loaded_image_[LEFT].load() && loaded_image_[RIGHT].load();
    }

    return loaded_image_[LEFT].load();
}

bool yolo_detection_module::finish_detections() const {
    if (camera_->setup_type_ == camera::setup_type_t::Stereo) {
        return finish_detection_[LEFT].load() && finish_detection_[RIGHT].load();
    }

    return finish_detection_[LEFT].load();
}

void yolo_detection_module::detect(const image_position_t image_position) const {
    const uint16_t image_position_id = (uint16_t)image_position;
    drp_ai::yolo_detector* yolo_detector = (image_position == image_position_t::Left) ? yolo_detector_left_ : yolo_detector_right_;

    MT_START(mt_yolo_detector_start[image_position_id]);

    bool start_succeed = yolo_detector->start();
    if (!start_succeed) {
        spdlog::critical("Failed to yolo_detector::start");
        exit(EXIT_FAILURE);
    }

    MT_FINISH(mt_yolo_detector_start[image_position_id]);

    MT_START(mt_yolo_detector_finish[image_position_id]);

    // busy wait
    const clock_t start = clock();
    while (true) {
        bool finish_succeed = yolo_detector->finish();
        spdlog::trace("finish_succeed : {}", finish_succeed);

        if (finish_succeed)
            break;

        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        clock_t now = clock();
        double sec = (double)(now - start) / CLOCKS_PER_SEC;
        if (drp_ai::WAITING_TIME < sec) {
            spdlog::critical("Failed to yolo_detector::finish");
            exit(EXIT_FAILURE);
        }
    }

    MT_FINISH(mt_yolo_detector_finish[image_position_id]);
}

void yolo_detection_module::set_input(const std::unique_ptr<cv::Mat>& input_image_ptr) {
    assert(!loaded_images());

    input_image_ = input_image_ptr.get()->clone();

    loaded_image_[LEFT].store(true);
}

void yolo_detection_module::set_input(const std::unique_ptr<cv::Mat>& input_image_ptr,
                                      const std::unique_ptr<cv::Mat>& input_right_image_ptr) {
    assert(!loaded_images());

    input_image_ = input_image_ptr.get()->clone();
    input_right_image_ = input_right_image_ptr.get()->clone();

    loaded_image_[LEFT].store(true);
    loaded_image_[RIGHT].store(true);
}

std::vector<drp_ai::bounding_box> yolo_detection_module::get_output(const image_position_t image_position) {
    std::vector<drp_ai::bounding_box> bounding_box_list;

    if (image_position == image_position_t::Left) {
        assert(finish_detection_[LEFT].load());

        bounding_box_list = yolo_detector_left_->get_output();

        finish_detection_[LEFT].store(false);
    }
    else if (image_position == image_position_t::Right) {
        assert(finish_detection_[RIGHT].load());

        bounding_box_list = yolo_detector_right_->get_output();

        finish_detection_[RIGHT].store(false);
    }
    else {
        spdlog::critical("Unknown image position type detected in yolo_detection_module::get_output.");
        exit(EXIT_FAILURE);
    }

    return bounding_box_list;
}

void yolo_detection_module::dump_yolo_input(const image_position_t image_position) const {
    const uint16_t image_position_id = (uint16_t)image_position;

    cv::Mat image = (image_position == image_position_t::Left) ? input_image_
                                                               : input_right_image_;

    std::ostringstream suffix_frame;
    suffix_frame << std::setw(4) << std::setfill('0') << frame_idx_;

    {
        std::ostringstream dir_name_oss;
        dir_name_oss << "yolo_input_" << image_position_id;
        std::string dir_name = dir_name_oss.str();

        struct stat statBuf;
        if (stat(dir_name.c_str(), &statBuf) != 0)
            mkdir(dir_name.c_str(), 0777);

        const std::string filename = dir_name + "/yolo_input_" + suffix_frame.str() + ".png";
        cv::imwrite(filename, image);
    }
}

void yolo_detection_module::dump_yolo_output(const image_position_t image_position) const {
    const uint16_t image_position_id = (uint16_t)image_position;

    std::ostringstream suffix_frame;
    suffix_frame << std::setw(4) << std::setfill('0') << frame_idx_;

    {
        std::ostringstream dir_name_oss;
        dir_name_oss << "yolo_bounding_box_list_" << image_position_id;
        std::string dir_name = dir_name_oss.str();

        struct stat statBuf;
        if (stat(dir_name.c_str(), &statBuf) != 0)
            mkdir(dir_name.c_str(), 0777);

        const std::string filename = dir_name + "/yolo_bounding_box_list_" + suffix_frame.str() + ".csv";
        std::ofstream ofs(filename);
        ofs << "tl.x,tl.y,br.x,br.y" << std::endl;

        std::vector<drp_ai::bounding_box> bounding_box_list;
        if (image_position == image_position_t::Left) {
            bounding_box_list = yolo_detector_left_->get_output();
        }
        else if (image_position == image_position_t::Right) {
            bounding_box_list = yolo_detector_right_->get_output();
        }

        for (size_t i = 0; i < bounding_box_list.size(); i++) {
            drp_ai::bounding_box bbox = bounding_box_list[i];
            if (bbox.label != "person") {
                continue;
            }

            ofs << std::fixed << std::setprecision(15)
                << bbox.left_x << ","
                << bbox.top_y << ","
                << bbox.right_x << ","
                << bbox.bottom_y << std::endl;
        }
        ofs.close();
    }
}

// Please refer to https://github.com/stella-cv/stella_vslam/blob/0.4.0/src/stella_vslam/mapping_module.cc#L559-L649

std::shared_future<void> yolo_detection_module::async_pause() {
    std::lock_guard<std::mutex> lock1(mtx_pause_);
    pause_is_requested_ = true;
    if (!future_pause_.valid()) {
        future_pause_ = promise_pause_.get_future().share();
    }
    return future_pause_;
}

void yolo_detection_module::resume() {
    std::lock_guard<std::mutex> lock1(mtx_pause_);
    std::lock_guard<std::mutex> lock2(mtx_terminate_);

    // if it has been already terminated, cannot resume
    if (is_terminated_) {
        return;
    }

    is_paused_ = false;
    pause_is_requested_ = false;

    spdlog::info("resume yolo detection module");
}

std::shared_future<void> yolo_detection_module::async_terminate() {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    terminate_is_requested_ = true;
    if (!future_terminate_.valid()) {
        future_terminate_ = promise_terminate_.get_future().share();
    }
    return future_terminate_;
}

bool yolo_detection_module::is_terminated() const {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    return is_terminated_;
}

bool yolo_detection_module::terminate_is_requested() const {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    return terminate_is_requested_;
}

void yolo_detection_module::terminate() {
    std::lock_guard<std::mutex> lock(mtx_terminate_);
    is_terminated_ = true;
    promise_terminate_.set_value();
    promise_terminate_ = std::promise<void>();
    future_terminate_ = std::shared_future<void>();
}

} // namespace stella_vslam
