#include "stella_vslam/image_load/monocular_camera_image_loading.h"

#include <string>
#include <sstream>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "stella_vslam/measure_time.h"

#include <cassert>

#if defined(NDEBUG)

#undef NDEBUG
#include <cassert>
#define NDEBUG

#endif

namespace stella_vslam {

monocular_camera_image_loading::monocular_camera_image_loading(const std::shared_ptr<config>& cfg, const image_loading_option option)
    : image_loading(cfg, option) {
    assert(0 <= option_.cam_num_);

    // Workaround #222
    // Cannot be set to cv::VideoCapture::set due to hardware problem, use v4l2src instead
    std::stringstream ss;
    ss << "v4l2src device=/dev/video" << option_.cam_num_
       << " ! "
       << "video/x-raw, "
       << "format=YUY2, "
       << "width=" << option_.camera_width_ << ", "
       << "height=" << option_.camera_height_ << ", "
       << "framerate=(fraction)" << (uint16_t)(option_.fps_) << "/1"
       << " ! "
       << "appsink";

    const std::string v4l2src_str = ss.str();

    spdlog::info("Open camera device");
    spdlog::info("v4l2src_str : {}", v4l2src_str);

    cap.open(v4l2src_str);
    if (!cap.isOpened()) {
        spdlog::critical("Failed to open /dev/video{}.", option_.cam_num_);
        exit(EXIT_FAILURE);
    }

    // cap.set(cv::CAP_PROP_FRAME_WIDTH, option_.camera_width_);
    // cap.set(cv::CAP_PROP_FRAME_HEIGHT, option_.camera_height_);
    // if (option_.camera_width_ != cap.get(cv::CAP_PROP_FRAME_WIDTH)) {
    //     spdlog::critical("Failed to set {} to cv::CAP_PROP_FRAME_WIDTH", option_.camera_width_);
    //     exit(EXIT_FAILURE);
    // }
    // if (option_.camera_height_ != cap.get(cv::CAP_PROP_FRAME_HEIGHT)) {
    //     spdlog::critical("Failed to set {} to cv::CAP_PROP_FRAME_HEIGHT", option_.camera_height_);
    //     exit(EXIT_FAILURE);
    // }

    // bool ret;
    // ret = cap.set(cv::CAP_PROP_FOURCC, cv::VideoWriter::fourcc('Y', 'U', 'Y', 'V'));
    // if (!ret) {
    //     spdlog::critical("Failed to set cv::VideoWriter::fourcc('Y', 'U', 'Y', 'V') to cv::CAP_PROP_FOURCC");
    //     exit(EXIT_FAILURE);
    // }
    // ret = cap.set(cv::CAP_PROP_FPS, option_.fps_);
    // if (!ret) {
    //     spdlog::critical("Failed to set {:.1f} to cv::CAP_PROP_FPS", option_.fps_);
    //     exit(EXIT_FAILURE);
    // }
    // ret = cap.set(cv::CAP_PROP_CONVERT_RGB, 0);
    // if (!ret) {
    //     spdlog::critical("Failed to set 0 to cv::CAP_PROP_CONVERT_RGB");
    //     exit(EXIT_FAILURE);
    // }

    loaded_images_.store(false);
    missing_image_.store(false);
    spdlog::debug("change image_loading::loaded_images_ to false in monocular_camera_image_loading.");
}

bool monocular_camera_image_loading::can_read_next_frame() {
    return !loaded_images_.load();
}

bool monocular_camera_image_loading::remain_read_next_frame() {
    return true;
}

bool monocular_camera_image_loading::read_monocular_frame() {
    assert(option_.sensor_type_ == camera::setup_type_t::Monocular);

    // Read image from device
    cv::Mat img, img_yuv;

    MT_START(mt_capture_read);

    cap.read(img_yuv);

    assert(!img_yuv.empty());

    // Please refer to https://github.com/stella-cv/stella_vslam_examples/blob/0.0.1/src/run_camera_slam.cc#L95-L97
    if (option_.scale_ != 1.0) {
        cv::resize(img_yuv, img_yuv, cv::Size(), option_.scale_, option_.scale_, cv::INTER_LINEAR);
    }

    MT_FINISH(mt_capture_read);

    const double timestamp = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::system_clock::now().time_since_epoch()).count();

    MT_START(mt_cvt_color);
    cv::cvtColor(img_yuv, img, cv::COLOR_YUV2GRAY_YUYV);
    MT_FINISH(mt_cvt_color);

    assert(!img.empty());

    {
        std::unique_lock<std::mutex> lock(mutex_frame_);
        img_ptr_.reset(new cv::Mat(img));
        timestamp_ = timestamp;
    }

    assert(!img_ptr_->empty());

    loaded_images_.store(true);
    spdlog::debug("change image_loading::loaded_images_ to true in monocular_camera_image_loading.");

    return true;
}

bool monocular_camera_image_loading::read_stereo_frame() {
    assert(option_.sensor_type_ == camera::setup_type_t::Stereo);

    spdlog::critical("monocular_camera_image_loading::read_stereo_frame is not implemented.");
    exit(EXIT_FAILURE);
}

bool monocular_camera_image_loading::read_RGBD_frame() {
    assert(option_.sensor_type_ == camera::setup_type_t::RGBD);

    spdlog::critical("monocular_camera_image_loading::read_RGBD_frame is not implemented.");
    exit(EXIT_FAILURE);
}

} // namespace stella_vslam
