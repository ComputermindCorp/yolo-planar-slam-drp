#include "stella_vslam/image_load/monocular_video_loading.h"

#include <chrono>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "stella_vslam/measure_time.h"

#include <cassert>

#if defined(NDEBUG)

#undef NDEBUG
#include <cassert>
#define NDEBUG

#endif

namespace stella_vslam {

monocular_video_loading::monocular_video_loading(const std::shared_ptr<config>& cfg, const image_loading_option option)
    : image_loading(cfg, option) {
    // Please refer to https://github.com/stella-cv/stella_vslam_examples/blob/0.0.1/src/run_video_slam.cc#L75-L80
    video_.open(option_.video_file_path_, cv::CAP_FFMPEG);
    if (!video_.isOpened()) {
        spdlog::critical("Failed to open {}.", option_.video_file_path_);
        exit(EXIT_FAILURE);
    }

    video_.set(0, option_.start_time_);

    if (option_.start_timestamp_ != 0.0) {
        timestamp_ = option_.start_timestamp_;
    }
    else {
        std::chrono::system_clock::time_point start_time_system = std::chrono::system_clock::now();
        timestamp_ = std::chrono::duration_cast<std::chrono::duration<double>>(start_time_system.time_since_epoch()).count();
    }

    loaded_images_.store(false);
    missing_image_.store(false);
    spdlog::debug("change image_loading::loaded_images_ to false in dataset_image_loading.");
}

bool monocular_video_loading::can_read_next_frame() {
    return !loaded_images_.load();
}

bool monocular_video_loading::remain_read_next_frame() {
    return true;
}

bool monocular_video_loading::read_monocular_frame() {
    assert(option_.sensor_type_ == camera::setup_type_t::Monocular);

    // Read image from file
    cv::Mat img;

    MT_START(mt_capture_read);
    video_.read(img);
    MT_FINISH(mt_capture_read);

    assert(!img.empty());

    {
        std::unique_lock<std::mutex> lock(mutex_frame_);
        img_ptr_.reset(new cv::Mat(img));
    }

    assert(!img_ptr_->empty());

    loaded_images_.store(true);
    spdlog::debug("change image_loading::loaded_images_ to true in dataset_image_loading.");

    // Please refer to https://github.com/stella-cv/stella_vslam_examples/blob/0.0.1/src/run_video_slam.cc#L123
    timestamp_ += 1.0 / option_.fps_;

    return true;
}

bool monocular_video_loading::read_stereo_frame() {
    assert(option_.sensor_type_ == camera::setup_type_t::Stereo);

    spdlog::critical("monocular_video_loading::read_stereo_frame is not implemented.");
    exit(EXIT_FAILURE);
}

bool monocular_video_loading::read_RGBD_frame() {
    assert(option_.sensor_type_ == camera::setup_type_t::RGBD);

    spdlog::critical("monocular_video_loading::read_RGBD_frame is not implemented.");
    exit(EXIT_FAILURE);
}

} // namespace stella_vslam
