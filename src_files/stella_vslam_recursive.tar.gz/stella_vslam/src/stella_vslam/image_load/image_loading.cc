#include "stella_vslam/image_load/image_loading.h"

#include "stella_vslam/util/yaml.h"
#include "stella_vslam/camera/camera_factory.h"

namespace stella_vslam {

image_loading::image_loading(const std::shared_ptr<config>& cfg,
                             const image_loading_option option)
    : frame_id_(0),
      option_(option),
      camera_(camera::camera_factory::create(util::yaml_optional_ref(cfg->yaml_node_, "Camera"))) {
}

bool image_loading::need_skip_frame() {
    return (frame_id_ % option_.frame_skip_ != 0);
}

} // namespace stella_vslam