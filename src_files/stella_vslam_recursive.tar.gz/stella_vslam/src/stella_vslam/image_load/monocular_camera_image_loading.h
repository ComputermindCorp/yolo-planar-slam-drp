#pragma once

#include <mutex>

#include <opencv2/videoio.hpp>

#include "stella_vslam/image_load/image_loading.h"

namespace stella_vslam {

class monocular_camera_image_loading : public image_loading {
public:
    monocular_camera_image_loading(const std::shared_ptr<config>& cfg, const image_loading_option option);
    ~monocular_camera_image_loading() = default;

    bool can_read_next_frame();
    bool remain_read_next_frame();

private:
    bool read_monocular_frame();
    bool read_stereo_frame();
    bool read_RGBD_frame();

    cv::VideoCapture cap;
};

} // namespace stella_vslam
