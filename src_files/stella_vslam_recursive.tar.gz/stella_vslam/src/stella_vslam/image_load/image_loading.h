#pragma once

#include <opencv2/core.hpp>

#include "stella_vslam/camera/base.h"
#include "stella_vslam/image_load/input_type.h"
#include "stella_vslam/image_load/image_loading_option.h"
#include "stella_vslam/util/stereo_rectifier.h"

namespace stella_vslam {

class image_loading {
public:
    image_loading(const std::shared_ptr<config>& cfg, const image_loading_option option);
    virtual ~image_loading() = default;

    virtual bool can_read_next_frame() = 0;
    virtual bool remain_read_next_frame() = 0;
    bool need_skip_frame();

    virtual bool read_monocular_frame() = 0;
    virtual bool read_stereo_frame() = 0;
    virtual bool read_RGBD_frame() = 0;

    std::unique_ptr<cv::Mat> img_ptr_;
    std::unique_ptr<cv::Mat> right_img_ptr_;
    std::unique_ptr<cv::Mat> depth_img_ptr_;
    double timestamp_;

    std::atomic<bool> loaded_images_;
    std::atomic<bool> missing_image_;

    std::mutex mutex_frame_;

    size_t frame_id_;

protected:
    const image_loading_option option_;

    camera::base* camera_;
};

} // namespace stella_vslam
