#include "stella_vslam/image_load/dataset_image_loading.h"

#include <opencv2/imgcodecs.hpp>

#include "stella_vslam/util/image_converter.h"

#include "stella_vslam/measure_time.h"

#include <cassert>

#if defined(NDEBUG)

#undef NDEBUG
#include <cassert>
#define NDEBUG

#endif

namespace stella_vslam {

dataset_image_loading::dataset_image_loading(const std::shared_ptr<config>& cfg,
                                             const image_loading_option option,
                                             const std::vector<stella_vslam::sequence::frame>& frames)
    : image_loading(cfg, option),
      frames_(frames),
      frane_n_(frames.size()) {
    if (option_.sensor_type_ == camera::setup_type_t::Stereo) {
        rectifier_ptr_.reset(new util::stereo_rectifier(cfg, camera_));
    }

    loaded_images_.store(false);
    missing_image_.store(false);
    spdlog::debug("change image_loading::loaded_images_ to false in dataset_image_loading.");
}

bool dataset_image_loading::can_read_next_frame() {
    if (frane_n_ <= frame_id_) {
        return false;
    }

    return !loaded_images_.load();
}

bool dataset_image_loading::remain_read_next_frame() {
    return frame_id_ < frane_n_;
}

bool dataset_image_loading::read_monocular_frame() {
    assert(option_.sensor_type_ == camera::setup_type_t::Monocular);

    const sequence::frame frame = frames_.at(frame_id_);

    MT_START(mt_imread);

    // Workaround #222
    // Dealing with hardware-based cv::imread failures
    cv::Mat img;
    for (uint8_t try_read_count = 0; try_read_count < MAX_TRY_READ_COUNT; try_read_count++) {
        img = cv::imread(frame.img_path_, cv::IMREAD_UNCHANGED);

        if (!img.empty()) {
            // Reading successful
            break;
        }

        spdlog::warn("Failed to read {} {} times in dataset_image_loading::read_monocular_frame.", frame.img_path_, try_read_count + 1);
    }

    if (img.empty()) {
        spdlog::error("Failed to read {} in dataset_image_loading::read_monocular_frame.", frame.img_path_);
        missing_image_.store(true);
        return false;
    }

    // Please refer to https://github.com/stella-cv/stella_vslam_examples/blob/0.0.1/src/run_euroc_slam.cc#L92-L99
    if (option_.equal_hist_) {
        util::equalize_histogram(img);
    }

    MT_FINISH(mt_imread);

    assert(!img.empty());

    {
        std::unique_lock<std::mutex> lock(mutex_frame_);
        img_ptr_.reset(new cv::Mat(img));
        timestamp_ = frame.timestamp_;
    }

    assert(!img_ptr_->empty());

    loaded_images_.store(true);
    spdlog::debug("change image_loading::loaded_images_ to true in dataset_image_loading.");

    return true;
}

bool dataset_image_loading::read_stereo_frame() {
    assert(option_.sensor_type_ == camera::setup_type_t::Stereo);

    const sequence::frame frame = frames_.at(frame_id_);

    MT_START(mt_imread);

    // Workaround #222
    // Dealing with hardware-based cv::imread failures
    cv::Mat img;
    for (uint8_t try_read_count = 0; try_read_count < MAX_TRY_READ_COUNT; try_read_count++) {
        img = cv::imread(frame.img_path_, cv::IMREAD_UNCHANGED);

        if (!img.empty()) {
            // Reading successful
            break;
        }

        spdlog::warn("Failed to read {} {} times in dataset_image_loading::read_stereo_frame.", frame.img_path_, try_read_count + 1);
    }

    if (img.empty()) {
        spdlog::error("Failed to read {} in dataset_image_loading::read_stereo_frame.", frame.img_path_);
        missing_image_.store(true);
        return false;
    }

    cv::Mat right_img;
    for (uint8_t try_read_count = 0; try_read_count < MAX_TRY_READ_COUNT; try_read_count++) {
        right_img = cv::imread(frame.right_img_path_, cv::IMREAD_UNCHANGED);

        if (!right_img.empty()) {
            // Reading successful
            break;
        }

        spdlog::warn("Failed to read {} {} times in dataset_image_loading::read_stereo_frame.", frame.right_img_path_, try_read_count + 1);
    }

    if (right_img.empty()) {
        spdlog::error("Failed to read {} in dataset_image_loading::read_stereo_frame.", frame.right_img_path_);
        missing_image_.store(true);
        return false;
    }

    // Please refer to https://github.com/stella-cv/stella_vslam_examples/blob/0.0.1/src/run_euroc_slam.cc#L251-L261
    if (option_.equal_hist_) {
        util::equalize_histogram(img);
        util::equalize_histogram(right_img);
    }

    // Please refer to https://github.com/stella-cv/stella_vslam_examples/blob/0.0.1/src/run_euroc_slam.cc#L267
    if (option_.rectify_) {
        cv::Mat img_rect, right_img_rect;
        rectifier_ptr_->rectify(img, right_img, img_rect, right_img_rect);
        img = img_rect;
        right_img = right_img_rect;
    }

    MT_FINISH(mt_imread);

    assert(!img.empty());
    assert(!right_img.empty());

    {
        std::unique_lock<std::mutex> lock(mutex_frame_);
        img_ptr_.reset(new cv::Mat(img));
        right_img_ptr_.reset(new cv::Mat(right_img));
        timestamp_ = frame.timestamp_;
    }

    assert(!img_ptr_->empty());
    assert(!right_img_ptr_->empty());

    loaded_images_.store(true);
    spdlog::debug("change image_loading::loaded_images_ to true in dataset_image_loading.");

    return true;
}

bool dataset_image_loading::read_RGBD_frame() {
    assert(option_.sensor_type_ == camera::setup_type_t::RGBD);

    const sequence::frame frame = frames_.at(frame_id_);

    MT_START(mt_imread);

    // Workaround #222
    // Dealing with hardware-based cv::imread failures
    cv::Mat img;
    for (uint8_t try_read_count = 0; try_read_count < MAX_TRY_READ_COUNT; try_read_count++) {
        img = cv::imread(frame.img_path_, cv::IMREAD_UNCHANGED);

        if (!img.empty()) {
            // Reading successful
            break;
        }

        spdlog::warn("Failed to read {} {} times in dataset_image_loading::read_RGBD_frame.", frame.img_path_, try_read_count + 1);
    }

    if (img.empty()) {
        spdlog::error("Failed to read {} in dataset_image_loading::read_RGBD_frame.", frame.img_path_);
        missing_image_.store(true);
        return false;
    }

    cv::Mat depth_img;
    for (uint8_t try_read_count = 0; try_read_count < MAX_TRY_READ_COUNT; try_read_count++) {
        depth_img = cv::imread(frame.depth_img_path_, cv::IMREAD_UNCHANGED);

        if (!depth_img.empty()) {
            // Reading successful
            break;
        }

        spdlog::warn("Failed to read {} {} times in dataset_image_loading::read_RGBD_frame.", frame.depth_img_path_, try_read_count + 1);
    }

    if (depth_img.empty()) {
        spdlog::error("Failed to read {} in dataset_image_loading::read_RGBD_frame.", frame.depth_img_path_);
        missing_image_.store(true);
        return false;
    }

    MT_FINISH(mt_imread);

    assert(!img.empty());
    assert(!depth_img.empty());

    {
        std::unique_lock<std::mutex> lock(mutex_frame_);
        img_ptr_.reset(new cv::Mat(img));
        depth_img_ptr_.reset(new cv::Mat(depth_img));
        timestamp_ = frame.timestamp_;
    }

    assert(!img_ptr_->empty());
    assert(!depth_img_ptr_->empty());

    loaded_images_.store(true);
    spdlog::debug("change image_loading::loaded_images_ to true in dataset_image_loading.");

    return true;
}

} // namespace stella_vslam
