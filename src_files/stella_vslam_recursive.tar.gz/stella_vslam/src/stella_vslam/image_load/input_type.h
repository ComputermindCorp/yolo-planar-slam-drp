#pragma once

namespace stella_vslam {

enum class input_type_t {
    DATASET = 0,
    MONO_CAMERA = 1,
    VIDEO = 2
};

}
