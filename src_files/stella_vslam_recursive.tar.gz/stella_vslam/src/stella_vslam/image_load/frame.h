#pragma once

#include <string>

namespace stella_vslam {

// Please refer to https://github.com/stella-cv/stella_vslam_examples/blob/0.0.1/src/util/euroc_util.h
namespace sequence {

struct frame {
    frame(const std::string& img_path,
          const std::string& right_img_path,
          const std::string& depth_img_path,
          const double timestamp)
        : img_path_(img_path),
          right_img_path_(right_img_path),
          depth_img_path_(depth_img_path),
          timestamp_(timestamp){};

    frame(const std::string& img_path)
        : img_path_(img_path),
          right_img_path_(""),
          depth_img_path_(""),
          timestamp_(0.0){};

    const std::string img_path_;
    const std::string right_img_path_;
    const std::string depth_img_path_;
    const double timestamp_;
};

} // namespace sequence

} // namespace stella_vslam
