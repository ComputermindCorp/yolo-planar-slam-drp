#pragma once

#include "stella_vslam/camera/base.h"
#include "stella_vslam/image_load/input_type.h"

namespace stella_vslam {

class image_loading_option {
public:
    image_loading_option(const camera::setup_type_t sensor_type,
                         const input_type_t input_type,
                         const int32_t cam_num,
                         const uint32_t frame_skip,
                         const bool equal_hist,
                         const bool rectify,
                         const float scale,
                         const std::string video_file_path,
                         const uint32_t start_time,
                         const double start_timestamp,
                         const uint32_t camera_width,
                         const uint32_t camera_height,
                         const double fps);

    // Dataset
    image_loading_option(const camera::setup_type_t sensor_type,
                         const input_type_t input_type,
                         const uint32_t frame_skip,
                         const bool equal_hist,
                         const bool rectify);

    // Camera
    image_loading_option(const camera::setup_type_t sensor_type,
                         const input_type_t input_type,
                         const int32_t cam_num,
                         const bool rectify,
                         const float scale,
                         const uint32_t camera_width,
                         const uint32_t camera_height,
                         const double fps);

    // Video
    image_loading_option(const camera::setup_type_t sensor_type,
                         const input_type_t input_type,
                         const uint32_t frame_skip,
                         const std::string video_file_path,
                         const uint32_t start_time,
                         const double start_timestamp,
                         const double fps);

    const camera::setup_type_t sensor_type_;
    const input_type_t input_type_;

    const int32_t cam_num_;
    const uint32_t frame_skip_;
    const bool equal_hist_;
    const bool rectify_;
    const float scale_;

    const std::string video_file_path_;
    const uint32_t start_time_;
    const double start_timestamp_;
    const uint32_t camera_width_;
    const uint32_t camera_height_;
    const double fps_;

private:
    static constexpr int32_t DUMMY_CAM_NUM = -1;
    static constexpr float DEFAULT_SCALE = 1.0f;
    static constexpr uint32_t DEFAULT_START_TIME = 0;
    static constexpr uint32_t DEFAULT_START_TIMESTAMP = 0.0;
    static constexpr uint32_t DUMMY_CAMERA_WIDTH = 0;
    static constexpr uint32_t DUMMY_CAMERA_HEIGHT = 0;
    static constexpr double DUMMY_FPS = 0.0;
};

} // namespace stella_vslam
