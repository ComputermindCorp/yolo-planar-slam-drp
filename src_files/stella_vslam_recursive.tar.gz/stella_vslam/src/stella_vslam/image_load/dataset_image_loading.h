#pragma once

#include <mutex>

#include "stella_vslam/image_load/image_loading.h"
#include "stella_vslam/image_load/frame.h"

namespace stella_vslam {

class dataset_image_loading : public image_loading {
public:
    dataset_image_loading(const std::shared_ptr<config>& cfg,
                          const image_loading_option option,
                          const std::vector<stella_vslam::sequence::frame>& frames);
    ~dataset_image_loading() = default;

    bool can_read_next_frame();
    bool remain_read_next_frame();

private:
    bool read_monocular_frame();
    bool read_stereo_frame();
    bool read_RGBD_frame();

    const std::vector<stella_vslam::sequence::frame> frames_;
    const size_t frane_n_;

    std::unique_ptr<util::stereo_rectifier> rectifier_ptr_ = nullptr;

    static constexpr uint8_t MAX_TRY_READ_COUNT = 8;
};

} // namespace stella_vslam
