#pragma once

#include <opencv2/core.hpp>

#include "stella_vslam/image_position.h"

#include "MeraDrpRuntimeWrapper.h"
#include "PreRuntime.h"
#include "camera/define.h"
#include "box.h"

namespace stella_vslam {

namespace drp_ai {

constexpr double WAITING_TIME = 10.0; // sec

class bounding_box {
public:
    bounding_box(float ty, float by, float lx, float rx, std::string l, float conf)
        : top_y(ty),
          bottom_y(by),
          left_x(lx),
          right_x(rx),
          label(l),
          confidence(conf) {}

    ~bounding_box() {}

    float top_y;
    float bottom_y;
    float left_x;
    float right_x;
    std::string label;
    float confidence;
};

class yolo_detector {
public:
    yolo_detector(const image_position_t image_position);
    ~yolo_detector();

    void set_input(const cv::Mat& input_image);
    std::vector<bounding_box> get_output() const;
    bool start();
    bool finish();

private:
    int8_t get_result();
    void R_Post_Proc(float* floatarr);

    void yuv_to_yuyv(const cv::Mat& yuv, cv::Mat& yuyv);
    template<int T>
    void bottom_padding(const cv::Mat& rgb_image, cv::Mat& square_image);

    const image_position_t image_position_;
    const uint16_t image_position_id_;

    /* Model Binary */
    const std::string model_dir;
    /* Pre-processing Runtime Object */
    const std::string pre_dir;

    // Please refer to drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/define_color.h
    /* Pascal VOC dataset label list */
    const std::vector<std::string> label_file_map = {
        "aeroplane",
        "bicycle",
        "bird",
        "boat",
        "bottle",
        "bus",
        "car",
        "cat",
        "chair",
        "cow",
        "diningtable",
        "dog",
        "horse",
        "motorbike",
        "person",
        "pottedplant",
        "sheep",
        "sofa",
        "train",
        "tvmonitor"};
    /* DRP-AI TVM[*1] Runtime object */
    MeraDrpRuntimeWrapper runtime;
    /* Pre-processing Runtime object */
    PreRuntime preruntime;

    int8_t drpai_fd;

    cv::Mat input_image_;
    const uint32_t resize_output_width = 640;
    double resize_scale;                                    // expected to be 1.0 (== 640 / 640)
    constexpr static double output_exceptional_scale = 1.0; // Exceptional scale value
    const uint64_t preruntime_input_address = 0x25F000000;

    float drpai_output_buf[num_inf_out];
    std::vector<detection> det;
    std::vector<bounding_box> bounding_box_list;
};

} // namespace drp_ai

} // namespace stella_vslam
