#include "yolo_detector.h"

#include <fstream>
#include <climits>

#include <sys/time.h>

#include <opencv2/imgproc.hpp>

#include <spdlog/spdlog.h>

#include <linux/drpai.h>
#include <builtin_fp16.h>

#include "stella_vslam/drp_device_lock.h"

#include "stella_vslam/measure_time.h"

#include <cassert>

#if defined(NDEBUG)

#undef NDEBUG
#include <cassert>
#define NDEBUG

#endif

namespace stella_vslam {

namespace drp_ai {

// Please refer to drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/main.cpp

/*****************************************
 * Function Name     : float16_to_float32
 * Description       : Function by Edgecortex. Cast uint16_t a into float value.
 * Arguments         : a = uint16_t number
 * Return value      : float = float32 number
 ******************************************/
float float16_to_float32(uint16_t a) {
    return __extendXfYf2__<uint16_t, uint16_t, 10, float, uint32_t, 23>(a);
}

/*****************************************
 * Function Name : index
 * Description   : Get the index of the bounding box attributes based on the input offset.
 * Arguments     : n = output layer number.
 *                 offs = offset to access the bounding box attributesd.
 *                 channel = channel to access each bounding box attribute.
 * Return value  : index to access the bounding box attribute.
 ******************************************/
int32_t index(uint8_t n, int32_t offs, int32_t channel) {
    uint8_t num_grid = num_grids[n];
    return offs + channel * num_grid * num_grid;
}

/*****************************************
 * Function Name : offset
 * Description   : Get the offset nuber to access the bounding box attributes
 *                 To get the actual value of bounding box attributes, use index() after this function.
 * Arguments     : n = output layer number [0~2].
 *                 b = Number to indicate which bounding box in the region [0~2]
 *                 y = Number to indicate which region [0~13]
 *                 x = Number to indicate which region [0~13]
 * Return value  : offset to access the bounding box attributes.
 ******************************************/
int32_t offset(uint8_t n, int32_t b, int32_t y, int32_t x) {
    uint8_t num = num_grids[n];
    uint32_t prev_layer_num = 0;
    int32_t i = 0;

    for (i = 0; i < n; i++) {
        prev_layer_num += NUM_BB * (NUM_CLASS + 5) * num_grids[i] * num_grids[i];
    }
    return prev_layer_num + b * (NUM_CLASS + 5) * num * num + y * num + x;
}

#if (1) // TVM
/*****************************************
 * Function Name : get_drpai_start_addr
 * Description   : Function to get the start address of DRPAImem.
 * Arguments     : drpai_fd: DRP-AI file descriptor
 * Return value  : If non-zero, DRP-AI memory start address.
 *                 0 is failure.
 ******************************************/
#ifdef V2H
uint64_t get_drpai_start_addr(int drpai_fd)
#else
uint32_t get_drpai_start_addr(int drpai_fd)
#endif
{
    int ret = 0;
    drpai_data_t drpai_data;

    errno = 0;

    /* Get DRP-AI Memory Area Address via DRP-AI Driver */
    ret = ioctl(drpai_fd, DRPAI_GET_DRPAI_AREA, &drpai_data);
    if (-1 == ret) {
        spdlog::error("Failed to get DRP-AI Memory Area : errno={}", errno);
        return 0;
    }

    return drpai_data.address;
}

/*****************************************
 * Function Name : set_drpai_freq
 * Description   : Function to set the DRP and DRP-AI frequency.
 * Arguments     : drpai_fd: DRP-AI file descriptor
 * Return value  : 0 if succeeded
 *                 not 0 otherwise
 ******************************************/
int set_drpai_freq(int drpai_fd) {
    int ret = 0;
    uint32_t data;
    int32_t drp_max_freq = 2;
    int32_t drpai_freq = 2;

    errno = 0;
    data = drp_max_freq;
    ret = ioctl(drpai_fd, DRPAI_SET_DRP_MAX_FREQ, &data);
    if (-1 == ret) {
        spdlog::error("Failed to set DRP Max Frequency : errno={}", errno);
        return -1;
    }

    errno = 0;
    data = drpai_freq;
    ret = ioctl(drpai_fd, DRPAI_SET_DRPAI_FREQ, &data);
    if (-1 == ret) {
        spdlog::error("Failed to set DRP-AI Frequency : errno={}", errno);
        return -1;
    }
    return 0;
}

/*****************************************
 * Function Name : init_drpai
 * Description   : Function to initialize DRP-AI.
 * Arguments     : drpai_fd: DRP-AI file descriptor
 * Return value  : If non-zero, DRP-AI memory start address.
 *                 0 is failure.
 ******************************************/
#ifdef V2H
uint64_t init_drpai(int drpai_fd)
#else
#error
uint32_t init_drpai(int drpai_fd)
#endif
{
    int ret = 0;
#ifdef V2H
    uint64_t drpai_addr = 0;
#else
#error
    uint32_t drpai_addr = 0;
#endif

    /*Get DRP-AI memory start address*/
    drpai_addr = get_drpai_start_addr(drpai_fd);
    if (drpai_addr == 0) {
        return 0;
    }

    /*Set DRP-AI frequency*/
    ret = set_drpai_freq(drpai_fd);
    if (ret != 0) {
        return 0;
    }

    return drpai_addr;
}
#endif // TVM

// Please refer to drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/main.cpp
yolo_detector::yolo_detector(const image_position_t image_position)
    : image_position_(image_position),
      image_position_id_((uint16_t)image_position),
      model_dir("yolox_cam"),
      pre_dir("yolox_cam/preprocess") {
    uint64_t drpaimem_addr_start = 0;

    errno = 0;
    drpai_fd = open("/dev/drpai0", O_RDWR);
    if (0 > drpai_fd) {
        spdlog::critical("Failed to open DRP-AI Driver : errno={}", errno);
        exit(EXIT_FAILURE);
    }

    /*Initialzie DRP-AI (Get DRP-AI memory address and set DRP-AI frequency)*/
    drpaimem_addr_start = init_drpai(drpai_fd);
    if (drpaimem_addr_start == 0) {
        spdlog::critical("Failed to init_drpai : errno={}", errno);
        exit(EXIT_FAILURE);
    }

    /*Load model_dir structure and its weight to runtime object */
    /*Load pre_dir object to DRP-AI */
    uint8_t ret = preruntime.Load(pre_dir);
    if (0 < ret) {
        spdlog::critical("Failed to run Pre-processing Runtime Load().");
        exit(EXIT_FAILURE);
    }

    /* Currently, the start address can only use the head of the area managed by the DRP-AI. */
    bool runtime_status = runtime.LoadModel(model_dir, drpaimem_addr_start);

    if (!runtime_status) {
        spdlog::critical("Failed to load model.");
        exit(EXIT_FAILURE);
    }
}

yolo_detector::~yolo_detector() {
    close(drpai_fd);
}

/*****************************************
 * Function Name : get_result
 * Description   : Get DRP-AI Output from memory via DRP-AI Driver
 * Arguments     : -
 * Return value  : 0 if succeeded
 *                 not 0 otherwise
 ******************************************/
int8_t yolo_detector::get_result() {
    int8_t ret = 0;
    int32_t i = 0;
    int32_t output_num = 0;
    std::tuple<InOutDataType, void*, int64_t> output_buffer;
    int64_t output_size;
    uint32_t size_count = 0;

    /* Get the number of output of the target model. */
    output_num = runtime.GetNumOutput();
    size_count = 0;
    /*GetOutput loop*/
    for (i = 0; i < output_num; i++) {
        /* output_buffer below is tuple, which is { data type, address of output data, number of elements } */
        output_buffer = runtime.GetOutput(i);
        /*Output Data Size = std::get<2>(output_buffer). */
        output_size = std::get<2>(output_buffer);

        /*Output Data Type = std::get<0>(output_buffer)*/
        if (InOutDataType::FLOAT16 == std::get<0>(output_buffer)) {
            /*Output Data = std::get<1>(output_buffer)*/
            uint16_t* data_ptr = reinterpret_cast<uint16_t*>(std::get<1>(output_buffer));

            for (int j = 0; j < output_size; j++) {
                /*FP16 to FP32 conversion*/
                drpai_output_buf[j + size_count] = float16_to_float32(data_ptr[j]);
            }
        }
        else if (InOutDataType::FLOAT32 == std::get<0>(output_buffer)) {
            /*Output Data = std::get<1>(output_buffer)*/
            float* data_ptr = reinterpret_cast<float*>(std::get<1>(output_buffer));
            for (int j = 0; j < output_size; j++) {
                drpai_output_buf[j + size_count] = data_ptr[j];
            }
        }
        else {
            spdlog::error("Output data type : not floating point.");
            ret = -1;
            break;
        }
        size_count += output_size;
    }
    return ret;
}

/*****************************************
 * Function Name : R_Post_Proc
 * Description   : Process CPU post-processing for YoloX
 * Arguments     : floatarr = drpai output address
 * Return value  : -
 ******************************************/
void yolo_detector::R_Post_Proc(float* floatarr) {
    std::mutex mtx;

    /* Following variables are required for correct_region_boxes in Darknet implementation*/
    /* Note: This implementation refers to the "darknet detector test" */
    std::vector<detection> det_buff;
    float new_w, new_h;
    float correct_w = 1.;
    float correct_h = 1.;
    if ((float)(MODEL_IN_W / correct_w) < (float)(MODEL_IN_H / correct_h)) {
        new_w = (float)MODEL_IN_W;
        new_h = correct_h * MODEL_IN_W / correct_w;
    }
    else {
        new_w = correct_w * MODEL_IN_H / correct_h;
        new_h = MODEL_IN_H;
    }

    int32_t n = 0;
    int32_t b = 0;
    int32_t y = 0;
    int32_t x = 0;
    int32_t offs = 0;
    int32_t i = 0;
    float tx = 0;
    float ty = 0;
    float tw = 0;
    float th = 0;
    float tc = 0;
    float center_x = 0;
    float center_y = 0;
    float box_w = 0;
    float box_h = 0;
    float objectness = 0;
    uint8_t num_grid = 0;
    float classes[NUM_CLASS];
    float max_pred = 0;
    int32_t pred_class = -1;
    float probability = 0;
    detection d;
    // YOLOX
    int stride = 0;
    std::vector<int> strides = {8, 16, 32};

    for (n = 0; n < NUM_INF_OUT_LAYER; n++) {
        num_grid = num_grids[n];

        for (b = 0; b < NUM_BB; b++) {
            stride = strides[n];
            for (y = 0; y < num_grid; y++) {
                for (x = 0; x < num_grid; x++) {
                    offs = offset(n, b, y, x);
                    tc = floatarr[index(n, offs, 4)];

                    objectness = tc;

                    if (objectness > TH_PROB) {
                        /* Get the class prediction */
                        for (i = 0; i < NUM_CLASS; i++) {
                            classes[i] = floatarr[index(n, offs, 5 + i)];
                        }

                        max_pred = 0;
                        pred_class = -1;
                        for (i = 0; i < NUM_CLASS; i++) {
                            if (classes[i] > max_pred) {
                                pred_class = i;
                                max_pred = classes[i];
                            }
                        }

                        /* Store the result into the list if the probability is more than the threshold */
                        probability = max_pred * objectness;
                        if (probability > TH_PROB) {
                            tx = floatarr[offs];
                            ty = floatarr[index(n, offs, 1)];
                            tw = floatarr[index(n, offs, 2)];
                            th = floatarr[index(n, offs, 3)];

                            /* Compute the bounding box */
                            /*get_yolo_box/get_region_box in paper implementation*/
                            center_x = (tx + float(x)) * stride;
                            center_y = (ty + float(y)) * stride;
                            center_x = center_x / (float)MODEL_IN_W;
                            center_y = center_y / (float)MODEL_IN_H;
                            box_w = exp(tw) * stride;
                            box_h = exp(th) * stride;
                            box_w = box_w / (float)MODEL_IN_W;
                            box_h = box_h / (float)MODEL_IN_H;

                            /* Adjustment for size */
                            /* correct_yolo/region_boxes */
                            center_x = (center_x - (MODEL_IN_W - new_w) / 2. / MODEL_IN_W) / ((float)new_w / MODEL_IN_W);
                            center_y = (center_y - (MODEL_IN_H - new_h) / 2. / MODEL_IN_H) / ((float)new_h / MODEL_IN_H);
                            box_w *= (float)(MODEL_IN_W / new_w);
                            box_h *= (float)(MODEL_IN_H / new_h);

                            center_x = round(center_x * DRPAI_IN_WIDTH);
                            center_y = round(center_y * DRPAI_IN_HEIGHT);
                            box_w = round(box_w * DRPAI_IN_WIDTH);
                            box_h = round(box_h * DRPAI_IN_HEIGHT);

                            center_x /= resize_scale;
                            center_y /= resize_scale;
                            box_w /= resize_scale;
                            box_h /= resize_scale;

                            Box bb = {center_x, center_y, box_w, box_h};
                            d = {bb, pred_class, probability};
                            det_buff.push_back(d);
                        }
                    }
                }
            }
        }
    }
    /* Non-Maximum Supression filter */
    filter_boxes_nms(det_buff, det_buff.size(), TH_NMS);

    /* Log Output */
    int iBoxCount = 0;
    for (i = 0; i < (int32_t)det_buff.size(); i++) {
        /* Skip the overlapped bounding boxes */
        if (det_buff[i].prob == 0)
            continue;

        spdlog::debug(" Bounding Box Number : {}", i + 1);
        spdlog::debug(" Bounding Box        : (X, Y, W, H) = ({}, {}, {}, {})", (int)det_buff[i].bbox.x, (int)det_buff[i].bbox.y, (int)det_buff[i].bbox.w, (int)det_buff[i].bbox.h);
        spdlog::debug(" Detected Class      : {} (Class {})", label_file_map[det_buff[i].c].c_str(), det_buff[i].c);
        spdlog::debug(" Probability         : {} %", (std::round((det_buff[i].prob * 100) * 10) / 10));

        iBoxCount++;
    }

    spdlog::debug(" Bounding Box Count  : {}", iBoxCount);

    mtx.lock();
    /* Clear the detected result list */
    det.clear();
    for (i = 0; i < (int32_t)det_buff.size(); i++) {
        /* Skip the overlapped bounding boxes */
        if (det_buff[i].prob == 0)
            continue;
        det.push_back(det_buff[i]);
    }
    mtx.unlock();
    return;
}

void yolo_detector::yuv_to_yuyv(const cv::Mat& yuv, cv::Mat& yuyv) {
    for (int iy = 0; iy < yuv.rows; iy++) {
        for (int ix = 0; ix < yuv.cols; ix += 2) {
            uint8_t y0 = yuv.at<cv::Vec3b>(iy, ix)[0];
            uint8_t u0 = yuv.at<cv::Vec3b>(iy, ix)[1];
            uint8_t v0 = yuv.at<cv::Vec3b>(iy, ix)[2];
            uint8_t y1 = yuv.at<cv::Vec3b>(iy, ix + 1)[0];
            uint8_t u1 = yuv.at<cv::Vec3b>(iy, ix + 1)[1];
            uint8_t v1 = yuv.at<cv::Vec3b>(iy, ix + 1)[2];

            uint8_t u = (u0 + u1 + 1) >> 1;
            uint8_t v = (v0 + v1 + 1) >> 1;

            yuyv.at<cv::Vec2b>(iy, ix)[0] = y0;
            yuyv.at<cv::Vec2b>(iy, ix)[1] = u;
            yuyv.at<cv::Vec2b>(iy, ix + 1)[0] = y1;
            yuyv.at<cv::Vec2b>(iy, ix + 1)[1] = v;
        }
    }
}

template<>
void yolo_detector::bottom_padding<CV_8UC2>(const cv::Mat& yuyv_image, cv::Mat& square_yuyv_image) {
    assert(yuyv_image.rows == 1440 || yuyv_image.rows == 1225);
    assert(yuyv_image.cols == 1920);
    assert(yuyv_image.channels() == 2);

    assert(square_yuyv_image.rows == 1920);
    assert(square_yuyv_image.cols == 1920);
    assert(square_yuyv_image.channels() == 2);

    cv::Mat roi = square_yuyv_image(cv::Rect(0, 0, yuyv_image.cols, yuyv_image.rows));
    yuyv_image.copyTo(roi);

    // Please refer to R_Capture_Thread implemented in app_yolox_cam/src/main.cpp
    /** Fill buffer with the brightness 114. */
    for (int32_t y = yuyv_image.rows; y < square_yuyv_image.rows; y++) {
        cv::Vec2b* row_ptr = square_yuyv_image.ptr<cv::Vec2b>(y);
        for (int32_t x = 0; x < square_yuyv_image.cols; x++) {
            row_ptr[x] = cv::Vec2b(114, 128);
        }
    }
}

template<>
void yolo_detector::bottom_padding<CV_8UC3>(const cv::Mat& rgb_image, cv::Mat& square_rgb_image) {
    assert(rgb_image.rows == 1440 || rgb_image.rows == 1225);
    assert(rgb_image.cols == 1920);
    assert(rgb_image.channels() == 3);

    assert(square_rgb_image.rows == 1920);
    assert(square_rgb_image.cols == 1920);
    assert(square_rgb_image.channels() == 3);

    cv::Mat roi = square_rgb_image(cv::Rect(0, 0, rgb_image.cols, rgb_image.rows));
    rgb_image.copyTo(roi);

    // Please refer to R_Capture_Thread implemented in app_yolox_cam/src/main.cpp
    /** Fill buffer with the brightness 114. */
    for (int32_t y = rgb_image.rows; y < square_rgb_image.rows; y++) {
        cv::Vec3b* row_ptr = square_rgb_image.ptr<cv::Vec3b>(y);
        for (int32_t x = 0; x < square_rgb_image.cols; x++) {
            row_ptr[x] = cv::Vec3b(114, 114, 114);
        }
    }
}

void yolo_detector::set_input(const cv::Mat& input_image) {
    input_image_ = input_image.clone();
}

std::vector<bounding_box> yolo_detector::get_output() const {
    return bounding_box_list;
}

bool yolo_detector::start() {
    spdlog::trace("Start yolo_detector::start");

    const bool convert_to_yuyv = true;
    const bool convert_to_rgb = !convert_to_yuyv;
    const bool resize_input = true;
    const bool use_bottom_padding = true;

    assert(input_image_.rows == 480);
    assert(input_image_.cols == 640 || input_image_.cols == 752);
    assert(input_image_.channels() == 1 || input_image_.channels() == 3);

    cv::Mat img;

    MT_START(mt_drp_ai_yolo_convert_color_format[image_position_id_]);

    if (convert_to_yuyv) {
        cv::Mat yuyv_image(480, input_image_.cols, CV_8UC2);
        cv::Mat yuv24_image(480, input_image_.cols, CV_8UC3);

        if (input_image_.type() == CV_8UC1) {
            // cv::COLOR_GRAY2YUV is not defined
            cv::cvtColor(input_image_, yuv24_image, cv::COLOR_GRAY2BGR);
            cv::cvtColor(yuv24_image, yuv24_image, cv::COLOR_BGR2YUV);
        }
        else if (input_image_.type() == CV_8UC3) {
            cv::cvtColor(input_image_, yuv24_image, cv::COLOR_BGR2YUV);
        }
        else {
            spdlog::critical("Incorrect color format to DRP-AI input image.");
            exit(EXIT_FAILURE);
        }

        yuv_to_yuyv(yuv24_image, yuyv_image);

        assert(yuyv_image.rows == 480);
        assert(yuyv_image.cols == 640 || yuyv_image.cols == 752);
        assert(yuyv_image.channels() == 2);
        assert(yuyv_image.isContinuous());

        img = yuyv_image;
    }
    else if (convert_to_rgb) {
        cv::Mat rgb_image(480, input_image_.cols, CV_8UC3);

        if (input_image_.type() == CV_8UC1) {
            cv::cvtColor(input_image_, rgb_image, cv::COLOR_GRAY2RGB);
        }
        else if (input_image_.type() == CV_8UC3) {
            cv::cvtColor(input_image_, rgb_image, cv::COLOR_BGR2RGB);
        }
        else {
            spdlog::critical("Incorrect color format to DRP-AI input image.");
            exit(EXIT_FAILURE);
        }

        assert(rgb_image.rows == 480);
        assert(rgb_image.cols == 640 || rgb_image.cols == 752);
        assert(rgb_image.channels() == 3);
        assert(rgb_image.isContinuous());

        img = rgb_image;
    }
    else {
        spdlog::critical("Incorrect setting to convert input image to DRP-AI input image.");
        exit(EXIT_FAILURE);
    }

    MT_FINISH(mt_drp_ai_yolo_convert_color_format[image_position_id_]);

    MT_START(mt_drp_ai_yolo_resize[image_position_id_]);

    if (resize_input) {
        resize_scale = (double)resize_output_width / input_image_.cols;   // 1920 / 640 == 3.0 or 1920 / 752 ~= 2.55
        uint32_t resize_output_height = resize_scale * input_image_.rows; // 480 * 3.0 == 1440 or 480 * 2.55 ~= 1,225.5
        const cv::Size resize_sz(resize_output_width, resize_output_height);

        spdlog::trace("resize_scale : {:.2f}", resize_scale);

        drp_device_lock::mutex_drp_device.lock();
        cv::resize(img, img, resize_sz);
        drp_device_lock::mutex_drp_device.unlock();

        assert(img.rows == (int)resize_output_height);
        assert(img.cols == (int)resize_output_width);
        assert(img.isContinuous());
    }

    MT_FINISH(mt_drp_ai_yolo_resize[image_position_id_]);

    MT_START(mt_drp_ai_yolo_padding[image_position_id_]);

    if (use_bottom_padding) {
        const int color_format = convert_to_yuyv  ? CV_8UC2
                                 : convert_to_rgb ? CV_8UC3
                                                  : -1;
        assert(color_format == CV_8UC2 || color_format == CV_8UC3);

        cv::Mat square(img.cols, img.cols, color_format);
        bottom_padding<color_format>(img, square);

        assert(square.rows == 1920);
        assert(square.cols == 1920);
        assert(square.channels() == CV_MAT_CN(color_format));
        assert(square.isContinuous());

        img = square;
    }

    MT_FINISH(mt_drp_ai_yolo_padding[image_position_id_]);

    MT_START(mt_drp_ai_yolo_u2p_input[image_position_id_]);
    {
        int ret = 0;
        drpai_data_t drpai_input;
        drpai_input.address = preruntime_input_address;
        drpai_input.size = img.cols * img.rows * img.channels();
        ret = ioctl(drpai_fd, DRPAI_ASSIGN, &drpai_input);
        if (-1 == ret) {
            spdlog::error("Failed to run DRPAI_ASSIGN in SetInput(): errno={}", errno);
            MT_FINISH(mt_drp_ai_yolo_u2p_input[image_position_id_]);
            return false;
        }
        ret = write(drpai_fd, img.data, drpai_input.size);
        if (-1 == ret) {
            spdlog::error("Failed to write via DRP-AI Driver in SetInput(): errno={}", errno);
            MT_FINISH(mt_drp_ai_yolo_u2p_input[image_position_id_]);
            return false;
        }
    }

    MT_FINISH(mt_drp_ai_yolo_u2p_input[image_position_id_]);

    // Please refer to R_Inf_Thread on drp-tvm_dev-v210_add_yolox_240119/how-to/sample_app_v2h/src/main.cpp
    {
        /*Get input data */
        auto input_data_type = runtime.GetInputDataType(0);

        /*Load input data */
        /*Input data type can be either FLOAT32 or FLOAT16, which depends on the model */
        if (InOutDataType::FLOAT32 == input_data_type) {
            /*Do nothing*/
        }
        else if (InOutDataType::FLOAT16 == input_data_type) {
            spdlog::error("Input data type : FP16.");
            /*If your model input data type is FP16, use std::vector<uint16_t> for reading input data. */
            return false;
        }
        else {
            spdlog::error("Input data type : neither FP32 nor FP16.");
            return false;
        }

        /*Variable for getting Inference output data*/
        void* output_ptr;
        uint32_t out_size;
        /*Variable for Pre-processing parameter configuration*/
        s_preproc_param_t in_param;

        in_param.pre_in_addr = /*(uintptr_t)*/ preruntime_input_address;

        MT_START(mt_drp_ai_yolo_pre[image_position_id_]);
        uint8_t ret = preruntime.Pre(&in_param, &output_ptr, &out_size);
        MT_FINISH(mt_drp_ai_yolo_pre[image_position_id_]);

        if (ret != 0) {
            spdlog::error("Failed to run Pre-processing Runtime Pre()");
            return false;
        }

        /*Set Pre-processing output to be inference input. */
        MT_START(mt_drp_ai_yolo_set_input[image_position_id_]);
        runtime.SetInput(0, (float*)output_ptr);
        MT_FINISH(mt_drp_ai_yolo_set_input[image_position_id_]);

        MT_START(mt_drp_ai_yolo_run[image_position_id_]);
        runtime.Run();
        MT_FINISH(mt_drp_ai_yolo_run[image_position_id_]);
    }

    spdlog::trace("Finish yolo_detector::start");

    return true;
}

bool yolo_detector::finish() {
    MT_START(mt_drp_ai_yolo_receive_result[image_position_id_]);

    /*Process to read the DRPAI output data.*/
    int8_t ret = get_result();
    if (0 != ret) {
        spdlog::error("Failed to get result from memory.");
        MT_FINISH(mt_drp_ai_yolo_receive_result[image_position_id_]);
        return false;
    }

    /*Preparation for Post-Processing*/
    /*CPU Post-Processing For YOLOX*/
    R_Post_Proc(drpai_output_buf);

    bounding_box_list.clear();
    for (const detection d : det) {
        std::string label = label_file_map[d.c];
        bounding_box_list.push_back(bounding_box(d.bbox.y - (d.bbox.h / 2),
                                                 d.bbox.y + (d.bbox.h / 2),
                                                 d.bbox.x - (d.bbox.w / 2),
                                                 d.bbox.x + (d.bbox.w / 2),
                                                 label,
                                                 d.prob));
    }

    MT_FINISH(mt_drp_ai_yolo_receive_result[image_position_id_]);

    return true;
}

} // namespace drp_ai

} // namespace stella_vslam