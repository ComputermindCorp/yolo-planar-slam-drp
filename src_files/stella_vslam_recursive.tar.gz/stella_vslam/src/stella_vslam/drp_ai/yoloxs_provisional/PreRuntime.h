#pragma once

/*
 * Original Code (C) Copyright Renesas Electronics Corporation 2023
 *　
 *  *1 DRP-AI TVM is powered by EdgeCortix MERA(TM) Compiler Framework.
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 */

/***********************************************************************************************************************
 * File Name    : PreRuntime.h
 * Version      : 1.1.0
 * Description  : PreRuntime Header file
 ***********************************************************************************************************************/
#pragma once

#ifndef PRERUNTIME_H
#define PRERUNTIME_H
/***********************************************************************************************************************
 * Include
 ***********************************************************************************************************************/
#include <linux/drpai.h>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <termios.h>
#include <errno.h>
#include <vector>
#include <map>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <unordered_map>
#include <cstring>
#include <float.h>
#include <signal.h>
#include <cmath>

#include <builtin_fp16.h>
/***********************************************************************************************************************
 * Macro
 ***********************************************************************************************************************/
#define BUF_SIZE (1024)
#define NUM_OBJ_FILE (6)
#define INDEX_I (0)
#define INDEX_D (1)
#define INDEX_C (2)
#define INDEX_P (3)
#define INDEX_A (4)
#define INDEX_W (5)
#define DRPAI_TIMEOUT (5)

/*Uncomment to enable displaying the debug console log*/
// #define DEBUG_LOG

/*Error List*/
#define PRE_SUCCESS (0)
#define PRE_ERROR (1)
#define PRE_ERROR_UI (-1)

/* Library Name */
#define LIB_CONVYUV2RGB ("conv_yuv2rgb")
#define LIB_RESIZE_HWC ("resize_hwc")
#define LIB_IMAGESCALER ("imagescaler")
#define LIB_TRANSPOSE ("transpose")
#define LIB_CASTFP16_FP32 ("cast_fp16_fp32")
#define LIB_CONVX2GRAY ("conv_x2gray")
#define LIB_CROP ("crop")
#define LIB_ARGMINMAX ("argminmax")

/* Param Info ID */
#define OP_HEAD ("OFFSET_ADD:")
#define OP_LAYER_NAME ("layer_name:")
#define OP_LIB ("drp_lib:")
#define PRAM_HEAD ("Param:")
#define PARAM_VALUE ("Value:")
#define PARAM_OFFSET ("offset:")
#define PARAM_SIZE ("size:")

/* Param name */
#define P_RADDR ("raddr")
#define P_WADDR ("waddr")
#define P_IMG_IWIDTH ("IMG_IWIDHT")
#define P_IMG_IHEIGHT ("IMG_IHEIGHT")
#define P_IMG_OWIDTH ("IMG_OWIDTH")
#define P_IMG_OHEIGHT ("IMG_OHEIGHT")
#define P_INPUT_YUV_FORMAT ("INPUT_YUV_FORMAT")
#define P_DOUT_RGB_FORMAT ("DOUT_RGB_FORMAT")
#define P_RESIZE_ALG ("RESIZE_ALG")
#define P_DATA_TYPE ("DATA_TYPE")
#define P_ADD_ADDR ("ADD_ADDR")
#define P_MUL_ADDR ("MUL_ADDR")
#define P_DOUT_RGB_ORDER ("DOUT_RGB_ORDER")
#define P_WORD_SIZE ("WORD_SIZE")
#define P_IS_CHW2HWC ("IS_CHW2HWC")
#define P_CAST_MODE ("CAST_MODE")
#define P_CROP_POS_X ("CROP_POS_X")
#define P_CROP_POS_Y ("CROP_POS_Y")
#define P_DIN_FORMAT ("DIN_FORMAT")
#define P_DOUT_RGB_FORMAT ("DOUT_RGB_FORMAT")
#define P_IMG_ICH ("IMG_ICH")
#define P_IMG_OCH ("IMG_OCH")

/* Other related values */
#define FORMAT_YUYV_422 (0x0000)
#define FORMAT_YVYU_422 (0x0001)
#define FORMAT_UYUV_422 (0x0002)
#define FORMAT_VUYY_422 (0x0003)
#define FORMAT_YUYV_420 (0x1000)
#define FORMAT_UYVY_420 (0x1001)
#define FORMAT_YV12_420 (0x1002)
#define FORMAT_IYUV_420 (0x1003)
#define FORMAT_NV12_420 (0x1004)
#define FORMAT_NV21_420 (0x1005)
#define FORMAT_IMC1_420 (0x1006)
#define FORMAT_IMC2_420 (0x1007)
#define FORMAT_IMC3_420 (0x1008)
#define FORMAT_IMC4_420 (0x1009)
#define FORMAT_GRAY (0xFFFC)
#define FORMAT_BGR (0xFFFD)
#define FORMAT_RGB (0xFFFE)
#define FORMAT_UNKNOWN (0xFFFF)

/* Format in string. Only used when DEBUG_LOG is ON */
#define FORMAT_YUYV_422_STR ("YUYV_422")
#define FORMAT_YVYU_422_STR ("YVYU_422")
#define FORMAT_UYUV_422_STR ("UYUV_422")
#define FORMAT_VUYY_422_STR ("VUYY_422")
#define FORMAT_YUYV_420_STR ("YVYU_420")
#define FORMAT_UYVY_420_STR ("UYVY_420")
#define FORMAT_YV12_420_STR ("YV12_420")
#define FORMAT_IYUV_420_STR ("IYUV_420")
#define FORMAT_NV12_420_STR ("NV12_420")
#define FORMAT_NV21_420_STR ("NV21_420")
#define FORMAT_IMC1_420_STR ("IMC1_420")
#define FORMAT_IMC2_420_STR ("IMC2_420")
#define FORMAT_IMC3_420_STR ("IMC3_420")
#define FORMAT_IMC4_420_STR ("IMC4_420")
#define FORMAT_GRAY_STR ("GRAY")
#define FORMAT_BGR_STR ("BGR")
#define FORMAT_RGB_STR ("RGB")
#define FORMAT_UNKNOWN_STR ("UNKNOWN")
/* Format in string. Only used when DEBUG_LOG is ON */
static const std::unordered_map<uint16_t, std::string> format_string_table = {
    {FORMAT_YUYV_422, FORMAT_YUYV_422_STR},
    {FORMAT_YVYU_422, FORMAT_YVYU_422_STR},
    {FORMAT_UYUV_422, FORMAT_UYUV_422_STR},
    {FORMAT_VUYY_422, FORMAT_VUYY_422_STR},
    {FORMAT_YUYV_420, FORMAT_YUYV_420_STR},
    {FORMAT_UYVY_420, FORMAT_UYVY_420_STR},
    {FORMAT_YV12_420, FORMAT_YV12_420_STR},
    {FORMAT_IYUV_420, FORMAT_IYUV_420_STR},
    {FORMAT_NV12_420, FORMAT_NV12_420_STR},
    {FORMAT_NV21_420, FORMAT_NV21_420_STR},
    {FORMAT_IMC1_420, FORMAT_IMC1_420_STR},
    {FORMAT_IMC2_420, FORMAT_IMC2_420_STR},
    {FORMAT_IMC3_420, FORMAT_IMC3_420_STR},
    {FORMAT_IMC4_420, FORMAT_IMC4_420_STR},
    {FORMAT_GRAY, FORMAT_GRAY_STR},
    {FORMAT_BGR, FORMAT_BGR_STR},
    {FORMAT_RGB, FORMAT_RGB_STR},
    {FORMAT_UNKNOWN, FORMAT_UNKNOWN_STR}};

/*If FORMAT_* >> BIT_YUV is 1, YUV420.
  If 0, YUV422.
  >1 otherwise.*/
#define BIT_YUV (12)

#define DIN_FORMAT_RGB (0x1000)
#define DIN_FORMAT_BGR (0x1001)

#define NUM_C_YUV (2)
#define NUM_C_RGB_BGR (3)
#define NUM_C_GRAY (1)

#define ALG_NEAREST (0)
#define ALG_BILINEAR (1)
#define INVALID_ADDR (0xFFFFFFFF)
#define INVALID_SHAPE (0xFFFF)
#define INVALID_FORMAT (FORMAT_UNKNOWN)
#define INVALID_RESIZE_ALG (0xFF)

#define MIN_INPUT_W_BOUND (0)
#define MIN_INPUT_H_BOUND (0)
#define MIN_RESIZE_W_BOUND (2)
#define MIN_RESIZE_H_BOUND (2)
#define MAX_RESIZE_W_BOUND (4096)
#define MAX_RESIZE_H_BOUND (4096)
#define MIN_CROP_W_BOUND (0)
#define MIN_CROP_H_BOUND (0)

#define MODE_PRE (0)
#define MODE_POST (1)
/***********************************************************************************************************************
 * Struct and related function
 ***********************************************************************************************************************/

/* For dynamic allocation support of DRP-AI Object files */
typedef struct
{
    std::string directory_name;
    uint64_t start_address;
    uint64_t object_files_size;
    uint64_t data_in_addr;
    uint64_t data_in_size;
    uint64_t data_out_addr;
    uint64_t data_out_size;
} st_drpai_data_t;

typedef struct
{
    uint64_t desc_aimac_addr;
    uint64_t desc_aimac_size;
    uint64_t desc_drp_addr;
    uint64_t desc_drp_size;
    uint64_t drp_param_addr;
    uint64_t drp_param_size;
    uint64_t data_in_addr;
    uint64_t data_in_size;
    uint64_t data_addr;
    uint64_t data_size;
    uint64_t work_addr;
    uint64_t work_size;
    uint64_t data_out_addr;
    uint64_t data_out_size;
    uint64_t drp_config_addr;
    uint64_t drp_config_size;
    uint64_t weight_addr;
    uint64_t weight_size;
    uint64_t aimac_param_cmd_addr;
    uint64_t aimac_param_cmd_size;
    uint64_t aimac_param_desc_addr;
    uint64_t aimac_param_desc_size;
    uint64_t aimac_cmd_addr;
    uint64_t aimac_cmd_size;
} st_addr_info_t;

typedef struct
{
    int drpai_fd = -1;
    st_drpai_data_t data_inout;
    st_addr_info_t drpai_address;
} drpai_handle_t;

typedef struct
{
    uint16_t pre_in_shape_w = INVALID_SHAPE;
    uint16_t pre_in_shape_h = INVALID_SHAPE;
    uint64_t pre_in_addr = INVALID_ADDR;
    uint16_t pre_in_format = INVALID_FORMAT;
    uint16_t pre_out_format = INVALID_FORMAT;
    uint8_t resize_alg = INVALID_RESIZE_ALG;
    uint16_t resize_w = INVALID_SHAPE;
    uint16_t resize_h = INVALID_SHAPE;
    float cof_add[3] = {-FLT_MAX, -FLT_MAX, -FLT_MAX};
    float cof_mul[3] = {-FLT_MAX, -FLT_MAX, -FLT_MAX};
    uint16_t crop_tl_x = INVALID_SHAPE;
    uint16_t crop_tl_y = INVALID_SHAPE;
    uint16_t crop_w = INVALID_SHAPE;
    uint16_t crop_h = INVALID_SHAPE;
} s_preproc_param_t;

typedef struct
{
    std::string name;
    uint32_t value;
    uint16_t offset;
    uint16_t size;
} s_op_param_t;

typedef struct
{
    std::string name;
    std::string lib;
    uint16_t offset;
    std::vector<s_op_param_t> param_list;
} s_op_t;

/***********************************************************************************************************************
 * PreRuntime Class
 ***********************************************************************************************************************/
class PreRuntime {
public:
    PreRuntime();
    ~PreRuntime();

    uint8_t Load(const std::string pre_dir, uint64_t start_addr);
    uint8_t Load(const std::string pre_dir, uint32_t start_addr = INVALID_ADDR, uint8_t mode = MODE_PRE);
    int SetInput(void* indata);
    uint8_t Pre(s_preproc_param_t* param, void** out_ptr, uint32_t* out_size);
    uint8_t Pre(void** out_ptr, uint32_t* out_size, uint64_t phyaddr);
    int Occupied_size;

private:
    /*Internal parameter value holder*/
    s_preproc_param_t internal_param_val;
    /*Internal output buffer*/
    void* internal_buffer = NULL;
    /*Internal output buffer size*/
    uint32_t internal_buffer_size = 0;
    /*DRP-AI Driver dynamic allocation function*/
    drpai_handle_t drpai_obj_info;
    drpai_data_t drpai_data0;
    std::string obj_prefix = "pp";

    /*Since ADRCONV cannot delete just any entry, a means to reconfigure everything became necessary.*/
    uint64_t start_addr_v2h;
    uint64_t mapped_in_addr_v2h;

    /*Functions*/
    uint8_t ReadAddrmapTxt(std::string addr_file);
    uint8_t WritePrerunData(const std::string dir);
    uint8_t LoadDataToMem(std::vector<uint8_t>* data, uint64_t from, uint64_t size);
    uint8_t ReadFileData(std::vector<uint8_t>* data, std::string file, uint64_t size);
    uint8_t GetResult(uint64_t output_addr, uint64_t output_size);
    uint8_t ParseParamInfo(const std::string info_file);

    uint64_t GetStartAddress(uint64_t addr, drpai_data_t drpai_data);
    double timedifference_msec(struct timespec t0, struct timespec t1);
};

#endif // PRERUNTIME_H
