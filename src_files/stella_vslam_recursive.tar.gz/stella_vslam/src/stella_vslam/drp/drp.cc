
#include "drp.h"
#include "dmabuf.h"

#include <cmath>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include <spdlog/spdlog.h>

#include "stella_vslam/drp_device_lock.h"

#include "stella_vslam/measure_time.h"

#include <cassert>

#if defined(NDEBUG)

#undef NDEBUG
#include <cassert>
#define NDEBUG

#endif

#include "linux/drp.h"
#include "linux/drpai.h"

namespace drp_driver_native {

static gaussian_blur_drp_param_st*   gaussian_blur_drp_param_buf;
static orb_descriptors_drp_param_st* orb_descriptors_drp_param_buf;
static resize_drp_param_st*          resize_drp_param_buf;
static cvfast_drp_param_st*          cvfast_drp_param_buf;
static slamfast_drp_param_st*        slamfast_drp_param_buf;

static dma_buffer*                   gaussian_blur_dma_buf;
static dma_buffer*                   orb_descriptors_dma_buf;
static dma_buffer*                   resize_dma_buf;
static dma_buffer*                   cvfast_dma_buf;
static dma_buffer*                   slamfast_dma_buf;

static uintptr_t pyramid_address[8];
static uintptr_t GaussianBlur_output_address[8];

constexpr uint16_t MIN_WIDTH = 16;
constexpr uint16_t MIN_HEIGHT = 16;
constexpr uint16_t MAX_WIDTH = 800;
constexpr uint16_t MAX_HEIGHT = 600;

static uint32_t gaussian_blur_config_size;   /* size of gaussian_blur_drp_out.bin */
static uint32_t orb_descriptors_config_size; /* size of orb_descriptors_drp_out.bin */
static uint32_t resize_config_size;          /* size of resize_drp_out.bin */
static uint32_t cvfast_config_size;          /* size of cvfast_drp_out.bin */
static uint32_t slamfast_config_size;        /* size of slamfast_drp_out.bin */

static uint32_t drp_gaussian_blur_config_address;
static uint32_t drp_orb_descriptors_config_address;
static uint32_t drp_resize_config_address;
static uint32_t drp_cvfast_config_address;
static uint32_t drp_slamfast_config_address;

static uint32_t drp_gaussian_blur_param_address;
static uint32_t drp_orb_descriptors_param_address;
static uint32_t drp_resize_param_address;
static uint32_t drp_cvfast_param_address;
static uint32_t drp_slamfast_param_address;

int32_t activate_mode = STATE_NONE;

drp_data_t proc[8];

#define PROC_GAUSSIAN_BLUR_CONFIG 0
#define PROC_GAUSSIAN_BLUR_PARAM 1
#define PROC_ORB_DESCRIPTORS_CONFIG 2
#define PROC_ORB_DESCRIPTORS_PARAM 3
#define PROC_RESIZE_CONFIG 4
#define PROC_RESIZE_PARAM 5
#define PROC_CVFAST_CONFIG 6
#define PROC_CVFAST_PARAM 7
#define PROC_SLAMFAST_CONFIG PROC_CVFAST_CONFIG
#define PROC_SLAMFAST_PARAM PROC_CVFAST_PARAM

#define BUF_SIZE 128

#define DRPCFG_NUM 1

bool write_configuration_code(const int drp_fd, const char* file_path, const drp_data_t* data) {
    assert(DRP_FIRST_ADDRESS <= data->address);
    assert(data->address <= DRP_LAST_ADDRESS);
    assert(data->address % DRP_ALIGN_BYTE == 0);

    int file_fd = open(file_path, O_RDONLY);
    if (file_fd < 0) {
        spdlog::error("Failed to open {}", file_path);
        close(file_fd);
        return false;
    }

    drp_device_lock::mutex_drp_device.lock();
    int drpai_ret = ioctl(drp_fd, DRP_ASSIGN, data);
    drp_device_lock::mutex_drp_device.unlock();

    bool ioctl_succeed = ((drpai_ret == 0) && (errno == 0));
    if (!ioctl_succeed) {
        spdlog::error("Failed to ioctl(DRP_ASSIGN) in write_configuration_code. Return code is {}, errno is {}", drpai_ret, errno);
        close(file_fd);
        return false;
    }

    const size_t loop_count = data->size / BUF_SIZE;
    const ssize_t loop_remain = data->size % BUF_SIZE;
    for (size_t i = 0; i < loop_count; i++) {
        ssize_t rw_ret;
        uint8_t buf[BUF_SIZE];

        /* sd -> user buf */
        errno = 0;
        rw_ret = read(file_fd, buf, BUF_SIZE);
        if (BUF_SIZE != rw_ret) {
            spdlog::error("Failed to read in write_configuration_code. Return code is {}, errno is {}", rw_ret, errno);
            close(file_fd);
            return false;
        }

        /* user buf -> kernel buf -> DRP for CMA */
        errno = 0;
        rw_ret = write(drp_fd, buf, BUF_SIZE);
        if (BUF_SIZE != rw_ret) {
            spdlog::error("Failed to write in write_configuration_code. Return code is {}, errno is {}", rw_ret, errno);
            close(file_fd);
            return false;
        }
    }

    if (0 != loop_remain) {
        ssize_t rw_ret;
        uint8_t buf[BUF_SIZE];

        /* sd -> user buf */
        errno = 0;
        rw_ret = read(file_fd, buf, loop_remain);
        if (loop_remain != rw_ret) {
            spdlog::error("Failed to read in write_configuration_code. Return code is {}, errno is {}", rw_ret, errno);
            close(file_fd);
            return false;
        }

        /* user buf -> kernel buf -> DRP for CMA */
        errno = 0;
        rw_ret = write(drp_fd, buf, loop_remain);
        if (loop_remain != rw_ret) {
            spdlog::error("Failed to write in write_configuration_code. Return code is {}, errno is {}", rw_ret, errno);
            close(file_fd);
            return false;
        }
    }

    close(file_fd);
    return true;
}

bool memcpy_u2p(const int drp_fd, const void* src, const drp_data_t* data) {
    spdlog::trace("Start memcpy_u2p");

    assert(DRP_FIRST_ADDRESS <= data->address);
    assert(data->address <= DRP_LAST_ADDRESS);
    assert(data->address % DRP_ALIGN_BYTE == 0);

    spdlog::trace("  data->address : {:#012x}", data->address);
    spdlog::trace("  data->size    : {:#012x}({})", data->size, data->size);

    errno = 0;
    drp_device_lock::mutex_drp_device.lock();
    int drpai_ret = ioctl(drp_fd, DRP_ASSIGN, data);
    drp_device_lock::mutex_drp_device.unlock();

    bool ioctl_succeed = ((drpai_ret == 0) && (errno == 0));
    if (!ioctl_succeed) {
        spdlog::error("Failed to ioctl(DRP_ASSIGN) in memcpy_u2p. Return code is {}, errno is {}", drpai_ret, errno);
        return false;
    }

    errno = 0;
    ssize_t rw_ret = write(drp_fd, src, data->size);
    if (data->size != rw_ret) {
        spdlog::error("Failed to write in memcpy_u2p. Return code is {}, errno is {}", rw_ret, errno);
        return false;
    }

    spdlog::trace("Finish memcpy_u2p");

    return true;
}

bool memcpy_p2u(const int drp_fd, void* dst, const drp_data_t* data) {
    spdlog::trace("Start memcpy_p2u");

    assert(DRP_FIRST_ADDRESS <= data->address);
    assert(data->address <= DRP_LAST_ADDRESS);
    assert(data->address % DRP_ALIGN_BYTE == 0);

    spdlog::trace("  data->address : {:#012x}", data->address);
    spdlog::trace("  data->size    : {:#012x}({})", data->size, data->size);

    drp_device_lock::mutex_drp_device.lock();
    int drpai_ret = ioctl(drp_fd, DRP_ASSIGN, data);
    drp_device_lock::mutex_drp_device.unlock();

    bool ioctl_succeed = ((drpai_ret == 0) && (errno == 0));
    if (!ioctl_succeed) {
        spdlog::error("Failed to ioctl(DRP_ASSIGN) in memcpy_p2u. Return code is {}, errno is {}", drpai_ret, errno);
        return false;
    }

    errno = 0;
    ssize_t rw_ret = read(drp_fd, dst, data->size);
    if (data->size != rw_ret) {
        spdlog::error("Failed to read in memcpy_p2u. Return code is {}, errno is {}", rw_ret, errno);
        return false;
    }

    spdlog::trace("Finish memcpy_p2u");

    return true;
}

bool activate(const int drp_fd,
              const iodata_info_st* iodata,
              const uint32_t iodata_num) {
    assert(0 < drp_fd);

    drp_seq_t seq;
    seq.num = DRPCFG_NUM;
    seq.order[0] = DRP_EXE_DRP_40BIT;
    //seq.address = DRP_SEQ_ADDRESS;
    seq.address = (uintptr_t)resize_drp_param_buf->desc;

    seq.iodata_num = iodata_num;
    for (size_t i = 0; i < seq.iodata_num; i++) {
        seq.iodata[i].address = iodata[i].address;
        seq.iodata[i].size = iodata[i].size;
        seq.iodata[i].pos = iodata[i].pos;
    }

    errno = 0;

    drp_device_lock::mutex_drp_device.lock();
    int drpai_ret = ioctl(drp_fd, DRP_SET_SEQ, &seq);
    drp_device_lock::mutex_drp_device.unlock();

    bool ioctl_succeed = ((drpai_ret == 0) && (errno == 0));

    if (!ioctl_succeed) {
        spdlog::error("Failed to ioctl(DRP_SET_SEQ). Return code is {}, errno is {}", drpai_ret, errno);
        return false;
    }

    return ioctl_succeed;
}

bool start(const int drp_fd, const drp_data_t* proc) {
    assert(DRP_FIRST_ADDRESS <= proc[0].address);
    assert(proc[0].address <= DRP_LAST_ADDRESS);
    assert(proc[0].address % DRP_ALIGN_BYTE == 0);
    assert(DRP_FIRST_ADDRESS <= proc[1].address);
    assert(proc[1].address <= DRP_LAST_ADDRESS);
    assert(proc[1].address % DRP_ALIGN_BYTE == 0);

    errno = 0;

    drp_device_lock::mutex_drp_device.lock();
    int drpai_ret = ioctl(drp_fd, DRP_START, proc);

    bool ioctl_succeed = ((drpai_ret == 0) && (errno == 0));

    if (!ioctl_succeed) {
        spdlog::error("Failed to start(DRP_START). Return code is {}, errno is {}", drpai_ret, errno);
        return false;
    }

    return ioctl_succeed;
}

bool get_status(const int drp_fd) {
    drp_status_t drpai_status;

    errno = 0;
    int drpai_ret = ioctl(drp_fd, DRP_GET_STATUS, &drpai_status);
    bool ioctl_succeed = ((drpai_ret == 0) && (errno == 0));
    bool status_ok = (drpai_status.status == DRP_STATUS_IDLE);
    bool err_is_success = (drpai_status.err == DRP_ERRINFO_SUCCESS);

    bool finished = (ioctl_succeed && status_ok && err_is_success);

    if (finished) {
        drp_device_lock::mutex_drp_device.unlock();
    }

    return finished;
}

uint32_t get_configuration_size(const char* file_path) {
    struct stat statBuf;

    if (stat(file_path, &statBuf) != 0) {
        spdlog::critical("Failed to get the size of {}", file_path);
        exit(EXIT_FAILURE);
    }

    return statBuf.st_size;
}

bool load_bin_configurations(const int drp_fd, const std::shared_ptr<Options> options) {
    bool succeed;
    int ret;
    uintptr_t drp_param_tmp;

    //gaussian_blur_config_size = get_configuration_size(GAUSSIAN_BLUR_CONFIG_PATH);
    gaussian_blur_config_size = GAUSSIAN_BLUR_CONFIG_SIZE;
    //orb_descriptors_config_size = get_configuration_size(ORB_DESCRIPTORS_CONFIG_PATH);
    orb_descriptors_config_size = ORB_DESCRIPTORS_CONFIG_SIZE;
    //resize_config_size = get_configuration_size(RESIZE_CONFIG_PATH);
    resize_config_size = RESIZE_CONFIG_SIZE;

    //if (options->use_cvfast_) {
    //    cvfast_config_size = get_configuration_size(CVFAST_CONFIG_PATH);
    cvfast_config_size = CVFAST_CONFIG_SIZE;
    //}
    //else if (options->use_slamfast_) {
    //    slamfast_config_size = get_configuration_size(SLAMFAST_CONFIG_PATH);
    slamfast_config_size = SLAMFAST_CONFIG_SIZE;
    //}

    /*========== mmnger DRP memory area ==========*/
    gaussian_blur_dma_buf   = (drp_driver_native::dma_buffer*)malloc(sizeof(drp_driver_native::dma_buffer));
    orb_descriptors_dma_buf = (drp_driver_native::dma_buffer*)malloc(sizeof(drp_driver_native::dma_buffer));
    resize_dma_buf          = (drp_driver_native::dma_buffer*)malloc(sizeof(drp_driver_native::dma_buffer));
    cvfast_dma_buf          = (drp_driver_native::dma_buffer*)malloc(sizeof(drp_driver_native::dma_buffer));
    slamfast_dma_buf        = (drp_driver_native::dma_buffer*)malloc(sizeof(drp_driver_native::dma_buffer));

    ret = drp_driver_native::buffer_alloc_dmabuf(gaussian_blur_dma_buf,sizeof(drp_driver_native::gaussian_blur_drp_param_st));
    if (-1 == ret) {
        fprintf(stderr, "[ERROR] Failed to Allocate DMA buffer for the drp\n");
        return false;
    }
    ret = drp_driver_native::buffer_alloc_dmabuf(orb_descriptors_dma_buf,sizeof(drp_driver_native::orb_descriptors_drp_param_st));
    if (-1 == ret) {
        fprintf(stderr, "[ERROR] Failed to Allocate DMA buffer for the drp\n");
        return false;
    }
    ret = drp_driver_native::buffer_alloc_dmabuf(resize_dma_buf,sizeof(drp_driver_native::resize_drp_param_st));
    if (-1 == ret) {
        fprintf(stderr, "[ERROR] Failed to Allocate DMA buffer for the drp\n");
        return false;
    }
    ret = drp_driver_native::buffer_alloc_dmabuf(cvfast_dma_buf,sizeof(drp_driver_native::cvfast_drp_param_st));
    if (-1 == ret) {
        fprintf(stderr, "[ERROR] Failed to Allocate DMA buffer for the drp\n");
        return false;
    }
    ret = drp_driver_native::buffer_alloc_dmabuf(slamfast_dma_buf,sizeof(drp_driver_native::slamfast_drp_param_st));
    if (-1 == ret) {
        fprintf(stderr, "[ERROR] Failed to Allocate DMA buffer for the drp\n");
        return false;
    }

    drp_param_tmp = ((gaussian_blur_dma_buf->phy_addr) & 0xffffffc0) + 0x0040;    /* 64-byte aligned */
    gaussian_blur_drp_param_buf = (drp_driver_native::gaussian_blur_drp_param_st*) drp_param_tmp;
    
    drp_param_tmp = ((orb_descriptors_dma_buf->phy_addr) & 0xffffffc0) + 0x0040;    /* 64-byte aligned */
    orb_descriptors_drp_param_buf = (drp_driver_native::orb_descriptors_drp_param_st*) drp_param_tmp;
    
    drp_param_tmp = ((resize_dma_buf->phy_addr) & 0xffffffc0) + 0x0040;    /* 64-byte aligned */
    resize_drp_param_buf = (drp_driver_native::resize_drp_param_st*) drp_param_tmp;
    
    drp_param_tmp = ((cvfast_dma_buf->phy_addr) & 0xffffffc0) + 0x0040;    /* 64-byte aligned */
    cvfast_drp_param_buf = (drp_driver_native::cvfast_drp_param_st*) drp_param_tmp;
    
    drp_param_tmp = ((slamfast_dma_buf->phy_addr) & 0xffffffc0) + 0x0040;    /* 64-byte aligned */
    slamfast_drp_param_buf = (drp_driver_native::slamfast_drp_param_st*) drp_param_tmp;
    
    pyramid_address[0] = (uintptr_t)resize_drp_param_buf->pyramid0;
    pyramid_address[1] = (uintptr_t)resize_drp_param_buf->pyramid1;
    pyramid_address[2] = (uintptr_t)resize_drp_param_buf->pyramid2;
    pyramid_address[3] = (uintptr_t)resize_drp_param_buf->pyramid3;
    pyramid_address[4] = (uintptr_t)resize_drp_param_buf->pyramid4;
    pyramid_address[5] = (uintptr_t)resize_drp_param_buf->pyramid5;
    pyramid_address[6] = (uintptr_t)resize_drp_param_buf->pyramid6;
    pyramid_address[7] = (uintptr_t)resize_drp_param_buf->pyramid7;
    
    GaussianBlur_output_address[0] = (uintptr_t)gaussian_blur_drp_param_buf->output0;
    GaussianBlur_output_address[1] = (uintptr_t)gaussian_blur_drp_param_buf->output1;
    GaussianBlur_output_address[2] = (uintptr_t)gaussian_blur_drp_param_buf->output2;
    GaussianBlur_output_address[3] = (uintptr_t)gaussian_blur_drp_param_buf->output3;
    GaussianBlur_output_address[4] = (uintptr_t)gaussian_blur_drp_param_buf->output4;
    GaussianBlur_output_address[5] = (uintptr_t)gaussian_blur_drp_param_buf->output5;
    GaussianBlur_output_address[6] = (uintptr_t)gaussian_blur_drp_param_buf->output6;
    GaussianBlur_output_address[7] = (uintptr_t)gaussian_blur_drp_param_buf->output7;
    /*========== mmnger DRP memory area ==========*/

    // Workaround #126
    //drp_gaussian_blur_config_address = DRP_CONFIG_ADDRESS;
    //drp_gaussian_blur_config_address += (DRP_ALIGN_BYTE - (drp_gaussian_blur_config_address % DRP_ALIGN_BYTE));
    drp_gaussian_blur_config_address = (uintptr_t)gaussian_blur_drp_param_buf->config;
    drp_gaussian_blur_param_address  = (uintptr_t)gaussian_blur_drp_param_buf->param;
    printf("addr:0x%010X size:0x%08X gaussian_blur\n", drp_gaussian_blur_config_address, gaussian_blur_config_size);

    //drp_orb_descriptors_config_address = drp_gaussian_blur_config_address + gaussian_blur_config_size;
    //drp_orb_descriptors_config_address += (DRP_ALIGN_BYTE - (drp_orb_descriptors_config_address % DRP_ALIGN_BYTE));
    drp_orb_descriptors_config_address = (uintptr_t)orb_descriptors_drp_param_buf->config;
    drp_orb_descriptors_param_address  = (uintptr_t)orb_descriptors_drp_param_buf->param;
    printf("addr:0x%010X size:0x%08X orb_descriptors\n", drp_orb_descriptors_config_address, orb_descriptors_config_size);

    //drp_resize_config_address = drp_orb_descriptors_config_address + orb_descriptors_config_size;
    //drp_resize_config_address += (DRP_ALIGN_BYTE - (drp_resize_config_address % DRP_ALIGN_BYTE));
    drp_resize_config_address = (uintptr_t)resize_drp_param_buf->config;
    drp_resize_param_address =  (uintptr_t)resize_drp_param_buf->param;
    printf("addr:0x%010X size:0x%08X resize\n", drp_resize_config_address, resize_config_size);

    if (options->use_cvfast_) {
        //drp_cvfast_config_address = drp_resize_config_address + resize_config_size;
        //drp_cvfast_config_address += (DRP_ALIGN_BYTE - (drp_cvfast_config_address % DRP_ALIGN_BYTE));
        drp_cvfast_config_address = (uintptr_t)cvfast_drp_param_buf->config;
        drp_cvfast_param_address =  (uintptr_t)cvfast_drp_param_buf->param;
        printf("addr:0x%010X size:0x%08X cvfast\n", drp_cvfast_config_address, cvfast_config_size);
    }
    else if (options->use_slamfast_) {
        //drp_slamfast_config_address = drp_resize_config_address + resize_config_size;
        //drp_slamfast_config_address += (DRP_ALIGN_BYTE - (drp_slamfast_config_address % DRP_ALIGN_BYTE));
        drp_slamfast_config_address = (uintptr_t)slamfast_drp_param_buf->config;
        drp_slamfast_param_address =  (uintptr_t)slamfast_drp_param_buf->param;
        printf("addr:0x%010X size:0x%08X slamfast\n", drp_slamfast_config_address, slamfast_config_size);
    }

    //assert(drp_gaussian_blur_config_address < drp_orb_descriptors_config_address);
    //assert(drp_orb_descriptors_config_address < drp_resize_config_address);

    //if (options->use_cvfast_) {
    //    assert(drp_resize_config_address < drp_cvfast_config_address);
    //}
    //else if (options->use_slamfast_) {
    //    assert(drp_resize_config_address < drp_slamfast_config_address);
    //}

    assert(DRP_FIRST_ADDRESS <= drp_gaussian_blur_config_address);
    assert(drp_gaussian_blur_config_address <= DRP_LAST_ADDRESS);
    assert(drp_gaussian_blur_config_address % DRP_ALIGN_BYTE == 0);

    assert(DRP_FIRST_ADDRESS <= drp_orb_descriptors_config_address);
    assert(drp_orb_descriptors_config_address <= DRP_LAST_ADDRESS);
    assert(drp_orb_descriptors_config_address % DRP_ALIGN_BYTE == 0);

    assert(DRP_FIRST_ADDRESS <= drp_resize_config_address);
    assert(drp_resize_config_address <= DRP_LAST_ADDRESS);
    assert(drp_resize_config_address % DRP_ALIGN_BYTE == 0);

    if (options->use_cvfast_) {
        assert(DRP_FIRST_ADDRESS <= drp_cvfast_config_address);
        assert(drp_cvfast_config_address <= DRP_LAST_ADDRESS);
        assert(drp_cvfast_config_address % DRP_ALIGN_BYTE == 0);
    }
    else if (options->use_slamfast_) {
        assert(DRP_FIRST_ADDRESS <= drp_slamfast_config_address);
        assert(drp_slamfast_config_address <= DRP_LAST_ADDRESS);
        assert(drp_slamfast_config_address % DRP_ALIGN_BYTE == 0);
    }

    proc[PROC_GAUSSIAN_BLUR_CONFIG].address = drp_gaussian_blur_config_address;
    proc[PROC_GAUSSIAN_BLUR_CONFIG].size = gaussian_blur_config_size;

    succeed = write_configuration_code(drp_fd, GAUSSIAN_BLUR_CONFIG_PATH, &proc[PROC_GAUSSIAN_BLUR_CONFIG]);
    if (!succeed) {
        spdlog::error("Failed to write_configuration_code of gaussian_blur.");
        return false;
    }

    proc[PROC_ORB_DESCRIPTORS_CONFIG].address = drp_orb_descriptors_config_address;
    proc[PROC_ORB_DESCRIPTORS_CONFIG].size = orb_descriptors_config_size;

    succeed = write_configuration_code(drp_fd, ORB_DESCRIPTORS_CONFIG_PATH, &proc[PROC_ORB_DESCRIPTORS_CONFIG]);
    if (!succeed) {
        spdlog::error("Failed to write_configuration_code of compute_orb_descriptors.");
        return false;
    }

    proc[PROC_RESIZE_CONFIG].address = drp_resize_config_address;
    proc[PROC_RESIZE_CONFIG].size = resize_config_size;

    succeed = write_configuration_code(drp_fd, RESIZE_CONFIG_PATH, &proc[PROC_RESIZE_CONFIG]);
    if (!succeed) {
        spdlog::error("Failed to write_configuration_code of resize.");
        return false;
    }

    if (options->use_cvfast_) {
        proc[PROC_CVFAST_CONFIG].address = drp_cvfast_config_address;
        proc[PROC_CVFAST_CONFIG].size = cvfast_config_size;

        succeed = write_configuration_code(drp_fd, CVFAST_CONFIG_PATH, &proc[PROC_CVFAST_CONFIG]);
        if (!succeed) {
            spdlog::error("Failed to write_configuration_code of cvfast.");
            return false;
        }
    }
    else if (options->use_slamfast_) {
        proc[PROC_SLAMFAST_CONFIG].address = drp_slamfast_config_address;
        proc[PROC_SLAMFAST_CONFIG].size = slamfast_config_size;

        succeed = write_configuration_code(drp_fd, SLAMFAST_CONFIG_PATH, &proc[PROC_SLAMFAST_CONFIG]);
        if (!succeed) {
            spdlog::error("Failed to write_configuration_code of slamfast.");
            return false;
        }
    }

    return true;
}

bool memory_free() {

    buffer_free_dmabuf(gaussian_blur_dma_buf);
    buffer_free_dmabuf(orb_descriptors_dma_buf);
    buffer_free_dmabuf(resize_dma_buf);
    buffer_free_dmabuf(cvfast_dma_buf);
    buffer_free_dmabuf(slamfast_dma_buf);
    
    free(gaussian_blur_dma_buf);
    free(orb_descriptors_dma_buf);
    free(resize_dma_buf);
    free(cvfast_dma_buf);
    free(slamfast_dma_buf);

    return true;
}

bool resize_setup(const int drp_fd, const image_position_t image_position, const size_t input_level) {
    const uint32_t iodata_num = 2;
    iodata_info_st iodata[iodata_num];

    // Input
    iodata[0].address = pyramid_address[input_level];
    iodata[0].size = MAX_WIDTH * MAX_HEIGHT;
    iodata[0].pos = 0;

    // Output
    iodata[1].address = pyramid_address[input_level + 1];
    iodata[1].size = MAX_WIDTH * MAX_HEIGHT;
    iodata[1].pos = 4;

    MT_START(mt_drp_resize_activate[(uint8_t)image_position]);
    bool activate_succeed = activate(drp_fd, iodata, iodata_num);
    MT_FINISH(mt_drp_resize_activate[(uint8_t)image_position]);

    if (!activate_succeed) {
        spdlog::error("Failed to activate in resize_setup.");
        return false;
    }
    return true;
}

bool resize_start(const int drp_fd, const image_position_t image_position, const cv::Mat& src, const size_t input_level, const cv::Size output_image_size) {
    assert(src.type() == CV_8UC1);
    assert(src.isContinuous());

    bool succeed;

    const uint32_t image_bytes = sizeof(uint8_t) * src.rows * src.cols;

    assert(image_bytes <= max_image_data_size[input_level]);

    drp_data_t input_data;
    input_data.address = pyramid_address[input_level];
    input_data.size = image_bytes;

    MT_START(mt_drp_resize_u2p_input[(uint8_t)image_position][input_level + 1]);
    succeed = memcpy_u2p(drp_fd, src.data, &input_data);
    MT_FINISH(mt_drp_resize_u2p_input[(uint8_t)image_position][input_level + 1]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of input data in resize_start.");
        return false;
    }

    return resize_start(drp_fd, image_position, cv::Size(src.cols, src.rows), input_level, output_image_size);
}

bool resize_start(const int drp_fd, const image_position_t image_position, const cv::Size input_image_size, const size_t input_level, const cv::Size output_image_size) {
    bool succeed;

    assert(MIN_WIDTH <= input_image_size.width);
    assert(MIN_HEIGHT <= input_image_size.height);
    assert(input_image_size.width <= MAX_WIDTH);
    assert(input_image_size.height <= MAX_HEIGHT);

    assert(input_level < 8);

    assert(MIN_WIDTH <= output_image_size.width);
    assert(MIN_HEIGHT <= output_image_size.height);
    assert(output_image_size.width <= MAX_WIDTH);
    assert(output_image_size.height <= MAX_HEIGHT);

    uint32_t parameter[14];

    const uint32_t image_bytes = sizeof(uint8_t) * input_image_size.width * input_image_size.height;
    assert(image_bytes <= max_image_data_size[input_level]);

    MT_START(mt_drp_resize_calc_param[(uint8_t)image_position][input_level + 1]);
    parameter[0] = pyramid_address[input_level];     // input
    parameter[1] = pyramid_address[input_level + 1]; // output
    parameter[2] = input_image_size.width + (input_image_size.height << 16);
    parameter[3] = 1; // input channel
    parameter[4] = output_image_size.width + (output_image_size.height << 16);
    parameter[5] = 1; // output channel
    // OCH0_SYYNCSET_DT ～ OCH3_SYYNCSET_ID
    parameter[6] = 0;
    parameter[7] = 0;
    parameter[8] = 0;
    parameter[9] = 0;
    parameter[10] = 0; // INT_DISABLE
    parameter[11] = 0;
    parameter[12] = 1; // algorithm, data_type
    parameter[13] = 0;
    MT_FINISH(mt_drp_resize_calc_param[(uint8_t)image_position][input_level + 1]);

    //proc[PROC_RESIZE_PARAM].address = DRP_PARAM_ADDRESS;
    proc[PROC_RESIZE_PARAM].address = drp_resize_param_address;
    proc[PROC_RESIZE_PARAM].size = 14 * 4;

    MT_START(mt_drp_resize_u2p_param[(uint8_t)image_position][input_level + 1]);
    succeed = memcpy_u2p(drp_fd, parameter, &proc[PROC_RESIZE_PARAM]);
    MT_FINISH(mt_drp_resize_u2p_param[(uint8_t)image_position][input_level + 1]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of parameter in resize_start.");
        return false;
    }

    proc[PROC_RESIZE_CONFIG].address = drp_resize_config_address;
    proc[PROC_RESIZE_CONFIG].size = resize_config_size;

    MT_START(mt_drp_resize_start[(uint8_t)image_position][input_level + 1]);
    bool start_succeed = start(drp_fd, &proc[PROC_RESIZE_CONFIG]);
    MT_FINISH(mt_drp_resize_start[(uint8_t)image_position][input_level + 1]);

    if (!start_succeed) {
        spdlog::error("Failed to start in resize_start.");
        return false;
    }

    MT_SUM_START(mt_drp_time[(uint8_t)image_position][drp_driver_native::STATE_RESIZE][input_level + 1]);

    return true;
}

bool resize_finish(const int drp_fd, const image_position_t image_position, const size_t input_level, const cv::Size output_image_size, cv::Mat& dst) {
    bool succeed;

    assert(0 < drp_fd);

    assert(input_level < 8);

    assert(MIN_WIDTH <= output_image_size.width);
    assert(MIN_HEIGHT <= output_image_size.height);
    assert(output_image_size.width <= MAX_WIDTH);
    assert(output_image_size.height <= MAX_HEIGHT);

    bool finished = get_status(drp_fd);
    if (finished) {
        MT_SUM_FINISH(mt_drp_time[(uint8_t)image_position][drp_driver_native::STATE_RESIZE][input_level + 1]);
    }

    if (!finished) {
        return false;
    }

    const uint32_t image_bytes = sizeof(uint8_t) * output_image_size.width * output_image_size.height;
    uint8_t data[image_bytes];

    assert(image_bytes <= max_image_data_size[input_level + 1]);

    drp_data_t output_data;
    output_data.address = pyramid_address[input_level + 1];
    output_data.size = image_bytes;

    MT_START(mt_drp_resize_p2u[(uint8_t)image_position][input_level + 1]);
    succeed = memcpy_p2u(drp_fd, data, &output_data);
    MT_FINISH(mt_drp_resize_p2u[(uint8_t)image_position][input_level + 1]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_p2u of input data in resize_finish.");
        return false;
    }

    MT_START(mt_drp_resize_clone_output_mat[(uint8_t)image_position][input_level + 1]);
    cv::Mat temp(output_image_size.height, output_image_size.width, CV_8UC1, data);
    dst = temp.clone();
    MT_FINISH(mt_drp_resize_clone_output_mat[(uint8_t)image_position][input_level + 1]);

    return true;
}

bool resize(const int drp_fd, const image_position_t image_position, const cv::Mat& src, const size_t input_level, const cv::Size output_image_size, cv::Mat& dst) {
    /*
      src.type() == CV_8UC1
      src.isContinuous() == true
      dst.type() == CV_8UC1
      dst.isContinuous() == true
    */
    spdlog::trace("Start drp_driver_native::resize(input_level={})", input_level);
    spdlog::trace("  output_image_size.width  : {}", output_image_size.width);
    spdlog::trace("  output_image_size.height : {}", output_image_size.height);

    bool setup_succeed = resize_setup(drp_fd, image_position, input_level);
    if (!setup_succeed) {
        spdlog::error("resize_setup error");
        activate_mode = STATE_NONE;
        return false;
    }
    activate_mode = STATE_RESIZE;

    bool start_succeed = resize_start(drp_fd, image_position, src, input_level, output_image_size);
    if (!start_succeed) {
        spdlog::error("resize_start error");
        return false;
    }

    // busy wait
    const clock_t start = clock();
    while (true) {
        bool finish_succeed = resize_finish(drp_fd, image_position, input_level, output_image_size, dst);
        if (finish_succeed) {
            break;
        }

        clock_t now = clock();
        double sec = (double)(now - start) / CLOCKS_PER_SEC;
        if (WAITING_TIME < sec) {
            spdlog::critical("Failed to drp_driver_native::resize");
            exit(EXIT_FAILURE);
        }
    }

    spdlog::trace("Finish drp_driver_native::resize(input_level={})", input_level);

    return true;
}

bool gaussian_blur_setup(const int drp_fd, const image_position_t image_position, const size_t level) {
    //const uint32_t input_address = (level == 0) ? DRP_RESIZE_INPUT_ADDRESS : (DRP_GAUSSIAN_BLUR_INPUT_ADDRESS + image_data_stride[level]);
    const uint32_t input_address = (uintptr_t)pyramid_address[level];
    //const uint32_t output_address = DRP_GAUSSIAN_BLUR_OUTPUT_ADDRESS + image_data_stride[level];
    const uint32_t output_address = (uintptr_t)GaussianBlur_output_address[level];

    const uint32_t iodata_num = 2;
    iodata_info_st iodata[iodata_num];

    // Input
    iodata[0].address = input_address;
    iodata[0].size = MAX_WIDTH * MAX_HEIGHT;
    iodata[0].pos = 0;

    // Output
    iodata[1].address = output_address;
    iodata[1].size = MAX_WIDTH * MAX_HEIGHT;
    iodata[1].pos = 4;

    MT_START(mt_drp_gaussian_blur_activate[(uint8_t)image_position]);
    bool activate_succeed = activate(drp_fd, iodata, iodata_num);
    MT_FINISH(mt_drp_gaussian_blur_activate[(uint8_t)image_position]);

    if (!activate_succeed) {
        spdlog::error("Failed to activate in gaussian_blur_setup.");
        return false;
    }
    return true;
}

bool gaussian_blur_start(const int drp_fd, const image_position_t image_position, const cv::Mat& src, const size_t level) {
    assert(src.type() == CV_8UC1);
    assert(src.isContinuous());

    bool succeed;

    const uint32_t image_bytes = sizeof(uint8_t) * src.rows * src.cols;
    //const uint32_t input_address = (level == 0) ? DRP_RESIZE_INPUT_ADDRESS : (DRP_GAUSSIAN_BLUR_INPUT_ADDRESS + image_data_stride[level]);
    const uint32_t input_address = (uintptr_t)pyramid_address[level];

    drp_data_t input_data;
    input_data.address = input_address;
    input_data.size = image_bytes;

    MT_START(mt_drp_gaussian_blur_u2p_input[(uint8_t)image_position][level]);
    succeed = memcpy_u2p(drp_fd, src.data, &input_data);
    MT_FINISH(mt_drp_gaussian_blur_u2p_input[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of input data in gaussian_blur_start.");
        return false;
    }

    return gaussian_blur_start(drp_fd, image_position, src.cols, src.rows, level);
}

bool gaussian_blur_start(const int drp_fd, const image_position_t image_position, const uint16_t cols, const uint16_t rows, const size_t level) {
    assert(0 < drp_fd);

    bool succeed;

    assert(MIN_WIDTH <= cols);
    assert(MIN_HEIGHT <= rows);
    assert(cols <= MAX_WIDTH);
    assert(rows <= MAX_HEIGHT);
    assert(level < 8);

    uint32_t parameter[4];

    //const uint32_t input_address = (level == 0) ? DRP_RESIZE_INPUT_ADDRESS : (DRP_GAUSSIAN_BLUR_INPUT_ADDRESS + image_data_stride[level]);
    const uint32_t input_address = (uintptr_t)pyramid_address[level];
    //const uint32_t output_address = DRP_GAUSSIAN_BLUR_OUTPUT_ADDRESS + image_data_stride[level];
    const uint32_t output_address =  (uintptr_t)GaussianBlur_output_address[level];

    MT_START(mt_drp_gaussian_blur_calc_param[(uint8_t)image_position][level]);
    parameter[0] = input_address;
    parameter[1] = output_address;
    parameter[2] = cols + (rows << 16);
    parameter[3] = 0;
    MT_FINISH(mt_drp_gaussian_blur_calc_param[(uint8_t)image_position][level]);

    //proc[PROC_GAUSSIAN_BLUR_PARAM].address = DRP_PARAM_ADDRESS;
    proc[PROC_GAUSSIAN_BLUR_PARAM].address = drp_gaussian_blur_param_address;
    proc[PROC_GAUSSIAN_BLUR_PARAM].size = 4 * 4;

    MT_START(mt_drp_gaussian_blur_u2p_param[(uint8_t)image_position][level]);
    succeed = memcpy_u2p(drp_fd, parameter, &proc[PROC_GAUSSIAN_BLUR_PARAM]);
    MT_FINISH(mt_drp_gaussian_blur_u2p_param[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of parameter in gaussian_blur_start.");
        return false;
    }

    proc[PROC_GAUSSIAN_BLUR_CONFIG].address = drp_gaussian_blur_config_address;
    proc[PROC_GAUSSIAN_BLUR_CONFIG].size = gaussian_blur_config_size;

    MT_START(mt_drp_gaussian_blur_start[(uint8_t)image_position][level]);
    bool start_succeed = start(drp_fd, &proc[PROC_GAUSSIAN_BLUR_CONFIG]);
    MT_FINISH(mt_drp_gaussian_blur_start[(uint8_t)image_position][level]);

    if (!start_succeed) {
        spdlog::error("Failed to start in gaussian_blur_start.");
        return false;
    }

    MT_SUM_START(mt_drp_time[(uint8_t)image_position][drp_driver_native::STATE_GAUSSIAN_BLUR][level]);

    return true;
}

bool gaussian_blur_finish(const int drp_fd, const image_position_t image_position, const size_t level) {
    assert(0 < drp_fd);

    bool finished = get_status(drp_fd);
    if (finished) {
        MT_SUM_FINISH(mt_drp_time[(uint8_t)image_position][drp_driver_native::STATE_GAUSSIAN_BLUR][level]);
    }

    return finished;
}

bool gaussian_blur_finish(const int drp_fd, const image_position_t image_position, const size_t level, cv::Mat& dst) {
    bool succeed;

    assert(dst.type() == CV_8UC1);
    assert(dst.isContinuous());
    assert(MIN_WIDTH <= dst.cols);
    assert(MIN_HEIGHT <= dst.rows);
    assert(dst.cols <= MAX_WIDTH);
    assert(dst.rows <= MAX_HEIGHT);
    assert(level < 8);

    const uint32_t image_bytes = sizeof(uint8_t) * dst.rows * dst.cols;

    bool finished = gaussian_blur_finish(drp_fd, image_position, level);
    if (!finished) {
        return false;
    }

    //const uint32_t output_address = DRP_GAUSSIAN_BLUR_OUTPUT_ADDRESS + image_data_stride[level];
    const uint32_t output_address =  (uintptr_t)GaussianBlur_output_address[level];

    drp_data_t output_data;
    output_data.address = output_address;
    output_data.size = image_bytes;

    MT_START(mt_drp_gaussian_blur_p2u[(uint8_t)image_position][level]);
    succeed = memcpy_p2u(drp_fd, dst.data, &output_data);
    MT_FINISH(mt_drp_gaussian_blur_p2u[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_p2u of input data in gaussian_blur_finish.");
        return false;
    }

    return true;
}

bool gaussian_blur(const int drp_fd, const image_position_t image_position, const cv::Mat& src, const size_t level, cv::Mat& dst) {
    /*
    src.type() == CV_8UC1
    src.isContinuous() == true
    dst.type() == CV_8UC1
    dst.isContinuous() == true
    ksize == cv::Size(7, 7)
    sigma1 == 2.0
    sigma2 == 2.0
    borderType == cv::BORDER_REFLECT_101
    */
    spdlog::trace("Start drp_driver_native::gaussian_blur(level={})", level);

    bool setup_succeed = gaussian_blur_setup(drp_fd, image_position, level);
    if (!setup_succeed) {
        spdlog::error("gaussian_blur_setup error");
        activate_mode = STATE_NONE;
        return false;
    }
    activate_mode = STATE_GAUSSIAN_BLUR;

    bool start_succeed = gaussian_blur_start(drp_fd, image_position, src, level);
    if (!start_succeed) {
        spdlog::error("gaussian_blur_start error");
        return false;
    }

    // busy wait
    const clock_t start = clock();
    while (true) {
        bool finish_succeed = gaussian_blur_finish(drp_fd, image_position, level, dst);
        if (finish_succeed) {
            break;
        }

        usleep(500); // Sleep 0.5ms
        clock_t now = clock();
        double sec = (double)(now - start) / CLOCKS_PER_SEC;
        if (WAITING_TIME < sec) {
            spdlog::critical("Failed to drp_driver_native::gaussian_blur");
            exit(EXIT_FAILURE);
        }
    }

    spdlog::trace("Finish drp_driver_native::gaussian_blur(level={})", level);

    return true;
}

bool cvfast_setup(const int drp_fd, const image_position_t image_position) {
    const uint32_t iodata_num = 3;
    iodata_info_st iodata[iodata_num];

    // Input
    //iodata[0].address = DRP_CVFAST_INPUT_ADDRESS;
    iodata[0].address = (uintptr_t)cvfast_drp_param_buf->input;
    iodata[0].size = MAX_CELL_SIZE * MAX_CELL_SIZE;
    iodata[0].pos = 0;

    // Output
    //iodata[1].address = DRP_CVFAST_OUTPUT_ADDRESS;
    iodata[1].address = (uintptr_t)cvfast_drp_param_buf->output;
    iodata[1].size = MAX_KEYPOINTS * 8;
    iodata[1].pos = 4;
    //iodata[2].address = DRP_OPTIONAL_ADDRESS;
    iodata[2].address = (uintptr_t)cvfast_drp_param_buf->optional;
    iodata[2].size = 2;
    iodata[2].pos = 8;

    MT_SUM_START(mt_drp_cvfast_activate[(uint8_t)image_position]);
    bool activate_succeed = activate(drp_fd, iodata, iodata_num);
    MT_SUM_FINISH(mt_drp_cvfast_activate[(uint8_t)image_position]);

    if (!activate_succeed) {
        spdlog::error("Failed to activate in cvfast_setup.");
        return false;
    }
    return true;
}

bool cvfast_start(const int drp_fd, const image_position_t image_position, const cv::Mat& src, const size_t level, const unsigned int thresholds[2]) {
    bool succeed;

    assert(0 < cvfast_config_size && "cvfast is not initialized.");

    assert(src.type() == CV_8UC1);
    assert(src.isContinuous());
    assert(level < 8);
    assert(thresholds[0] > thresholds[1] && "thresholds[1] must be smaller than thresholds[0]");

    const uint32_t image_bytes = sizeof(uint8_t) * src.rows * src.cols;
    uint32_t parameter[6];
    uint16_t zeros[2] = {0, 0};

    MT_SUM_START(mt_drp_cvfast_calc_param[(uint8_t)image_position][level]);
    //parameter[0] = DRP_CVFAST_INPUT_ADDRESS;
    parameter[0] = (uintptr_t)cvfast_drp_param_buf->input;
    //parameter[1] = DRP_CVFAST_OUTPUT_ADDRESS; // consider w_addr_keypoints
    parameter[1] = (uintptr_t)cvfast_drp_param_buf->output;
    //parameter[2] = DRP_OPTIONAL_ADDRESS;      // consider w_addr_num
    parameter[2] = (uintptr_t)cvfast_drp_param_buf->optional;
    parameter[3] = src.cols + (src.rows << 16);
    parameter[4] = thresholds[0] + (thresholds[1] << 16);
    parameter[5] = 0; // 0 padding
    MT_SUM_FINISH(mt_drp_cvfast_calc_param[(uint8_t)image_position][level]);

    //proc[PROC_CVFAST_PARAM].address = DRP_PARAM_ADDRESS;
    proc[PROC_CVFAST_PARAM].address = drp_cvfast_param_address;
    proc[PROC_CVFAST_PARAM].size = 6 * 4;

    MT_SUM_START(mt_drp_cvfast_u2p_param[(uint8_t)image_position][level]);
    succeed = memcpy_u2p(drp_fd, parameter, &proc[PROC_CVFAST_PARAM]);
    MT_SUM_FINISH(mt_drp_cvfast_u2p_param[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of parameter in cvfast_start.");
        return false;
    }

    assert(MIN_CELL_SIZE <= src.rows);
    assert(MIN_CELL_SIZE <= src.cols);
    assert(src.rows <= MAX_CELL_SIZE);
    assert(src.cols <= MAX_CELL_SIZE);
    assert(0 < image_bytes);
    assert(image_bytes <= MAX_CELL_SIZE * MAX_CELL_SIZE);

    drp_data_t input_data;
    //input_data.address = DRP_CVFAST_INPUT_ADDRESS;
    input_data.address = (uintptr_t)cvfast_drp_param_buf->input;
    input_data.size = image_bytes;

    MT_SUM_START(mt_drp_cvfast_u2p_input[(uint8_t)image_position][level]);
    succeed = memcpy_u2p(drp_fd, src.data, &input_data);
    MT_SUM_FINISH(mt_drp_cvfast_u2p_input[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of input data in cvfast_start.");
        return false;
    }

    drp_data_t result_size;
    //result_size.address = DRP_OPTIONAL_ADDRESS;
    result_size.address = (uintptr_t)cvfast_drp_param_buf->optional;
    result_size.size = 2;

    // clear old keypoints_size
    succeed = memcpy_u2p(drp_fd, zeros, &result_size);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of zero clear in cvfast_start.");
        return false;
    }

    proc[PROC_CVFAST_CONFIG].address = drp_cvfast_config_address;
    proc[PROC_CVFAST_CONFIG].size = cvfast_config_size;

    MT_SUM_START(mt_drp_cvfast_start[(uint8_t)image_position][level]);
    bool start_succeed = start(drp_fd, &proc[PROC_CVFAST_CONFIG]);
    MT_SUM_FINISH(mt_drp_cvfast_start[(uint8_t)image_position][level]);

    if (!start_succeed) {
        spdlog::error("Failed to start in cvfast_start.");
        return false;
    }

    MT_SUM_START(mt_drp_time[(uint8_t)image_position][drp_driver_native::STATE_CVFAST][level]);

    return true;
}

bool cvfast_finish(const int drp_fd, const image_position_t image_position, const size_t level, std::vector<cv::KeyPoint>& dst) {
    bool succeed;

    assert(0 < drp_fd);

    assert(level < 8);

    bool finished = get_status(drp_fd);
    if (finished) {
        MT_SUM_FINISH(mt_drp_time[(uint8_t)image_position][drp_driver_native::STATE_CVFAST][level]);
    }

    if (!finished) {
        return false;
    }

    KeyPoint_FAST keypoints[MAX_KEYPOINTS];
    uint16_t keypoints_size;

    drp_data_t output_size;
    //output_size.address = DRP_OPTIONAL_ADDRESS;
    output_size.address = (uintptr_t)cvfast_drp_param_buf->optional;
    output_size.size = 2;

    MT_SUM_START(mt_drp_cvfast_p2u_keypoints_size[(uint8_t)image_position][level]);
    succeed = memcpy_p2u(drp_fd, &keypoints_size, &output_size);
    MT_SUM_FINISH(mt_drp_cvfast_p2u_keypoints_size[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_p2u of input data in cvfast_finish.");
        return false;
    }

    if (keypoints_size == 0) {
        return true;
    }

    // assert(keypoints_size <= MAX_KEYPOINTS);

    drp_data_t output_data;
    //output_data.address = DRP_CVFAST_OUTPUT_ADDRESS;
    output_data.address = (uintptr_t)cvfast_drp_param_buf->output;
    output_data.size = keypoints_size * 8;

    MT_SUM_START(mt_drp_cvfast_p2u_keypoints[(uint8_t)image_position][level]);
    succeed = memcpy_p2u(drp_fd, keypoints, &output_data);
    MT_SUM_FINISH(mt_drp_cvfast_p2u_keypoints[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_p2u of input data in cvfast_finish.");
        return false;
    }

    MT_SUM_START(mt_drp_cvfast_cast_to_cv[(uint8_t)image_position][level]);
    for (uint16_t i = 0; i < keypoints_size; i++) {
        cv::KeyPoint kp;
        kp.pt.x = keypoints[i].pt.x;
        kp.pt.y = keypoints[i].pt.y;
        kp.response = (int16_t)(keypoints[i].response & 0xFF);
        kp.size = 7.f;
        dst.emplace_back(kp);
    }
    MT_SUM_FINISH(mt_drp_cvfast_cast_to_cv[(uint8_t)image_position][level]);

    return true;
}

bool cvfast(const int drp_fd, const image_position_t image_position, const cv::Mat& src, const size_t level, const unsigned int thresholds[2], std::vector<cv::KeyPoint>& dst) {
    /*
      src.type() == CV_8UC1
      src.isContinuous() == true
      nonmax_suppression == true
    */
    spdlog::trace("Start drp_driver_native::cvfast(level={})", level);

    // Since input/output address is fixed, it may not be necessary to re-execute ioctl(DRP_SET_SEQ).
    if (activate_mode != STATE_CVFAST) {
        bool setup_succeed = cvfast_setup(drp_fd, image_position);
        if (!setup_succeed) {
            spdlog::error("cvfast_setup error");
            activate_mode = STATE_NONE;
            return false;
        }
        activate_mode = STATE_CVFAST;
    }

    bool start_succeed = cvfast_start(drp_fd, image_position, src, level, thresholds);
    if (!start_succeed) {
        spdlog::error("cvfast_start error");
        return false;
    }

    // busy wait
    clock_t start = clock();
    while (true) {
        bool finish_succeed = cvfast_finish(drp_fd, image_position, level, dst);
        if (finish_succeed) {
            break;
        }

        clock_t now = clock();
        double sec = (double)(now - start) / CLOCKS_PER_SEC;
        if (WAITING_TIME < sec) {
            spdlog::critical("Failed to drp_driver_native::cvfast");
            exit(EXIT_FAILURE);
        }
    }

    spdlog::trace("Finish drp_driver_native::cvfast(level={})", level);

    return true;
}

bool slamfast_setup(const int drp_fd, const image_position_t image_position, const size_t level) {
    const uint32_t iodata_num = 3;
    iodata_info_st iodata[iodata_num];

    // Input
    iodata[0].address = pyramid_address[level];
    iodata[0].size = MAX_WIDTH * MAX_HEIGHT;
    iodata[0].pos = 0;

    // Output
    //iodata[1].address = DRP_SLAMFAST_OUTPUT_ADDRESS;
    iodata[1].address = (uintptr_t)slamfast_drp_param_buf->output;
    iodata[1].size = MAX_KEYPOINTS * 8;
    iodata[1].pos = 4;
    //iodata[2].address = DRP_OPTIONAL_ADDRESS;
    iodata[2].address = (uintptr_t)slamfast_drp_param_buf->optional;
    iodata[2].size = 2;
    iodata[2].pos = 8;

    MT_START(mt_drp_slamfast_activate[(uint8_t)image_position]);
    bool activate_succeed = activate(drp_fd, iodata, iodata_num);
    MT_FINISH(mt_drp_slamfast_activate[(uint8_t)image_position]);

    if (!activate_succeed) {
        spdlog::error("Failed to activate in slamfast_setup.");
        return false;
    }
    return true;
}

bool slamfast_start(const int drp_fd, const image_position_t image_position, const cv::Mat& src, const size_t level) {
    assert(src.type() == CV_8UC1);
    assert(src.isContinuous());

    bool succeed;

    const uint32_t image_bytes = sizeof(uint8_t) * src.rows * src.cols;

    assert(image_bytes <= max_image_data_size[level]);

    drp_data_t input_data;
    input_data.address = pyramid_address[level];
    input_data.size = image_bytes;

    MT_START(mt_drp_slamfast_u2p_input[(uint8_t)image_position][level]);
    succeed = memcpy_u2p(drp_fd, src.data, &input_data);
    MT_FINISH(mt_drp_slamfast_u2p_input[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of input data in slamfast_start.");
        return false;
    }

    return slamfast_start(drp_fd, image_position, src.cols, src.rows, level);
}

bool slamfast_start(const int drp_fd, const image_position_t image_position, const uint16_t cols, const uint16_t rows, const size_t level) {
    bool succeed;

    assert(MIN_WIDTH <= cols);
    assert(MIN_HEIGHT <= rows);
    assert(cols <= MAX_WIDTH);
    assert(rows <= MAX_HEIGHT);

    assert(level < 8);

    uint32_t parameter[4];
    uint16_t zeros[2] = {0, 0};

    MT_START(mt_drp_slamfast_calc_param[(uint8_t)image_position][level]);
    parameter[0] = pyramid_address[level];
    //parameter[1] = DRP_SLAMFAST_OUTPUT_ADDRESS; // consider w_addr_keypoints
    parameter[1] = (uintptr_t)slamfast_drp_param_buf->output;
    //parameter[2] = DRP_OPTIONAL_ADDRESS;        // consider w_addr_num
    parameter[2] = (uintptr_t)slamfast_drp_param_buf->optional;
    parameter[3] = cols + (rows << 16);
    MT_FINISH(mt_drp_slamfast_calc_param[(uint8_t)image_position][level]);

    //proc[PROC_SLAMFAST_PARAM].address = DRP_PARAM_ADDRESS;
    proc[PROC_SLAMFAST_PARAM].address = drp_slamfast_param_address;
    proc[PROC_SLAMFAST_PARAM].size = 4 * 4;

    MT_SUM_START(mt_drp_slamfast_u2p_param[(uint8_t)image_position][level]);
    succeed = memcpy_u2p(drp_fd, parameter, &proc[PROC_SLAMFAST_PARAM]);
    MT_SUM_FINISH(mt_drp_slamfast_u2p_param[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of parameter in slamfast_start.");
        return false;
    }

    drp_data_t result_size;
    //result_size.address = DRP_OPTIONAL_ADDRESS;
    result_size.address = (uintptr_t)slamfast_drp_param_buf->optional;
    result_size.size = 2;

    // clear old keypoints_size
    succeed = memcpy_u2p(drp_fd, zeros, &result_size);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of zero clear in slamfast_start.");
        return false;
    }

    proc[PROC_SLAMFAST_CONFIG].address = drp_slamfast_config_address;
    proc[PROC_SLAMFAST_CONFIG].size = slamfast_config_size;

    MT_SUM_START(mt_drp_slamfast_start[(uint8_t)image_position][level]);
    bool start_succeed = start(drp_fd, &proc[PROC_SLAMFAST_CONFIG]);
    MT_SUM_FINISH(mt_drp_slamfast_start[(uint8_t)image_position][level]);

    if (!start_succeed) {
        spdlog::error("Failed to start in slamfast_start.");
        return false;
    }

    MT_SUM_START(mt_drp_time[(uint8_t)image_position][drp_driver_native::STATE_SLAMFAST][level]);

    return true;
}

bool slamfast_finish(const int drp_fd, const image_position_t image_position, const size_t level, std::vector<cv::KeyPoint>& dst) {
    bool succeed;

    assert(0 < drp_fd);

    assert(level < 8);

    bool finished = get_status(drp_fd);
    if (finished) {
        MT_SUM_FINISH(mt_drp_time[(uint8_t)image_position][drp_driver_native::STATE_SLAMFAST][level]);
    }

    if (!finished) {
        return false;
    }

    KeyPoint_FAST keypoints[MAX_KEYPOINTS];
    uint16_t keypoints_size;

    drp_data_t output_size;
    //output_size.address = DRP_OPTIONAL_ADDRESS;
    output_size.address = (uintptr_t)slamfast_drp_param_buf->optional;
    output_size.size = 2;

    MT_SUM_START(mt_drp_slamfast_p2u_keypoints_size[(uint8_t)image_position][level]);
    succeed = memcpy_p2u(drp_fd, &keypoints_size, &output_size);
    MT_SUM_FINISH(mt_drp_slamfast_p2u_keypoints_size[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_p2u of input data in slamfast_finish.");
        return false;
    }

    if (keypoints_size == 0) {
        return true;
    }

    // assert(keypoints_size <= MAX_KEYPOINTS);

    drp_data_t output_data;
    //output_data.address = DRP_SLAMFAST_OUTPUT_ADDRESS;
    output_data.address = (uintptr_t)slamfast_drp_param_buf->output;
    output_data.size = keypoints_size * 8;

    MT_SUM_START(mt_drp_slamfast_p2u_keypoints[(uint8_t)image_position][level]);
    succeed = memcpy_p2u(drp_fd, keypoints, &output_data);
    MT_SUM_FINISH(mt_drp_slamfast_p2u_keypoints[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_p2u of input data in slamfast_finish.");
        return false;
    }

    //////////////////

    MT_START(mt_drp_slamfast_cast_to_cv[(uint8_t)image_position][level]);
    for (uint16_t i = 0; i < keypoints_size; i++) {
        cv::KeyPoint kp;
        kp.pt.x = keypoints[i].pt.x;
        kp.pt.y = keypoints[i].pt.y;
        kp.response = (int16_t)(keypoints[i].response & 0xFF);
        kp.size = 7.f;
        dst.emplace_back(kp);
    }
    MT_FINISH(mt_drp_slamfast_cast_to_cv[(uint8_t)image_position][level]);

    return true;
}

bool slamfast(const int drp_fd, const image_position_t image_position, const cv::Mat& src, const size_t level, std::vector<cv::KeyPoint>& dst) {
    /*
    src.type() == CV_8UC1
    src.isContinuous() == true
    nonmax_suppression == true
    threshold == 20, 7
    */
    spdlog::trace("Start drp_driver_native::slamfast(level={})", level);

    bool setup_succeed = slamfast_setup(drp_fd, image_position, level);
    if (!setup_succeed) {
        spdlog::error("slamfast_setup error");
        activate_mode = STATE_NONE;
        return false;
    }
    activate_mode = STATE_SLAMFAST;

    bool start_succeed = slamfast_start(drp_fd, image_position, src, level);
    if (!start_succeed) {
        spdlog::error("slamfast_start error");
        return false;
    }

    // busy wait
    const clock_t start = clock();
    while (true) {
        bool finish_succeed = slamfast_finish(drp_fd, image_position, level, dst);
        if (finish_succeed) {
            break;
        }

        clock_t now = clock();
        double sec = (double)(now - start) / CLOCKS_PER_SEC;
        if (WAITING_TIME < sec) {
            spdlog::critical("Failed to drp_driver_native::slamfast");
            exit(EXIT_FAILURE);
        }
    }

    spdlog::trace("Finish drp_driver_native::slamfast(level={})", level);

    return true;
}

bool compute_orb_descriptors_setup(const int drp_fd, const image_position_t image_position, const size_t level) {
    //const uint32_t input_image_address = DRP_ORB_DESCRIPTORS_INPUT_IMAGE_ADDRESS + image_data_stride[level];
    const uint32_t input_image_address = (uintptr_t)GaussianBlur_output_address[level];

    const uint32_t iodata_num = 3;
    iodata_info_st iodata[iodata_num];

    // Input
    iodata[0].address = input_image_address;
    iodata[0].size = MAX_WIDTH * MAX_HEIGHT;
    iodata[0].pos = 0;
    //iodata[1].address = DRP_ORB_DESCRIPTORS_INPUT_KEYPOINTS_ADDRESS;
    iodata[1].address = (uintptr_t)orb_descriptors_drp_param_buf->input_keypoint;
    iodata[1].size = MAX_NFEATURES * 8;
    iodata[1].pos = 4;

    // Output
    //iodata[2].address = DRP_ORB_DESCRIPTORS_OUTPUT_ADDRESS;
    iodata[2].address = (uintptr_t)orb_descriptors_drp_param_buf->output;
    iodata[2].size = MAX_NFEATURES * 32;
    iodata[2].pos = 8;

    MT_START(mt_drp_orb_descriptors_activate[(uint8_t)image_position]);
    bool activate_succeed = activate(drp_fd, iodata, iodata_num);
    MT_FINISH(mt_drp_orb_descriptors_activate[(uint8_t)image_position]);

    if (!activate_succeed) {
        spdlog::error("Failed to activate in compute_orb_descriptors_setup.");
        return false;
    }
    return true;
}

bool compute_orb_descriptors_start(const int drp_fd, const image_position_t image_position, const cv::Mat& src, const std::vector<cv::KeyPoint>& src_keypoints, const size_t level) {
    bool succeed;

    assert(src.type() == CV_8UC1);
    assert(src.isContinuous());

    const uint32_t image_bytes = sizeof(uint8_t) * src.rows * src.cols;
    //const uint32_t input_image_address = DRP_ORB_DESCRIPTORS_INPUT_IMAGE_ADDRESS + image_data_stride[level];
    const uint32_t input_image_address = (uintptr_t)GaussianBlur_output_address[level];

    drp_data_t input_data;
    input_data.address = input_image_address;
    input_data.size = image_bytes;

    MT_START(mt_drp_orb_descriptors_u2p_input_image[(uint8_t)image_position][level]);
    succeed = memcpy_u2p(drp_fd, src.data, &input_data);
    MT_FINISH(mt_drp_orb_descriptors_u2p_input_image[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of input data in compute_orb_descriptors_start.");
        return false;
    }

    return compute_orb_descriptors_start(drp_fd, image_position, src.cols, src.rows, src_keypoints, level);
}

bool compute_orb_descriptors_start(const int drp_fd, const image_position_t image_position, const uint16_t cols, const uint16_t rows, const std::vector<cv::KeyPoint>& src_keypoints, const size_t level) {
    assert(0 < drp_fd);

    bool succeed;

    assert(MIN_WIDTH <= cols);
    assert(MIN_HEIGHT <= rows);
    assert(cols <= MAX_WIDTH);
    assert(rows <= MAX_HEIGHT);
    assert(level < 8);

    const uint16_t keypoints_size = src_keypoints.size();
    assert(keypoints_size <= MAX_NFEATURES);

    KeyPoint_ORB keypoints[MAX_NFEATURES];

    uint32_t parameter[6];

    //const uint32_t input_image_address = DRP_ORB_DESCRIPTORS_INPUT_IMAGE_ADDRESS + image_data_stride[level];
    const uint32_t input_image_address = (uintptr_t)GaussianBlur_output_address[level];

    MT_START(mt_drp_orb_descriptors_calc_param[(uint8_t)image_position][level]);
    parameter[0] = input_image_address;                         // consider r_addr_image
    //parameter[1] = DRP_ORB_DESCRIPTORS_INPUT_KEYPOINTS_ADDRESS; // consider r_addr_keypts
    parameter[1] = (uintptr_t)orb_descriptors_drp_param_buf->input_keypoint; // consider r_addr_keypts
    //parameter[2] = DRP_ORB_DESCRIPTORS_OUTPUT_ADDRESS;
    parameter[2] = (uintptr_t)orb_descriptors_drp_param_buf->output;
    parameter[3] = cols + (rows << 16);
    parameter[4] = keypoints_size;
    parameter[5] = 0;
    MT_FINISH(mt_drp_orb_descriptors_calc_param[(uint8_t)image_position][level]);

    MT_START(mt_drp_orb_descriptors_cast_to_drp[(uint8_t)image_position][level]);
    for (uint16_t i = 0; i < keypoints_size; i++) {
        keypoints[i].pt.x = src_keypoints[i].pt.x;
        keypoints[i].pt.y = src_keypoints[i].pt.y;
        // floating point to fixed point
        uint32_t fixed_angle = src_keypoints[i].angle * FIXED_POINT;
        keypoints[i].angle[0] = fixed_angle & 0xFF;
        keypoints[i].angle[1] = (fixed_angle >> 8) & 0xFF;
        keypoints[i].angle[2] = (fixed_angle >> 16) & 0xFF;
        keypoints[i].angle[3] = (fixed_angle >> 24) & 0xFF;
    }
    MT_FINISH(mt_drp_orb_descriptors_cast_to_drp[(uint8_t)image_position][level]);

    //proc[PROC_ORB_DESCRIPTORS_PARAM].address = DRP_PARAM_ADDRESS;
    proc[PROC_ORB_DESCRIPTORS_PARAM].address = drp_orb_descriptors_param_address;
    proc[PROC_ORB_DESCRIPTORS_PARAM].size = 6 * 4;

    MT_START(mt_drp_orb_descriptors_u2p_param[(uint8_t)image_position][level]);
    succeed = memcpy_u2p(drp_fd, parameter, &proc[PROC_ORB_DESCRIPTORS_PARAM]);
    MT_FINISH(mt_drp_orb_descriptors_u2p_param[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of parameter in compute_orb_descriptors_start.");
        return false;
    }

    drp_data_t input_data;
    //input_data.address = DRP_ORB_DESCRIPTORS_INPUT_KEYPOINTS_ADDRESS;
    input_data.address = (uintptr_t)orb_descriptors_drp_param_buf->input_keypoint;
    input_data.size = keypoints_size * 8;

    MT_START(mt_drp_orb_descriptors_u2p_input_keypoints[(uint8_t)image_position][level]);
    succeed = memcpy_u2p(drp_fd, keypoints, &input_data);
    MT_FINISH(mt_drp_orb_descriptors_u2p_input_keypoints[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_u2p of input data in compute_orb_descriptors_start.");
        return false;
    }

    proc[PROC_ORB_DESCRIPTORS_CONFIG].address = drp_orb_descriptors_config_address;
    proc[PROC_ORB_DESCRIPTORS_CONFIG].size = orb_descriptors_config_size;

    MT_START(mt_drp_orb_descriptors_start[(uint8_t)image_position][level]);
    bool start_succeed = start(drp_fd, &proc[PROC_ORB_DESCRIPTORS_CONFIG]);
    MT_FINISH(mt_drp_orb_descriptors_start[(uint8_t)image_position][level]);

    if (!start_succeed) {
        spdlog::error("Failed to start in compute_orb_descriptors_start.");
        return false;
    }

    MT_SUM_START(mt_drp_time[(uint8_t)image_position][drp_driver_native::STATE_ORB_DESCRIPTORS][level]);

    return true;
}

bool compute_orb_descriptors_finish(const int drp_fd, const image_position_t image_position, const std::vector<cv::KeyPoint>& src_keypoints, const size_t level, cv::Mat& dst) {
    bool succeed;

    assert(0 < drp_fd);

    assert(level < 8);

    bool finished = get_status(drp_fd);
    if (finished) {
        MT_SUM_FINISH(mt_drp_time[(uint8_t)image_position][drp_driver_native::STATE_ORB_DESCRIPTORS][level]);
    }

    if (!finished) {
        return false;
    }

    const uint16_t keypoints_size = src_keypoints.size();
    assert(keypoints_size <= MAX_NFEATURES);

    drp_data_t output_data;
    //output_data.address = DRP_ORB_DESCRIPTORS_OUTPUT_ADDRESS;
    output_data.address = (uintptr_t)orb_descriptors_drp_param_buf->output;
    output_data.size = keypoints_size * 32;

    MT_START(mt_drp_orb_descriptors_p2u[(uint8_t)image_position][level]);
    succeed = memcpy_p2u(drp_fd, dst.data, &output_data);
    MT_FINISH(mt_drp_orb_descriptors_p2u[(uint8_t)image_position][level]);

    if (!succeed) {
        spdlog::error("Failed to memcpy_p2u of input data in compute_orb_descriptors_finish.");
        return false;
    }

    return true;
}

bool compute_orb_descriptors(const int drp_fd, const image_position_t image_position, const cv::Mat& src, const std::vector<cv::KeyPoint>& src_keypoints, const size_t level, cv::Mat& dst) {
    /*
    src.type() == CV_8UC1
    src.isContinuous() == true
    dst.type() == CV_8UC1
    dst.isContinuous() == true
    */
    spdlog::trace("Start drp_driver_native::compute_orb_descriptors(level={})", level);

    bool setup_succeed = compute_orb_descriptors_setup(drp_fd, image_position, level);
    if (!setup_succeed) {
        spdlog::error("compute_orb_descriptors_setup error");
        activate_mode = STATE_NONE;
        return false;
    }
    activate_mode = STATE_ORB_DESCRIPTORS;

    bool start_succeed = compute_orb_descriptors_start(drp_fd, image_position, src, src_keypoints, level);
    if (!start_succeed) {
        spdlog::error("compute_orb_descriptors_start error");
        return false;
    }

    // busy wait
    const clock_t start = clock();
    while (true) {
        bool finish_succeed = compute_orb_descriptors_finish(drp_fd, image_position, src_keypoints, level, dst);
        if (finish_succeed) {
            break;
        }

        usleep(500); // Sleep 0.5ms
        clock_t now = clock();
        double sec = (double)(now - start) / CLOCKS_PER_SEC;
        if (WAITING_TIME < sec) {
            spdlog::critical("Failed to drp_driver_native::compute_orb_descriptors");
            exit(EXIT_FAILURE);
        }
    }

    spdlog::trace("Finish drp_driver_native::compute_orb_descriptors(level={})", level);

    return true;
}

} // namespace drp_driver_native
