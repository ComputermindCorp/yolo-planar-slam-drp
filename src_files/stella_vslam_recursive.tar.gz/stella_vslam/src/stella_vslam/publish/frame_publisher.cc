#include "stella_vslam/data/landmark.h"
#include "stella_vslam/data/map_database.h"
#include "stella_vslam/publish/frame_publisher.h"

#include <iomanip>

#include <spdlog/spdlog.h>
#include <opencv2/imgproc.hpp>
#include <tinycolormap.hpp>

#if defined(NDEBUG)

#undef NDEBUG
#include <cassert>
#define NDEBUG

#endif

namespace stella_vslam {
namespace publish {

frame_publisher::frame_publisher(const std::shared_ptr<config>& cfg, data::map_database* map_db,
                                 const unsigned int img_width)
    : cfg_(cfg), map_db_(map_db), img_width_(img_width),
      img_(cv::Mat(480, img_width_, CV_8UC3, cv::Scalar(0, 0, 0))) {
    spdlog::debug("CONSTRUCT: publish::frame_publisher");

    auto viewer_yaml_node = cfg_->yaml_node_["Viewer"];
    draw_tracking_time_ = viewer_yaml_node["draw_tracking_time"].as<bool>(false);
}

frame_publisher::~frame_publisher() {
    spdlog::debug("DESTRUCT: publish::frame_publisher");
}

cv::Mat frame_publisher::draw_frame() {
    cv::Mat img;
    tracker_state_t tracking_state;
    std::vector<cv::KeyPoint> curr_keypts;
    bool mapping_is_enabled;
    std::vector<std::shared_ptr<data::landmark>> curr_lms;
    double tracking_time_ms;
#if defined(ENABLE_DRP_AI_TVM)
    std::vector<drp_ai::bounding_box> bounding_box_list;
#endif

    // copy to avoid memory access conflict
    {
        std::lock_guard<std::mutex> lock(mtx_);

        img_.copyTo(img);

        tracking_state = tracking_state_;

        // copy tracking information
        curr_keypts = curr_keypts_;

        mapping_is_enabled = mapping_is_enabled_;

        curr_lms = curr_lms_;

        tracking_time_ms = tracking_time_ms_;

#if defined(ENABLE_DRP_AI_TVM)
        bounding_box_list = bounding_box_list_;
#endif
    }

    // resize image
    const float mag = (img_width_ < img_.cols) ? static_cast<float>(img_width_) / img.cols : 1.0;
    if (mag != 1.0) {
        cv::resize(img, img, cv::Size(), mag, mag, cv::INTER_NEAREST);
    }

    // to draw COLOR information
    if (img.channels() < 3) {
        cvtColor(img, img, cv::COLOR_GRAY2BGR);
    }

    // draw keypoints
    unsigned int num_tracked = 0;
    switch (tracking_state) {
        case tracker_state_t::Tracking: {
            num_tracked = draw_tracked_points(img, curr_keypts, curr_lms, mapping_is_enabled, mag);
            break;
        }
        default: {
            break;
        }
    }

#if defined(ENABLE_DRP_AI_TVM)
    draw_bounding_box(img, bounding_box_list);
#endif

    if (draw_tracking_time_) {
        cv::Mat dst;
        draw_tracking_time(img, tracking_time_ms, dst);
        img = dst;
    }

    spdlog::trace("num_tracked: {}", num_tracked);

    return img;
}

unsigned int frame_publisher::draw_tracked_points(cv::Mat& img, const std::vector<cv::KeyPoint>& curr_keypts,
                                                  const std::vector<std::shared_ptr<data::landmark>>& curr_lms,
                                                  const bool mapping_is_enabled,
                                                  const float mag) const {
    constexpr float radius = 5;

    unsigned int num_tracked = 0;

    for (unsigned int i = 0; i < curr_keypts.size(); ++i) {
        const auto& lm = curr_lms.at(i);
        if (!lm) {
            continue;
        }
        if (lm->will_be_erased()) {
            continue;
        }

        const cv::Point2f pt_begin{curr_keypts.at(i).pt.x * mag - radius, curr_keypts.at(i).pt.y * mag - radius};
        const cv::Point2f pt_end{curr_keypts.at(i).pt.x * mag + radius, curr_keypts.at(i).pt.y * mag + radius};

        double score = lm->get_observed_ratio();
        const tinycolormap::Color color = tinycolormap::GetColor(score, tinycolormap::ColormapType::Turbo);
        if (mapping_is_enabled) {
            const cv::Scalar mapping_color{color.b() * 255, color.g() * 255, color.r() * 255};
            cv::circle(img, curr_keypts.at(i).pt * mag, 2, mapping_color, -1);
        }
        else {
            cv::circle(img, curr_keypts.at(i).pt * mag, 2, localization_color_, -1);
        }

        ++num_tracked;
    }

    return num_tracked;
}

#if defined(ENABLE_DRP_AI_TVM)

std::map<const std::string, const cv::Scalar> label_to_color = {
    {"background", cv::Scalar(0, 0, 0)},
    {"aeroplane", cv::Scalar(255, 0, 0)},
    {"bicycle", cv::Scalar(255, 76, 0)},
    {"bird", cv::Scalar(255, 153, 0)},
    {"boat", cv::Scalar(255, 229, 0)},
    {"bottle", cv::Scalar(204, 255, 0)},
    {"bus", cv::Scalar(127, 255, 0)},
    {"car", cv::Scalar(50, 255, 0)},
    {"cat", cv::Scalar(0, 255, 25)},
    {"chair", cv::Scalar(0, 255, 101)},
    {"cow", cv::Scalar(0, 255, 178)},
    {"diningtable", cv::Scalar(0, 255, 255)},
    {"dog", cv::Scalar(0, 178, 255)},
    {"horse", cv::Scalar(0, 101, 255)},
    {"motorbike", cv::Scalar(0, 25, 255)},
    {"person", cv::Scalar(51, 178, 255)},
    {"pottedplant", cv::Scalar(127, 0, 255)},
    {"sheep", cv::Scalar(203, 0, 255)},
    {"sofa", cv::Scalar(255, 0, 229)},
    {"train", cv::Scalar(255, 0, 152)},
    {"tvmonitor", cv::Scalar(255, 0, 76)}};

void frame_publisher::draw_bounding_box(cv::Mat& img, const std::vector<drp_ai::bounding_box> bounding_box_list) const {
    for (size_t i = 0; i < bounding_box_list.size(); i++) {
        std::string label = bounding_box_list[i].label;
        float confidence = bounding_box_list[i].confidence;

        cv::Point2i tl(bounding_box_list[i].left_x, bounding_box_list[i].top_y);
        cv::Point2i br(bounding_box_list[i].right_x, bounding_box_list[i].bottom_y);
        const int32_t left_x = bounding_box_list[i].left_x;
        const int32_t top_y = bounding_box_list[i].top_y;

        char text[30];
        sprintf(text, "%s %4.2f", label.c_str(), confidence);

        assert(0 < label_to_color.count(label));

        constexpr int thickness = 2;
        const cv::Scalar color = label_to_color[label];
        cv::rectangle(img, tl, br, color, thickness);
        cv::rectangle(img, cv::Point(left_x, top_y - 20), cv::Point(left_x + 150, top_y), color, -1);
        cv::putText(img, text, tl, cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 0, 0), thickness);
    }
}

#endif

void frame_publisher::draw_tracking_time(const cv::Mat& src, const double time_ms, cv::Mat& dst) const {
    const double font_scale = 2.0;
    const int thickness = 2;
    int baseline = 0;

    std::ostringstream oss;
    oss << std::fixed << std::setprecision(1) << time_ms;
    const std::string text = "tracking time : " + oss.str() + "[msec]";
    const cv::Size text_size = cv::getTextSize(text, cv::FONT_HERSHEY_PLAIN, font_scale, thickness, &baseline);

    dst = cv::Mat(src.rows + text_size.height + 10, src.cols, src.type());
    src.copyTo(dst.rowRange(0, src.rows).colRange(0, src.cols));
    dst.rowRange(src.rows, dst.rows) = cv::Mat::zeros(text_size.height + 10, src.cols, src.type());
    cv::putText(dst, text, cv::Point(5, dst.rows - 5), cv::FONT_HERSHEY_PLAIN, font_scale, cv::Scalar(255, 255, 255), thickness, 8);
}

void frame_publisher::update(const std::vector<std::shared_ptr<data::landmark>>& curr_lms,
                             bool mapping_is_enabled,
                             tracker_state_t tracking_state,
                             std::vector<cv::KeyPoint>& keypts,
                             const cv::Mat& img,
                             const double tracking_time_ms,
#if defined(ENABLE_DRP_AI_TVM)
                             const std::vector<drp_ai::bounding_box>& bounding_box_list,
#endif
                             double elapsed_ms) {
    std::lock_guard<std::mutex> lock(mtx_);

    img.copyTo(img_);

    curr_keypts_ = keypts;
    elapsed_ms_ = elapsed_ms;
    mapping_is_enabled_ = mapping_is_enabled;
    tracking_state_ = tracking_state;
    curr_lms_ = curr_lms;
    tracking_time_ms_ = tracking_time_ms;

#if defined(ENABLE_DRP_AI_TVM)
    bounding_box_list_ = bounding_box_list;
#endif
}

} // namespace publish
} // namespace stella_vslam
