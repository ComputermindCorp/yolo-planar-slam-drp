#!/bin/bash

(
    set -ex

    export YOCTO_DIR=(/yocto_rzv2x_*_workdir)

    install -m 0755 \
    ${TVM_HOME}/build_runtime/libtvm_runtime.so \
    ${YOCTO_DIR}/bsp_sdk/sysroots/aarch64-poky-linux/usr/lib64/

    export DEST_DIR=${YOCTO_DIR}/bsp_sdk/sysroots/aarch64-poky-linux/usr/include/drp-ai_tvm
    export TVM_HOME_SED=`echo ${TVM_HOME} | sed 's/\//\\\\\//g'`
    export DEST_DIR_SED=`echo ${DEST_DIR} | sed 's/\//\\\\\//g'`
    find \
      ${TVM_HOME}/include \
      ${TVM_HOME}/3rdparty/dlpack/include \
      ${TVM_HOME}/3rdparty/dmlc-core/include \
      ${TVM_HOME}/3rdparty/compiler-rt \
      -type d | \
    sed "s/${TVM_HOME_SED}/${DEST_DIR_SED}/g" | \
    xargs install -d

    mkdir -p /tmp/drp-ai_tvm
    find \
      ${TVM_HOME}/include \
      ${TVM_HOME}/3rdparty/dlpack/include \
      ${TVM_HOME}/3rdparty/dmlc-core/include \
      ${TVM_HOME}/3rdparty/compiler-rt \
      -type f > /tmp/drp-ai_tvm/file.txt

    cat /tmp/drp-ai_tvm/file.txt | xargs -I{} dirname {} > /tmp/drp-ai_tvm/directory.txt
    sed -i "s/${TVM_HOME_SED}/${DEST_DIR_SED}/g" /tmp/drp-ai_tvm/directory.txt
    paste /tmp/drp-ai_tvm/file.txt /tmp/drp-ai_tvm/directory.txt > /tmp/drp-ai_tvm/install.txt

    while read line
    do
      arr=(${line})
      file=${arr[0]}
      dst=${arr[1]}
      install -m 0644 ${file} ${dst}
    done < /tmp/drp-ai_tvm/install.txt
)
