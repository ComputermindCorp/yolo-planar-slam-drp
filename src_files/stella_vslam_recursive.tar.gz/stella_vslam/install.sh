#!/bin/bash

(
    set -ex

    cd build
    make install
    cd ..
)
