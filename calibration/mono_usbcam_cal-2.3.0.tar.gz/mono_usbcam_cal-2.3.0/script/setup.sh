#!/bin/bash -u

export NOETIC_DOCKER_IMAGE_VERSION=2.3.0

export PATH=$WORK/mono_usbcam_cal-${NOETIC_DOCKER_IMAGE_VERSION}/script:$PATH
export PATH=$WORK/mono_usbcam_cal-${NOETIC_DOCKER_IMAGE_VERSION}/script/docker:$PATH
export PATH=$WORK/mono_usbcam_cal-${NOETIC_DOCKER_IMAGE_VERSION}/script/drp:$PATH

echo NOETIC_DOCKER_IMAGE_VERSION=$NOETIC_DOCKER_IMAGE_VERSION
