#!/bin/bash -u

trap 'exit 1' SIGINT

(
  set -ex

  mkdir -p $HOME/drp_cv_lib/output

  XSOCK=/tmp/.X11-unix
  XAUTH=/tmp/.docker.xauth
  touch $XAUTH
  xauth nlist $DISPLAY | sed -e 's/^..../ffff/' | xauth -f $XAUTH nmerge -

  docker run -it --rm --privileged \
    --device /dev:/dev:rwm \
    --env "XAUTHORITY=${XAUTH}" \
    --env "DISPLAY=${DISPLAY}" \
    --env TERM=xterm-256color \
    --env QT_X11_NO_MITSHM=1 \
    --volume $XSOCK:$XSOCK:rw \
    --volume $XAUTH:$XAUTH:rw \
    --volume /opt/dataset:/home/rns/dataset \
    --volume $WORK/mono_usbcam_cal-${NOETIC_DOCKER_IMAGE_VERSION}/output:/home/rns/output \
    --net host \
    --name noetic \
    rns/ros-noetic:${NOETIC_DOCKER_IMAGE_VERSION} \
    bash
)
