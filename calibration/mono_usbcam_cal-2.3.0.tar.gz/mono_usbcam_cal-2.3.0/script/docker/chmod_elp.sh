#!/bin/bash -u

trap 'exit 1' SIGINT

(
  set -ex

  BUS_NUMBER=`lsusb | grep '32e4:0144' | sed -e 's/Bus \([0-9]\{3\}\).*$/\1/'`
  DEVICE_NUMBER=`lsusb | grep '32e4:0144' | sed -e 's/.*Device \([0-9]\{3\}\).*$/\1/'`

  chmod 666 /dev/bus/usb/${BUS_NUMBER}/${DEVICE_NUMBER}
)
