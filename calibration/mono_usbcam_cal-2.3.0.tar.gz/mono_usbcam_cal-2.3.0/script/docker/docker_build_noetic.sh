#!/bin/bash -u

trap 'exit 1' SIGINT

docker build \
  --build-arg USER_NAME=rns \
  --build-arg USER_ID=$(id -u) \
  --build-arg GROUP_ID=$(id -g) \
  --build-arg NOETIC_DOCKER_IMAGE_VERSION=${NOETIC_DOCKER_IMAGE_VERSION} \
  -t rns/ros-noetic:${NOETIC_DOCKER_IMAGE_VERSION} \
  -f Dockerfile.noetic \
  .
